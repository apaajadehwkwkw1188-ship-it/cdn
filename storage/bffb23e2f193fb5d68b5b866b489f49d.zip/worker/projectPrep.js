const os = require('os');
const path = require('path');
const fs = require('fs-extra');
const axios = require('axios');
const sharp = require('sharp');
const config = require('../config');
const NATIVE_URL_TEMPLATE_DIR = path.resolve(__dirname, '..', 'assets', 'android-native-template-safe');

function sh(value) {
  return "'" + String(value).replace(/'/g, "'\"'\"'") + "'";
}

function sanitizeFileName(fileName) {
  const fallback = 'source.zip';
  return String(fileName || fallback).replace(/[^a-zA-Z0-9._-]/g, '_') || fallback;
}

function sanitizeProjectName(input) {
  let value = String(input || 'web2apk_app')
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '');

  if (!value) value = 'web2apk_app';
  if (!/^[a-z]/.test(value)) value = `app_${value}`;
  if (value.length < 3) value = `${value}_app`;
  return value.slice(0, 30);
}

function escapeDart(value) {
  return String(value || '')
    .replace(/\r?\n/g, ' ')
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'");
}

function escapeXml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function formatExecError(result, fallbackMessage) {
  const details = [result?.stderr, result?.stdout].filter(Boolean).join('\n').trim();
  if (!details) return fallbackMessage;
  return `${fallbackMessage}: ${details}`;
}

async function downloadToFile(url, destinationPath) {
  await fs.ensureDir(path.dirname(destinationPath));
  const response = await axios({
    method: 'get',
    url,
    responseType: 'stream',
    timeout: 120000
  });

  await new Promise((resolve, reject) => {
    const writeStream = fs.createWriteStream(destinationPath);
    response.data.pipe(writeStream);
    response.data.on('error', reject);
    writeStream.on('error', reject);
    writeStream.on('finish', resolve);
  });
}

async function getTelegramFileUrls(fileId) {
  if (!fileId) throw new Error('fileId Telegram tidak ditemukan pada job');
  const urls = [];
  const token = config?.telegram?.botToken;
  let publicApiError = null;

  // Prioritaskan Public API Telegram karena paling stabil untuk download file.
  if (token) {
    try {
      const response = await axios.get(`https://api.telegram.org/bot${token}/getFile`, {
        params: { file_id: fileId },
        timeout: 30000
      });

      const filePath = response?.data?.result?.file_path;
      if (response?.data?.ok && filePath) {
        urls.push(`https://api.telegram.org/file/bot${token}/${filePath}`);
      }
    } catch (error) {
      publicApiError = error;
    }
  }

  // Untuk Local Bot API, file_path adalah path absolut di filesystem.
  // Jangan generate HTTP URL karena akan salah (ada double slash).
  // Sebagai gantinya, worker akan copy file langsung dari filesystem lokal.
  // Skip adding Local Bot API HTTP URLs karena tidak reliable.

  const unique = [...new Set(urls.filter(Boolean))];
  if (unique.length === 0) {
    if (publicApiError) {
      throw new Error(`Gagal mendapatkan URL file Telegram: ${publicApiError.message}`);
    }
    throw new Error('Gagal mendapatkan URL download file dari Telegram Public API. Pastikan bot dapat mengakses api.telegram.org');
  }

  return unique;
}

function maskTelegramToken(url) {
  return String(url || '').replace(/bot\d+:[^/]+/g, 'bot<token>');
}

async function downloadFromAny(urls, destinationPath) {
  let lastError = null;
  const failures = [];
  for (const url of urls) {
    try {
      await downloadToFile(url, destinationPath);
      return;
    } catch (error) {
      lastError = error;
      const status = error?.response?.status;
      const reason = status ? `HTTP ${status}` : (error?.message || 'Unknown error');
      failures.push(`${maskTelegramToken(url)} -> ${reason}`);
    }
  }
  if (failures.length > 0) {
    throw new Error(`Semua URL download Telegram gagal: ${failures.join(' | ')}`);
  }
  throw lastError || new Error('Semua URL download Telegram gagal diakses');
}

async function resolveFlutterCommand(ssh, worker) {
  const preferred = typeof worker.flutterBin === 'string' ? worker.flutterBin.trim() : '';
  const script = `
set -e
preferred=${sh(preferred)}
if [ -n "$preferred" ] && [ -x "$preferred" ]; then
  echo "$preferred"
  exit 0
fi
if command -v flutter >/dev/null 2>&1; then
  command -v flutter
  exit 0
fi
if [ -x /opt/flutter/bin/flutter ]; then
  echo /opt/flutter/bin/flutter
  exit 0
fi
if [ -x /root/flutter/bin/flutter ]; then
  echo /root/flutter/bin/flutter
  exit 0
fi
exit 1
  `.trim();

  const result = await ssh.execCommand(`bash -lc ${sh(script)}`);
  if (result.code !== 0) return null;

  const value = String(result.stdout || '')
    .split('\n')
    .map(line => line.trim())
    .filter(Boolean)
    .pop();

  return value || null;
}

async function ensureBuildDir(ssh, buildDir) {
  const result = await ssh.execCommand(`mkdir -p ${sh(buildDir)}`);
  if (result.code !== 0) {
    throw new Error(formatExecError(result, `Gagal membuat build directory ${buildDir}`));
  }
}

function parseProjectDetection(stdout = '') {
  const typeMatch = stdout.match(/PROJECT_TYPE=(.+)/);
  const rootMatch = stdout.match(/PROJECT_ROOT=(.+)/);
  return {
    projectType: typeMatch ? typeMatch[1].trim() : 'unknown',
    projectPath: rootMatch ? rootMatch[1].trim() : null
  };
}

function parseJsonSafe(text) {
  try {
    return JSON.parse(String(text || '').trim());
  } catch (_) {
    return null;
  }
}

/**
 * TIER 1: Try getFile + copy from Local API storage on the worker itself
 */
async function tryGetFileOnWorker(ssh, worker, fileId, remoteZipPath) {
  const botToken = String(config?.telegram?.botToken || '').trim();
  if (!botToken) return { success: false, error: 'Bot token tidak tersedia' };

  const apiPort = Number(worker?.apiPort) > 0 ? Number(worker.apiPort) : 8081;

  const getFileScript = `
set -e
API_PORT=${sh(String(apiPort))}
BOT_TOKEN=${sh(botToken)}
FILE_ID=${sh(fileId)}
RESULT=$(curl -sS --get --data-urlencode "file_id=$FILE_ID" "http://127.0.0.1:$API_PORT/bot$BOT_TOKEN/getFile" 2>&1) || {
  echo "GETFILE_FAILED: $RESULT"
  exit 1
}
echo "$RESULT"
  `.trim();

  const getFileResult = await ssh.execCommand(`bash -lc ${sh(getFileScript)}`);
  if (getFileResult.code !== 0) {
    return { success: false, error: formatExecError(getFileResult, 'getFile gagal') };
  }

  const payload = parseJsonSafe(getFileResult.stdout);
  if (!payload?.ok || !payload?.result?.file_path) {
    return { success: false, error: `Respons getFile tidak valid: ${String(getFileResult.stdout || '').slice(0, 200)}` };
  }

  const workerFilePath = String(payload.result.file_path);

  // Copy from Local API storage with multiple path fallbacks
  const copyScript = `
set -e
FILE_PATH=${sh(workerFilePath)}
DEST=${sh(remoteZipPath)}

copy_if_exists() {
  if [ -f "$1" ]; then
    cp "$1" "$DEST"
    echo "OK: $1"
    return 0
  fi
  return 1
}

copy_if_exists "$FILE_PATH" && exit 0
copy_if_exists "/$FILE_PATH" && exit 0
copy_if_exists "/var/lib/telegram-bot-api/$FILE_PATH" && exit 0
copy_if_exists "/opt/telegram-bot-api/$FILE_PATH" && exit 0
copy_if_exists "/home/container/$FILE_PATH" && exit 0

echo "FILE_NOT_FOUND"
exit 1
  `.trim();

  const copyResult = await ssh.execCommand(`bash -lc ${sh(copyScript)}`);
  if (copyResult.code !== 0) {
    return { success: false, error: `File tidak ditemukan di storage: ${workerFilePath}` };
  }

  // Cleanup cache
  ssh.execCommand(`rm -f ${sh(workerFilePath)} 2>/dev/null || true`).catch(() => {});

  return { success: true, method: 'getFile+copy' };
}

/**
 * TIER 2: Direct HTTP download on worker via its own Local Bot API
 * Each worker downloads through its OWN Local API independently
 */
async function tryHttpDownloadOnWorker(ssh, worker, fileId, remoteZipPath) {
  const botToken = String(config?.telegram?.botToken || '').trim();
  if (!botToken) return { success: false, error: 'Bot token tidak tersedia' };

  const apiPort = Number(worker?.apiPort) > 0 ? Number(worker.apiPort) : 8081;

  // Step 1: getFile to get file_path, then download via HTTP on the worker itself
  const downloadScript = `
set -e
API_PORT=${sh(String(apiPort))}
BOT_TOKEN=${sh(botToken)}
FILE_ID=${sh(fileId)}
DEST=${sh(remoteZipPath)}

# Get file path from Local API
RESPONSE=$(curl -sS --get --data-urlencode "file_id=$FILE_ID" "http://127.0.0.1:$API_PORT/bot$BOT_TOKEN/getFile" 2>&1)

# Extract file_path from JSON (simple grep, no jq needed)
FILE_PATH=$(echo "$RESPONSE" | grep -oP '"file_path":"\\K[^"]+' || echo "")

if [ -z "$FILE_PATH" ]; then
  echo "GETFILE_NO_PATH"
  # Try direct download without getFile (some Local API setups)
  # Try to download using sendDocument trick - skip
  exit 1
fi

# Try copy from filesystem first
if [ -f "$FILE_PATH" ]; then
  cp "$FILE_PATH" "$DEST"
  echo "OK: copied $FILE_PATH"
  rm -f "$FILE_PATH" 2>/dev/null || true
  exit 0
fi

# Fallback: download via HTTP from Local API
NORMALIZED="$FILE_PATH"
# Remove any absolute prefix
case "$NORMALIZED" in
  /var/lib/telegram-bot-api/*)
    NORMALIZED=$(echo "$NORMALIZED" | sed "s|^/var/lib/telegram-bot-api/[^/]*/||")
    ;;
  /*)
    NORMALIZED=$(echo "$NORMALIZED" | sed "s|^/||")
    ;;
esac

curl -fsS "http://127.0.0.1:$API_PORT/file/bot$BOT_TOKEN/$NORMALIZED" -o "$DEST" && {
  echo "OK: http download $NORMALIZED"
  rm -f "$FILE_PATH" 2>/dev/null || true
  exit 0
}

# Try with original path
curl -fsS "http://127.0.0.1:$API_PORT/file/bot$BOT_TOKEN/$FILE_PATH" -o "$DEST" && {
  echo "OK: http download $FILE_PATH"
  rm -f "$FILE_PATH" 2>/dev/null || true
  exit 0
}

echo "ALL_HTTP_FAILED"
exit 1
  `.trim();

  const result = await ssh.execCommand(`bash -lc ${sh(downloadScript)}`);
  if (result.code !== 0) {
    return { success: false, error: formatExecError(result, 'HTTP download via worker Local API gagal') };
  }

  return { success: true, method: 'worker-http' };
}

/**
 * TIER 3: Download from worker's Local API URL via bot server (external HTTP)
 * Bot server connects to worker's external Local API URL to download
 */
async function tryDownloadFromWorkerApi(worker, fileId, localZipPath) {
  const botToken = String(config?.telegram?.botToken || '').trim();
  if (!botToken) return { success: false, error: 'Bot token tidak tersedia' };

  // Build the worker's external Local API URL
  const workerLocalApiUrl = worker.localApiUrl || (worker.host ? `http://${worker.host}:${Number(worker.apiPort) > 0 ? worker.apiPort : 8081}` : null);
  if (!workerLocalApiUrl) {
    return { success: false, error: 'Worker tidak punya Local API URL' };
  }

  try {
    // Step 1: getFile from worker's Local API
    const getFileUrl = `${workerLocalApiUrl}/bot${botToken}/getFile`;
    console.log(`[Download] Trying getFile from worker API: ${workerLocalApiUrl}`);
    
    const getFileResp = await axios.get(getFileUrl, {
      params: { file_id: fileId },
      timeout: 30000
    });

    if (!getFileResp.data?.ok || !getFileResp.data?.result?.file_path) {
      return { success: false, error: 'getFile dari worker API gagal' };
    }

    const filePath = getFileResp.data.result.file_path;

    // Step 2: Download file content from worker's Local API
    // Normalize the file path for the download URL
    let downloadPath = filePath;
    if (downloadPath.startsWith('/')) {
      // For absolute paths, try to extract relative part
      const match = downloadPath.match(/\/var\/lib\/telegram-bot-api\/[^/]+\/(.+)/);
      if (match) downloadPath = match[1];
      else downloadPath = downloadPath.replace(/^\/+/, '');
    }

    const downloadUrl = `${workerLocalApiUrl}/file/bot${botToken}/${downloadPath}`;
    console.log(`[Download] Downloading from worker API: ${downloadUrl}`);
    
    await downloadToFile(downloadUrl, localZipPath);
    return { success: true, method: 'worker-external-api' };
  } catch (err) {
    return { success: false, error: `Worker external API gagal: ${err.message}` };
  }
}

async function detectExtractedProject(ssh, projectPath) {
  const script = `
set -e
PROJECT_PATH=${sh(projectPath)}

detect_flutter="$(find "$PROJECT_PATH" -maxdepth 5 -type f -name pubspec.yaml | head -n 1 || true)"
if [ -n "$detect_flutter" ]; then
  echo "PROJECT_TYPE=flutter"
  echo "PROJECT_ROOT=$(dirname "$detect_flutter")"
  exit 0
fi

detect_android_gradlew="$(find "$PROJECT_PATH" -maxdepth 5 -type f -name gradlew | head -n 1 || true)"
if [ -n "$detect_android_gradlew" ]; then
  echo "PROJECT_TYPE=android"
  echo "PROJECT_ROOT=$(dirname "$detect_android_gradlew")"
  exit 0
fi

detect_android_build="$(find "$PROJECT_PATH" -maxdepth 6 -type f -path "*/app/build.gradle" | head -n 1 || true)"
if [ -n "$detect_android_build" ]; then
  echo "PROJECT_TYPE=android"
  echo "PROJECT_ROOT=$(dirname "$(dirname "$detect_android_build")")"
  exit 0
fi

echo "PROJECT_TYPE=unknown"
echo "PROJECT_ROOT=$PROJECT_PATH"
  `.trim();

  const result = await ssh.execCommand(`bash -lc ${sh(script)}`);
  if (result.code !== 0) {
    return {
      success: false,
      error: formatExecError(result, 'Gagal mendeteksi tipe project setelah ekstrak ZIP')
    };
  }

  const parsed = parseProjectDetection(result.stdout);
  return {
    success: true,
    projectType: parsed.projectType,
    projectPath: parsed.projectPath || projectPath
  };
}

async function prepareZipProject(ssh, worker, job, buildDir, projectPath, onProgress) {
  const localJobDir = path.join(os.tmpdir(), 'web2apk-v2-jobs', job.jobId);
  const localZipName = sanitizeFileName(job.fileName || `${job.jobId}.zip`);
  const localZipPath = path.join(localJobDir, localZipName);
  const remoteZipPath = `/tmp/${job.jobId}.zip`;

  try {
    await ensureBuildDir(ssh, buildDir);

    const resetResult = await ssh.execCommand(`bash -lc ${sh(`
set -e
rm -rf ${sh(projectPath)}
mkdir -p ${sh(projectPath)}
rm -f ${sh(remoteZipPath)}
    `.trim())}`);

    if (resetResult.code !== 0) {
      return {
        success: false,
        error: formatExecError(resetResult, 'Gagal menyiapkan folder project di VPS')
      };
    }

    await onProgress(17, 'Downloading ZIP source...');
    const workerLabel = worker.label || worker.alias || worker.id;
    
    let downloaded = false;

    // === TIER 0: Use pre-downloaded file (fastest, no Telegram API needed) ===
    if (!downloaded && job.localFilePath) {
      const localStat = await fs.stat(job.localFilePath).catch(() => null);
      if (localStat && localStat.size > 0) {
        console.log(`[${job.jobId}] TIER 0: Uploading pre-downloaded ZIP (${localStat.size} bytes) to ${workerLabel}`);
        await onProgress(18, 'Uploading ZIP to worker...');
        
        // Try upload with retry
        let uploadSuccess = false;
        for (let attempt = 1; attempt <= 2; attempt++) {
          try {
            await ssh.putFile(job.localFilePath, remoteZipPath);
            
            // Verify upload succeeded by checking remote file size
            const verifyUpload = await ssh.execCommand(`stat -c%s ${sh(remoteZipPath)} 2>/dev/null || stat -f%z ${sh(remoteZipPath)} 2>/dev/null`);
            if (verifyUpload.code === 0) {
              const remoteSize = parseInt(verifyUpload.stdout.trim(), 10);
              if (remoteSize === localStat.size) {
                console.log(`[${job.jobId}] ✅ TIER 0: ZIP uploaded successfully (${remoteSize} bytes)`);
                downloaded = true;
                uploadSuccess = true;
                break;
              } else {
                console.warn(`[${job.jobId}] TIER 0 attempt ${attempt}: Size mismatch local=${localStat.size}, remote=${remoteSize}`);
              }
            }
          } catch (uploadErr) {
            console.warn(`[${job.jobId}] TIER 0 attempt ${attempt} failed: ${uploadErr.message}`);
          }
          
          if (attempt < 2) {
            await new Promise(r => setTimeout(r, 1000)); // Wait 1s before retry
          }
        }
        
        if (!uploadSuccess) {
          console.warn(`[${job.jobId}] TIER 0: All upload attempts failed, will try other tiers`);
          // Don't fail here - let other tiers try
        }
        
        // Cleanup pre-downloaded file (async, don't wait)
        fs.remove(job.localFilePath).catch(() => {});
      } else {
        console.warn(`[${job.jobId}] TIER 0: Pre-downloaded file not found or empty: ${job.localFilePath}`);
      }
    }

    // === TIER 1: getFile + copy from Local API storage on worker ===
    if (!downloaded) {
      const tier1 = await tryGetFileOnWorker(ssh, worker, job.fileId, remoteZipPath);
      if (tier1.success) {
        console.log(`[${job.jobId}] ✅ TIER 1: ZIP downloaded on ${workerLabel} via ${tier1.method}`);
        await onProgress(18, 'ZIP source ready on worker...');
        downloaded = true;
      } else {
        console.warn(`[${job.jobId}] TIER 1 failed (${workerLabel}): ${tier1.error}`);
      }
    }

    // === TIER 2: HTTP download directly on worker via Local API ===
    if (!downloaded) {
      const tier2 = await tryHttpDownloadOnWorker(ssh, worker, job.fileId, remoteZipPath);
      if (tier2.success) {
        console.log(`[${job.jobId}] ✅ TIER 2: ZIP downloaded on ${workerLabel} via ${tier2.method}`);
        await onProgress(18, 'ZIP source ready on worker...');
        downloaded = true;
      } else {
        console.warn(`[${job.jobId}] TIER 2 failed (${workerLabel}): ${tier2.error}`);
      }
    }

    // === TIER 3: Download from worker's Local API to bot server → upload via SSH ===
    if (!downloaded) {
      const tier3 = await tryDownloadFromWorkerApi(worker, job.fileId, localZipPath);
      if (tier3.success) {
        console.log(`[${job.jobId}] ✅ TIER 3: ZIP downloaded from ${workerLabel}'s API to bot server`);
        await onProgress(18, 'Uploading ZIP to worker...');
        await ssh.putFile(localZipPath, remoteZipPath);
        downloaded = true;
        // Cleanup local ZIP after successful upload (async, don't wait)
        fs.remove(localZipPath).catch(() => {});
      } else {
        console.warn(`[${job.jobId}] TIER 3 failed (${workerLabel}): ${tier3.error}`);
      }
    }

    // === TIER 4: Download via global.bot (bot's API connection) → upload via SSH ===
    if (!downloaded && global.bot && typeof global.bot.downloadFile === 'function') {
      try {
        console.log(`[${job.jobId}] TIER 4: Trying bot.downloadFile (${global.isLocalApiActive ? 'Local' : 'Public'} API)...`);
        await fs.ensureDir(localJobDir);
        const downloadedPath = await global.bot.downloadFile(job.fileId, localJobDir);
        if (downloadedPath && await fs.pathExists(downloadedPath)) {
          await fs.move(downloadedPath, localZipPath, { overwrite: true });
          console.log(`[${job.jobId}] ✅ TIER 4: ZIP downloaded via bot API`);
          await onProgress(18, 'Uploading ZIP to worker...');
          await ssh.putFile(localZipPath, remoteZipPath);
          downloaded = true;
          // Cleanup local ZIP after successful upload (async, don't wait)
          fs.remove(localZipPath).catch(() => {});
        }
      } catch (botErr) {
        console.warn(`[${job.jobId}] TIER 4 failed: ${botErr.message}`);
      }
    }

    // === TIER 5: Public Telegram API last resort (works for files ≤ 20MB) ===
    if (!downloaded) {
      try {
        console.log(`[${job.jobId}] TIER 5: Fallback to public Telegram API...`);
        const zipUrls = await getTelegramFileUrls(job.fileId);
        await fs.ensureDir(localJobDir);
        await downloadFromAny(zipUrls, localZipPath);
        console.log(`[${job.jobId}] ✅ TIER 5: ZIP downloaded via public API`);
        await onProgress(18, 'Uploading ZIP to worker...');
        await ssh.putFile(localZipPath, remoteZipPath);
        downloaded = true;
        // Cleanup local ZIP after successful upload (async, don't wait)
        fs.remove(localZipPath).catch(() => {});
      } catch (publicErr) {
        console.error(`[${job.jobId}] TIER 5 failed: ${publicErr.message}`);
      }
    }

    if (!downloaded) {
      return {
        success: false,
        error: 'Gagal download ZIP dari semua metode (Local API worker, Bot API, Public API). Pastikan Local Bot API di VPS berjalan dengan benar.'
      };
    }

    // Verify uploaded file size matches local file (corruption check)
    await onProgress(18, 'Verifying ZIP integrity...');
    const verifyResult = await ssh.execCommand(`bash -lc ${sh(`
set -e
# Check file exists and has content
if [ ! -f ${sh(remoteZipPath)} ]; then
  echo "FILE_NOT_FOUND"
  exit 1
fi

SIZE=$(stat -c%s ${sh(remoteZipPath)} 2>/dev/null || stat -f%z ${sh(remoteZipPath)} 2>/dev/null)
if [ -z "$SIZE" ] || [ "$SIZE" -eq 0 ]; then
  echo "FILE_EMPTY"
  exit 1
fi

# Verify ZIP integrity (check magic number and central directory)
if ! unzip -t ${sh(remoteZipPath)} >/dev/null 2>&1; then
  echo "ZIP_INVALID"
  exit 1
fi

echo "OK: $SIZE bytes"
exit 0
    `.trim())}`);

    if (verifyResult.code !== 0) {
      const errorType = verifyResult.stdout?.trim();
      let errorMsg = 'ZIP file corrupt atau upload gagal';
      if (errorType === 'FILE_NOT_FOUND') errorMsg = 'File ZIP tidak ditemukan di worker setelah upload';
      if (errorType === 'FILE_EMPTY') errorMsg = 'File ZIP kosong (0 bytes)';
      if (errorType === 'ZIP_INVALID') errorMsg = 'File ZIP corrupt atau bukan file ZIP valid';
      return {
        success: false,
        error: `${errorMsg}. Silakan coba upload ulang file ZIP.`
      };
    }

    const sizeMatch = verifyResult.stdout?.match(/(\d+) bytes/);
    if (sizeMatch) {
      const remoteSize = parseInt(sizeMatch[1], 10);
      const localSize = job.localFilePath ? (await fs.stat(job.localFilePath).catch(() => ({ size: 0 }))).size : 0;
      if (localSize > 0 && remoteSize !== localSize) {
        console.warn(`[${job.jobId}] ⚠️ Size mismatch: local=${localSize}, remote=${remoteSize}`);
      }
    }

    await onProgress(19, 'Extracting ZIP on worker...');
    const unzipResult = await ssh.execCommand(`bash -lc ${sh(`
set -e
unzip -oq ${sh(remoteZipPath)} -d ${sh(projectPath)}
rm -f ${sh(remoteZipPath)}
    `.trim())}`);

    if (unzipResult.code !== 0) {
      return {
        success: false,
        error: formatExecError(unzipResult, 'Gagal ekstrak ZIP di VPS')
      };
    }

    const detected = await detectExtractedProject(ssh, projectPath);
    if (!detected.success) return detected;

    if (detected.projectType === 'unknown') {
      return {
        success: false,
        error: 'ZIP tidak berisi project Flutter/Android yang valid (pubspec.yaml/gradlew tidak ditemukan)'
      };
    }

    let flutterCmd = null;
    if (detected.projectType === 'flutter') {
      flutterCmd = await resolveFlutterCommand(ssh, worker);
      if (!flutterCmd) {
        return {
          success: false,
          error: 'Flutter tidak ditemukan di VPS. Jalankan /installvps ulang atau set worker.flutterBin.'
        };
      }
      
      // Auto-fix build.gradle to use compileSdk 36
      await onProgress(20, 'Auto-fixing build configuration...');
      await autoFixBuildGradle(ssh, detected.projectPath);
    }

    return {
      success: true,
      projectType: detected.projectType,
      projectPath: detected.projectPath,
      flutterCmd
    };
  } catch (error) {
    return { success: false, error: `Project preparation failed: ${error.message}` };
  } finally {
    await fs.remove(localJobDir).catch(() => {});
    await ssh.execCommand(`rm -f ${sh(remoteZipPath)}`).catch(() => {});
  }
}

function escapeJavaString(value) {
  return String(value || '')
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')
    .replace(/\r?\n/g, ' ');
}

function encodeUrlForTemplate(url) {
  const reversed = String(url || '').split('').reverse().join('');
  return Buffer.from(reversed, 'utf8').toString('base64');
}

/**
 * Auto-fix build.gradle/build.gradle.kts to use compileSdk 36
 */
async function autoFixBuildGradle(ssh, projectPath) {
  try {
    const script = `
set -e
PROJECT_PATH=${sh(projectPath)}

# Find build.gradle or build.gradle.kts in android/app directory
BUILD_GRADLE=""
if [ -f "$PROJECT_PATH/android/app/build.gradle.kts" ]; then
  BUILD_GRADLE="$PROJECT_PATH/android/app/build.gradle.kts"
elif [ -f "$PROJECT_PATH/android/app/build.gradle" ]; then
  BUILD_GRADLE="$PROJECT_PATH/android/app/build.gradle"
fi

if [ -z "$BUILD_GRADLE" ]; then
  echo "No build.gradle found in android/app"
  exit 0
fi

echo "Found: $BUILD_GRADLE"

# Detect file type and update compileSdk
case "$BUILD_GRADLE" in
  *.kts)
    # Kotlin DSL (build.gradle.kts)
    sed -i 's/compileSdk[[:space:]]*=[[:space:]]*[0-9]*/compileSdk = 36/g' "$BUILD_GRADLE"
    sed -i 's/compileSdkVersion[[:space:]]*=[[:space:]]*[0-9]*/compileSdk = 36/g' "$BUILD_GRADLE"
    sed -i 's/targetSdk[[:space:]]*=[[:space:]]*[0-9]*/targetSdk = 36/g' "$BUILD_GRADLE"
    ;;
  *)
    # Groovy DSL (build.gradle)
    sed -i 's/compileSdk[[:space:]]\\+[0-9]\\+/compileSdk 36/g' "$BUILD_GRADLE"
    sed -i 's/compileSdkVersion[[:space:]]\\+[0-9]\\+/compileSdk 36/g' "$BUILD_GRADLE"
    sed -i 's/targetSdk[[:space:]]\\+[0-9]\\+/targetSdk 36/g' "$BUILD_GRADLE"
    ;;
esac

echo "Updated compileSdk to 36 in $BUILD_GRADLE"
exit 0
`;
    const result = await ssh.execCommand(`bash -lc ${sh(script.trim())}`);
    if (result.code !== 0) {
      console.warn(`⚠️ Auto-fix build.gradle warning: ${result.stderr || result.stdout}`);
    } else {
      console.log(`✅ ${result.stdout.trim()}`);
    }
  } catch (e) {
    console.warn('⚠️ Failed to auto-fix build.gradle:', e.message);
  }
}

const ICON_SPECS = [
  { dir: 'mipmap-mdpi', size: 48 },
  { dir: 'mipmap-hdpi', size: 72 },
  { dir: 'mipmap-xhdpi', size: 96 },
  { dir: 'mipmap-xxhdpi', size: 144 },
  { dir: 'mipmap-xxxhdpi', size: 192 }
];

async function applyCustomLauncherIcon(localProjectPath, sourceIconPath) {
  // Validate source icon exists
  if (!await fs.pathExists(sourceIconPath)) {
    console.warn('⚠️ Source icon not found, using default template icons');
    return;
  }

  // Validate source is valid image
  try {
    const metadata = await sharp(sourceIconPath).metadata();
    if (!metadata || !metadata.format) {
      console.warn('⚠️ Source icon is not a valid image, using default template icons');
      return;
    }
  } catch (e) {
    console.warn('⚠️ Failed to read source icon metadata, using default template icons:', e.message);
    return;
  }

  for (const spec of ICON_SPECS) {
    const baseDir = path.join(localProjectPath, 'app', 'src', 'main', 'res', spec.dir);
    const launcher = path.join(baseDir, 'ic_launcher.png');
    const round = path.join(baseDir, 'ic_launcher_round.png');

    await fs.ensureDir(baseDir);
    
    try {
      // Generate PNG with explicit settings for Android compatibility
      await sharp(sourceIconPath)
        .resize(spec.size, spec.size, {
          fit: 'cover',
          position: 'centre'
        })
        .png({
          compressionLevel: 9,
          adaptiveFiltering: true,
          force: true
        })
        .toFile(launcher);
      
      // Verify the generated file is valid
      const stats = await fs.stat(launcher);
      if (stats.size === 0) {
        throw new Error('Generated icon file is empty');
      }
      
      await fs.copy(launcher, round, { overwrite: true });
    } catch (e) {
      console.error(`❌ Failed to generate icon for ${spec.dir}:`, e.message);
      // Continue with other sizes, template will have default icons
    }
  }
}

async function prepareNativeUrlProjectFiles(localProjectPath, appName, targetUrl) {
  const stringsPath = path.join(localProjectPath, 'app', 'src', 'main', 'res', 'values', 'strings.xml');
  const mainActivityPath = path.join(localProjectPath, 'app', 'src', 'main', 'java', 'com', 'web2apk', 'app', 'MainActivity.java');

  const safeName = escapeXml(appName || 'FxhlProject Web2Apk App');
  const encodedUrl = encodeUrlForTemplate(targetUrl);
  const fallbackUrl = escapeJavaString(targetUrl || 'https://google.com');

  const stringsXml = await fs.readFile(stringsPath, 'utf8');
  const updatedStrings = stringsXml.replace(
    /<string name="app_name">.*<\/string>/,
    `<string name="app_name">${safeName}</string>`
  );
  await fs.writeFile(stringsPath, updatedStrings, 'utf8');

  const mainActivity = await fs.readFile(mainActivityPath, 'utf8');
  let updatedMainActivity = mainActivity.replace(/ENCODED_URL_PLACEHOLDER/g, encodedUrl);
  updatedMainActivity = updatedMainActivity.replace(
    /private static final String FALLBACK_URL = ".*";/,
    `private static final String FALLBACK_URL = "${fallbackUrl}";`
  );
  updatedMainActivity = updatedMainActivity.replace(/https:\/\/google\.com/g, fallbackUrl);
  await fs.writeFile(mainActivityPath, updatedMainActivity, 'utf8');
}

async function prepareUrlProject(ssh, worker, job, buildDir, projectPath, onProgress) {
  const appName = job?.payload?.appName || job.appName || 'FxhlProject Web2Apk App';
  const targetUrl = job?.url || 'https://google.com';
  const customIconFileId = job?.payload?.customIcon || null;
  const localJobDir = path.join(os.tmpdir(), 'web2apk-v2-jobs', job.jobId, 'url-native-project');
  const localProjectPath = path.join(localJobDir, 'project');
  const localIconPath = path.join(localJobDir, 'icon-source.bin');

  try {
    const hasTemplate = await fs.pathExists(NATIVE_URL_TEMPLATE_DIR);
    if (!hasTemplate) {
      return {
        success: false,
        error: `Template Android native tidak ditemukan di ${NATIVE_URL_TEMPLATE_DIR}`
      };
    }

    await onProgress(17, 'Generating native Android project...');
    await ensureBuildDir(ssh, buildDir);

    const resetResult = await ssh.execCommand(`bash -lc ${sh(`
set -e
rm -rf ${sh(projectPath)}
mkdir -p ${sh(projectPath)}
    `.trim())}`);

    if (resetResult.code !== 0) {
      return {
        success: false,
        error: formatExecError(resetResult, 'Gagal menyiapkan folder project native di VPS')
      };
    }

    await fs.ensureDir(localJobDir);
    await fs.copy(NATIVE_URL_TEMPLATE_DIR, localProjectPath, { overwrite: true });

    await onProgress(18, 'Configuring native project...');
    await prepareNativeUrlProjectFiles(localProjectPath, appName, targetUrl);

    if (customIconFileId) {
      await onProgress(19, 'Downloading custom icon...');
      const iconUrls = await getTelegramFileUrls(customIconFileId);
      await downloadFromAny(iconUrls, localIconPath);

      await onProgress(19, 'Applying custom icon...');
      await applyCustomLauncherIcon(localProjectPath, localIconPath);
    }

    await onProgress(19, 'Uploading native project...');
    const uploaded = await ssh.putDirectory(localProjectPath, projectPath, {
      recursive: true,
      concurrency: 5,
      validate: () => true
    });

    if (!uploaded) {
      return {
        success: false,
        error: 'Gagal upload project Android native ke VPS'
      };
    }

    await ssh.execCommand('chmod +x gradlew || true', { cwd: projectPath });

    return {
      success: true,
      projectType: 'android',
      projectPath
    };
  } catch (error) {
    return { success: false, error: `Native project generation failed: ${error.message}` };
  } finally {
    await fs.remove(localJobDir).catch(() => {});
  }
}

async function prepare(ssh, worker, job, onProgress = async () => {}) {
  const buildDir = worker.buildDir || config.workers.defaultBuildDir;
  const projectPath = `${buildDir}/${job.jobId}`;

  if (job.mode === 'zip') {
    return prepareZipProject(ssh, worker, job, buildDir, projectPath, onProgress);
  }

  if (job.mode === 'url') {
    return prepareUrlProject(ssh, worker, job, buildDir, projectPath, onProgress);
  }

  try {
    await ensureBuildDir(ssh, buildDir);
    const type = job.projectType || 'flutter';
    let flutterCmd = null;
    if (type === 'flutter') {
      flutterCmd = await resolveFlutterCommand(ssh, worker);
      if (!flutterCmd) {
        return {
          success: false,
          error: 'Flutter tidak ditemukan di VPS. Jalankan /installvps terlebih dahulu.'
        };
      }
    }
    return {
      success: true,
      projectType: type,
      projectPath,
      flutterCmd
    };
  } catch (error) {
    return { success: false, error: `Preparation fallback failed: ${error.message}` };
  }
}

module.exports = {
  prepare
};
