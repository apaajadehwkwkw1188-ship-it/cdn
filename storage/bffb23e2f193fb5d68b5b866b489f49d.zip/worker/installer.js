/**
 * VPS Remote Installer for Web2Apk V2 Gen 1
 * 
 * Installs build toolchain on remote VPS via SSH with real-time streaming logs:
 * 1. System packages (ninja-build, cmake, unzip, openjdk-17-jdk)
 * 2. Android SDK (commandlinetools, platform-tools, build-tools)
 * 3. Flutter SDK
 * 4. Telegram Local Bot API Server (compile from source)
 * 
 * Each VPS has its own Local Bot API running on port 8081
 */

const { NodeSSH } = require('node-ssh');
const config = require('../config');
const db = require('../bot/db');

class VpsInstaller {
  constructor() {
    this.ssh = new NodeSSH();
    this.logBuffer = [];
    this.currentStep = 0;
    this.totalSteps = 7; // Added Node.js check step
  }

  /**
   * Run full installation on a worker (legacy method - use runInstallWithLogger for streaming UI)
   * @param {Object} worker - Worker object from database
   * @param {Object} bot - Telegram bot instance for messaging
   * @param {Number} chatId - Admin chat ID for progress updates
   */
  async runInstall(worker, bot, chatId) {
    const { apiId, apiHash } = config.telegram;
    
    if (!apiId || !apiHash) {
      throw new Error('API_ID and API_HASH must be configured in config.js');
    }

    const log = (msg) => {
      console.log(`[Installer ${worker.host}] ${msg}`);
    };

    try {
      // Step 0: Connect SSH with auth method detection
      log('🔌 Connecting to VPS...');
      
      const connectConfig = {
        host: worker.host,
        username: worker.user
      };
      
      if (worker.authMethod === 'password' && worker.password) {
        connectConfig.password = worker.password;
        log('🔐 Using password authentication');
      } else if (worker.sshKeyPath) {
        connectConfig.privateKey = worker.sshKeyPath;
        log('🔑 Using SSH key authentication');
      } else {
        connectConfig.privateKey = worker.sshKeyPath;
      }
      
      await this.ssh.connect(connectConfig);
      log('✅ SSH Connected');

      // Update worker status to installing
      await this.updateWorkerStatus(worker.id, 'installing');
      log('🔧 Status: Installing (builds will not be assigned)');

      // Step 1: System packages
      log(`━━━ Step 1/${this.totalSteps}: System Packages ━━━`);
      await this.installSystemPackages(log);
      log('✅ System packages installed');

      // Step 2: Check & Install Node.js 20.x
      log(`━━━ Step 2/${this.totalSteps}: Node.js & npm ━━━`);
      await this.checkAndInstallNodejs(log);
      log('✅ Node.js & npm verified');

      // Step 3: Java JDK
      log(`━━━ Step 3/${this.totalSteps}: Java JDK 17 ━━━`);
      await this.installJava(log);
      log('✅ Java JDK verified');

      // Step 4: Android SDK
      log(`━━━ Step 4/${this.totalSteps}: Android SDK ━━━`);
      await this.installAndroidSdk(log);
      log('✅ Android SDK installed');

      // Step 5: Flutter SDK
      log(`━━━ Step 5/${this.totalSteps}: Flutter SDK ━━━`);
      await this.installFlutter(log);
      log('✅ Flutter SDK installed');

      // Step 6: Local Bot API Server (takes longest!)
      log(`━━━ Step 6/${this.totalSteps}: Telegram Local Bot API Server ━━━`);
      log('⏳ This step takes 15-30 minutes (compiling from source)...');
      await this.installLocalBotApi(apiId, apiHash, log);
      log('✅ Local Bot API Server installed and running');

      // Step 7: Finalize
      log(`━━━ Step 7/${this.totalSteps}: Finalize ━━━`);
      await this.finalize(worker, apiId, apiHash, log);

      // Update worker with Local API URL
      const localApiUrl = `http://${worker.host}:8081`;
      await this.updateWorkerLocalApi(worker.id, localApiUrl);
      log(`🌐 Local Bot API URL: ${localApiUrl}`);

      // Update worker status
      await this.updateWorkerStatus(worker.id, 'online');
      // BUG FIX #4 & #5: Mark as installed
      await this.updateInstallationStatus(worker.id, 'installed');
      log('🎉 Installation complete! VPS is ready for builds.');

    } catch (error) {
      log(`❌ Installation failed: ${error.message}`);
      await this.updateWorkerStatus(worker.id, 'offline');
      // BUG FIX #4 & #5: Mark as pending if installation failed
      await this.updateInstallationStatus(worker.id, 'pending');
      throw error;
    } finally {
      this.ssh.dispose();
    }
  }

  /**
   * Update worker Local API URL in database (per-worker)
   * Includes defensive check to prevent duplicate entries
   */
  async updateWorkerLocalApi(workerId, localApiUrl) {
    const workers = await db.getWorkers();
    
    // Defensive: Remove any duplicate entries for this worker ID first
    const uniqueWorkers = workers.filter((w, index, self) => 
      index === self.findIndex(t => t.id === w.id)
    );
    
    const index = uniqueWorkers.findIndex(w => w.id === workerId);
    if (index > -1) {
      uniqueWorkers[index].localApiUrl = localApiUrl;
      uniqueWorkers[index].apiPort = 8081;
      await db.saveWorkers(uniqueWorkers);
      console.log(`[Installer] Updated Local API URL for ${workerId}: ${localApiUrl}`);
    } else {
      console.error(`[Installer] Worker ${workerId} not found for Local API update`);
    }
  }

  /**
   * Update worker status in database
   * Includes defensive check to prevent duplicate entries
   */
  async updateWorkerStatus(workerId, status) {
    const workers = await db.getWorkers();
    
    // Defensive: Remove any duplicate entries for this worker ID first
    const uniqueWorkers = workers.filter((w, index, self) => 
      index === self.findIndex(t => t.id === w.id)
    );
    
    const index = uniqueWorkers.findIndex(w => w.id === workerId);
    if (index > -1) {
      uniqueWorkers[index].status = status;
      await db.saveWorkers(uniqueWorkers);
      console.log(`[Installer] Updated status for ${workerId}: ${status}`);
    } else {
      console.error(`[Installer] Worker ${workerId} not found for status update`);
    }
  }

  /**
   * BUG FIX #4 & #5: Update worker installation status in database
   * @param {string} workerId - Worker ID
   * @param {string} status - 'pending' | 'installing' | 'installed'
   */
  async updateInstallationStatus(workerId, status) {
    const workers = await db.getWorkers();
    
    // Defensive: Remove any duplicate entries for this worker ID first
    const uniqueWorkers = workers.filter((w, index, self) => 
      index === self.findIndex(t => t.id === w.id)
    );
    
    const index = uniqueWorkers.findIndex(w => w.id === workerId);
    if (index > -1) {
      uniqueWorkers[index].installationStatus = status;
      if (status === 'installed') {
        uniqueWorkers[index].installedAt = new Date().toISOString();
      }
      await db.saveWorkers(uniqueWorkers);
      console.log(`[Installer] Updated installationStatus for ${workerId}: ${status}`);
    } else {
      console.error(`[Installer] Worker ${workerId} not found for installation status update`);
    }
  }

  /**
   * Step 2: Check & Install Node.js 20.x (like Gen 4)
   */
  async checkAndInstallNodejs(log) {
    // Check current Node.js version
    log('🔍 Checking Node.js installation...');
    const nodeCheck = await this.ssh.execCommand('node --version 2>&1 || echo "NOT_FOUND"');
    const nodeVersion = nodeCheck.stdout.trim();

    let needsNodeInstall = false;

    if (nodeVersion.includes('NOT_FOUND') || nodeVersion.includes('command not found')) {
      log('⚠️ Node.js not found! Installing Node.js 20.x...');
      needsNodeInstall = true;
    } else {
      // Parse version: v20.11.0 → 20
      const majorMatch = nodeVersion.match(/v?(\d+)\./);
      const majorVersion = majorMatch ? parseInt(majorMatch[1], 10) : 0;
      log(`📌 Found Node.js ${nodeVersion} (major: ${majorVersion})`);

      if (majorVersion < 20) {
        log(`⚠️ Node.js ${nodeVersion} is too old. Upgrading to v20.x...`);
        needsNodeInstall = true;
      } else {
        log(`✅ Node.js ${nodeVersion} is OK (v20+)`);
      }
    }

    // Also check npm
    const npmCheck = await this.ssh.execCommand('npm --version 2>&1 || echo "NOT_FOUND"');
    const npmVersion = npmCheck.stdout.trim();
    
    if (npmVersion.includes('NOT_FOUND') || npmVersion.includes('command not found')) {
      log('⚠️ npm not found! Will install with Node.js...');
      needsNodeInstall = true;
    } else {
      log(`📌 Found npm ${npmVersion}`);
    }

    if (needsNodeInstall) {
      log('📦 Installing Node.js 20.x via NodeSource...');

      // Install prerequisites
      log('⏳ Installing prerequisites...');
      await this.ssh.execCommand('apt-get update -y');
      await this.ssh.execCommand('apt-get install -y ca-certificates curl gnupg');

      // Add NodeSource repository
      log('⏳ Setting up NodeSource repository...');
      await this.ssh.execCommand('mkdir -p /etc/apt/keyrings');
      await this.ssh.execCommand('curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg');
      await this.ssh.execCommand('echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_20.x nodistro main" > /etc/apt/sources.list.d/nodesource.list');

      // Install Node.js
      log('⬇️ Installing Node.js 20.x (this may take a few minutes)...');
      await this.ssh.execCommand('apt-get update -y');
      await this.ssh.execCommand('apt-get install -y nodejs');

      // Verify installation
      const verifyNode = await this.ssh.execCommand('node --version');
      const verifyNpm = await this.ssh.execCommand('npm --version');

      if (verifyNode.stdout.includes('command not found') || verifyNpm.stdout.includes('command not found')) {
        throw new Error(`Node.js installation failed! node: ${verifyNode.stdout}, npm: ${verifyNpm.stdout}`);
      }

      log(`✅ Node.js installed: ${verifyNode.stdout.trim()}, npm: ${verifyNpm.stdout.trim()}`);
    } else {
      log(`✅ Node.js & npm already up to date`);
    }
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // ============================================
  // INSTALLATION STEPS WITH STREAMING LOGS
  // ============================================

  /**
   * Step 1: Install system packages with streaming output
   */
  async installSystemPackages(log) {
    const commands = [
      { cmd: 'apt-get update -y', desc: 'Updating package list' },
      { cmd: 'apt-get install -y ninja-build cmake unzip git curl wget', desc: 'Installing build tools' },
      { cmd: 'apt-get install -y make zlib1g-dev libssl-dev gperf g++ build-essential', desc: 'Installing development libraries' },
      { cmd: 'apt-get install -y openjdk-17-jdk', desc: 'Installing OpenJDK 17' }
    ];

    for (const { cmd, desc } of commands) {
      log(`⏳ ${desc}...`);
      const result = await this.ssh.execCommand(cmd, {
        execOptions: { timeout: 0 },
        onStdout: (chunk) => {
          const lines = chunk.toString().trim();
          if (lines && !lines.includes('GET') && !lines.includes('Unpacking')) {
            log(`  ${lines.substring(0, 100)}`);
          }
        }
      });
      
      if (result.code !== 0 && !result.stderr.includes('already')) {
        log(`⚠️ Warning: ${desc} exited with code ${result.code}`);
      } else {
        log(`✅ ${desc} complete`);
      }
    }

    // Auto-detect JAVA_HOME
    const javaResult = await this.ssh.execCommand(
      'readlink -f $(which java) | sed "s|/bin/java||" | sed "s|/jre||"'
    );
    
    if (javaResult.code === 0 && javaResult.stdout) {
      const javaHome = javaResult.stdout.trim();
      await this.ssh.execCommand(`echo 'export JAVA_HOME=${javaHome}' >> ~/.bashrc`);
      await this.ssh.execCommand(`echo 'export PATH=$JAVA_HOME/bin:$PATH' >> ~/.bashrc`);
      log(`🔧 JAVA_HOME set to ${javaHome}`);
    }
  }

  /**
   * Step 2: Verify Java installation
   */
  async installJava(log) {
    const result = await this.ssh.execCommand('java -version 2>&1');
    if (result.code !== 0) {
      throw new Error('Java installation verification failed');
    }
    log(`✅ Java: ${result.stdout.split('\n')[0] || result.stderr.split('\n')[0]}`);
  }

  /**
   * Step 3: Install Android SDK with streaming output
   */
  async installAndroidSdk(log) {
    const sdkRoot = '/opt/android-sdk';
    const cmdlineDir = `${sdkRoot}/cmdline-tools`;
    const latestDir = `${cmdlineDir}/latest`;

    // Check if already installed and has required SDK versions
    const checkResult = await this.ssh.execCommand(
      `test -f ${latestDir}/bin/sdkmanager && echo "sdkmanager_exists"`
    );
    
    const sdk36Check = await this.ssh.execCommand(
      `test -d ${sdkRoot}/platforms/android-36 && echo "sdk36_exists"`
    );
    
    if (checkResult.stdout.includes('sdkmanager_exists') && sdk36Check.stdout.includes('sdk36_exists')) {
      log('✅ Android SDK already installed (SDK 35/36 available)');
      return;
    }
    
    if (checkResult.stdout.includes('sdkmanager_exists') && !sdk36Check.stdout.includes('sdk36_exists')) {
      log('⚠️ Android SDK found but SDK 35/36 missing, updating...');
      // Continue to install missing SDK versions
    }

    log('⬇️ Downloading Android Command Line Tools...');
    const dlUrl = 'https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip';
    const tempFile = '/tmp/cmdline-tools.zip';

    await this.ssh.execCommand(`curl -L ${dlUrl} -o ${tempFile}`, {
      execOptions: { timeout: 0 },
      onStdout: (chunk) => log(`  ${chunk.toString().trim()}`)
    });

    log('📦 Extracting Android Tools...');
    await this.ssh.execCommand(`mkdir -p ${cmdlineDir}`);
    await this.ssh.execCommand(`unzip -q ${tempFile} -d /tmp/android_temp`);
    await this.ssh.execCommand(`mv /tmp/android_temp/cmdline-tools ${latestDir}`);
    await this.ssh.execCommand(`rm -rf ${tempFile} /tmp/android_temp`);
    await this.ssh.execCommand(`chmod -R 777 ${sdkRoot}`);

    log('📝 Accepting Licenses...');
    const sdkManager = `${latestDir}/bin/sdkmanager`;
    await this.ssh.execCommand(`yes | ${sdkManager} --licenses`, {
      execOptions: { timeout: 0 }
    });

    log('📦 Installing SDK Components...');
    const packages = [
      'platform-tools',
      'platforms;android-33',
      'platforms;android-34',
      'platforms;android-35',
      'platforms;android-36',
      'build-tools;34.0.0',
      'build-tools;35.0.0',
      'build-tools;36.0.0',
      'ndk;27.0.12077973',
      'cmake;3.22.1'
    ];

    for (const pkg of packages) {
      log(`  ⬇️ Installing ${pkg}...`);
      await this.ssh.execCommand(`yes | ${sdkManager} "${pkg}"`, {
        execOptions: { timeout: 0 },
        onStdout: (chunk) => {
          const text = chunk.toString();
          if (text.includes('done') || text.includes('Installed')) {
            log(`    ✅ ${pkg} installed`);
          }
        }
      });
    }

    // Set environment variables
    await this.ssh.execCommand(`echo 'export ANDROID_HOME=${sdkRoot}' >> ~/.bashrc`);
    await this.ssh.execCommand(`echo 'export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH' >> ~/.bashrc`);
    log(`🔧 ANDROID_HOME set to ${sdkRoot}`);
  }

  /**
   * Step 4: Install Flutter SDK with streaming output
   */
  async installFlutter(log) {
    const flutterHome = '/opt/flutter';

    // Check if already installed
    const checkResult = await this.ssh.execCommand(
      `test -d ${flutterHome}/bin && echo "exists"`
    );
    
    if (checkResult.stdout.includes('exists')) {
      log('✅ Flutter already installed');
      return;
    }

    log('⬇️ Downloading Flutter SDK...');
    const dlUrl = 'https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.38.0-stable.tar.xz';
    const tempFile = '/tmp/flutter.tar.xz';

    await this.ssh.execCommand(`curl -L ${dlUrl} -o ${tempFile}`, {
      execOptions: { timeout: 0 },
      onStdout: (chunk) => log(`  ${chunk.toString().trim()}`)
    });

    log('📦 Extracting Flutter...');
    await this.ssh.execCommand(`mkdir -p /opt`);
    await this.ssh.execCommand(`tar -xf ${tempFile} -C /opt`);
    await this.ssh.execCommand(`rm ${tempFile}`);
    await this.ssh.execCommand(`chmod -R 777 ${flutterHome}`);
    
    // Fix git safe directory
    await this.ssh.execCommand('git config --global --add safe.directory "*"');
    await this.ssh.execCommand(`git config --global --add safe.directory ${flutterHome}`);

    // Add to PATH
    await this.ssh.execCommand(`echo 'export PATH=$PATH:${flutterHome}/bin' >> ~/.bashrc`);

    log('🔄 Running flutter precache...');
    await this.ssh.execCommand(`${flutterHome}/bin/flutter precache`, {
      execOptions: { timeout: 0 },
      onStdout: (chunk) => {
        const text = chunk.toString().trim();
        if (text && text.length > 0) {
          log(`  ${text.substring(0, 80)}`);
        }
      }
    });
    
    log('✅ Flutter precache complete');
  }

  /**
   * Step 5: Install Telegram Local Bot API Server with streaming output
   * This takes 15-30 minutes!
   */
  async installLocalBotApi(apiId, apiHash, log) {
    // Check if already installed
    const checkResult = await this.ssh.execCommand(
      'test -f /usr/local/bin/telegram-bot-api && echo "exists"'
    );
    
    if (checkResult.stdout.includes('exists')) {
      log('✅ Local Bot API already installed, updating service...');
      await this.setupServiceFile(apiId, apiHash, log);
      return;
    }

    const buildDir = '/tmp/tdlib-build';
    const repoUrl = 'https://github.com/tdlib/telegram-bot-api.git';

    log('📥 Cloning repository...');
    await this.ssh.execCommand(`rm -rf ${buildDir}`);
    await this.ssh.execCommand(`mkdir -p ${buildDir}`);
    await this.ssh.execCommand(`git clone --recursive ${repoUrl} ${buildDir}/telegram-bot-api`, {
      execOptions: { timeout: 300000 },
      onStdout: (chunk) => log(`  ${chunk.toString().trim()}`)
    });

    log('⚙️ Configuring with CMake...');
    const buildPath = `${buildDir}/telegram-bot-api/build`;
    await this.ssh.execCommand(`mkdir -p ${buildPath}`);
    
    await this.ssh.execCommand(
      `cd ${buildPath} && cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX:PATH=/usr/local ..`,
      {
        execOptions: { timeout: 120000 },
        onStdout: (chunk) => log(`  ${chunk.toString().trim()}`)
      }
    );

    log('🔨 Compiling (this takes 15-30 minutes)...');
    log('☕ Grab a coffee, this is the longest step...');
    
    // Use -j 1 for low RAM VPS to prevent OOM
    let lastProgress = '';
    await this.ssh.execCommand(
      `cd ${buildPath} && cmake --build . --target install -j 1`,
      {
        execOptions: { timeout: 0 },
        onStdout: (chunk) => {
          const text = chunk.toString().trim();
          // Only log progress indicators
          if (text.includes('%') || text.includes('Built target') || text.includes('Linking')) {
            if (text !== lastProgress) {
              log(`  ${text.substring(0, 100)}`);
              lastProgress = text;
            }
          }
        },
        onStderr: (chunk) => {
          const text = chunk.toString().trim();
          if (text.includes('error') || text.includes('Error')) {
            log(`  ⚠️ ${text.substring(0, 100)}`);
          }
        }
      }
    );

    log('✅ Compilation complete!');

    // Setup service file
    await this.setupServiceFile(apiId, apiHash, log);

    // Cleanup
    await this.ssh.execCommand(`rm -rf ${buildDir}`);
  }

  /**
   * Create systemd service file for Local Bot API
   */
  async setupServiceFile(apiId, apiHash, log) {
    log('📝 Creating systemd service...');
    
    const serviceContent = `[Unit]
Description=Telegram Bot API Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/telegram-bot-api --api-id=${apiId} --api-hash=${apiHash} --local --http-port=8081 --http-stat-port=8082 --dir=/var/lib/telegram-bot-api --log=/var/log/telegram-bot-api.log
Restart=always
RestartSec=5
User=root
WorkingDirectory=/var/lib/telegram-bot-api
Environment="TELEGRAM_API_ID=${apiId}"
Environment="TELEGRAM_API_HASH=${apiHash}"

[Install]
WantedBy=multi-user.target`;

    // Write service file
    await this.ssh.execCommand(`cat > /tmp/telegram-bot-api.service << 'EOF'
${serviceContent}
EOF`);

    // Move to systemd
    await this.ssh.execCommand('mv /tmp/telegram-bot-api.service /etc/systemd/system/');
    await this.ssh.execCommand('mkdir -p /var/lib/telegram-bot-api');
    await this.ssh.execCommand('systemctl daemon-reload');
    await this.ssh.execCommand('systemctl enable telegram-bot-api');
    
    log('🚀 Starting Local Bot API service...');
    await this.ssh.execCommand('systemctl restart telegram-bot-api || true');
    
    // Wait a moment and check status
    await new Promise(r => setTimeout(r, 3000));
    const statusResult = await this.ssh.execCommand('systemctl is-active telegram-bot-api');
    
    if (statusResult.stdout.trim() === 'active') {
      log('✅ Local Bot API service is running');
    } else {
      log('⚠️ Service status: ' + statusResult.stdout.trim());
    }
  }

  /**
   * Step 6: Finalize installation
   */
  async finalize(worker, apiId, apiHash, log) {
    log('🔍 Verifying installations...');
    
    const checks = [
      { cmd: 'java -version 2>&1 | head -1', name: 'Java' },
      { cmd: 'test -d /opt/android-sdk && echo "Android SDK OK"', name: 'Android SDK' },
      { cmd: 'test -d /opt/flutter && echo "Flutter OK"', name: 'Flutter' },
      { cmd: 'systemctl is-active telegram-bot-api', name: 'Local Bot API Service' }
    ];

    for (const check of checks) {
      const result = await this.ssh.execCommand(check.cmd);
      log(`  ${check.name}: ${result.stdout || result.stderr || 'OK'}`);
    }

    // Source bashrc for current session
    log('🔧 Setting environment for current session...');
    await this.ssh.execCommand('export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64');
    await this.ssh.execCommand('export ANDROID_HOME=/opt/android-sdk');
    await this.ssh.execCommand('export PATH=$PATH:/opt/flutter/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools');
    
    log('✅ Environment configured');
  }

  /**
   * Run installation with custom logger (for streaming UI)
   * @param {Object} worker - Worker object
   * @param {Object} bot - Telegram bot
   * @param {Number} chatId - Chat ID
   * @param {Function} customLog - Custom log function
   */
  async runInstallWithLogger(worker, bot, chatId, customLog) {
    const { apiId, apiHash } = config.telegram;
    
    if (!apiId || !apiHash) {
      throw new Error('API_ID and API_HASH must be configured in config.js');
    }

    // Use custom log function if provided, otherwise default
    const log = customLog || ((msg) => {
      console.log(`[Installer ${worker.host}] ${msg}`);
    });

    try {
      // Step 0: Connect SSH
      log('🔌 Connecting to VPS...');
      
      const connectConfig = {
        host: worker.host,
        username: worker.user
      };
      
      if (worker.authMethod === 'password' && worker.password) {
        connectConfig.password = worker.password;
        log('🔐 Using password authentication');
      } else if (worker.sshKeyPath) {
        connectConfig.privateKey = worker.sshKeyPath;
        log('🔑 Using SSH key authentication');
      } else {
        connectConfig.privateKey = worker.sshKeyPath;
      }
      
      await this.ssh.connect(connectConfig);
      log('✅ SSH Connected');

      // Update worker status
      await this.updateWorkerStatus(worker.id, 'installing');
      log('🔧 Status: Installing (builds will not be assigned)');

      // Run installation steps
      log(`━━━ Step 1/7: System Packages ━━━`);
      await this.installSystemPackages(log);
      log('✅ System packages installed');

      log(`━━━ Step 2/7: Node.js & npm ━━━`);
      await this.checkAndInstallNodejs(log);
      log('✅ Node.js & npm verified');

      log(`━━━ Step 3/7: Java JDK 17 ━━━`);
      await this.installJava(log);
      log('✅ Java JDK verified');

      log(`━━━ Step 4/7: Android SDK ━━━`);
      await this.installAndroidSdk(log);
      log('✅ Android SDK installed');

      log(`━━━ Step 5/7: Flutter SDK ━━━`);
      await this.installFlutter(log);
      log('✅ Flutter SDK installed');

      log(`━━━ Step 6/7: Telegram Local Bot API Server ━━━`);
      log('⏳ This step takes 15-30 minutes (compiling from source)...');
      await this.installLocalBotApi(apiId, apiHash, log);
      log('✅ Local Bot API Server installed and running');

      log(`━━━ Step 7/7: Finalize ━━━`);
      await this.finalize(worker, apiId, apiHash, log);

      // Update worker
      const localApiUrl = `http://${worker.host}:8081`;
      await this.updateWorkerLocalApi(worker.id, localApiUrl);
      log(`🌐 Local Bot API URL: ${localApiUrl}`);

      await this.updateWorkerStatus(worker.id, 'online');
      // BUG FIX: Mark as installed in streaming installer
      await this.updateInstallationStatus(worker.id, 'installed');
      log('🎉 Installation complete! VPS is ready for builds.');

    } catch (error) {
      log(`❌ Installation failed: ${error.message}`);
      await this.updateWorkerStatus(worker.id, 'offline');
      // BUG FIX: Mark as pending if failed
      await this.updateInstallationStatus(worker.id, 'pending');
      throw error;
    } finally {
      this.ssh.dispose();
    }
  }
}

module.exports = new VpsInstaller();

// Re-export streaming UI functions for backward compatibility
const { runInstallationWithStreaming, runDualInstallationWithStreaming } = require('./utils/installerUI');
module.exports.runInstallationWithStreaming = runInstallationWithStreaming;
module.exports.runDualInstallationWithStreaming = runDualInstallationWithStreaming;
