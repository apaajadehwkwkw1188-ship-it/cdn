const config = require('../../config');

function sh(value) {
  return "'" + String(value).replace(/'/g, "'\"'\"'") + "'";
}

function formatCommandError(step, result) {
  const details = [result?.stderr, result?.stdout].filter(Boolean).join('\n').trim();
  if (!details) return `${step} failed`;
  return `${step} failed: ${details}`;
}

async function runFlutterWithEnv(ssh, projectPath, flutterCmd, commandBody) {
  const script = `
set -e
export BOT=true

if [ -z "$JAVA_HOME" ] && [ -d /usr/lib/jvm/java-17-openjdk-amd64 ]; then
  export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
fi
if [ -n "$JAVA_HOME" ]; then
  export PATH="$JAVA_HOME/bin:$PATH"
fi

if [ -z "$ANDROID_HOME" ]; then
  if [ -d /opt/android-sdk ]; then
    export ANDROID_HOME=/opt/android-sdk
  elif [ -d /usr/lib/android-sdk ]; then
    export ANDROID_HOME=/usr/lib/android-sdk
  fi
fi

if [ -n "$ANDROID_HOME" ]; then
  export ANDROID_SDK_ROOT="$ANDROID_HOME"
  export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"
fi

export PATH="$PATH:/opt/flutter/bin:/root/flutter/bin"
FLUTTER_BIN=${sh(flutterCmd)}

if [ -n "$ANDROID_HOME" ]; then
  "$FLUTTER_BIN" config --android-sdk "$ANDROID_HOME" >/dev/null 2>&1 || true
  mkdir -p android
  echo "sdk.dir=$ANDROID_HOME" > android/local.properties
fi

# Set flutter.sdk in local.properties (required by Gradle)
FLUTTER_SDK_PATH=$(dirname "$(dirname "$(which flutter 2>/dev/null || echo /opt/flutter)")")
if [ -d "$FLUTTER_SDK_PATH/bin" ]; then
  mkdir -p android
  echo "flutter.sdk=$FLUTTER_SDK_PATH" >> android/local.properties
elif [ -d "/opt/flutter" ]; then
  mkdir -p android
  echo "flutter.sdk=/opt/flutter" >> android/local.properties
elif [ -d "/root/flutter" ]; then
  mkdir -p android
  echo "flutter.sdk=/root/flutter" >> android/local.properties
fi

# Disable Gradle daemon to prevent daemon crashes (MUST be in android folder)
mkdir -p android
echo "org.gradle.daemon=false" > android/gradle.properties
echo "org.gradle.jvmargs=-Xmx4g -XX:MaxMetaspaceSize=512m" >> android/gradle.properties
echo "android.useAndroidX=true" >> android/gradle.properties
echo "android.enableJetifier=true" >> android/gradle.properties

${commandBody}
  `.trim();

  return ssh.execCommand(`bash -lc ${sh(script)}`, { cwd: projectPath });
}

class FlutterPipeline {
  async run(ssh, worker, job, onProgress = () => {}) {
    const buildDir = worker.buildDir || config.workers.defaultBuildDir;
    const projectPath = job.projectPath || `${buildDir}/${job.jobId}`;
    const flutterCmd = job.flutterCmd || 'flutter';

    try {
      await onProgress(22, 'Preparing project...');
      console.log(`[${job.jobId}] Step 1: Cleaning...`);

      const clean = await runFlutterWithEnv(
        ssh,
        projectPath,
        flutterCmd,
        '"$FLUTTER_BIN" clean'
      );
      if (clean.code !== 0) throw new Error(formatCommandError('Flutter clean', clean));

      await onProgress(30, 'Getting dependencies...');
      console.log(`[${job.jobId}] Step 2: Pub get...`);
      const pubGet = await runFlutterWithEnv(
        ssh,
        projectPath,
        flutterCmd,
        '"$FLUTTER_BIN" pub get'
      );
      if (pubGet.code !== 0) throw new Error(formatCommandError('Flutter pub get', pubGet));

      await onProgress(35, 'Checking launcher icon config...');
      console.log(`[${job.jobId}] Step 2.5: Checking flutter_launcher_icons config...`);
      // Check if flutter_launcher_icons is configured in pubspec.yaml
      const checkConfig = await ssh.execCommand(`test -f pubspec.yaml && grep -q "flutter_launcher_icons:" pubspec.yaml && echo "FOUND" || echo "NOT_FOUND"`, { cwd: projectPath });
      
      if (checkConfig.stdout.trim() === 'FOUND') {
        await onProgress(40, 'Generating launcher icons...');
        console.log(`[${job.jobId}] Step 3: Generating launcher icons...`);
        const genIcons = await runFlutterWithEnv(
          ssh,
          projectPath,
          flutterCmd,
          '"$FLUTTER_BIN" pub run flutter_launcher_icons'
        );
        if (genIcons.code !== 0) {
          console.warn(`[${job.jobId}] Icon generation warning: ${genIcons.stderr || genIcons.stdout}`);
          // Don't fail build, just log warning
        } else {
          console.log(`[${job.jobId}] Icons generated successfully`);
        }
      } else {
        console.log(`[${job.jobId}] No flutter_launcher_icons config found, skipping`);
      }

      await onProgress(45, 'Validating resources...');
      console.log(`[${job.jobId}] Step 2.5: Checking for corrupt/duplicate icons...`);
      // Check and fix corrupt launcher icons (conservative approach)
      const checkIcons = await runFlutterWithEnv(
        ssh,
        projectPath,
        flutterCmd,
        `
# Remove obviously corrupt (zero-size) icon files
if [ -d "android/app/src/main/res" ]; then
  find android/app/src/main/res/mipmap-* -name "ic_launcher*.png" -size 0 -delete 2>/dev/null || true
  find android/app/src/main/res/mipmap-* -name "ic_launcher*.jpg" -size 0 -delete 2>/dev/null || true
fi

# Remove duplicate icon files (keep PNG, remove JPG if both exist)
if [ -d "android/app/src/main/res" ]; then
  for mipmap in android/app/src/main/res/mipmap-*; do
    if [ -d "$mipmap" ]; then
      for icon in "$mipmap"/ic_launcher*.jpg; do
        if [ -f "$icon" ]; then
          basename=$(basename "$icon" .jpg)
          if [ -f "$mipmap/$basename.png" ]; then
            echo "Removing duplicate JPG: $icon (PNG exists)"
            rm -f "$icon"
          fi
        fi
      done
    fi
  done
  echo "Icon validation complete - removed zero-size and duplicate files"
fi
        `.trim()
      );
      // Don't fail on icon check, just log warning
      if (checkIcons.code !== 0) {
        console.warn(`[${job.jobId}] Icon check warning: ${checkIcons.stderr || checkIcons.stdout}`);
      }

      await onProgress(55, 'Building APK...');
      console.log(`[${job.jobId}] Step 3: Building APK (${job.buildType || 'release'})...`);
      
      const isDebug = job.buildType === 'debug';
      // gradle.properties already has org.gradle.daemon=false
      const buildCommand = isDebug
        ? '"$FLUTTER_BIN" build apk --debug'
        : '"$FLUTTER_BIN" build apk --release';
      
      const buildApk = await runFlutterWithEnv(
        ssh,
        projectPath,
        flutterCmd,
        buildCommand
      );
      if (buildApk.code !== 0) throw new Error(formatCommandError('Flutter build apk', buildApk));

      await onProgress(95, 'Finalizing...');

      const apkFileName = isDebug ? 'app-debug.apk' : 'app-release.apk';
      const expectedApkPath = `${projectPath}/build/app/outputs/flutter-apk/${apkFileName}`;

      // Try to find the actual APK file - handle different project structures
      const findApkCmd = await ssh.execCommand(`find ${projectPath} -name "${apkFileName}" -type f 2>/dev/null | head -1`);
      const actualApkPath = findApkCmd.stdout.trim();

      if (actualApkPath) {
        console.log(`[${job.jobId}] APK found at: ${actualApkPath}`);
        return {
          success: true,
          apkPath: actualApkPath
        };
      }

      // Fallback to expected path if find command didn't work
      console.log(`[${job.jobId}] APK not found via find, using expected path: ${expectedApkPath}`);
      return {
        success: true,
        apkPath: expectedApkPath
      };
    } catch (error) {
      console.error(`[${job.jobId}] Build error:`, error.message);
      return { success: false, error: error.message };
    }
  }
}

module.exports = new FlutterPipeline();
