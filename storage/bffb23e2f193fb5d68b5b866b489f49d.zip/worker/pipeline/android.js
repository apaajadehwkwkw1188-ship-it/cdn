﻿const config = require('../../config');

function sh(value) {
  return "'" + String(value).replace(/'/g, "'\"'\"'") + "'";
}

function formatCommandError(step, result) {
  const details = [result?.stderr, result?.stdout].filter(Boolean).join('\n').trim();
  if (!details) return `${step} failed`;
  return `${step} failed: ${details}`;
}

async function runGradleWithEnv(ssh, projectPath, commandBody) {
  const script = `
set -e

if [ -z "$JAVA_HOME" ] && [ -d /usr/lib/jvm/java-17-openjdk-amd64 ]; then
  export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
fi
if [ -n "$JAVA_HOME" ]; then
  export PATH="$JAVA_HOME/bin:$PATH"
fi

if [ -z "$ANDROID_HOME" ]; then
  if [ -d /opt/android-sdk ]; then
    export ANDROID_HOME=/opt/android-sdk
  elif [ -d /usr/lib/android-sdk ]; then
    export ANDROID_HOME=/usr/lib/android-sdk
  fi
fi

if [ -n "$ANDROID_HOME" ]; then
  export ANDROID_SDK_ROOT="$ANDROID_HOME"
  export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"
  echo "sdk.dir=$ANDROID_HOME" > local.properties
fi

chmod +x gradlew || true
${commandBody}
  `.trim();

  return ssh.execCommand(`bash -lc ${sh(script)}`, { cwd: projectPath });
}

class AndroidPipeline {
  async run(ssh, worker, job, onProgress = () => {}) {
    const buildDir = worker.buildDir || config.workers.defaultBuildDir;
    const projectPath = job.projectPath || `${buildDir}/${job.jobId}`;

    try {
      await onProgress(22, 'Preparing Android project...');
      console.log(`[${job.jobId}] Step 1: Cleaning...`);

      const clean = await runGradleWithEnv(ssh, projectPath, './gradlew clean');
      if (clean.code !== 0) throw new Error(formatCommandError('Gradle clean', clean));

      await onProgress(35, 'Resolving dependencies...');
      console.log(`[${job.jobId}] Step 2: Resolving dependencies...`);
      const deps = await runGradleWithEnv(ssh, projectPath, './gradlew dependencies');
      if (deps.code !== 0) throw new Error(formatCommandError('Gradle dependencies', deps));

      await onProgress(60, 'Building Android APK...');
      console.log(`[${job.jobId}] Step 3: Building APK (${job.buildType || 'release'})...`);
      
      const isDebug = job.buildType === 'debug';
      const buildCommand = isDebug
        ? './gradlew assembleDebug'
        : './gradlew assembleRelease';
      
      const buildApk = await runGradleWithEnv(ssh, projectPath, buildCommand);
      if (buildApk.code !== 0) throw new Error(formatCommandError('Gradle assemble', buildApk));

      const isRelease = !isDebug;
      const apkFileName = isDebug ? 'app-debug.apk' : 'app-release.apk';
      const expectedApkPath = `${projectPath}/app/build/outputs/apk/${isDebug ? 'debug' : 'release'}/${apkFileName}`;

      // DEBUG: List build directory structure
      console.log(`[${job.jobId}] DEBUG: Listing APK files in build directory...`);
      const listApkCmd = await ssh.execCommand(`find ${projectPath} -name "*.apk" -type f 2>/dev/null`);
      console.log(`[${job.jobId}] DEBUG: Found APK files:\n${listApkCmd.stdout || 'NONE'}`);

      // DEBUG: List outputs directory
      const listOutputsCmd = await ssh.execCommand(`ls -la ${projectPath}/app/build/outputs/apk/*/ 2>/dev/null || echo "Directory not found"`);
      console.log(`[${job.jobId}] DEBUG: Outputs directory:\n${listOutputsCmd.stdout || listOutputsCmd.stderr}`);

      // Try to find the actual APK file - handle different project structures
      // First try exact match
      const findApkCmd = await ssh.execCommand(`find ${projectPath} -name "${apkFileName}" -type f 2>/dev/null | head -1`);
      const actualApkPath = findApkCmd.stdout.trim();

      if (actualApkPath) {
        console.log(`[${job.jobId}] APK found at: ${actualApkPath}`);
        return {
          success: true,
          apkPath: actualApkPath
        };
      }

      // Fallback: try any APK file with release/debug suffix
      const fallbackPattern = isRelease ? '*release*.apk' : '*debug*.apk';
      const findAnyApkCmd = await ssh.execCommand(`find ${projectPath} -name "${fallbackPattern}" -type f 2>/dev/null | head -1`);
      const anyApkPath = findAnyApkCmd.stdout.trim();

      if (anyApkPath) {
        console.log(`[${job.jobId}] APK found via wildcard: ${anyApkPath}`);
        return {
          success: true,
          apkPath: anyApkPath
        };
      }

      // Last fallback: any APK file
      const findAllApkCmd = await ssh.execCommand(`find ${projectPath} -name "*.apk" -type f 2>/dev/null | head -1`);
      const anyFoundApk = findAllApkCmd.stdout.trim();

      if (anyFoundApk) {
        console.log(`[${job.jobId}] APK found (generic search): ${anyFoundApk}`);
        return {
          success: true,
          apkPath: anyFoundApk
        };
      }

      // Fallback to expected path if find command didn't work
      console.log(`[${job.jobId}] APK not found via find, using expected path: ${expectedApkPath}`);
      return {
        success: true,
        apkPath: expectedApkPath
      };
    } catch (error) {
      console.error(`[${job.jobId}] Build error:`, error.message);
      return { success: false, error: error.message };
    }
  }
}

module.exports = new AndroidPipeline();
