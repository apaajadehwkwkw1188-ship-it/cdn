const buildMenu = [
  [{ text: 'Build dari ZIP', callback_data: 'zip_to_apk', icon_custom_emoji_id: "5433653135799228968" }, { text: 'Build dari URL', callback_data: 'url_to_apk', icon_custom_emoji_id: "5447410659077661506" }],
  [{ text: 'Kembali', callback_data: 'main_menu', icon_custom_emoji_id: "6084901676886526521" }],
];

module.exports = buildMenu;
