const db = require('../db');
const config = require('../../config');
const joinChecker = require('../joinCheck/checker');
const { getMainMenu, stripStyles } = require('../menus/mainMenu');
const path = require('path');

function isStyleUnsupportedError(error) {
  const message = String(
    error?.response?.body?.description ||
    error?.response?.body ||
    error?.message ||
    ''
  ).toLowerCase();

  return (
    message.includes("can't parse inline keyboard button") ||
    message.includes('inline keyboard button') ||
    message.includes('field "style"') ||
    message.includes('style')
  );
}

function buildMainMenus() {
  const colored = getMainMenu(true);
  return {
    colored,
    fallback: stripStyles(colored)
  };
}

async function sendWithMenuFallback(sendFn, coloredMenu, fallbackMenu) {
  try {
    return await sendFn(coloredMenu);
  } catch (error) {
    if (!isStyleUnsupportedError(error)) throw error;
    console.warn('[start] Button style unsupported by current API endpoint. Fallback to non-style keyboard.');
    return sendFn(fallbackMenu);
  }
}

async function startHandler(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Save user to database
  await db.addUser(userId);

  // Check if user has joined all required channels
  const allJoined = await joinChecker.isAllJoined(bot, userId);
  if (!allJoined) {
    const channels = config.requiredJoins.map((handle, idx) => {
      const url = `https://t.me/${handle.replace('@', '')}`;
      return [{ text: `Channel ${idx + 1}`, url }];
    });
    const keyboard = [
      ...channels
    ];

    return bot.sendMessage(chatId, '<tg-emoji emoji-id="5364090007227210044">👋</tg-emoji> Halo! Sebelum menggunakan bot ini, kamu wajib bergabung di semua channel/grup berikut:', {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: keyboard,
      }
    });
  }

  // Show main menu
  const caption = `<blockquote>WELCOME TO WEB2APK KENZIE</blockquote>

<b>Fitur utama</b>
• Multi-worker (VPS + GitHub Actions)
• Antrian otomatis saat slot penuh
• Build dari ZIP atau URL

Silakan pilih menu:`;

  const coverPath = path.resolve(__dirname, '../../assets/start.jpg');
  const { colored: coloredMenu, fallback: fallbackMenu } = buildMainMenus();

  try {
    return await sendWithMenuFallback(
      (menu) => bot.sendPhoto(chatId, coverPath, {
        caption,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: menu
        }
      }),
      coloredMenu,
      fallbackMenu
    );
  } catch (_) {
    try {
      return await sendWithMenuFallback(
        (menu) => bot.sendMessage(chatId, caption, {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: menu
          }
        }),
        coloredMenu,
        fallbackMenu
      );
    } catch (fallbackError) {
      return bot.sendMessage(chatId, caption, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: fallbackMenu
        }
      });
    }
  }
}

module.exports = startHandler;
