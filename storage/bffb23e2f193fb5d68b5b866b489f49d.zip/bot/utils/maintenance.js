const fs = require('fs-extra');
const path = require('path');
const MAINTENANCE_FILE = path.resolve(__dirname, '../../database/maintenance.json');

fs.ensureDirSync(path.dirname(MAINTENANCE_FILE));

function isEnabled() {
  try {
    if (!fs.existsSync(MAINTENANCE_FILE)) return false;
    const data = fs.readJsonSync(MAINTENANCE_FILE);
    return !!data.enabled;
  } catch (error) {
    console.error('[maintenance] Failed reading maintenance file:', error.message);
    return false;
  }
}

function set(enabled) {
  try {
    fs.writeJsonSync(MAINTENANCE_FILE, {
      enabled: !!enabled,
      updatedAt: new Date().toISOString()
    }, { spaces: 2 });
    return true;
  } catch (error) {
    console.error('[maintenance] Failed writing maintenance file:', error.message);
    return false;
  }
}

module.exports = {
  isEnabled,
  set,
  file: MAINTENANCE_FILE
};
