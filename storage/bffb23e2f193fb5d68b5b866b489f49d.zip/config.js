// config.js — Web2Apk V2 Gen 1 Configuration

const config = {

  // ─── Telegram ────────────────────────────────────────────────────────────
  telegram: {
    botToken: '8932626364:AAHFJbk-SwzwsWYsfHC1MYUm1YffsJps2eU',
    // API credentials untuk Local Bot API Server (dari https://my.telegram.org)
    // Setiap VPS Worker akan punya Local Bot API sendiri di port 8081
    apiId: '29521616',
    apiHash: '9640c8fffb988a6a2096abe06de39ec3',
    // Aktifkan auto-discovery Local Bot API dari data VPS worker (multi VPS).
    useLocalApi: true,
    // ID admin yang berhak menjalankan perintah management
    adminIds: [8155916749],
    ownerLink: 'https://t.me/Kenzie_Lenz',
    informationLink: 'https://t.me/Xterclose_mjs',
  },

  // ─── Payment ─────────────────────────────────────────────────────────────
  payment: {
    // ID channel untuk nota transaksi (receipt)
    paymentChannelId: '-1004457132557',
  },

  // ─── Wajib Join Channel / Grup ───────────────────────────────────────────
  // User harus join SEMUA channel/grup di sini sebelum bisa menggunakan bot
  requiredJoins: [
    '@Xterclose_mjs'
  ],

  // ─── Akses & Membership ──────────────────────────────────────────────────
  access: {
    // URL to APK = GRATIS (semua user bisa)
    urlToApkFree: true,
    // ZIP to APK = BERBAYAR (hanya member aktif)
    zipToApkMembersOnly: true,
    // Pesan yang ditampilkan ke non-member saat coba akses ZIP to APK
    nonMemberMessage: '🔒 Fitur ini memerlukan akses.\nHubungi admin untuk mendapatkan akses.',
  },

  // ─── Worker Pool Settings (default untuk semua worker) ──────────────────
  // Identitas & data tiap worker disimpan di database/workers/*.json
  // Di sini hanya setting global yang berlaku untuk semua worker
  workers: {
    // Timeout SSH ke VPS sebelum dianggap gagal koneksi (detik)
    sshTimeoutSeconds: 15,
    // Timeout trigger GitHub Actions sebelum dianggap gagal (detik)
    githubTriggerTimeoutSeconds: 30,
    // Direktori build default di setiap VPS (bisa di-override per worker di JSON)
    defaultBuildDir: '/opt/web2apk/builds',
    // Direktori cache default di setiap VPS
    defaultCacheDir: '/opt/web2apk/cache',
    // Cooldown duration after build completes (ms) - worker enters cooldown before accepting new jobs
    cooldownMs: 30000,
    // Maximum build duration before timeout (ms) - 30 minutes default
    buildTimeoutMs: 30 * 60 * 1000,
  },

  // ─── Global Queue (jika semua worker penuh) ───────────────────────────────
  queue: {
    // Maks total job yang boleh antri di global queue
    maxQueueSize: 50,
    // Notifikasi posisi antrian ke user setiap N menit
    notifyIntervalMinutes: 5,
  },

  // ─── Build Settings ───────────────────────────────────────────────────────
  build: {
    outputDir: '/tmp/web2apk/builds',
    maxFileSizeMb: 2048,
    timeoutMinutes: 30,
    allowHttp: true,
    // Retry hanya untuk error yang BISA di-fix (bukan restart dari awal)
    maxRetries: 2,
    // Cache dependency untuk memangkas waktu build berulang
    cache: {
      enabled: true,
      dir: '/opt/web2apk/cache',
      maxAgeDays: 7,
      maxSizeGb: 10,
    },
  },

  // ─── Worker Health Monitor ────────────────────────────────────────────────
  // Bot ping tiap worker secara berkala, tandai offline jika tidak merespons
  healthMonitor: {
    enabled: true,
    intervalSeconds: 30,
    timeoutSeconds: 10,
    // Kirim alert ke admin jika ada worker offline
    alertAdminOnOffline: true,
  },

  // ─── URL to APK Settings ──────────────────────────────────────────────────
  urlToApk: {
    allowedProtocols: ['http', 'https'],
    allowCustomIcon: true,
    allowedIconFormats: ['image/png', 'image/jpeg', 'image/webp'],
    minIconSize: 512,
  },

  // ─── Database (folder & file JSON) ───────────────────────────────────────
  // Tidak ada .env / .env.example — semua konfigurasi di file ini
  database: {
    dir: './database',
    usersFile: './database/users.json',
    membersFile: './database/members.json',
    queueFile: './database/queue.json',
    workersFile: './database/workers.json',
    resellersFile: './database/resellers.json',
    approvalsFile: './database/approvals.json',
    buildsFile: './database/builds.json',
    paymentsFile: './database/payments.json',
    pricesFile: './database/prices.json',
    ordersFile: './database/orders.json',
  },

};

module.exports = config;

