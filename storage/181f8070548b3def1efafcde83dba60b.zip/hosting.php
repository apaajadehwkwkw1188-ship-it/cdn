<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config.php';

$action = $_GET['action'] ?? 'home';

$id = (int)($_GET['id'] ?? 0);
$trxId = $_GET['trx_id'] ?? '';
$isPayPressed = isset($_GET['pay']) && $_GET['pay'] == '1';

$showQris = false;
$paymentStatus = '';
$qrImage = '';

if ($action == 'checkout' && isset($products[$id])) {
    $item = $products[$id];

    if ($isPayPressed && empty($trxId)) {
        $postData = json_encode(['amount' => $item['harga'], 'method' => 'qris']);
        $ch = curl_init($baseUrl . '/deposit/create');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['X-API-Key: ' . $apiKey, 'Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $res = json_decode(curl_exec($ch), true);
        curl_close($ch);

        if (isset($res['success']) && $res['success'] == true) {
            $trxId = $res['data']['depositId'];
            $qrImage = $res['data']['qrImage'];
            $_SESSION['qr_'.$trxId] = $qrImage;
            header("Location: hosting.php?action=checkout&id=" . $id . "&trx_id=" . $trxId);
            exit;
        }
    }

    if (!empty($trxId)) {
        $showQris = true;
        $paymentStatus = 'pending';
        $qrImage = $_SESSION['qr_'.$trxId] ?? '';

        $ch = curl_init($baseUrl . '/deposit/status/' . $trxId);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['X-API-Key: ' . $apiKey]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $statusRes = json_decode(curl_exec($ch), true);
        curl_close($ch);

        if (isset($statusRes['success']) && $statusRes['success'] == true) {
            $rawStatus = strtolower($statusRes['data']['status']);
            if ($rawStatus == 'success' || $rawStatus == 'settlement') {
                $paymentStatus = 'success';
            }
            if (isset($statusRes['data']['qrImage'])) {
                $qrImage = $statusRes['data']['qrImage'];
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TOKO TEAM DAFXZ DAFXZ NESIA</title>

<meta property="og:type" content="website">
<meta property="og:title" content="DAFXZ NESIA">
<meta property="og:description" content="Website Terbaik Masa Kini. Auto Proses, Online 24 Jam Aman, Cepat dan Terpercaya.">

<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --white: #ffffff;
    --gray-50: #f8fafc;
    --gray-100: #f1f5f9;
    --gray-200: #e2e8f0;
    --gray-300: #cbd5e1;
    --gray-400: #94a3b8;
    --gray-500: #64748b;
    --gray-600: #475569;
    --gray-700: #334155;
    --gray-800: #1e293b;
    --gray-900: #0f172a;
    --blue-400: #60a5fa;
    --blue-500: #3b82f6;
    --blue-600: #2563eb;
    --blue-700: #1d4ed8;
    --cyan-400: #22d3ee;
    --cyan-500: #06b6d4;
    --green-400: #4ade80;
    --green-500: #22c55e;
    --red-500: #ef4444;
    --red-100: #fee2e2;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.07), 0 1px 2px rgba(0,0,0,0.05);
    --shadow-md: 0 4px 16px rgba(0,0,0,0.08), 0 2px 6px rgba(0,0,0,0.05);
    --shadow-lg: 0 10px 40px rgba(0,0,0,0.1), 0 4px 12px rgba(0,0,0,0.06);
    --shadow-blue: 0 4px 24px rgba(59,130,246,0.22);
    --radius-sm: 10px;
    --radius-md: 16px;
    --radius-lg: 24px;
    --radius-xl: 32px;
}

* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: 'Plus Jakarta Sans', sans-serif;
    background: var(--gray-50);
    color: var(--gray-800);
    overflow-x: hidden;
    padding-top: 72px;
    min-height: 100vh;
}

::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-track { background: var(--gray-100); }
::-webkit-scrollbar-thumb { background: var(--blue-500); border-radius: 999px; }

/* ── NAVBAR ── */
.navbar {
    position: fixed;
    top: 0; left: 0; width: 100%;
    height: 72px;
    background: rgba(255,255,255,0.92);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-bottom: 1px solid var(--gray-200);
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 6%;
    z-index: 1000;
    box-shadow: 0 1px 12px rgba(0,0,0,0.06);
}

.nav-brand {
    display: flex;
    align-items: center;
    gap: 10px;
    text-decoration: none;
}
.brand-icon-wrap {
    width: 38px; height: 38px;
    border-radius: 10px;
    background: linear-gradient(135deg, var(--blue-600), var(--cyan-500));
    display: flex; align-items: center; justify-content: center;
    font-size: 15px;
    color: white;
    box-shadow: var(--shadow-blue);
}
.nav-brand-text {
    font-family: 'Outfit', sans-serif;
    font-size: 18px;
    font-weight: 800;
    letter-spacing: 0.5px;
    color: var(--gray-900);
}
.nav-brand-text span {
    background: linear-gradient(90deg, var(--blue-600), var(--cyan-500));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.nav-toggle-btn {
    width: 40px; height: 40px;
    border-radius: 10px;
    background: var(--gray-100);
    border: 1px solid var(--gray-200);
    color: var(--gray-600);
    font-size: 15px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer;
    transition: all 0.2s;
}
.nav-toggle-btn:hover {
    background: var(--blue-500);
    border-color: var(--blue-500);
    color: white;
    box-shadow: var(--shadow-blue);
}

/* ── SIDEBAR ── */
.sidebar {
    position: fixed;
    top: 0; right: -300px;
    width: 290px; height: 100%;
    background: white;
    border-left: 1px solid var(--gray-200);
    z-index: 2000;
    transition: right 0.35s cubic-bezier(0.4, 0, 0.2, 1);
    padding: 30px 22px;
    display: flex;
    flex-direction: column;
    box-shadow: -8px 0 40px rgba(0,0,0,0.1);
}
.sidebar.active { right: 0; }

.sidebar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 32px;
}
.sidebar-title {
    font-family: 'Outfit', sans-serif;
    font-size: 13px;
    font-weight: 700;
    color: var(--gray-400);
    letter-spacing: 1.5px;
    text-transform: uppercase;
}
.sidebar-close-btn {
    background: var(--gray-100);
    border: 1px solid var(--gray-200);
    width: 32px; height: 32px;
    border-radius: 8px;
    color: var(--gray-500);
    font-size: 13px;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: all 0.2s;
}
.sidebar-close-btn:hover { background: var(--red-100); color: var(--red-500); border-color: transparent; }

.sidebar-menu-list { list-style: none; display: flex; flex-direction: column; gap: 4px; }
.sidebar-menu-item a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 14px;
    color: var(--gray-600);
    text-decoration: none;
    font-size: 14px;
    font-weight: 600;
    border-radius: 12px;
    transition: all 0.2s;
}
.sidebar-menu-item a i { width: 16px; text-align: center; font-size: 13px; color: var(--gray-400); transition: color 0.2s; }
.sidebar-menu-item a:hover {
    background: var(--gray-100);
    color: var(--blue-600);
}
.sidebar-menu-item a:hover i { color: var(--blue-500); }
.sidebar-menu-item.active a {
    background: linear-gradient(135deg, rgba(59,130,246,0.08), rgba(6,182,212,0.05));
    color: var(--blue-600);
    border: 1px solid rgba(59,130,246,0.15);
}
.sidebar-menu-item.active a i { color: var(--blue-500); }

.sidebar-overlay {
    position: fixed; inset: 0;
    background: rgba(15,23,42,0.4);
    backdrop-filter: blur(4px);
    z-index: 1500;
    display: none;
}
.sidebar-overlay.active { display: block; }

/* ── HERO ── */
.hero {
    padding: 48px 5% 36px;
    text-align: center;
    background: white;
    border-bottom: 1px solid var(--gray-200);
}
.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    background: linear-gradient(135deg, rgba(59,130,246,0.08), rgba(6,182,212,0.05));
    border: 1px solid rgba(59,130,246,0.2);
    padding: 6px 16px;
    border-radius: 999px;
    margin-bottom: 18px;
}
.hero-dot {
    width: 6px; height: 6px;
    background: var(--green-500);
    border-radius: 50%;
    box-shadow: 0 0 8px var(--green-500);
    animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse {
    0%,100% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.3); opacity: 0.7; }
}
.hero-badge-txt {
    font-size: 11px;
    font-weight: 700;
    color: var(--blue-600);
    letter-spacing: 1.5px;
    text-transform: uppercase;
}
.hero h1 {
    font-family: 'Outfit', sans-serif;
    font-size: 38px;
    font-weight: 900;
    color: var(--gray-900);
    line-height: 1.1;
    margin-bottom: 12px;
}
.hero h1 .grad {
    background: linear-gradient(135deg, var(--blue-600) 0%, var(--cyan-500) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.hero p {
    font-size: 15px;
    color: var(--gray-500);
    max-width: 400px;
    margin: 0 auto;
    line-height: 1.7;
    font-weight: 500;
}

/* ── STATS BAR ── */
.stats-bar {
    background: white;
    border-bottom: 1px solid var(--gray-200);
    padding: 14px 6%;
    display: flex;
    justify-content: center;
    gap: 40px;
}
.stat-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    font-weight: 600;
    color: var(--gray-500);
}
.stat-item i { color: var(--blue-500); font-size: 13px; }
.stat-item strong { color: var(--gray-800); font-size: 13px; }

/* ── MAIN CONTENT ── */
.page-wrapper {
    max-width: 1100px;
    margin: 0 auto;
    padding: 36px 5% 80px;
}

/* ── FEATURED CARD ── */
.featured-card {
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: var(--radius-lg);
    overflow: hidden;
    display: flex;
    align-items: stretch;
    min-height: 210px;
    box-shadow: var(--shadow-md);
    transition: all 0.3s ease;
    margin-bottom: 36px;
    position: relative;
}
.featured-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: linear-gradient(90deg, var(--blue-600), var(--cyan-500));
    z-index: 1;
}
.featured-card:hover {
    box-shadow: var(--shadow-lg);
    transform: translateY(-3px);
    border-color: rgba(59,130,246,0.25);
}

.featured-img-col {
    width: 280px;
    min-width: 280px;
    position: relative;
    overflow: hidden;
    flex-shrink: 0;
}
.featured-img-col img {
    width: 100%; height: 100%;
    object-fit: cover;
    display: block;
    transition: transform 0.5s ease;
}
.featured-card:hover .featured-img-col img { transform: scale(1.05); }
.featured-no-img {
    width: 100%; height: 100%;
    background: var(--gray-100);
    display: flex; align-items: center; justify-content: center;
    color: var(--gray-300); font-size: 56px;
}

.featured-content-col {
    flex: 1;
    padding: 30px 36px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 12px;
}
.featured-badges {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}
.badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 11px;
    border-radius: 6px;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
}
.badge-blue {
    background: rgba(59,130,246,0.08);
    border: 1px solid rgba(59,130,246,0.2);
    color: var(--blue-600);
}
.badge-red {
    background: rgba(239,68,68,0.06);
    border: 1px solid rgba(239,68,68,0.2);
    color: var(--red-500);
}
.featured-title {
    font-family: 'Outfit', sans-serif;
    font-size: 28px;
    font-weight: 900;
    color: var(--gray-900);
    line-height: 1.1;
}
.featured-title span {
    background: linear-gradient(90deg, var(--blue-600), var(--cyan-500));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.featured-desc {
    font-size: 14px;
    color: var(--gray-500);
    line-height: 1.7;
    max-width: 380px;
}
.featured-desc strong { color: var(--blue-600); }

.btn-primary {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    padding: 13px 24px;
    border-radius: var(--radius-sm);
    background: linear-gradient(135deg, var(--blue-600), var(--cyan-500));
    color: white;
    font-family: 'Outfit', sans-serif;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 0.5px;
    text-decoration: none;
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 16px rgba(59,130,246,0.3);
    transition: all 0.25s ease;
    align-self: flex-start;
    position: relative;
    overflow: hidden;
}
.btn-primary::after {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.12), transparent);
    opacity: 0;
    transition: opacity 0.25s;
}
.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 28px rgba(59,130,246,0.4);
}
.btn-primary:hover::after { opacity: 1; }
.btn-primary:active { transform: translateY(0); }
.btn-arrow { font-size: 10px; transition: transform 0.25s; }
.btn-primary:hover .btn-arrow { transform: translateX(3px); }

/* ── PRODUCT GRID ── */
.products {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 18px;
}

.product-card {
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: var(--radius-md);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    transition: all 0.25s ease;
    box-shadow: var(--shadow-sm);
    position: relative;
}
.product-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg, var(--blue-600), var(--cyan-500));
    opacity: 0;
    transition: opacity 0.25s;
    z-index: 1;
}
.product-card:hover {
    transform: translateY(-4px);
    border-color: rgba(59,130,246,0.25);
    box-shadow: var(--shadow-lg);
}
.product-card:hover::before { opacity: 1; }

.product-img-wrap { position: relative; overflow: hidden; }
.product-banner-img {
    width: 100%; height: 185px;
    object-fit: cover;
    display: block;
    transition: transform 0.45s ease;
}
.product-card:hover .product-banner-img { transform: scale(1.05); }
.product-img-overlay {
    position: absolute; inset: 0;
    background: linear-gradient(to top, rgba(15,23,42,0.55) 0%, transparent 55%);
}

.product-tag {
    position: absolute;
    top: 12px; right: 12px;
    background: white;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 10px;
    font-weight: 700;
    color: var(--blue-600);
    letter-spacing: 0.8px;
    box-shadow: var(--shadow-sm);
}

.product-content {
    padding: 18px 20px 20px;
    display: flex;
    flex-direction: column;
    flex-grow: 1;
    gap: 14px;
}

.product-title {
    font-family: 'Outfit', sans-serif;
    font-size: 16px;
    font-weight: 700;
    color: var(--gray-900);
    line-height: 1.3;
}

.product-price-block {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: var(--gray-50);
    border: 1px solid var(--gray-200);
    border-radius: var(--radius-sm);
    padding: 10px 14px;
}
.price-left {
    display: flex;
    flex-direction: column;
    gap: 1px;
}
.price-label {
    font-size: 10px;
    font-weight: 600;
    color: var(--gray-400);
    text-transform: uppercase;
    letter-spacing: 1px;
}
.price-value {
    font-family: 'Outfit', sans-serif;
    font-size: 22px;
    font-weight: 800;
    color: var(--gray-900);
    line-height: 1;
}
.price-value span {
    font-size: 13px;
    font-weight: 600;
    color: var(--gray-500);
    margin-right: 2px;
}
.price-badge {
    background: rgba(34,197,94,0.1);
    border: 1px solid rgba(34,197,94,0.2);
    color: #16a34a;
    font-size: 10px;
    font-weight: 700;
    padding: 4px 9px;
    border-radius: 6px;
    letter-spacing: 0.5px;
}

.buy-btn {
    width: 100%;
    border: none;
    padding: 12px 20px;
    border-radius: var(--radius-sm);
    background: var(--gray-900);
    color: white;
    font-family: 'Outfit', sans-serif;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 0.5px;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.25s ease;
    position: relative;
    overflow: hidden;
}
.buy-btn::after {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(135deg, var(--blue-600), var(--cyan-500));
    opacity: 0;
    transition: opacity 0.3s;
}
.buy-btn span, .buy-btn i { position: relative; z-index: 1; }
.buy-btn:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(0,0,0,0.2); }
.buy-btn:hover::after { opacity: 1; }
.buy-btn:active { transform: translateY(0); }

/* ───────────────────────────────────────────
   CHECKOUT — PANEL REDESIGN (ELEGANT)
─────────────────────────────────────────── */
.checkout-page {
    min-height: calc(100vh - 72px);
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding: 32px 16px 80px;
    background: var(--gray-50);
}

.panel-box {
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: var(--radius-xl);
    width: 100%;
    max-width: 500px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.08), 0 4px 16px rgba(0,0,0,0.04);
    animation: fadeUp 0.45s cubic-bezier(0.22,1,0.36,1);
    overflow: hidden;
}

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(22px); }
    to   { opacity: 1; transform: translateY(0); }
}

/* Panel top strip */
.panel-header-strip {
    background: linear-gradient(135deg, var(--gray-900) 0%, #1a2744 100%);
    padding: 24px 28px 22px;
    position: relative;
    overflow: hidden;
}
.panel-header-strip::before {
    content: '';
    position: absolute;
    top: -40px; right: -40px;
    width: 160px; height: 160px;
    border-radius: 50%;
    background: rgba(59,130,246,0.12);
}
.panel-header-strip::after {
    content: '';
    position: absolute;
    bottom: -30px; left: -20px;
    width: 100px; height: 100px;
    border-radius: 50%;
    background: rgba(6,182,212,0.08);
}
.panel-store-label {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.12);
    padding: 4px 11px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 700;
    color: rgba(255,255,255,0.6);
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin-bottom: 12px;
    position: relative; z-index: 1;
}
.panel-store-label i { font-size: 8px; color: var(--cyan-400); }
.panel-header-title {
    font-family: 'Outfit', sans-serif;
    font-size: 22px;
    font-weight: 800;
    color: white;
    line-height: 1.15;
    position: relative; z-index: 1;
}
.panel-header-title span {
    background: linear-gradient(90deg, var(--blue-400), var(--cyan-400));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.panel-header-sub {
    font-size: 12px;
    color: rgba(255,255,255,0.45);
    margin-top: 4px;
    font-weight: 500;
    position: relative; z-index: 1;
}

/* Product preview inside checkout */
.checkout-product-row {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 20px 28px;
    border-bottom: 1px solid var(--gray-100);
    background: var(--gray-50);
}
.checkout-product-thumb {
    width: 56px; height: 56px;
    min-width: 56px;
    border-radius: 14px;
    overflow: hidden;
    background: var(--gray-200);
    display: flex; align-items: center; justify-content: center;
    font-size: 20px;
    color: var(--gray-400);
    cursor: pointer;
    transition: all 0.25s;
    border: 2px solid var(--gray-200);
    box-shadow: var(--shadow-sm);
}
.checkout-product-thumb:hover { transform: scale(1.06); box-shadow: var(--shadow-md); border-color: rgba(59,130,246,0.3); }
.checkout-product-thumb img { width: 100%; height: 100%; object-fit: cover; }
.checkout-product-meta { flex: 1; }
.checkout-product-name {
    font-family: 'Outfit', sans-serif;
    font-size: 15px;
    font-weight: 700;
    color: var(--gray-900);
    line-height: 1.3;
}
.checkout-product-hint {
    font-size: 11px;
    color: var(--gray-400);
    margin-top: 3px;
    font-weight: 500;
}
.checkout-product-price-tag {
    font-family: 'Outfit', sans-serif;
    font-size: 18px;
    font-weight: 900;
    color: var(--gray-900);
    white-space: nowrap;
}
.checkout-product-price-tag small {
    font-size: 11px;
    font-weight: 600;
    color: var(--gray-400);
    display: block;
    text-align: right;
    margin-bottom: 1px;
}

/* Summary lines */
.summary-section {
    padding: 20px 28px 0;
}
.summary-heading {
    font-family: 'Outfit', sans-serif;
    font-size: 12px;
    font-weight: 700;
    color: var(--gray-400);
    letter-spacing: 1.8px;
    text-transform: uppercase;
    margin-bottom: 14px;
}
.summary-line {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
    color: var(--gray-500);
    font-weight: 500;
    padding: 8px 0;
    border-bottom: 1px dashed var(--gray-100);
}
.summary-line:last-child { border-bottom: none; }
.summary-line .s-label { display: flex; align-items: center; gap: 7px; }
.summary-line .s-label i { color: var(--gray-300); font-size: 11px; width: 14px; text-align: center; }
.summary-line .s-val { font-weight: 600; color: var(--gray-700); font-family: 'Outfit', sans-serif; font-size: 13px; }
.summary-line .s-val.accent { color: var(--blue-600); }
.summary-line .s-val.free {
    color: #16a34a;
    background: rgba(34,197,94,0.08);
    border: 1px solid rgba(34,197,94,0.2);
    font-size: 10px;
    font-weight: 700;
    padding: 2px 8px;
    border-radius: 5px;
    letter-spacing: 0.5px;
}

/* Total bar */
.total-bar {
    margin: 16px 28px 0;
    background: linear-gradient(135deg, var(--gray-900), #1a2744);
    border-radius: var(--radius-md);
    padding: 16px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.total-bar-left {
    display: flex;
    flex-direction: column;
    gap: 2px;
}
.total-bar-label {
    font-size: 10px;
    font-weight: 700;
    color: rgba(255,255,255,0.45);
    text-transform: uppercase;
    letter-spacing: 1.5px;
}
.total-bar-amount {
    font-family: 'Outfit', sans-serif;
    font-size: 26px;
    font-weight: 900;
    color: white;
    line-height: 1;
}
.total-bar-amount small {
    font-size: 13px;
    font-weight: 600;
    color: rgba(255,255,255,0.5);
    margin-right: 3px;
}
.total-bar-badge {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 4px;
}
.total-bar-badge span {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.12);
    color: rgba(255,255,255,0.6);
    font-size: 10px;
    font-weight: 700;
    padding: 3px 9px;
    border-radius: 5px;
    letter-spacing: 0.5px;
}
.total-bar-badge .qris-label {
    background: rgba(59,130,246,0.2);
    border-color: rgba(59,130,246,0.35);
    color: var(--blue-400);
}

/* Paid state */
.total-bar.paid {
    background: linear-gradient(135deg, #14532d, #166534);
}
.total-bar.paid .total-bar-amount { color: #86efac; }

/* ── QRIS / PAYMENT AREA ── */
.payment-area {
    margin: 20px 28px 0;
}

/* QRIS pending */
.qris-card {
    border: 1.5px dashed var(--gray-300);
    border-radius: var(--radius-md);
    background: var(--gray-50);
    overflow: hidden;
}
.qris-card-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 16px;
    border-bottom: 1px solid var(--gray-200);
    background: white;
}
.qris-method-label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    font-weight: 700;
    color: var(--gray-700);
}
.qris-method-label i { color: var(--blue-500); font-size: 14px; }
.qris-status-dot {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 10px;
    font-weight: 700;
    color: #d97706;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    background: rgba(251,191,36,0.1);
    border: 1px solid rgba(251,191,36,0.25);
    padding: 3px 10px;
    border-radius: 999px;
}
.qris-status-dot i { font-size: 8px; animation: pulse 1.5s ease-in-out infinite; }

.qris-img-wrap {
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
}
.qris-img-wrap img {
    width: 180px; height: 180px;
    object-fit: contain;
    border-radius: 10px;
    box-shadow: var(--shadow-md);
    border: 1px solid var(--gray-200);
    background: white;
    padding: 6px;
}
.qris-scan-hint {
    font-size: 11px;
    font-weight: 600;
    color: var(--gray-400);
    text-align: center;
    line-height: 1.6;
}

.trx-id-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: 8px;
    padding: 8px 14px;
    margin-top: 4px;
}
.trx-id-label {
    font-size: 10px;
    font-weight: 700;
    color: var(--gray-400);
    text-transform: uppercase;
    letter-spacing: 1px;
}
.trx-id-val {
    font-family: monospace;
    font-size: 11px;
    color: var(--gray-600);
    font-weight: 600;
    max-width: 200px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

/* SUCCESS state */
.success-card {
    border: 1px solid rgba(34,197,94,0.25);
    border-radius: var(--radius-md);
    background: rgba(34,197,94,0.03);
    padding: 28px 20px;
    text-align: center;
}
.success-anim {
    width: 72px; height: 72px;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(34,197,94,0.15), rgba(34,197,94,0.05));
    border: 2px solid rgba(34,197,94,0.3);
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 16px;
    font-size: 30px;
    color: var(--green-500);
    animation: successPop 0.5s cubic-bezier(0.34,1.6,0.64,1);
}
@keyframes successPop {
    0% { transform: scale(0.5); opacity: 0; }
    100% { transform: scale(1); opacity: 1; }
}
.success-title {
    font-family: 'Outfit', sans-serif;
    font-size: 20px;
    font-weight: 800;
    color: #15803d;
    margin-bottom: 6px;
}
.success-desc {
    font-size: 12px;
    color: var(--gray-500);
    line-height: 1.7;
    max-width: 300px;
    margin: 0 auto;
    font-weight: 500;
}
.success-trx {
    margin-top: 14px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: white;
    border: 1px solid rgba(34,197,94,0.2);
    padding: 6px 14px;
    border-radius: 8px;
    font-family: monospace;
    font-size: 11px;
    color: #16a34a;
    font-weight: 600;
}

/* ── ACTION BUTTONS ── */
.action-area {
    padding: 20px 28px 28px;
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.btn-checkout {
    width: 100%;
    border: none;
    padding: 15px 20px;
    border-radius: var(--radius-sm);
    background: linear-gradient(135deg, var(--blue-700) 0%, var(--blue-600) 50%, var(--cyan-500) 100%);
    color: white;
    font-family: 'Outfit', sans-serif;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    transition: all 0.25s;
    box-shadow: 0 4px 20px rgba(59,130,246,0.35);
    letter-spacing: 0.3px;
    position: relative;
    overflow: hidden;
}
.btn-checkout::after {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.1), transparent);
    opacity: 0; transition: opacity 0.2s;
}
.btn-checkout:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 30px rgba(59,130,246,0.45);
}
.btn-checkout:hover::after { opacity: 1; }
.btn-checkout:active { transform: translateY(0); }

.btn-checkout.green-btn {
    background: linear-gradient(135deg, #16a34a, #15803d);
    box-shadow: 0 4px 20px rgba(34,197,94,0.3);
}
.btn-checkout.green-btn:hover { box-shadow: 0 8px 30px rgba(34,197,94,0.4); }

.btn-cancel {
    width: 100%;
    padding: 13px 20px;
    border-radius: var(--radius-sm);
    background: var(--gray-100);
    border: 1px solid var(--gray-200);
    color: var(--gray-600);
    font-family: 'Outfit', sans-serif;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.2s;
}
.btn-cancel:hover { background: var(--red-100); color: var(--red-500); border-color: transparent; }

/* Trust strip at bottom of panel */
.trust-strip {
    padding: 14px 28px;
    border-top: 1px solid var(--gray-100);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 20px;
    background: var(--gray-50);
}
.trust-item {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 10px;
    font-weight: 700;
    color: var(--gray-400);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.trust-item i { color: var(--blue-500); font-size: 11px; }

/* ── SOCIAL PROOF SECTION ── */
.social-proof {
    background: white;
    border-top: 1px solid var(--gray-200);
    border-bottom: 1px solid var(--gray-200);
    padding: 48px 6% 52px;
    margin-top: 10px;
}
.social-proof-inner {
    max-width: 1100px;
    margin: 0 auto;
}
.social-proof-top {
    text-align: center;
    margin-bottom: 40px;
}
.social-proof-top h2 {
    font-family: 'Outfit', sans-serif;
    font-size: 26px;
    font-weight: 800;
    color: var(--gray-900);
    margin-bottom: 8px;
}
.social-proof-top h2 span {
    background: linear-gradient(90deg, var(--blue-600), var(--cyan-500));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.social-proof-top p {
    font-size: 14px;
    color: var(--gray-500);
    font-weight: 500;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 40px;
}
.stat-card {
    background: var(--gray-50);
    border: 1px solid var(--gray-200);
    border-radius: var(--radius-md);
    padding: 22px 16px;
    text-align: center;
    transition: all 0.25s;
}
.stat-card:hover {
    border-color: rgba(59,130,246,0.25);
    box-shadow: var(--shadow-md);
    transform: translateY(-2px);
}
.stat-icon {
    width: 44px; height: 44px;
    border-radius: 12px;
    background: linear-gradient(135deg, rgba(59,130,246,0.1), rgba(6,182,212,0.07));
    border: 1px solid rgba(59,130,246,0.15);
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 12px;
    font-size: 18px;
    color: var(--blue-600);
}
.stat-number {
    font-family: 'Outfit', sans-serif;
    font-size: 28px;
    font-weight: 900;
    color: var(--gray-900);
    line-height: 1;
    margin-bottom: 4px;
}
.stat-number span {
    background: linear-gradient(90deg, var(--blue-600), var(--cyan-500));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.stat-desc {
    font-size: 12px;
    font-weight: 600;
    color: var(--gray-500);
    text-transform: uppercase;
    letter-spacing: 0.8px;
}

.rating-row {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    margin-bottom: 6px;
}
.star { color: #f59e0b; font-size: 16px; }
.rating-num {
    font-family: 'Outfit', sans-serif;
    font-size: 15px;
    font-weight: 800;
    color: var(--gray-800);
    margin-left: 6px;
}

.cta-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
    margin-top: 10px;
}
.wa-card {
    background: linear-gradient(135deg, #dcfce7, #f0fdf4);
    border: 1px solid #86efac;
    border-radius: var(--radius-md);
    padding: 22px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    text-decoration: none;
    transition: all 0.25s;
}
.wa-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 28px rgba(34,197,94,0.2);
    border-color: #4ade80;
}
.wa-icon {
    width: 52px; height: 52px;
    min-width: 52px;
    border-radius: 14px;
    background: #25d366;
    display: flex; align-items: center; justify-content: center;
    font-size: 24px;
    color: white;
    box-shadow: 0 4px 16px rgba(37,211,102,0.35);
    flex-shrink: 0;
}
.wa-info h4 {
    font-family: 'Outfit', sans-serif;
    font-size: 15px;
    font-weight: 800;
    color: #15803d;
    margin-bottom: 3px;
}
.wa-info p {
    font-size: 12px;
    font-weight: 600;
    color: #16a34a;
    opacity: 0.8;
}
.wa-info span {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: white;
    border: 1px solid #86efac;
    color: #16a34a;
    font-size: 10px;
    font-weight: 700;
    padding: 3px 9px;
    border-radius: 999px;
    margin-top: 6px;
    letter-spacing: 0.5px;
}

.brand-card {
    background: linear-gradient(135deg, rgba(59,130,246,0.05), rgba(6,182,212,0.03));
    border: 1px solid rgba(59,130,246,0.18);
    border-radius: var(--radius-md);
    padding: 22px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
}
.brand-logo {
    width: 52px; height: 52px;
    min-width: 52px;
    border-radius: 14px;
    background: linear-gradient(135deg, var(--blue-600), var(--cyan-500));
    display: flex; align-items: center; justify-content: center;
    font-size: 22px;
    color: white;
    box-shadow: var(--shadow-blue);
    flex-shrink: 0;
}
.brand-info h4 {
    font-family: 'Outfit', sans-serif;
    font-size: 15px;
    font-weight: 800;
    color: var(--gray-900);
    margin-bottom: 3px;
}
.brand-info p {
    font-size: 12px;
    color: var(--gray-500);
    font-weight: 500;
    line-height: 1.5;
}
.trust-badges {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    margin-top: 8px;
}
.trust-badge {
    background: white;
    border: 1px solid var(--gray-200);
    color: var(--gray-600);
    font-size: 10px;
    font-weight: 700;
    padding: 3px 8px;
    border-radius: 6px;
    letter-spacing: 0.3px;
}

/* Footer */
.footer-bar {
    background: var(--gray-900);
    padding: 24px 6%;
    text-align: center;
}
.footer-inner {
    max-width: 1100px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
}
.footer-brand {
    display: flex;
    align-items: center;
    gap: 9px;
}
.footer-brand-icon {
    width: 30px; height: 30px;
    border-radius: 8px;
    background: linear-gradient(135deg, var(--blue-600), var(--cyan-500));
    display: flex; align-items: center; justify-content: center;
    font-size: 13px;
    color: white;
}
.footer-brand-txt {
    font-family: 'Outfit', sans-serif;
    font-size: 14px;
    font-weight: 800;
    color: white;
}
.footer-brand-txt span {
    background: linear-gradient(90deg, var(--blue-400), var(--cyan-400));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.footer-copy {
    font-size: 12px;
    color: #64748b;
    font-weight: 500;
}
.footer-links {
    display: flex;
    gap: 16px;
}
.footer-links a {
    font-size: 12px;
    color: #64748b;
    text-decoration: none;
    font-weight: 600;
    transition: color 0.2s;
}
.footer-links a:hover { color: var(--blue-400); }

/* Lightbox */
.lightbox-overlay {
    position: fixed; inset: 0;
    background: rgba(0,0,0,0.7);
    backdrop-filter: blur(10px);
    z-index: 9999;
    display: flex; align-items: center; justify-content: center;
    opacity: 0; pointer-events: none;
    transition: opacity 0.3s;
}
.lightbox-overlay.show { opacity: 1; pointer-events: auto; }
.lightbox-content { position: relative; max-width: 85%; max-height: 80vh; }
.lightbox-img {
    max-width: 100%; max-height: 80vh;
    border-radius: 16px;
    box-shadow: 0 30px 80px rgba(0,0,0,0.4);
    transform: scale(0.92);
    transition: transform 0.3s cubic-bezier(0.34,1.4,0.64,1);
    display: none;
}
.lightbox-overlay.show .lightbox-img { transform: scale(1); }
.lightbox-close {
    position: absolute; top: -44px; right: 0;
    background: white;
    border: none;
    width: 36px; height: 36px;
    border-radius: 10px;
    color: var(--gray-600);
    font-size: 15px;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: 0.2s;
    box-shadow: var(--shadow-md);
}
.lightbox-close:hover { background: var(--red-100); color: var(--red-500); }

@media (max-width: 900px) {
    .hero h1 { font-size: 28px; }
    .featured-card { flex-direction: column; }
    .featured-img-col { width: 100%; min-width: unset; height: 170px; }
    .featured-content-col { padding: 22px 20px; }
    .featured-title { font-size: 22px; }
    .products { grid-template-columns: repeat(2, 1fr); gap: 12px; }
    .product-banner-img { height: 130px; }
    .product-title { font-size: 14px; }
    .price-value { font-size: 18px; }
    .stats-bar { gap: 20px; flex-wrap: wrap; }
    .panel-box { border-radius: var(--radius-lg); }
    .panel-header-strip, .summary-section, .action-area, .payment-area { padding-left: 20px; padding-right: 20px; }
    .checkout-product-row { padding-left: 20px; padding-right: 20px; }
    .total-bar { margin-left: 20px; margin-right: 20px; }
    .trust-strip { padding-left: 20px; padding-right: 20px; gap: 12px; }
    .stats-grid { grid-template-columns: repeat(2, 1fr); }
    .cta-row { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<nav class="navbar">
    <a class="nav-brand" href="hosting.php">
        <div class="brand-icon-wrap">
            <i class="fa-solid fa-wand-magic-sparkles"></i>
        </div>
        <div class="nav-brand-text">DAFXZ <span>OFFICIAL</span></div>
    </a>
    <button class="nav-toggle-btn" onclick="toggleSidebar()">
        <i class="fa-solid fa-bars"></i>
    </button>
</nav>

<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>
<div class="sidebar" id="sidebarMenu">
    <div class="sidebar-header">
        <div class="sidebar-title">Menu</div>
        <button class="sidebar-close-btn" onclick="toggleSidebar()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <ul class="sidebar-menu-list">
        <li class="sidebar-menu-item <?= $action == 'home' ? 'active' : '' ?>">
            <a href="hosting.php"><i class="fa-solid fa-house"></i> Beranda</a>
        </li>
        <li class="sidebar-menu-item">
            <a href="jasteb.php"><i class="fa-solid fa-fire-flame-curved"></i> Order Jasteb</a>
        </li>
        <li class="sidebar-menu-item">
            <a href="https://whatsapp.com/channel/0029VbBfjDvHVvTimoAAuh04" target="_blank"><i class="fa-solid fa-bullhorn"></i> Saluran</a>
        </li>
        <li class="sidebar-menu-item">
            <a href="https://wa.me/6283830159806" target="_blank"><i class="fa-solid fa-user-shield"></i> Owner</a>
        </li>
    </ul>
</div>

<?php if($action == 'home'): ?>

<section class="hero">
    <div class="hero-badge">
        <div class="hero-dot"></div>
        <span class="hero-badge-txt">Online 24 Jam · Auto Proses</span>
    </div>
    <h1>WEB STORE <span class="grad">Dafxz</span></h1>
    <p>Sistem otomatisasi Jasteb instan 24 jam non-stop dan sangat Terpercaya.</p>
</section>

<div class="stats-bar">
    <div class="stat-item"><i class="fa-solid fa-bolt"></i> <strong>Instan</strong> Auto Aktivasi</div>
    <div class="stat-item"><i class="fa-solid fa-lock"></i> <strong>Aman</strong> Payment Secure</div>
    <div class="stat-item"><i class="fa-solid fa-headset"></i> <strong>24/7</strong> Support</div>
    <div class="stat-item"><i class="fa-solid fa-star"></i> <strong>Terpercaya</strong></div>
</div>

<div class="page-wrapper">

    <!-- FEATURED / JASTEB CARD -->
    <div class="featured-card">
        <div class="featured-img-col">
            <img src="https://i.ibb.co.com/fzhQ2jJ8/file-000000001ec872078119292b33d95db5.png" alt="Featured Product">
        </div>
        <div class="featured-content-col">
            <div class="featured-badges">
                <div class="badge badge-blue"><i class="fa-solid fa-fire"></i> JASTEB</div>
                <div class="badge badge-red"><i class="fa-solid fa-bolt"></i> UNCHAK FRESH</div>
            </div>
            <div class="featured-title">JASTEB <span>GACOR</span></div>
            <div class="featured-desc">
                Jasteb adalah Data Akun Atau Bisa di sebut UNCHAK FRESH. <strong>Terdapat Akun FF / ML / Roblox</strong>.
            </div>
            <a href="jasteb.php" class="btn-primary">
                <i class="fa-solid fa-cart-shopping"></i>
                <span>Beli Sekarang</span>
                <i class="fa-solid fa-arrow-right btn-arrow"></i>
            </a>
        </div>
    </div>

    <!-- PRODUCT GRID (no header labels) -->
    <div class="products">
        <?php foreach($products as $item): ?>
        <div class="product-card">
            <?php if(!empty($item['gambar'])): ?>
            <div class="product-img-wrap">
                <img src="<?= htmlspecialchars($item['gambar']) ?>" class="product-banner-img" alt="<?= htmlspecialchars($item['nama']) ?>">
                <div class="product-img-overlay"></div>
                <div class="product-tag">PREMIUM</div>
            </div>
            <?php else: ?>
            <div style="height:8px;"></div>
            <?php endif; ?>

            <div class="product-content">
                <div class="product-title"><?= htmlspecialchars($item['nama']) ?></div>

                <div class="product-price-block">
                    <div class="price-left">
                        <div class="price-label">Harga</div>
                        <div class="price-value"><span>Rp</span><?= number_format($item['harga']) ?></div>
                    </div>
                    <div class="price-badge">TERSEDIA</div>
                </div>

                <a class="buy-btn" href="?action=checkout&id=<?= $item['id'] ?>" onclick="handleBtnLoading(this, 'Memproses...')">
                    <i class="fa-solid fa-cart-shopping"></i>
                    <span>Checkout</span>
                    <i class="fa-solid fa-arrow-right btn-arrow"></i>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

</div>

<!-- SOCIAL PROOF -->
<section class="social-proof">
    <div class="social-proof-inner">
        <div class="social-proof-top">
            <h2>Dipercaya <span>Ribuan Pelanggan</span></h2>
            <p>Bergabung bersama pelanggan setia Dafxz Official yang puas dengan layanan kami</p>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-users"></i></div>
                <div class="stat-number"><span>1K+</span></div>
                <div class="stat-desc">Pelanggan Aktif</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-bag-shopping"></i></div>
                <div class="stat-number"><span>5K+</span></div>
                <div class="stat-desc">Transaksi Berhasil</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-star"></i></div>
                <div>
                    <div class="rating-row">
                        <i class="fa-solid fa-star star"></i>
                        <i class="fa-solid fa-star star"></i>
                        <i class="fa-solid fa-star star"></i>
                        <i class="fa-solid fa-star star"></i>
                        <i class="fa-solid fa-star star"></i>
                        <span class="rating-num">5.0</span>
                    </div>
                    <div class="stat-desc" style="margin-top:8px;">Rating Kepuasan</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-bolt"></i></div>
                <div class="stat-number"><span>24/7</span></div>
                <div class="stat-desc">Online &amp; Support</div>
            </div>
        </div>

        <div class="cta-row">
            <a href="https://wa.me/6287796882859" target="_blank" class="wa-card">
                <div class="wa-icon"><i class="fa-brands fa-whatsapp"></i></div>
                <div class="wa-info">
                    <h4>WhatsApp Support</h4>
                    <p>Respon cepat, siap bantu 24 jam</p>
                    <span><i class="fa-solid fa-circle" style="font-size:7px;color:#16a34a;"></i> Online Sekarang</span>
                </div>
            </a>
            <div class="brand-card">
                <div class="brand-logo"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
                <div class="brand-info">
                    <h4>Dafxz <span style="background:linear-gradient(90deg,#2563eb,#06b6d4);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Official</span></h4>
                    <p>Platform jasteb terpercaya, aman &amp; otomatis proses instan</p>
                    <div class="trust-badges">
                        <span class="trust-badge"><i class="fa-solid fa-shield-check" style="color:var(--blue-500);"></i> Verified</span>
                        <span class="trust-badge"><i class="fa-solid fa-lock" style="color:var(--blue-500);"></i> Secure</span>
                        <span class="trust-badge"><i class="fa-solid fa-bolt" style="color:#f59e0b;"></i> Auto</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php elseif($action == 'checkout'): ?>

<?php
if(!isset($products[$id])){
    die('<div style="padding:40px;text-align:center;"><h3 style="color:var(--red-500);">Produk tidak ditemukan</h3></div>');
}
?>

<div class="checkout-page">
<div class="panel-box">

    <!-- TOP HEADER STRIP -->
    <div class="panel-header-strip">
        <div class="panel-store-label">
            <i class="fa-solid fa-wand-magic-sparkles"></i> DAFXZ OFFICIAL
        </div>
        <div class="panel-header-title">
            <?php if($showQris && $paymentStatus == 'success'): ?>
                Pembayaran <span>Berhasil!</span>
            <?php elseif($showQris): ?>
                Scan &amp; <span>Bayar</span>
            <?php else: ?>
                Konfirmasi <span>Pesanan</span>
            <?php endif; ?>
        </div>
        <div class="panel-header-sub">
            <?php if($showQris && $paymentStatus == 'success'): ?>
                Transaksi telah terverifikasi · Terima kasih!
            <?php elseif($showQris): ?>
                Gunakan aplikasi e-wallet / m-banking untuk scan QRIS
            <?php else: ?>
                Periksa rincian pesanan sebelum melanjutkan pembayaran
            <?php endif; ?>
        </div>
    </div>

    <!-- PRODUCT ROW -->
    <div class="checkout-product-row">
        <div class="checkout-product-thumb" onclick="openLightbox('<?= !empty($item['gambar']) ? htmlspecialchars($item['gambar']) : '' ?>')">
            <?php if(!empty($item['gambar'])): ?>
                <img src="<?= htmlspecialchars($item['gambar']) ?>" alt="img">
            <?php else: ?>
                <i class="fa-solid fa-server"></i>
            <?php endif; ?>
        </div>
        <div class="checkout-product-meta">
            <div class="checkout-product-name"><?= htmlspecialchars($item['nama']) ?></div>
            <div class="checkout-product-hint">Tap ikon untuk preview gambar produk</div>
        </div>
        <div class="checkout-product-price-tag">
            <small>Harga</small>
            Rp <?= number_format($item['harga']) ?>
        </div>
    </div>

    <!-- ORDER SUMMARY -->
    <div class="summary-section">
        <div class="summary-heading">Ringkasan Pesanan</div>

        <div class="summary-line">
            <div class="s-label"><i class="fa-solid fa-tag"></i> Nama Produk</div>
            <div class="s-val accent"><?= htmlspecialchars($item['nama']) ?></div>
        </div>
        <div class="summary-line">
            <div class="s-label"><i class="fa-solid fa-receipt"></i> Subtotal</div>
            <div class="s-val">Rp <?= number_format($item['harga']) ?></div>
        </div>
        <div class="summary-line">
            <div class="s-label"><i class="fa-solid fa-percent"></i> Diskon Member</div>
            <div class="s-val free">GRATIS</div>
        </div>
        <div class="summary-line">
            <div class="s-label"><i class="fa-solid fa-building-columns"></i> Biaya Admin</div>
            <div class="s-val free">GRATIS</div>
        </div>
    </div>

    <!-- TOTAL BAR -->
    <div class="total-bar <?= ($showQris && $paymentStatus == 'success') ? 'paid' : '' ?>">
        <div class="total-bar-left">
            <div class="total-bar-label">Total Pembayaran</div>
            <?php if($showQris && $paymentStatus == 'success'): ?>
                <div class="total-bar-amount" style="font-size:18px;color:#86efac;display:flex;align-items:center;gap:8px;">
                    <i class="fa-solid fa-circle-check"></i> LUNAS
                </div>
            <?php else: ?>
                <div class="total-bar-amount"><small>Rp</small><?= number_format($item['harga']) ?></div>
            <?php endif; ?>
        </div>
        <div class="total-bar-badge">
            <?php if($showQris && $paymentStatus == 'success'): ?>
                <span style="background:rgba(34,197,94,0.2);border-color:rgba(34,197,94,0.35);color:#86efac;"><i class="fa-solid fa-shield-check"></i> VERIFIED</span>
            <?php else: ?>
                <span class="qris-label"><i class="fa-solid fa-qrcode"></i> QRIS</span>
                <span><i class="fa-solid fa-bolt"></i> Instan</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- PAYMENT / STATUS AREA -->
    <?php if($showQris): ?>
    <div class="payment-area">
        <?php if($paymentStatus == 'success'): ?>
            <div class="success-card">
                <div class="success-anim">
                    <i class="fa-solid fa-check"></i>
                </div>
                <div class="success-title">Transaksi Berhasil!</div>
                <div class="success-desc">Silahkan klik <strong>Join Grup Premium</strong> di bawah. Jika link grup error, hubungi admin.</div>
                <div class="success-trx">
                    <i class="fa-solid fa-receipt"></i> <?= htmlspecialchars($trxId) ?>
                </div>
            </div>
        <?php else: ?>
            <div class="qris-card">
                <div class="qris-card-top">
                    <div class="qris-method-label">
                        <i class="fa-solid fa-qrcode"></i> Bayar via QRIS
                    </div>
                    <div class="qris-status-dot">
                        <i class="fa-solid fa-circle"></i> Menunggu
                    </div>
                </div>
                <div class="qris-img-wrap">
                    <img src="<?= htmlspecialchars($qrImage) ?>" alt="QRIS Code">
                    <div class="qris-scan-hint">Scan menggunakan GoPay, OVO, DANA,<br>ShopeePay, atau m-Banking manapun</div>
                    <div class="trx-id-row">
                        <div class="trx-id-label"><i class="fa-solid fa-hashtag"></i> ID Transaksi</div>
                        <div class="trx-id-val"><?= htmlspecialchars($trxId) ?></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- ACTION BUTTONS -->
    <div class="action-area">
        <?php if(!$showQris): ?>
            <form id="payment_form" method="GET" action="hosting.php" style="display:contents;">
                <input type="hidden" name="action" value="checkout">
                <input type="hidden" name="id" value="<?= $id ?>">
                <input type="hidden" name="pay" value="1">
                <button type="submit" class="btn-checkout" onclick="handleBtnLoading(this, 'Memproses Invoice...')">
                    <i class="fa-solid fa-wallet"></i>
                    Bayar Sekarang
                    <i class="fa-solid fa-arrow-right"></i>
                </button>
            </form>
            <a href="?action=home" class="btn-cancel">
                <i class="fa-solid fa-xmark"></i> Batalkan Pesanan
            </a>
        <?php elseif($paymentStatus == 'pending'): ?>
            <a href="hosting.php?action=checkout&id=<?= $id ?>&trx_id=<?= $trxId ?>" class="btn-checkout" onclick="handleBtnLoading(this, 'Mengecek Status...')">
                <i class="fa-solid fa-arrow-rotate-right"></i>
                Cek Status Pembayaran
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        <?php elseif($paymentStatus == 'success'): ?>
            <a href="<?= htmlspecialchars($item['link_produk'] ?? '#') ?>" target="_blank" class="btn-checkout green-btn">
                <i class="fa-solid fa-users"></i>
                Join Grup Premium
                <i class="fa-solid fa-arrow-right"></i>
            </a>
            <a href="hosting.php" class="btn-cancel">
                <i class="fa-solid fa-house"></i> Kembali ke Beranda
            </a>
        <?php endif; ?>
    </div>

    <!-- TRUST STRIP -->
    <div class="trust-strip">
        <div class="trust-item"><i class="fa-solid fa-lock"></i> Secure Payment</div>
        <div class="trust-item"><i class="fa-solid fa-bolt"></i> Instan Proses</div>
        <div class="trust-item"><i class="fa-solid fa-headset"></i> Support 24/7</div>
    </div>

</div>
</div>

<?php endif; ?>

<footer class="footer-bar">
    <div class="footer-inner">
        <div class="footer-brand">
            <div class="footer-brand-icon"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
            <div class="footer-brand-txt">DAFXZ <span>OFFICIAL</span></div>
        </div>
        <div class="footer-copy">© 2026 Dafxz Official Store · All rights reserved</div>
        <div class="footer-links">
            <a href="https://wa.me/6287796882859" target="_blank"><i class="fa-brands fa-whatsapp"></i> Support</a>
            <a href="jasteb.php"><i class="fa-solid fa-fire"></i> Jasteb</a>
        </div>
    </div>
</footer>

<!-- LIGHTBOX -->
<div class="lightbox-overlay" id="lightboxOverlay" onclick="closeLightbox()">
    <div class="lightbox-content" onclick="event.stopPropagation()">
        <button class="lightbox-close" onclick="closeLightbox()"><i class="fa-solid fa-xmark"></i></button>
        <img src="" alt="Preview" class="lightbox-img" id="lightboxImg">
    </div>
</div>

<script>
    function toggleSidebar() {
        document.getElementById('sidebarMenu').classList.toggle('active');
        document.getElementById('sidebarOverlay').classList.toggle('active');
    }

    function handleBtnLoading(el, txt) {
        el.style.pointerEvents = 'none';
        el.style.opacity = '0.75';
        el.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> ${txt}`;
    }

    function openLightbox(src) {
        if (!src) return;
        const overlay = document.getElementById('lightboxOverlay');
        const img = document.getElementById('lightboxImg');
        img.src = src;
        img.style.display = 'block';
        overlay.classList.add('show');
    }
    function closeLightbox() {
        document.getElementById('lightboxOverlay').classList.remove('show');
    }
</script>
</body>
</html>
