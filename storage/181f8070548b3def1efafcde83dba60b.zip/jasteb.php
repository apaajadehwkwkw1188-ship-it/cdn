<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_GET['clear_session'])) {
    unset($_SESSION['current_trx_id']);
    unset($_SESSION['current_local_trx_id']);
    unset($_SESSION['current_qr_img']);
    unset($_SESSION['current_prod_id']);
    unset($_SESSION['current_payment_status']);
    header("Location: jasteb.php");
    exit;
}

require_once 'config.php';

$products = [];

if (isset($products1) && is_array($products1)) {
    foreach ($products1 as $index => $item) {
        $products[$index] = [
            'id'     => $item['id'] ?? $index,
            'nama'   => ($item['result'] ?? '0') . ' Result - ' . ($item['label'] ?? 'Package'),
            'harga'  => $item['price'] ?? 0,
            'result' => $item['result'] ?? '',
            'label'  => $item['label'] ?? ''
        ];
    }
}

$action = $_GET['action'] ?? 'home';

if ($action === 'home') {
    unset($_SESSION['current_trx_id']);
    unset($_SESSION['current_local_trx_id']);
    unset($_SESSION['current_qr_img']);
    unset($_SESSION['current_prod_id']);
    unset($_SESSION['current_payment_status']);
}

$item = null;
$showQris = false;
$localTrxId = '';
$trxId = '';
$qrImage = '';
$paymentStatus = '';

if ($action == 'checkout') {
    $id = (int)($_GET['id'] ?? 0);
    if (isset($products[$id])) {
        $item = $products[$id];

        $isPayPressed         = isset($_POST['pay']) && $_POST['pay'] == '1';
        $isCheckStatusPressed = isset($_GET['check']) && $_GET['check'] == '1';

        if (isset($_SESSION['current_prod_id']) && $_SESSION['current_prod_id'] != $id) {
            unset($_SESSION['current_trx_id']);
            unset($_SESSION['current_local_trx_id']);
            unset($_SESSION['current_qr_img']);
            unset($_SESSION['current_prod_id']);
            unset($_SESSION['current_payment_status']);
        }

        $localTrxId    = $_GET['trx_id'] ?? $_SESSION['current_local_trx_id'] ?? '';
        $trxId         = $_GET['trx_id'] ?? $_SESSION['current_trx_id'] ?? '';
        $qrImage       = $_SESSION['current_qr_img'] ?? '';
        $paymentStatus = $_SESSION['current_payment_status'] ?? '';

        if (!empty($localTrxId) && isset($_SESSION['trx_history'][$localTrxId])) {
            $paymentStatus = 'success';
        }

        if ($isPayPressed) {
            if (isset($_POST['email'])) {
                $_SESSION['user_email'] = trim($_POST['email']);
            }

            if (!isset($_SESSION['current_trx_id']) || empty($_SESSION['current_trx_id'])) {
                $postData = json_encode(['amount' => $item['harga'], 'method' => 'qris']);
                $ch = curl_init(($baseUrl ?? '') . '/deposit/create');
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['X-API-Key: ' . ($apiKey ?? ''), 'Content-Type: application/json']);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $res = json_decode(curl_exec($ch), true);
                curl_close($ch);

                if (isset($res['success']) && $res['success'] == true) {
                    $realTrxId = $res['data']['depositId'] ?? $res['data']['transaction_id'] ?? ('TRX-' . rand(1000, 9999));

                    $_SESSION['current_local_trx_id'] = $realTrxId;
                    $_SESSION['current_trx_id']       = $realTrxId;
                    $_SESSION['current_qr_img']       = $res['data']['qrImage'] ?? $res['data']['qr_image_url'];
                    $_SESSION['current_prod_id']      = $id;
                    $_SESSION['current_payment_status'] = 'pending';

                    header("Location: jasteb.php?action=checkout&id=" . $id . "&trx_id=" . $realTrxId);
                    exit;
                }
            }
        }

        if (!empty($trxId)) {
            $showQris = true;

            if ($isCheckStatusPressed && $paymentStatus !== 'success') {
                $ch = curl_init(($baseUrl ?? '') . '/deposit/status/' . $trxId);
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['X-API-Key: ' . ($apiKey ?? '')]);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $statusRes = json_decode(curl_exec($ch), true);
                curl_close($ch);

                if (isset($statusRes['success']) && $statusRes['success'] == true) {
                    $rawStatus = strtolower($statusRes['data']['status']);
                    if ($rawStatus == 'success' || $rawStatus == 'settlement' || $rawStatus == 'paid') {
                        $_SESSION['current_payment_status'] = 'success';
                        $paymentStatus = 'success';

                        $_SESSION['trx_history'][$localTrxId] = [
                            'prod_name' => $item['nama'],
                            'price'     => $item['harga'],
                            'email'     => $_SESSION['user_email'] ?? '-',
                            'status'    => 'success'
                        ];

                        $_POST['email']        = $_SESSION['user_email'] ?? '-';
                        $_POST['jumlahResult'] = $item['result'] ?? '';

                        if (file_exists('panel.php')) {
                            ob_start();
                            include 'panel.php';
                            ob_end_clean();
                        }
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Order Jasteb — Dafxz Official</title>

<meta property="og:type" content="website">
<meta property="og:title" content="DAFXZ OFFICIAL · Order Jasteb">
<meta property="og:description" content="Beli Jasteb otomatis, instan & terpercaya 24 jam.">

<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --white: #ffffff;
    --gray-50: #f8fafc;
    --gray-100: #f1f5f9;
    --gray-200: #e2e8f0;
    --gray-300: #cbd5e1;
    --gray-400: #94a3b8;
    --gray-500: #64748b;
    --gray-600: #475569;
    --gray-700: #334155;
    --gray-800: #1e293b;
    --gray-900: #0f172a;
    --blue-400: #60a5fa;
    --blue-500: #3b82f6;
    --blue-600: #2563eb;
    --blue-700: #1d4ed8;
    --cyan-400: #22d3ee;
    --cyan-500: #06b6d4;
    --green-500: #22c55e;
    --amber-500: #f59e0b;
    --red-500: #ef4444;
    --red-100: #fee2e2;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.07), 0 1px 2px rgba(0,0,0,0.05);
    --shadow-md: 0 4px 16px rgba(0,0,0,0.08), 0 2px 6px rgba(0,0,0,0.05);
    --shadow-lg: 0 10px 40px rgba(0,0,0,0.1), 0 4px 12px rgba(0,0,0,0.06);
    --shadow-blue: 0 4px 24px rgba(59,130,246,0.22);
    --radius-sm: 10px;
    --radius-md: 16px;
    --radius-lg: 24px;
    --radius-xl: 32px;
}

* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: 'Plus Jakarta Sans', sans-serif;
    background: var(--gray-50);
    color: var(--gray-800);
    overflow-x: hidden;
    padding-top: 72px;
    min-height: 100vh;
}

::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-track { background: var(--gray-100); }
::-webkit-scrollbar-thumb { background: var(--blue-500); border-radius: 999px; }

/* ── NAVBAR ── */
.navbar {
    position: fixed; top: 0; left: 0; width: 100%; height: 72px;
    background: rgba(255,255,255,0.92);
    backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
    border-bottom: 1px solid var(--gray-200);
    display: flex; justify-content: space-between; align-items: center;
    padding: 0 6%; z-index: 1000;
    box-shadow: 0 1px 12px rgba(0,0,0,0.06);
}
.nav-brand { display: flex; align-items: center; gap: 10px; text-decoration: none; }
.brand-icon-wrap {
    width: 38px; height: 38px; border-radius: 10px;
    background: linear-gradient(135deg, var(--blue-600), var(--cyan-500));
    display: flex; align-items: center; justify-content: center;
    font-size: 15px; color: white; box-shadow: var(--shadow-blue);
}
.nav-brand-text {
    font-family: 'Outfit', sans-serif; font-size: 18px; font-weight: 800;
    letter-spacing: 0.5px; color: var(--gray-900);
}
.nav-brand-text span {
    background: linear-gradient(90deg, var(--blue-600), var(--cyan-500));
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.nav-toggle-btn {
    width: 40px; height: 40px; border-radius: 10px;
    background: var(--gray-100); border: 1px solid var(--gray-200);
    color: var(--gray-600); font-size: 15px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; transition: all 0.2s;
}
.nav-toggle-btn:hover {
    background: var(--blue-500); border-color: var(--blue-500);
    color: white; box-shadow: var(--shadow-blue);
}

/* ── SIDEBAR ── */
.sidebar {
    position: fixed; top: 0; right: -300px;
    width: 290px; height: 100%; background: white;
    border-left: 1px solid var(--gray-200);
    z-index: 2000; transition: right 0.35s cubic-bezier(0.4,0,0.2,1);
    padding: 30px 22px; display: flex; flex-direction: column;
    box-shadow: -8px 0 40px rgba(0,0,0,0.1);
}
.sidebar.active { right: 0; }
.sidebar-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; }
.sidebar-title {
    font-family: 'Outfit', sans-serif; font-size: 13px; font-weight: 700;
    color: var(--gray-400); letter-spacing: 1.5px; text-transform: uppercase;
}
.sidebar-close-btn {
    background: var(--gray-100); border: 1px solid var(--gray-200);
    width: 32px; height: 32px; border-radius: 8px; color: var(--gray-500);
    font-size: 13px; cursor: pointer; display: flex; align-items: center;
    justify-content: center; transition: all 0.2s;
}
.sidebar-close-btn:hover { background: var(--red-100); color: var(--red-500); border-color: transparent; }
.sidebar-menu-list { list-style: none; display: flex; flex-direction: column; gap: 4px; }
.sidebar-menu-item a {
    display: flex; align-items: center; gap: 12px; padding: 12px 14px;
    color: var(--gray-600); text-decoration: none; font-size: 14px; font-weight: 600;
    border-radius: 12px; transition: all 0.2s;
}
.sidebar-menu-item a i { width: 16px; text-align: center; font-size: 13px; color: var(--gray-400); transition: color 0.2s; }
.sidebar-menu-item a:hover { background: var(--gray-100); color: var(--blue-600); }
.sidebar-menu-item a:hover i { color: var(--blue-500); }
.sidebar-menu-item.active a {
    background: linear-gradient(135deg, rgba(59,130,246,0.08), rgba(6,182,212,0.05));
    color: var(--blue-600); border: 1px solid rgba(59,130,246,0.15);
}
.sidebar-menu-item.active a i { color: var(--blue-500); }
.sidebar-overlay {
    position: fixed; inset: 0; background: rgba(15,23,42,0.4);
    backdrop-filter: blur(4px); z-index: 1500; display: none;
}
.sidebar-overlay.active { display: block; }

/* ── HERO (HOME only) ── */
.hero {
    padding: 44px 5% 32px; text-align: center;
    background: white; border-bottom: 1px solid var(--gray-200);
}
.hero-badge {
    display: inline-flex; align-items: center; gap: 7px;
    background: linear-gradient(135deg, rgba(59,130,246,0.08), rgba(6,182,212,0.05));
    border: 1px solid rgba(59,130,246,0.2);
    padding: 6px 16px; border-radius: 999px; margin-bottom: 16px;
}
.hero-dot {
    width: 6px; height: 6px; background: var(--green-500);
    border-radius: 50%; box-shadow: 0 0 8px var(--green-500);
    animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse {
    0%,100% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.3); opacity: 0.7; }
}
.hero-badge-txt {
    font-size: 11px; font-weight: 700; color: var(--blue-600);
    letter-spacing: 1.5px; text-transform: uppercase;
}
.hero h1 {
    font-family: 'Outfit', sans-serif; font-size: 36px; font-weight: 900;
    color: var(--gray-900); line-height: 1.1; margin-bottom: 12px;
}
.hero h1 .grad {
    background: linear-gradient(135deg, var(--blue-600) 0%, var(--cyan-500) 100%);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.hero p {
    font-size: 14px; color: var(--gray-500); max-width: 420px;
    margin: 0 auto; line-height: 1.75; font-weight: 500;
}

/* ── STATS BAR ── */
.stats-bar {
    background: white; border-bottom: 1px solid var(--gray-200);
    padding: 13px 6%; display: flex; justify-content: center; gap: 36px;
}
.stat-item { display: flex; align-items: center; gap: 7px; font-size: 12px; font-weight: 600; color: var(--gray-500); }
.stat-item i { color: var(--blue-500); font-size: 12px; }
.stat-item strong { color: var(--gray-800); font-size: 13px; }

/* ── PAGE WRAPPER (HOME) ── */
.page-wrapper { max-width: 600px; margin: 0 auto; padding: 36px 5% 80px; }

/* ── PACKAGE SECTION HEADER ── */
.pkg-section-header { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
.pkg-section-line { flex: 1; height: 1px; background: var(--gray-200); }
.pkg-section-label {
    display: flex; align-items: center; gap: 7px;
    font-size: 11px; font-weight: 700; color: var(--blue-600);
    letter-spacing: 1.8px; text-transform: uppercase;
    background: rgba(59,130,246,0.06); border: 1px solid rgba(59,130,246,0.15);
    padding: 5px 14px; border-radius: 999px; white-space: nowrap;
}
.pkg-section-label i { font-size: 10px; }

/* ── PACKAGE GRID ── */
.package-grid {
    display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px; margin-bottom: 0;
}
.package-card {
    background: white; border: 2px solid var(--gray-200);
    border-radius: var(--radius-md); padding: 22px 16px 20px;
    text-align: center; cursor: pointer;
    transition: all 0.25s cubic-bezier(0.4,0,0.2,1);
    position: relative; overflow: hidden; box-shadow: var(--shadow-sm);
}
.package-card::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: linear-gradient(90deg, var(--blue-600), var(--cyan-500));
    opacity: 0; transition: opacity 0.25s;
}
.package-card:hover { border-color: rgba(59,130,246,0.4); transform: translateY(-4px); box-shadow: var(--shadow-lg); }
.package-card:hover::before { opacity: 1; }
.package-card.selected {
    border-color: var(--blue-600);
    background: linear-gradient(135deg, rgba(59,130,246,0.04), rgba(6,182,212,0.02));
    box-shadow: 0 0 0 4px rgba(59,130,246,0.08), var(--shadow-md);
}
.package-card.selected::before { opacity: 1; }
.package-card.selected::after {
    content: '\f00c'; font-family: 'Font Awesome 6 Free'; font-weight: 900;
    position: absolute; top: 10px; left: 12px;
    font-size: 10px; color: var(--blue-600);
}
.pkg-badge {
    position: absolute; top: 0; right: 0;
    font-size: 9px; padding: 4px 10px; border-bottom-left-radius: 10px;
    font-weight: 800; letter-spacing: 1px; text-transform: uppercase;
    font-family: 'Outfit', sans-serif;
}
.pkg-badge.vip { background: rgba(245,158,11,0.1); color: var(--amber-500); border: 1px solid rgba(245,158,11,0.2); }
.pkg-badge.premium { background: rgba(59,130,246,0.08); color: var(--blue-600); border: 1px solid rgba(59,130,246,0.2); }
.pkg-result-num {
    font-family: 'Outfit', sans-serif; font-size: 36px; font-weight: 900;
    color: var(--gray-900); line-height: 1; margin-bottom: 4px;
}
.pkg-result-label {
    font-size: 10px; font-weight: 700; color: var(--gray-400);
    text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px;
}
.pkg-price {
    display: inline-block; font-family: 'Outfit', sans-serif; font-size: 14px; font-weight: 800;
    background: linear-gradient(90deg, var(--blue-600), var(--cyan-500));
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}

/* ── CHECKOUT ACTION (after select) ── */
.action-checkout-wrapper {
    margin-top: 20px; padding-top: 20px;
    border-top: 1px solid var(--gray-200);
    display: none; animation: fadeUp 0.3s ease forwards;
}
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(10px); }
    to   { opacity: 1; transform: translateY(0); }
}
.selected-summary-row {
    display: flex; align-items: center; justify-content: space-between;
    background: var(--gray-50); border: 1px solid var(--gray-200);
    border-radius: var(--radius-sm); padding: 13px 16px; margin-bottom: 14px;
}
.ss-label { font-size: 12px; font-weight: 600; color: var(--gray-500); }
.ss-name { font-family: 'Outfit', sans-serif; font-size: 14px; font-weight: 700; color: var(--gray-900); margin-top: 1px; }
.ss-price {
    font-family: 'Outfit', sans-serif; font-size: 20px; font-weight: 900;
    background: linear-gradient(90deg, var(--blue-600), var(--cyan-500));
    -webkit-background-clip: text; -webkit-text-fill-color: transparent; white-space: nowrap;
}

/* ───────────────────────────────────────
   CHECKOUT PAGE — PANEL (sama persis index.php)
─────────────────────────────────────── */
.checkout-page {
    min-height: calc(100vh - 72px);
    display: flex; align-items: flex-start; justify-content: center;
    padding: 32px 16px 80px; background: var(--gray-50);
}

.panel-box {
    background: white; border: 1px solid var(--gray-200);
    border-radius: var(--radius-xl); width: 100%; max-width: 500px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.08), 0 4px 16px rgba(0,0,0,0.04);
    animation: fadeUp 0.45s cubic-bezier(0.22,1,0.36,1);
    overflow: hidden;
}

/* Dark header strip */
.panel-header-strip {
    background: linear-gradient(135deg, var(--gray-900) 0%, #1a2744 100%);
    padding: 24px 28px 22px; position: relative; overflow: hidden;
}
.panel-header-strip::before {
    content: ''; position: absolute; top: -40px; right: -40px;
    width: 160px; height: 160px; border-radius: 50%;
    background: rgba(59,130,246,0.12);
}
.panel-header-strip::after {
    content: ''; position: absolute; bottom: -30px; left: -20px;
    width: 100px; height: 100px; border-radius: 50%;
    background: rgba(6,182,212,0.08);
}
.panel-store-label {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.12);
    padding: 4px 11px; border-radius: 999px;
    font-size: 10px; font-weight: 700; color: rgba(255,255,255,0.6);
    letter-spacing: 1.5px; text-transform: uppercase;
    margin-bottom: 12px; position: relative; z-index: 1;
}
.panel-store-label i { font-size: 8px; color: var(--cyan-400); }
.panel-header-title {
    font-family: 'Outfit', sans-serif; font-size: 22px; font-weight: 800;
    color: white; line-height: 1.15; position: relative; z-index: 1;
}
.panel-header-title span {
    background: linear-gradient(90deg, var(--blue-400), var(--cyan-400));
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.panel-header-sub {
    font-size: 12px; color: rgba(255,255,255,0.45);
    margin-top: 4px; font-weight: 500; position: relative; z-index: 1;
}

/* Product row */
.checkout-product-row {
    display: flex; align-items: center; gap: 14px;
    padding: 18px 28px; border-bottom: 1px solid var(--gray-100);
    background: var(--gray-50);
}
.checkout-product-thumb {
    width: 56px; height: 56px; min-width: 56px; border-radius: 14px;
    background: linear-gradient(135deg, rgba(59,130,246,0.08), rgba(6,182,212,0.05));
    border: 2px solid rgba(59,130,246,0.15);
    display: flex; align-items: center; justify-content: center;
    font-size: 22px; color: var(--blue-600); box-shadow: var(--shadow-sm);
}
.checkout-product-meta { flex: 1; }
.checkout-product-name {
    font-family: 'Outfit', sans-serif; font-size: 15px;
    font-weight: 700; color: var(--gray-900);
}
.checkout-product-hint { font-size: 11px; color: var(--gray-400); margin-top: 3px; font-weight: 500; }
.checkout-product-price-tag {
    font-family: 'Outfit', sans-serif; font-size: 18px; font-weight: 900;
    color: var(--gray-900); white-space: nowrap; text-align: right;
}
.checkout-product-price-tag small {
    font-size: 11px; font-weight: 600; color: var(--gray-400); display: block; margin-bottom: 1px;
}

/* Summary lines */
.summary-section { padding: 20px 28px 0; }
.summary-heading {
    font-family: 'Outfit', sans-serif; font-size: 12px; font-weight: 700;
    color: var(--gray-400); letter-spacing: 1.8px; text-transform: uppercase; margin-bottom: 14px;
}
.summary-line {
    display: flex; justify-content: space-between; align-items: center;
    font-size: 13px; color: var(--gray-500); font-weight: 500;
    padding: 8px 0; border-bottom: 1px dashed var(--gray-100);
}
.summary-line:last-child { border-bottom: none; }
.summary-line .s-label { display: flex; align-items: center; gap: 7px; }
.summary-line .s-label i { color: var(--gray-300); font-size: 11px; width: 14px; text-align: center; }
.summary-line .s-val { font-weight: 600; color: var(--gray-700); font-family: 'Outfit', sans-serif; font-size: 13px; }
.summary-line .s-val.accent { color: var(--blue-600); }
.summary-line .s-val.free {
    color: #16a34a; background: rgba(34,197,94,0.08); border: 1px solid rgba(34,197,94,0.2);
    font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 5px; letter-spacing: 0.5px;
}

/* Total bar */
.total-bar {
    margin: 16px 28px 0;
    background: linear-gradient(135deg, var(--gray-900), #1a2744);
    border-radius: var(--radius-md); padding: 16px 20px;
    display: flex; align-items: center; justify-content: space-between;
}
.total-bar-left { display: flex; flex-direction: column; gap: 2px; }
.total-bar-label { font-size: 10px; font-weight: 700; color: rgba(255,255,255,0.45); text-transform: uppercase; letter-spacing: 1.5px; }
.total-bar-amount { font-family: 'Outfit', sans-serif; font-size: 26px; font-weight: 900; color: white; line-height: 1; }
.total-bar-amount small { font-size: 13px; font-weight: 600; color: rgba(255,255,255,0.5); margin-right: 3px; }
.total-bar-badges { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; }
.total-bar-badge {
    background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.12);
    color: rgba(255,255,255,0.6); font-size: 10px; font-weight: 700;
    padding: 3px 9px; border-radius: 5px; letter-spacing: 0.5px;
}
.total-bar-badge.qris-label { background: rgba(59,130,246,0.2); border-color: rgba(59,130,246,0.35); color: var(--blue-400); }
.total-bar.paid { background: linear-gradient(135deg, #14532d, #166534); }
.total-bar.paid .total-bar-amount { font-size: 18px; color: #86efac; display: flex; align-items: center; gap: 8px; }

/* Email form */
.form-section { padding: 20px 28px 0; }
.form-label-txt {
    display: block; font-size: 12px; font-weight: 700; color: var(--gray-500);
    text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;
}
.form-control {
    width: 100%; padding: 13px 16px;
    background: var(--gray-50); border: 1.5px solid var(--gray-200);
    border-radius: var(--radius-sm); color: var(--gray-800); font-size: 14px;
    font-family: 'Plus Jakarta Sans', sans-serif; outline: none; transition: 0.2s;
}
.form-control::placeholder { color: var(--gray-400); }
.form-control:focus {
    border-color: var(--blue-500); box-shadow: 0 0 0 4px rgba(59,130,246,0.1); background: white;
}
.form-hint {
    font-size: 11px; color: var(--gray-400); margin-top: 8px; line-height: 1.6;
    background: var(--gray-50); padding: 10px 12px;
    border-radius: 8px; border: 1px solid var(--gray-200);
}
.form-hint i { color: var(--blue-500); }

/* Payment area */
.payment-area { margin: 20px 28px 0; }

/* QRIS card */
.qris-card {
    border: 1.5px dashed var(--gray-300); border-radius: var(--radius-md);
    background: var(--gray-50); overflow: hidden;
}
.qris-card-top {
    display: flex; align-items: center; justify-content: space-between;
    padding: 12px 16px; border-bottom: 1px solid var(--gray-200); background: white;
}
.qris-method-label { display: flex; align-items: center; gap: 8px; font-size: 12px; font-weight: 700; color: var(--gray-700); }
.qris-method-label i { color: var(--blue-500); font-size: 14px; }
.qris-status-dot {
    display: flex; align-items: center; gap: 5px; font-size: 10px; font-weight: 700;
    color: #d97706; text-transform: uppercase; letter-spacing: 0.8px;
    background: rgba(251,191,36,0.1); border: 1px solid rgba(251,191,36,0.25);
    padding: 3px 10px; border-radius: 999px;
}
.qris-status-dot i { font-size: 8px; animation: pulse 1.5s ease-in-out infinite; }
.qris-img-wrap { padding: 20px; display: flex; flex-direction: column; align-items: center; gap: 12px; }
.qris-img-wrap img {
    width: 180px; height: 180px; object-fit: contain; border-radius: 10px;
    box-shadow: var(--shadow-md); border: 1px solid var(--gray-200); background: white; padding: 6px;
}
.qris-scan-hint { font-size: 11px; font-weight: 600; color: var(--gray-400); text-align: center; line-height: 1.6; }
.trx-id-row {
    display: flex; align-items: center; justify-content: space-between;
    background: white; border: 1px solid var(--gray-200); border-radius: 8px; padding: 8px 14px;
}
.trx-id-label { font-size: 10px; font-weight: 700; color: var(--gray-400); text-transform: uppercase; letter-spacing: 1px; }
.trx-id-val {
    font-family: monospace; font-size: 11px; color: var(--gray-600); font-weight: 600;
    max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

/* Success card */
.success-card {
    border: 1px solid rgba(34,197,94,0.25); border-radius: var(--radius-md);
    background: rgba(34,197,94,0.03); padding: 28px 20px; text-align: center;
}
.success-anim {
    width: 72px; height: 72px; border-radius: 50%;
    background: linear-gradient(135deg, rgba(34,197,94,0.15), rgba(34,197,94,0.05));
    border: 2px solid rgba(34,197,94,0.3);
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 16px; font-size: 30px; color: var(--green-500);
    animation: successPop 0.5s cubic-bezier(0.34,1.6,0.64,1);
}
@keyframes successPop {
    0% { transform: scale(0.5); opacity: 0; }
    100% { transform: scale(1); opacity: 1; }
}
.success-title { font-family: 'Outfit', sans-serif; font-size: 20px; font-weight: 800; color: #15803d; margin-bottom: 6px; }
.success-desc { font-size: 12px; color: var(--gray-500); line-height: 1.7; max-width: 300px; margin: 0 auto; font-weight: 500; }

/* Detail rows after success */
.detail-section {
    margin-top: 14px; background: var(--gray-50); border: 1px solid var(--gray-200);
    border-radius: var(--radius-sm); overflow: hidden;
}
.detail-row {
    display: flex; justify-content: space-between; align-items: center;
    padding: 11px 16px; border-bottom: 1px solid var(--gray-100); font-size: 13px;
}
.detail-row:last-child { border-bottom: none; }
.detail-label { color: var(--gray-500); font-weight: 600; display: flex; align-items: center; gap: 7px; }
.detail-label i { color: var(--gray-300); font-size: 11px; }
.detail-value { font-weight: 700; color: var(--gray-800); font-family: 'Outfit', sans-serif; font-size: 13px; }
.detail-value.accent-green { color: #16a34a; }
.detail-value.accent-blue { color: var(--blue-600); font-family: monospace; font-size: 11px; }

/* Action buttons */
.action-area { padding: 20px 28px 28px; display: flex; flex-direction: column; gap: 10px; }

.btn-checkout {
    width: 100%; border: none; padding: 15px 20px; border-radius: var(--radius-sm);
    background: linear-gradient(135deg, var(--blue-700), var(--blue-600) 50%, var(--cyan-500));
    color: white; font-family: 'Outfit', sans-serif; font-size: 14px; font-weight: 700;
    cursor: pointer; text-decoration: none;
    display: inline-flex; align-items: center; justify-content: center; gap: 9px;
    transition: all 0.25s; box-shadow: 0 4px 20px rgba(59,130,246,0.35);
    letter-spacing: 0.3px; position: relative; overflow: hidden;
}
.btn-checkout::after { content: ''; position: absolute; inset: 0; background: linear-gradient(135deg, rgba(255,255,255,0.1), transparent); opacity: 0; transition: opacity 0.2s; }
.btn-checkout:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(59,130,246,0.45); }
.btn-checkout:hover::after { opacity: 1; }
.btn-checkout:active { transform: translateY(0); }
.btn-checkout.green-btn { background: linear-gradient(135deg, #16a34a, #15803d); box-shadow: 0 4px 20px rgba(34,197,94,0.3); }
.btn-checkout.green-btn:hover { box-shadow: 0 8px 30px rgba(34,197,94,0.4); }

.btn-cancel {
    width: 100%; padding: 13px 20px; border-radius: var(--radius-sm);
    background: var(--gray-100); border: 1px solid var(--gray-200);
    color: var(--gray-600); font-family: 'Outfit', sans-serif; font-size: 13px; font-weight: 600;
    text-decoration: none; display: inline-flex; align-items: center; justify-content: center;
    gap: 8px; transition: all 0.2s; cursor: pointer;
}
.btn-cancel:hover { background: var(--red-100); color: var(--red-500); border-color: transparent; }

/* Trust strip */
.trust-strip {
    padding: 14px 28px; border-top: 1px solid var(--gray-100);
    display: flex; align-items: center; justify-content: center;
    gap: 20px; background: var(--gray-50);
}
.trust-item { display: flex; align-items: center; gap: 5px; font-size: 10px; font-weight: 700; color: var(--gray-400); text-transform: uppercase; letter-spacing: 0.5px; }
.trust-item i { color: var(--blue-500); font-size: 11px; }

/* Footer */
.footer-bar { background: var(--gray-900); padding: 24px 6%; }
.footer-inner { max-width: 1100px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; }
.footer-brand { display: flex; align-items: center; gap: 9px; }
.footer-brand-icon { width: 30px; height: 30px; border-radius: 8px; background: linear-gradient(135deg, var(--blue-600), var(--cyan-500)); display: flex; align-items: center; justify-content: center; font-size: 13px; color: white; }
.footer-brand-txt { font-family: 'Outfit', sans-serif; font-size: 14px; font-weight: 800; color: white; }
.footer-brand-txt span { background: linear-gradient(90deg, var(--blue-400), var(--cyan-400)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.footer-copy { font-size: 12px; color: #64748b; font-weight: 500; }
.footer-links { display: flex; gap: 16px; }
.footer-links a { font-size: 12px; color: #64748b; text-decoration: none; font-weight: 600; transition: color 0.2s; }
.footer-links a:hover { color: var(--blue-400); }

@media (max-width: 600px) {
    .hero h1 { font-size: 26px; }
    .stats-bar { gap: 16px; flex-wrap: wrap; }
    .panel-box { border-radius: var(--radius-lg); }
    .panel-header-strip, .summary-section, .action-area, .payment-area, .form-section { padding-left: 20px; padding-right: 20px; }
    .checkout-product-row { padding-left: 20px; padding-right: 20px; }
    .total-bar { margin-left: 20px; margin-right: 20px; }
    .trust-strip { padding-left: 20px; padding-right: 20px; gap: 12px; }
    .package-grid { gap: 10px; }
    .pkg-result-num { font-size: 28px; }
}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
    <a class="nav-brand" href="hosting.php">
        <div class="brand-icon-wrap"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
        <div class="nav-brand-text">DAFXZ <span>OFFICIAL</span></div>
    </a>
    <button class="nav-toggle-btn" onclick="toggleSidebar()">
        <i class="fa-solid fa-bars"></i>
    </button>
</nav>

<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>
<div class="sidebar" id="sidebarMenu">
    <div class="sidebar-header">
        <div class="sidebar-title">Menu</div>
        <button class="sidebar-close-btn" onclick="toggleSidebar()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <ul class="sidebar-menu-list">
        <li class="sidebar-menu-item">
            <a href="hosting.php"><i class="fa-solid fa-house"></i> Beranda</a>
        </li>
        <li class="sidebar-menu-item active">
            <a href="jasteb.php"><i class="fa-solid fa-fire-flame-curved"></i> Order Jasteb</a>
        </li>
        <li class="sidebar-menu-item">
            <a href="https://linktr.ee/daffahosting" target="_blank"><i class="fa-solid fa-bullhorn"></i> Saluran</a>
        </li>
        <li class="sidebar-menu-item">
            <a href="https://wa.me/6283830159806" target="_blank"><i class="fa-solid fa-user-shield"></i> Owner</a>
        </li>
    </ul>
</div>

<?php if($action == 'home'): ?>

<!-- HERO hanya di halaman home -->
<section class="hero">
    <div class="hero-badge">
        <div class="hero-dot"></div>
        <span class="hero-badge-txt">Automated · Online 24 Jam</span>
    </div>
    <h1>BUY <span class="grad">JASTEB</span></h1>
    <p>Pilih jumlah result — Lakukan Pembayaran — diproses otomatis, aman &amp; terpercaya.</p>
</section>

<div class="stats-bar">
    <div class="stat-item"><i class="fa-solid fa-bolt"></i> <strong>Instan</strong> Auto Proses</div>
    <div class="stat-item"><i class="fa-solid fa-lock"></i> <strong>Aman</strong> Payment Secure</div>
    <div class="stat-item"><i class="fa-solid fa-headset"></i> <strong>24/7</strong> Support</div>
    <div class="stat-item"><i class="fa-solid fa-star"></i> <strong>Terpercaya</strong></div>
</div>

<div class="page-wrapper">

    <div class="pkg-section-header">
        <div class="pkg-section-line"></div>
        <div class="pkg-section-label"><i class="fa-solid fa-gem"></i> PILIH JUMLAH RESULT</div>
        <div class="pkg-section-line"></div>
    </div>

    <div class="package-grid">
        <?php if(!empty($products)): ?>
            <?php foreach($products as $pItem): ?>
            <div class="package-card"
                 data-id="<?= $pItem['id'] ?>"
                 data-name="<?= htmlspecialchars($pItem['nama']) ?>"
                 data-price="<?= number_format($pItem['harga'], 0, ',', '.') ?>"
                 onclick="selectPackage(this, <?= $pItem['id'] ?>)">
                <div class="pkg-badge <?= strtolower($pItem['label']) === 'vip' ? 'vip' : 'premium' ?>"><?= htmlspecialchars($pItem['label']) ?></div>
                <div class="pkg-result-num"><?= htmlspecialchars($pItem['result']) ?></div>
                <div class="pkg-result-label">Result</div>
                <div class="pkg-price">Rp <?= number_format($pItem['harga'], 0, ',', '.') ?></div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="grid-column:span 2; color:var(--gray-400); text-align:center; padding:24px 0; font-weight:600;">Gagal memuat paket jasteb.</p>
        <?php endif; ?>
    </div>

    <div class="action-checkout-wrapper" id="checkoutActionContainer">
        <div class="selected-summary-row">
            <div>
                <div class="ss-label">Paket Dipilih</div>
                <div class="ss-name" id="summaryName">—</div>
            </div>
            <div class="ss-price" id="summaryPrice">—</div>
        </div>
        <button type="button" class="btn-checkout" id="procCheckoutBtn" onclick="redirectCheckout()">
            <i class="fa-solid fa-cart-shopping"></i>
            Checkout Sekarang
            <i class="fa-solid fa-arrow-right"></i>
        </button>
    </div>

</div>

<?php elseif($action == 'checkout'): ?>

<?php
if(!$item){
    echo '<div class="checkout-page"><div class="panel-box"><div class="panel-header-strip"><div class="panel-store-label"><i class="fa-solid fa-wand-magic-sparkles"></i> DAFXZ OFFICIAL</div><div class="panel-header-title" style="color:#f87171;">Paket tidak ditemukan</div></div><div class="action-area"><a href="jasteb.php" class="btn-checkout">Ganti Pilihan</a></div></div></div>';
    exit;
}
?>

<!-- CHECKOUT: langsung panel tanpa hero/stats bar, sama persis kayak hosting.php -->
<div class="checkout-page">
<div class="panel-box">

    <!-- HEADER STRIP (dinamis) -->
    <div class="panel-header-strip">
        <div class="panel-store-label">
            <i class="fa-solid fa-wand-magic-sparkles"></i> DAFXZ OFFICIAL
        </div>
        <div class="panel-header-title">
            <?php if($showQris && $paymentStatus == 'success'): ?>
                Pembayaran <span>Berhasil!</span>
            <?php elseif($showQris): ?>
                Scan &amp; <span>Bayar</span>
            <?php else: ?>
                Konfirmasi <span>Pesanan</span>
            <?php endif; ?>
        </div>
        <div class="panel-header-sub">
            <?php if($showQris && $paymentStatus == 'success'): ?>
                Transaksi terverifikasi · Silahkan cek Gmail bagian Spam
            <?php elseif($showQris): ?>
                Gunakan e-wallet / m-Banking untuk scan QRIS
            <?php else: ?>
                Periksa rincian &amp; masukkan email aktif kamu
            <?php endif; ?>
        </div>
    </div>

    <!-- PRODUCT ROW -->
    <div class="checkout-product-row">
        <div class="checkout-product-thumb">
            <i class="fa-solid fa-gem"></i>
        </div>
        <div class="checkout-product-meta">
            <div class="checkout-product-name"><?= htmlspecialchars($item['nama']) ?></div>
            <div class="checkout-product-hint">Jasteb otomatis masuk ke Gmail</div>
        </div>
        <div class="checkout-product-price-tag">
            <small>Harga</small>
            Rp <?= number_format($item['harga'], 0, ',', '.') ?>
        </div>
    </div>

    <!-- SUMMARY -->
    <div class="summary-section">
        <div class="summary-heading">Ringkasan Pesanan</div>
        <div class="summary-line">
            <div class="s-label"><i class="fa-solid fa-tag"></i> Nama Produk</div>
            <div class="s-val accent"><?= htmlspecialchars($item['nama']) ?></div>
        </div>
        <div class="summary-line">
            <div class="s-label"><i class="fa-solid fa-receipt"></i> Subtotal</div>
            <div class="s-val">Rp <?= number_format($item['harga'], 0, ',', '.') ?></div>
        </div>
        <div class="summary-line">
            <div class="s-label"><i class="fa-solid fa-percent"></i> Diskon Member</div>
            <div class="s-val free">GRATIS</div>
        </div>
        <div class="summary-line">
            <div class="s-label"><i class="fa-solid fa-building-columns"></i> Biaya Admin</div>
            <div class="s-val free">GRATIS</div>
        </div>
    </div>

    <!-- TOTAL BAR -->
    <div class="total-bar <?= ($showQris && $paymentStatus == 'success') ? 'paid' : '' ?>">
        <div class="total-bar-left">
            <div class="total-bar-label">Total Pembayaran</div>
            <?php if($showQris && $paymentStatus == 'success'): ?>
                <div class="total-bar-amount"><i class="fa-solid fa-circle-check"></i> LUNAS</div>
            <?php else: ?>
                <div class="total-bar-amount"><small>Rp</small><?= number_format($item['harga'], 0, ',', '.') ?></div>
            <?php endif; ?>
        </div>
        <div class="total-bar-badges">
            <?php if($showQris && $paymentStatus == 'success'): ?>
                <span class="total-bar-badge" style="background:rgba(34,197,94,0.2);border-color:rgba(34,197,94,0.35);color:#86efac;">
                    <i class="fa-solid fa-shield-check"></i> VERIFIED
                </span>
            <?php else: ?>
                <span class="total-bar-badge qris-label"><i class="fa-solid fa-qrcode"></i> QRIS</span>
                <span class="total-bar-badge"><i class="fa-solid fa-bolt"></i> Instan</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- EMAIL FORM (hanya sebelum bayar) -->
    <?php if(!$showQris): ?>
    <div class="form-section" style="padding-top:20px;">
        <form action="?action=checkout&id=<?= $id ?>" method="POST" id="paymentForm" onsubmit="return validateCheckout(this)">
            <input type="hidden" name="pay" value="1">
            <label class="form-label-txt">Masukkan Gmail Aktif Kamu</label>
            <input type="email" name="email" id="emailInput" class="form-control" placeholder="nama@gmail.com" required>
            <div class="form-hint">
                <i class="fa-solid fa-info-circle"></i>
                Jasteb / unchak fresh akan dikirim otomatis ke Gmail ini setelah pembayaran lunas.
            </div>
        </form>
    </div>
    <?php endif; ?>

    <!-- PAYMENT / STATUS AREA -->
    <?php if($showQris): ?>
    <div class="payment-area">
        <?php if($paymentStatus == 'success'): ?>
            <div class="success-card">
                <div class="success-anim"><i class="fa-solid fa-check"></i></div>
                <div class="success-title">Transaksi Berhasil!</div>
                <div class="success-desc">Silahkan cek di Gmail bagian <strong>Spam</strong>. Jika ada kendala, hubungi admin.</div>
            </div>
            <div class="detail-section">
                <div class="detail-row">
                    <div class="detail-label"><i class="fa-solid fa-hashtag"></i> ID Transaksi</div>
                    <div class="detail-value accent-blue"><?= htmlspecialchars($localTrxId) ?></div>
                </div>
                <div class="detail-row">
                    <div class="detail-label"><i class="fa-solid fa-envelope"></i> Email</div>
                    <div class="detail-value"><?= htmlspecialchars($_SESSION['user_email'] ?? '-') ?></div>
                </div>
                <div class="detail-row">
                    <div class="detail-label"><i class="fa-solid fa-money-bill"></i> Total Dibayar</div>
                    <div class="detail-value accent-green">Rp <?= number_format($item['harga'], 0, ',', '.') ?></div>
                </div>
            </div>
        <?php else: ?>
            <div class="qris-card">
                <div class="qris-card-top">
                    <div class="qris-method-label"><i class="fa-solid fa-qrcode"></i> Bayar via QRIS</div>
                    <div class="qris-status-dot"><i class="fa-solid fa-circle"></i> Menunggu</div>
                </div>
                <div class="qris-img-wrap">
                    <img src="<?= htmlspecialchars($qrImage) ?>" alt="QRIS Code">
                    <div class="qris-scan-hint">Scan menggunakan GoPay, OVO, DANA,<br>ShopeePay, atau m-Banking manapun</div>
                    <div class="trx-id-row">
                        <div class="trx-id-label"><i class="fa-solid fa-hashtag"></i> ID Transaksi</div>
                        <div class="trx-id-val"><?= htmlspecialchars($localTrxId) ?></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- ACTION BUTTONS -->
    <div class="action-area">
        <?php if(!$showQris): ?>
            <button type="button" class="btn-checkout" id="submitOrderBtn" onclick="submitPaymentForm()">
                <i class="fa-solid fa-wallet"></i>
                Bayar Sekarang
                <i class="fa-solid fa-arrow-right"></i>
            </button>
            <a href="jasteb.php?clear_session=1" class="btn-cancel">
                <i class="fa-solid fa-xmark"></i> Batalkan Pesanan
            </a>
        <?php elseif($paymentStatus == 'pending'): ?>
            <a href="?action=checkout&id=<?= $id ?>&trx_id=<?= urlencode($trxId) ?>&check=1"
               class="btn-checkout" onclick="handleBtnLoading(this, 'Mengecek Status...')">
                <i class="fa-solid fa-arrow-rotate-right"></i>
                Cek Status Pembayaran
                <i class="fa-solid fa-arrow-right"></i>
            </a>
            <a href="jasteb.php?clear_session=1" class="btn-cancel">
                <i class="fa-solid fa-arrows-rotate"></i> Ganti Paket
            </a>
        <?php elseif($paymentStatus == 'success'): ?>
            <a href="jasteb.php?clear_session=1" class="btn-checkout green-btn">
                <i class="fa-solid fa-house"></i>
                Kembali ke Beranda
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        <?php endif; ?>
    </div>

    <!-- TRUST STRIP -->
    <div class="trust-strip">
        <div class="trust-item"><i class="fa-solid fa-lock"></i> Secure Payment</div>
        <div class="trust-item"><i class="fa-solid fa-bolt"></i> Instan Proses</div>
        <div class="trust-item"><i class="fa-solid fa-headset"></i> Support 24/7</div>
    </div>

</div>
</div>

<?php endif; ?>

<!-- FOOTER -->
<footer class="footer-bar">
    <div class="footer-inner">
        <div class="footer-brand">
            <div class="footer-brand-icon"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
            <div class="footer-brand-txt">DAFXZ <span>OFFICIAL</span></div>
        </div>
        <div class="footer-copy">© 2026 Dafxz Official Store · All rights reserved</div>
        <div class="footer-links">
            <a href="https://wa.me/6287796882859" target="_blank"><i class="fa-brands fa-whatsapp"></i> Support</a>
            <a href="hosting.php"><i class="fa-solid fa-house"></i> Beranda</a>
        </div>
    </div>
</footer>

<script>
    let selectedPackageId = null;

    function toggleSidebar() {
        document.getElementById('sidebarMenu').classList.toggle('active');
        document.getElementById('sidebarOverlay').classList.toggle('active');
    }

    function selectPackage(element, id) {
        document.querySelectorAll('.package-card').forEach(c => c.classList.remove('selected'));
        element.classList.add('selected');
        selectedPackageId = id;

        const name  = element.dataset.name;
        const price = element.dataset.price;
        document.getElementById('summaryName').textContent  = name;
        document.getElementById('summaryPrice').textContent = 'Rp ' + price;

        const wrapper = document.getElementById('checkoutActionContainer');
        wrapper.style.display = 'block';
        wrapper.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function redirectCheckout() {
        if (selectedPackageId !== null) {
            handleBtnLoading(document.getElementById('procCheckoutBtn'), 'Membuka Form...');
            window.location.href = '?action=checkout&id=' + selectedPackageId;
        }
    }

    function validateCheckout(form) {
        const email = document.getElementById('emailInput');
        if (!email || email.value.trim() === '') {
            alert('Mohon masukkan email aktif kamu terlebih dahulu!');
            return false;
        }
        const btn = document.getElementById('submitOrderBtn');
        if(btn) handleBtnLoading(btn, 'Memproses Invoice...');
        return true;
    }

    function submitPaymentForm() {
        const email = document.getElementById('emailInput');
        if (!email || email.value.trim() === '') {
            alert('Mohon masukkan email aktif kamu terlebih dahulu!');
            return;
        }
        handleBtnLoading(document.getElementById('submitOrderBtn'), 'Memproses Invoice...');
        document.getElementById('paymentForm').submit();
    }

    function handleBtnLoading(el, txt) {
        el.style.pointerEvents = 'none';
        el.style.opacity = '0.75';
        el.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> ${txt}`;
    }
</script>
</body>
</html>
