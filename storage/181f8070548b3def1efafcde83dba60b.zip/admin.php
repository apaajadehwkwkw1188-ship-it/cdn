<?php
session_start();
require_once 'config.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    // Menggunakan trim() untuk menghindari spasi tak sengaja saat mengetik
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    // Pengecekan langsung tanpa password_verify
    if ($username === $adminUsername && $password === $adminPassword) {
        $_SESSION['admin'] = true;
        header('Location: admin.php'); exit;
    } else {
        $error = 'Username atau Password salah!';
    }
}

if (isset($_GET['logout'])) {
    unset($_SESSION['admin']);
    header('Location: admin.php'); exit;
}

if (!isset($_SESSION['admin'])): ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — Dafxz Official</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --gray-50:#f8fafc;--gray-100:#f1f5f9;--gray-200:#e2e8f0;--gray-300:#cbd5e1;
    --gray-400:#94a3b8;--gray-500:#64748b;--gray-600:#475569;--gray-700:#334155;
    --gray-800:#1e293b;--gray-900:#0f172a;
    --blue-400:#60a5fa;--blue-500:#3b82f6;--blue-600:#2563eb;--blue-700:#1d4ed8;
    --cyan-400:#22d3ee;--cyan-500:#06b6d4;--green-500:#22c55e;--red-500:#ef4444;--red-100:#fee2e2;
    --shadow-blue:0 4px 24px rgba(59,130,246,0.22);
    --radius-sm:10px;--radius-md:16px;--radius-lg:24px;--radius-xl:32px;
}
*{margin:0;padding:0;box-sizing:border-box;}
body {
    font-family:'Plus Jakarta Sans',sans-serif;
    background:var(--gray-50);
    min-height:100vh;
    display:flex;align-items:center;justify-content:center;
    padding:20px;
}
.login-wrap { width:100%;max-width:400px;animation:fadeUp 0.45s cubic-bezier(0.22,1,0.36,1); }
@keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
.login-box {
    background:white;border:1px solid var(--gray-200);
    border-radius:var(--radius-xl);overflow:hidden;
    box-shadow:0 20px 60px rgba(0,0,0,0.08),0 4px 16px rgba(0,0,0,0.04);
}
.login-header {
    background:linear-gradient(135deg,var(--gray-900) 0%,#1a2744 100%);
    padding:32px 32px 28px;text-align:center;position:relative;overflow:hidden;
}
.login-header::before{content:'';position:absolute;top:-50px;right:-50px;width:180px;height:180px;border-radius:50%;background:rgba(59,130,246,0.1);}
.login-header::after{content:'';position:absolute;bottom:-30px;left:-20px;width:120px;height:120px;border-radius:50%;background:rgba(6,182,212,0.07);}
.login-icon {
    width:60px;height:60px;border-radius:18px;
    background:linear-gradient(135deg,rgba(59,130,246,0.2),rgba(6,182,212,0.1));
    border:1px solid rgba(255,255,255,0.15);
    display:flex;align-items:center;justify-content:center;
    font-size:24px;color:var(--cyan-400);
    margin:0 auto 16px;position:relative;z-index:1;
    box-shadow:0 0 24px rgba(59,130,246,0.2);
}
.login-title{font-family:'Outfit',sans-serif;font-size:22px;font-weight:800;color:white;margin-bottom:4px;position:relative;z-index:1;}
.login-sub{font-size:11px;color:rgba(255,255,255,0.4);font-weight:600;letter-spacing:1.5px;text-transform:uppercase;position:relative;z-index:1;}
.login-body{padding:28px 32px 32px;}
.alert-error {
    background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.2);
    color:#dc2626;padding:11px 14px;border-radius:var(--radius-sm);
    font-size:13px;font-weight:600;margin-bottom:18px;
    display:flex;align-items:center;gap:8px;
}
.input-group{position:relative;margin-bottom:12px;}
.input-icon{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--gray-400);font-size:13px;z-index:1;}
.input-group input {
    width:100%;padding:13px 14px 13px 40px;
    background:var(--gray-50);border:1.5px solid var(--gray-200);
    border-radius:var(--radius-sm);font-size:14px;color:var(--gray-800);
    font-family:'Plus Jakarta Sans',sans-serif;outline:none;transition:0.2s;
}
.input-group input::placeholder{color:var(--gray-400);}
.input-group input:focus{border-color:var(--blue-500);background:white;box-shadow:0 0 0 4px rgba(59,130,246,0.08);}
.btn-login {
    width:100%;padding:14px;margin-top:6px;border:none;border-radius:var(--radius-sm);
    background:linear-gradient(135deg,var(--blue-700),var(--blue-600) 50%,var(--cyan-500));
    color:white;font-family:'Outfit',sans-serif;font-size:14px;font-weight:700;
    cursor:pointer;display:flex;align-items:center;justify-content:center;gap:9px;
    box-shadow:0 4px 20px rgba(59,130,246,0.35);transition:all 0.25s;letter-spacing:0.3px;
}
.btn-login:hover{transform:translateY(-2px);box-shadow:0 8px 28px rgba(59,130,246,0.45);}
</style>
</head>
<body>
<div class="login-wrap">
    <div class="login-box">
        <div class="login-header">
            <div class="login-icon"><i class="fa-solid fa-user-shield"></i></div>
            <div class="login-title">Admin Panel</div>
            <div class="login-sub">Dafxz Official Dashboard</div>
        </div>
        <div class="login-body">
            <?php if($error): ?>
            <div class="alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= $error ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="input-group">
                    <i class="fa-solid fa-user input-icon"></i>
                    <input type="text" name="username" placeholder="Username" required autocomplete="off">
                </div>
                <div class="input-group">
                    <i class="fa-solid fa-lock input-icon"></i>
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <button type="submit" name="login" class="btn-login">
                    <i class="fa-solid fa-right-to-bracket"></i> Masuk ke Panel
                </button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
<?php exit; endif;

// ══ FUNGSI SIMPAN CONFIG ══
function saveConfigProducts($newProducts) {
    $configFile = 'config.php';
    $content = file_get_contents($configFile);
    $arrayString = "\$products = [\n";
    foreach ($newProducts as $id => $p) {
        $arrayString .= "    " . $id . " => [\n";
        $arrayString .= "        'id' => " . $p['id'] . ",\n";
        $arrayString .= "        'nama' => '" . addslashes($p['nama']) . "',\n";
        $arrayString .= "        'harga' => " . (int)$p['harga'] . ",\n";
        $arrayString .= "        'link_produk' => '" . addslashes($p['link_produk']) . "',\n";
        $arrayString .= "        'gambar' => '" . addslashes($p['gambar'] ?? '') . "'\n";
        $arrayString .= "    ],\n";
    }
    $arrayString .= "];";
    $pattern = '/\$products\s*=\s*\[.*?\];/s';
    $updatedContent = preg_replace($pattern, $arrayString, $content);
    file_put_contents($configFile, $updatedContent);
}

function saveConfigJasteb($newJasteb) {
    $configFile = 'config.php';
    $content = file_get_contents($configFile);
    $arrayString = "\$products1 = [\n";
    foreach ($newJasteb as $id => $p) {
        $arrayString .= "    " . $id . " => ['id' => " . $p['id'] . ", 'result' => '" . addslashes($p['result']) . "', 'price' => '" . addslashes($p['price']) . "', 'label' => '" . addslashes($p['label']) . "'],\n";
    }
    $arrayString .= "];";
    $pattern = '/\$products1\s*=\s*\[.*?\];/s';
    $updatedContent = preg_replace($pattern, $arrayString, $content);
    file_put_contents($configFile, $updatedContent);
}

// ── CRUD PRODUK ──
if (isset($_POST['tambah_produk'])) {
    $nextId = !empty($products) ? max(array_keys($products)) + 1 : 1;
    $products[$nextId] = ['id'=>$nextId,'nama'=>$_POST['nama'],'harga'=>(int)$_POST['harga'],'link_produk'=>$_POST['link'],'gambar'=>$_POST['gambar']??''];
    saveConfigProducts($products); header('Location: admin.php'); exit;
}
if (isset($_POST['edit_produk'])) {
    $id = (int)$_POST['id'];
    if (isset($products[$id])) {
        $products[$id] = ['id'=>$id,'nama'=>$_POST['nama'],'harga'=>(int)$_POST['harga'],'link_produk'=>$_POST['link'],'gambar'=>$_POST['gambar']??''];
        saveConfigProducts($products);
    }
    header('Location: admin.php'); exit;
}
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    if (isset($products[$id])) { unset($products[$id]); saveConfigProducts($products); }
    header('Location: admin.php'); exit;
}

// ── CRUD JASTEB ──
if (isset($_POST['tambah_jasteb'])) {
    $nextId = !empty($products1) ? max(array_keys($products1)) + 1 : 1;
    $products1[$nextId] = ['id'=>$nextId,'result'=>$_POST['result'],'price'=>$_POST['price'],'label'=>$_POST['label']];
    saveConfigJasteb($products1); header('Location: admin.php'); exit;
}
if (isset($_POST['edit_jasteb'])) {
    $id = (int)$_POST['id'];
    if (isset($products1[$id])) {
        $products1[$id] = ['id'=>$id,'result'=>$_POST['result'],'price'=>$_POST['price'],'label'=>$_POST['label']];
        saveConfigJasteb($products1);
    }
    header('Location: admin.php'); exit;
}
if (isset($_GET['hapus_jasteb'])) {
    $id = (int)$_GET['hapus_jasteb'];
    if (isset($products1[$id])) { unset($products1[$id]); saveConfigJasteb($products1); }
    header('Location: admin.php'); exit;
}

// ── EDIT MODE ──
$editData = null;
if (isset($_GET['action'],$_GET['id']) && $_GET['action']=='edit') {
    $editId = (int)$_GET['id'];
    if (isset($products[$editId])) $editData = $products[$editId];
}
$editJasteb = null;
if (isset($_GET['action'],$_GET['id']) && $_GET['action']=='edit_jasteb') {
    $editId = (int)$_GET['id'];
    if (isset($products1[$editId])) $editJasteb = $products1[$editId];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard — Dafxz Official</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --white:#ffffff;--gray-50:#f8fafc;--gray-100:#f1f5f9;--gray-200:#e2e8f0;
    --gray-300:#cbd5e1;--gray-400:#94a3b8;--gray-500:#64748b;--gray-600:#475569;
    --gray-700:#334155;--gray-800:#1e293b;--gray-900:#0f172a;
    --blue-400:#60a5fa;--blue-500:#3b82f6;--blue-600:#2563eb;--blue-700:#1d4ed8;
    --cyan-400:#22d3ee;--cyan-500:#06b6d4;--green-500:#22c55e;
    --amber-500:#f59e0b;--red-500:#ef4444;--red-100:#fee2e2;
    --shadow-sm:0 1px 3px rgba(0,0,0,0.07),0 1px 2px rgba(0,0,0,0.05);
    --shadow-md:0 4px 16px rgba(0,0,0,0.08),0 2px 6px rgba(0,0,0,0.05);
    --shadow-lg:0 10px 40px rgba(0,0,0,0.1),0 4px 12px rgba(0,0,0,0.06);
    --shadow-blue:0 4px 24px rgba(59,130,246,0.22);
    --radius-sm:10px;--radius-md:16px;--radius-lg:24px;--radius-xl:32px;
}
*{margin:0;padding:0;box-sizing:border-box;}
body{
    font-family:'Plus Jakarta Sans',sans-serif;
    background:var(--gray-50);color:var(--gray-800);
    overflow-x:hidden;padding-top:72px;padding-bottom:60px;min-height:100vh;
}
::-webkit-scrollbar{width:5px;}
::-webkit-scrollbar-track{background:var(--gray-100);}
::-webkit-scrollbar-thumb{background:var(--blue-500);border-radius:999px;}

/* ── NAVBAR ── */
.navbar{
    position:fixed;top:0;left:0;width:100%;height:72px;
    background:rgba(255,255,255,0.92);
    backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);
    border-bottom:1px solid var(--gray-200);
    display:flex;justify-content:space-between;align-items:center;
    padding:0 5%;z-index:1000;
    box-shadow:0 1px 12px rgba(0,0,0,0.06);
}
.nav-brand{display:flex;align-items:center;gap:10px;text-decoration:none;}
.brand-icon-wrap{
    width:38px;height:38px;border-radius:10px;
    background:linear-gradient(135deg,var(--blue-600),var(--cyan-500));
    display:flex;align-items:center;justify-content:center;
    font-size:15px;color:white;box-shadow:var(--shadow-blue);
}
.nav-brand-text{font-family:'Outfit',sans-serif;font-size:18px;font-weight:800;letter-spacing:0.5px;color:var(--gray-900);}
.nav-brand-text span{background:linear-gradient(90deg,var(--blue-600),var(--cyan-500));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.nav-right{display:flex;align-items:center;gap:10px;}
.nav-status-badge{
    display:inline-flex;align-items:center;gap:6px;
    background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.2);
    padding:6px 12px;border-radius:8px;
    font-size:11px;font-weight:700;color:#16a34a;letter-spacing:0.5px;
}
.nav-status-dot{width:6px;height:6px;background:var(--green-500);border-radius:50%;box-shadow:0 0 6px var(--green-500);animation:pulse 2s ease-in-out infinite;}
@keyframes pulse{0%,100%{transform:scale(1);opacity:1;}50%{transform:scale(1.3);opacity:0.7;}}
.btn-logout{
    display:inline-flex;align-items:center;gap:7px;
    padding:9px 16px;border-radius:var(--radius-sm);
    background:var(--gray-100);border:1px solid var(--gray-200);
    color:var(--gray-600);font-family:'Outfit',sans-serif;
    font-size:12px;font-weight:700;text-decoration:none;
    transition:all 0.2s;
}
.btn-logout:hover{background:var(--red-100);color:var(--red-500);border-color:transparent;}

/* ── MAIN ── */
.main-container{max-width:1080px;margin:32px auto 0;padding:0 5%;display:flex;flex-direction:column;gap:20px;}

/* ── SECTION LABEL ── */
.section-label{
    display:flex;align-items:center;gap:10px;margin-bottom:4px;
}
.section-label-line{flex:1;height:1px;background:var(--gray-200);}
.section-label-text{
    display:flex;align-items:center;gap:6px;
    font-size:10px;font-weight:700;color:var(--blue-600);
    letter-spacing:1.8px;text-transform:uppercase;
    background:rgba(59,130,246,0.06);border:1px solid rgba(59,130,246,0.15);
    padding:4px 12px;border-radius:999px;white-space:nowrap;
}
.section-label-text i{font-size:9px;}

/* ── PANEL CARD ── */
.panel-card{
    background:white;border:1px solid var(--gray-200);
    border-radius:var(--radius-lg);overflow:hidden;
    box-shadow:var(--shadow-md);
    animation:fadeUp 0.4s ease;
    position:relative;
}
.panel-card::before{
    content:'';position:absolute;top:0;left:0;right:0;height:3px;
    background:linear-gradient(90deg,var(--blue-600),var(--cyan-500));
}
.panel-card.edit-mode::before{background:linear-gradient(90deg,var(--cyan-500),var(--blue-600));}
@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}

.card-header{
    padding:18px 24px 16px;
    border-bottom:1px solid var(--gray-100);
    display:flex;align-items:center;gap:10px;
    background:var(--gray-50);
}
.card-header-icon{
    width:34px;height:34px;border-radius:10px;
    background:linear-gradient(135deg,rgba(59,130,246,0.1),rgba(6,182,212,0.07));
    border:1px solid rgba(59,130,246,0.15);
    display:flex;align-items:center;justify-content:center;
    font-size:13px;color:var(--blue-600);
}
.card-header-title{font-family:'Outfit',sans-serif;font-size:15px;font-weight:700;color:var(--gray-900);}
.card-header-badge{
    margin-left:auto;
    font-size:10px;font-weight:700;
    background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.18);
    color:var(--blue-600);padding:3px 9px;border-radius:6px;letter-spacing:0.5px;
}
.card-header-badge.edit{background:rgba(6,182,212,0.08);border-color:rgba(6,182,212,0.2);color:var(--cyan-500);}

.card-body{padding:20px 24px 22px;}

/* ── FORM ── */
.form-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:16px;}
@media(max-width:640px){.form-grid{grid-template-columns:1fr;}}
.form-group{display:flex;flex-direction:column;gap:6px;}
.form-label{font-size:11px;font-weight:700;color:var(--gray-500);text-transform:uppercase;letter-spacing:1px;}
.form-control{
    width:100%;padding:11px 14px;
    background:var(--gray-50);border:1.5px solid var(--gray-200);
    border-radius:var(--radius-sm);font-size:13px;color:var(--gray-800);
    font-family:'Plus Jakarta Sans',sans-serif;outline:none;transition:0.2s;
}
.form-control::placeholder{color:var(--gray-400);}
.form-control:focus{border-color:var(--blue-500);background:white;box-shadow:0 0 0 4px rgba(59,130,246,0.08);}
select.form-control{cursor:pointer;}
.form-actions{display:flex;gap:8px;flex-wrap:wrap;}

/* ── BUTTONS ── */
.btn-primary{
    display:inline-flex;align-items:center;justify-content:center;gap:7px;
    padding:11px 20px;border:none;border-radius:var(--radius-sm);
    background:linear-gradient(135deg,var(--blue-700),var(--blue-600) 50%,var(--cyan-500));
    color:white;font-family:'Outfit',sans-serif;font-size:13px;font-weight:700;
    cursor:pointer;box-shadow:0 4px 16px rgba(59,130,246,0.3);
    transition:all 0.25s;position:relative;overflow:hidden;letter-spacing:0.3px;
}
.btn-primary::after{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(255,255,255,0.1),transparent);opacity:0;transition:opacity 0.2s;}
.btn-primary:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(59,130,246,0.4);}
.btn-primary:hover::after{opacity:1;}
.btn-secondary{
    display:inline-flex;align-items:center;justify-content:center;gap:7px;
    padding:11px 18px;border-radius:var(--radius-sm);
    background:var(--gray-100);border:1px solid var(--gray-200);
    color:var(--gray-600);font-family:'Outfit',sans-serif;font-size:13px;font-weight:600;
    text-decoration:none;transition:all 0.2s;cursor:pointer;
}
.btn-secondary:hover{background:var(--red-100);color:var(--red-500);border-color:transparent;}

/* ── TABLE ── */
.table-wrap{width:100%;overflow-x:auto;}
table{width:100%;border-collapse:collapse;font-size:13px;}
thead th{
    background:var(--gray-50);padding:12px 16px;
    font-size:10px;font-weight:700;color:var(--gray-500);
    text-transform:uppercase;letter-spacing:1.2px;
    border-bottom:1px solid var(--gray-200);white-space:nowrap;text-align:left;
}
tbody td{
    padding:13px 16px;border-bottom:1px solid var(--gray-100);
    color:var(--gray-600);vertical-align:middle;
}
tbody tr:last-child td{border-bottom:none;}
tbody tr{transition:background 0.15s;}
tbody tr:hover td{background:var(--gray-50);}

/* Table cell types */
.td-id{font-family:monospace;font-size:11px;font-weight:700;color:var(--blue-600);}
.td-name{font-family:'Outfit',sans-serif;font-size:13px;font-weight:700;color:var(--gray-900);}
.td-price{
    font-family:'Outfit',sans-serif;font-size:14px;font-weight:800;
    background:linear-gradient(90deg,var(--blue-600),var(--cyan-500));
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.td-link code{
    background:var(--gray-100);border:1px solid var(--gray-200);
    padding:3px 8px;border-radius:6px;
    font-family:monospace;font-size:10px;color:var(--gray-500);
    display:inline-block;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
}
.prod-thumb{
    width:40px;height:40px;border-radius:10px;object-fit:cover;
    border:1px solid var(--gray-200);
}
.prod-thumb-placeholder{
    width:40px;height:40px;border-radius:10px;
    background:var(--gray-100);border:1px solid var(--gray-200);
    display:flex;align-items:center;justify-content:center;
    color:var(--gray-300);font-size:14px;
}

/* Label badges */
.label-badge{
    display:inline-flex;align-items:center;gap:4px;
    padding:3px 10px;border-radius:6px;
    font-size:10px;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;
}
.badge-vip{background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);color:var(--amber-500);}
.badge-premium{background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.2);color:var(--blue-600);}

/* Row action buttons */
.row-actions{display:flex;gap:6px;}
.btn-row-edit{
    display:inline-flex;align-items:center;gap:4px;
    padding:6px 12px;border-radius:8px;
    background:rgba(59,130,246,0.06);border:1px solid rgba(59,130,246,0.18);
    color:var(--blue-600);font-family:'Outfit',sans-serif;
    font-size:11px;font-weight:700;text-decoration:none;
    transition:all 0.18s;white-space:nowrap;
}
.btn-row-edit:hover{background:rgba(59,130,246,0.14);border-color:rgba(59,130,246,0.35);transform:translateY(-1px);}
.btn-row-delete{
    display:inline-flex;align-items:center;gap:4px;
    padding:6px 12px;border-radius:8px;
    background:rgba(239,68,68,0.05);border:1px solid rgba(239,68,68,0.15);
    color:var(--red-500);font-family:'Outfit',sans-serif;
    font-size:11px;font-weight:700;text-decoration:none;
    transition:all 0.18s;white-space:nowrap;
}
.btn-row-delete:hover{background:rgba(239,68,68,0.12);border-color:rgba(239,68,68,0.35);transform:translateY(-1px);}

/* Empty state */
.empty-state{text-align:center;padding:36px 20px;color:var(--gray-300);}
.empty-state i{font-size:28px;display:block;margin-bottom:10px;}
.empty-state span{font-size:12px;font-weight:600;color:var(--gray-400);}

@media(max-width:768px){
    .main-container{padding:0 4%;}
    .card-body{padding:16px 18px 18px;}
    .card-header{padding:14px 18px;}
    .nav-status-badge{display:none;}
    tbody td,thead th{padding:10px 12px;}
}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
    <a class="nav-brand" href="hosting.php">
        <div class="brand-icon-wrap"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
        <div class="nav-brand-text">Dafxz <span>ADMIN</span></div>
    </a>
    <div class="nav-right">
        <div class="nav-status-badge">
            <div class="nav-status-dot"></div>
            Panel Aktif
        </div>
        <a href="?logout=1" class="btn-logout">
            <i class="fa-solid fa-power-off"></i> Keluar
        </a>
    </div>
</nav>

<main class="main-container">

<?php if($editData): ?>
<!-- ══ EDIT PRODUK ══ -->
<div class="section-label">
    <div class="section-label-line"></div>
    <div class="section-label-text"><i class="fa-solid fa-pen-to-square"></i> Edit Produk</div>
    <div class="section-label-line"></div>
</div>
<div class="panel-card edit-mode">
    <div class="card-header">
        <div class="card-header-icon"><i class="fa-solid fa-pen-to-square"></i></div>
        <div class="card-header-title">Edit Produk</div>
        <div class="card-header-badge edit">ID #<?= $editData['id'] ?></div>
    </div>
    <div class="card-body">
        <form method="POST">
            <input type="hidden" name="id" value="<?= $editData['id'] ?>">
            <div class="form-grid">
                <div class="form-group">
                    <label class="form-label">Nama Produk</label>
                    <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($editData['nama']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Harga (IDR)</label>
                    <input type="number" name="harga" class="form-control" value="<?= $editData['harga'] ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Link Grup / Tujuan</label>
                    <input type="text" name="link" class="form-control" value="<?= htmlspecialchars($editData['link_produk']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Link Gambar (URL)</label>
                    <input type="text" name="gambar" class="form-control" value="<?= htmlspecialchars($editData['gambar']??'') ?>" placeholder="https://i.ibb.co/...">
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" name="edit_produk" class="btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan
                </button>
                <a href="admin.php" class="btn-secondary">
                    <i class="fa-solid fa-xmark"></i> Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php elseif($editJasteb): ?>
<!-- ══ EDIT JASTEB ══ -->
<div class="section-label">
    <div class="section-label-line"></div>
    <div class="section-label-text"><i class="fa-solid fa-pen-to-square"></i> Edit Paket Jasteb</div>
    <div class="section-label-line"></div>
</div>
<div class="panel-card edit-mode">
    <div class="card-header">
        <div class="card-header-icon"><i class="fa-solid fa-pen-to-square"></i></div>
        <div class="card-header-title">Edit Paket Jasteb</div>
        <div class="card-header-badge edit">ID #<?= $editJasteb['id'] ?></div>
    </div>
    <div class="card-body">
        <form method="POST">
            <input type="hidden" name="id" value="<?= $editJasteb['id'] ?>">
            <div class="form-grid">
                <div class="form-group">
                    <label class="form-label">Jumlah Result</label>
                    <input type="text" name="result" class="form-control" value="<?= htmlspecialchars($editJasteb['result']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Harga (IDR)</label>
                    <input type="number" name="price" class="form-control" value="<?= $editJasteb['price'] ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Label Paket</label>
                    <select name="label" class="form-control">
                        <option value="VIP" <?= $editJasteb['label']=='VIP'?'selected':'' ?>>VIP</option>
                        <option value="PREMIUM" <?= $editJasteb['label']=='PREMIUM'?'selected':'' ?>>PREMIUM</option>
                    </select>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" name="edit_jasteb" class="btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan
                </button>
                <a href="admin.php" class="btn-secondary">
                    <i class="fa-solid fa-xmark"></i> Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php else: ?>
<!-- ══ FORM TAMBAH PRODUK ══ -->
<div class="section-label">
    <div class="section-label-line"></div>
    <div class="section-label-text"><i class="fa-solid fa-boxes-stacked"></i> Produk — hosting.php</div>
    <div class="section-label-line"></div>
</div>
<div class="panel-card">
    <div class="card-header">
        <div class="card-header-icon"><i class="fa-solid fa-plus"></i></div>
        <div class="card-header-title">Tambah Produk Baru</div>
    </div>
    <div class="card-body">
        <form method="POST">
            <div class="form-grid">
                <div class="form-group">
                    <label class="form-label">Nama Produk</label>
                    <input type="text" name="nama" class="form-control" placeholder="JASTEB PREMIUM GRUP A" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Harga Jual (IDR)</label>
                    <input type="number" name="harga" class="form-control" placeholder="15000" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Link Grup / File</label>
                    <input type="text" name="link" class="form-control" placeholder="https://chat.whatsapp.com/..." required>
                </div>
                <div class="form-group">
                    <label class="form-label">Link Gambar (URL)</label>
                    <input type="text" name="gambar" class="form-control" placeholder="https://i.ibb.co/...">
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" name="tambah_produk" class="btn-primary">
                    <i class="fa-solid fa-plus"></i> Tambah Produk
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ══ FORM TAMBAH JASTEB ══ -->
<div class="section-label">
    <div class="section-label-line"></div>
    <div class="section-label-text"><i class="fa-solid fa-gem"></i> Paket Jasteb — jasteb.php</div>
    <div class="section-label-line"></div>
</div>
<div class="panel-card">
    <div class="card-header">
        <div class="card-header-icon"><i class="fa-solid fa-plus"></i></div>
        <div class="card-header-title">Tambah Paket Jasteb</div>
    </div>
    <div class="card-body">
        <form method="POST">
            <div class="form-grid">
                <div class="form-group">
                    <label class="form-label">Jumlah Result</label>
                    <input type="text" name="result" class="form-control" placeholder="70" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Harga Paket (IDR)</label>
                    <input type="number" name="price" class="form-control" placeholder="5000" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Label Paket</label>
                    <select name="label" class="form-control">
                        <option value="VIP">VIP</option>
                        <option value="PREMIUM">PREMIUM</option>
                    </select>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" name="tambah_jasteb" class="btn-primary">
                    <i class="fa-solid fa-plus"></i> Tambah Paket
                </button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- ══ TABEL PRODUK AKTIF ══ -->
<div class="section-label">
    <div class="section-label-line"></div>
    <div class="section-label-text"><i class="fa-solid fa-table-list"></i> Produk Aktif</div>
    <div class="section-label-line"></div>
</div>
<div class="panel-card">
    <div class="card-header">
        <div class="card-header-icon"><i class="fa-solid fa-boxes-stacked"></i></div>
        <div class="card-header-title">Daftar Produk</div>
        <div class="card-header-badge"><?= count($products) ?> produk</div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Gambar</th>
                    <th>ID</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Link Tujuan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($products)): foreach($products as $p): ?>
                <tr>
                    <td>
                        <?php if(!empty($p['gambar'])): ?>
                            <img src="<?= htmlspecialchars($p['gambar']) ?>" class="prod-thumb" alt="">
                        <?php else: ?>
                            <div class="prod-thumb-placeholder"><i class="fa-solid fa-image"></i></div>
                        <?php endif; ?>
                    </td>
                    <td><span class="td-id">#<?= $p['id'] ?></span></td>
                    <td><span class="td-name"><?= htmlspecialchars($p['nama']) ?></span></td>
                    <td><span class="td-price">Rp <?= number_format($p['harga']) ?></span></td>
                    <td class="td-link"><code><?= htmlspecialchars($p['link_produk']) ?></code></td>
                    <td>
                        <div class="row-actions">
                            <a href="?action=edit&id=<?= $p['id'] ?>" class="btn-row-edit">
                                <i class="fa-solid fa-pen"></i> Edit
                            </a>
                            <a href="?hapus=<?= $p['id'] ?>" class="btn-row-delete"
                               onclick="return confirm('Hapus produk ini?')">
                                <i class="fa-solid fa-trash-can"></i> Hapus
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; else: ?>
                <tr><td colspan="6">
                    <div class="empty-state">
                        <i class="fa-solid fa-box-open"></i>
                        <span>Belum ada produk terdaftar</span>
                    </div>
                </td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ══ TABEL PAKET JASTEB ══ -->
<div class="section-label">
    <div class="section-label-line"></div>
    <div class="section-label-text"><i class="fa-solid fa-gem"></i> Paket Jasteb Aktif</div>
    <div class="section-label-line"></div>
</div>
<div class="panel-card">
    <div class="card-header">
        <div class="card-header-icon"><i class="fa-solid fa-layer-group"></i></div>
        <div class="card-header-title">Daftar Paket Jasteb</div>
        <div class="card-header-badge"><?= count($products1??[]) ?> paket</div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Jumlah Result</th>
                    <th>Harga Paket</th>
                    <th>Label</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($products1)): foreach($products1 as $j): ?>
                <tr>
                    <td><span class="td-id">#<?= $j['id'] ?></span></td>
                    <td><span class="td-name"><?= htmlspecialchars($j['result']) ?> Result</span></td>
                    <td><span class="td-price">Rp <?= number_format((int)$j['price']) ?></span></td>
                    <td>
                        <?php if(strtoupper($j['label'])=='VIP'): ?>
                            <span class="label-badge badge-vip"><i class="fa-solid fa-crown"></i> VIP</span>
                        <?php else: ?>
                            <span class="label-badge badge-premium"><i class="fa-solid fa-gem"></i> PREMIUM</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="row-actions">
                            <a href="?action=edit_jasteb&id=<?= $j['id'] ?>" class="btn-row-edit">
                                <i class="fa-solid fa-pen"></i> Edit
                            </a>
                            <a href="?hapus_jasteb=<?= $j['id'] ?>" class="btn-row-delete"
                               onclick="return confirm('Hapus paket ini?')">
                                <i class="fa-solid fa-trash-can"></i> Hapus
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; else: ?>
                <tr><td colspan="5">
                    <div class="empty-state">
                        <i class="fa-solid fa-box-open"></i>
                        <span>Belum ada paket jasteb terdaftar</span>
                        
                        foreach($data as $i=>$row){

echo "<tr>";
echo "<td>".($i+1)."</td>";
echo "<td>".$row['email']."</td>";
echo "<td>".$row['paket']."</td>";
echo "<td>".$row['payment']."</td>";
echo "<td>".$row['status']."</td>";

foreach($data as $i=>$row){

echo "<tr>";
echo "<td>".($i+1)."</td>";
echo "<td>".$row['paket']."</td>";
echo "<td>".$row['payment']."</td>";
echo "<td>".$row['status']."</td>";

echo "<td>
<a class='lunas' href='?lunas=$i'>LUNAS</a>
<a class='hapus' href='?hapus=$i'>HAPUS</a>
</td>";

echo "</tr>";

}

?>
                    </div>
                </td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</main>
</body>
</html>
