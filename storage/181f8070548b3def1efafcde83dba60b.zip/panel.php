<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Ambil data baik dari POST (langsung) atau dari input stream
$email = $_POST['email'] ?? '';
$jumlahResult = $_POST['jumlahResult'] ?? '';

if (!$email || !$jumlahResult) {
    echo json_encode([
        "success" => false,
        "error" => "Data tidak lengkap: Email=$email, Result=$jumlahResult"
    ]);
    exit;
}

// 1. Simpan ke log lokal untuk backup
$logData = [
    'timestamp' => date('Y-m-d H:i:s'),
    'email' => $email,
    'jumlah_result' => $jumlahResult
];
file_put_contents('orders.log', json_encode($logData) . PHP_EOL, FILE_APPEND | LOCK_EX);

// 2. Kirim ke API add.php (Target Akhir)
$apiUrl = "https://ropihosting.unpkg.web.id/tesssssssssssssss/ropiHost/";

// Gunakan array untuk POST agar diterima sebagai $_POST di add.php
$postFields = [
    "email" => $email,
    "jumlahResult" => $jumlahResult
];

$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $postFields, // Mengirim sebagai multipart/form-data agar terbaca $_POST
    CURLOPT_TIMEOUT => 15,
    CURLOPT_SSL_VERIFYPEER => false 
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

// Output hasil untuk dibaca oleh Cron Monitor
if ($error) {
    echo json_encode(["success" => false, "error" => $error]);
} else {
    // Teruskan response dari add.php
    http_response_code($httpCode);
    echo $response;
}
?>
