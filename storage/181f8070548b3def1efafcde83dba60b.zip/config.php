<?php
// config.php

ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Asia/Jakarta');

// API CASAKU
$apiKey ='cashify_1e136acfe3f96d218807e1c54661c7c89e9136d47ab51b5800d7aeb9bf8ee2ec';
$baseUrl = 'https://api.casaku.id';


/*
|--------------------------------------------------------------------------
| WEBHOOK CASAKU
|--------------------------------------------------------------------------
| Isi dengan Webhook Secret dari dashboard Casaku
|--------------------------------------------------------------------------
*/

$casakuWebhookSecret = 'cashify_3bc9f84c8b9868adbc2fc281e7bd4665a09ca8f71074292bd1c7ae0617b8dc87fef2ecb8413f54ae09173fc27dbe9fc8f1a2b9cf498dd686f43ea249ae691a2b';


/*
|--------------------------------------------------------------------------
| LOGIN ADMIN
|--------------------------------------------------------------------------
*/

$adminUsername = '123';
$adminPassword = 'admin';


/*
|--------------------------------------------------------------------------
| DATA PRODUK UTAMA
|--------------------------------------------------------------------------
| Halaman hosting.php

|--------------------------------------------------------------------------
*/

$products = [
    1 => [
        'id' => 1,
        'nama' => 'PT JASTEB',
        'harga' => 10000,
        'link_produk' => 'https://chat.whatsapp.com/BaTMCc58xW43qBImUxu85E?s=cl&p=a&mlu=4',
        'gambar' => 'https://cdn.phototourl.com/free/2026-08-10-4783b70d-9007-4af6-aec0-51fd6f768538.png'
    ],

    2 => [
        'id' => 2,
        'nama' => 'MARGA JASTEB',
        'harga' => 20000,
        'link_produk' => 'https://chat.whatsapp.com/BFdMXZxHrOnJiDkVV22KZU?s=cl&p=a&mlu=4',
        'gambar' => 'https://cdn.phototourl.com/free/2026-08-10-62808c81-b949-4753-b13b-14dbd7c1f2f4.png'
    ],

    3 => [
        'id' => 3,
        'nama' => 'FOUNDER JASTEB',
        'harga' => 40000,
        'link_produk' => 'https://chat.whatsapp.com/JINqLJ2L0Tn5tklrW27zKO?s=cl&p=a&mlu=4',
        'gambar' => 'https://cdn.phototourl.com/free/2026-08-10-8e027b18-b815-4142-aa31-8098dc77651f.png'
    ],

    4 => [
        'id' => 4,
        'nama' => 'TANGAN KANAN',
        'harga' => 80000,
        'link_produk' => 'https://chat.whatsapp.com/Jq21tQvzAD9Jk973r2qiDL?s=cl&p=a&mlu=4',
        'gambar' => 'https://cdn.phototourl.com/free/2026-08-10-3fd72a0d-3277-495a-8e98-5ba661eff624.png'
    ]
];


/*
|--------------------------------------------------------------------------
| DATA PAKET JASTEB
|--------------------------------------------------------------------------
| Halaman jasteb.php
|--------------------------------------------------------------------------
*/

$products1 = [
    1 => [
        'id' => 2,
        'result' => '50',
        'price' => '5000',
        'label' => 'VIP'
    ],

    2 => [
        'id' => 3,
        'result' => '160',
        'price' => '10000',
        'label' => 'VIP'
    ],

    3 => [
        'id' => 4,
        'result' => '180',
        'price' => '15000',
        'label' => 'VIP'
    ],

    4 => [
        'id' => 5,
        'result' => '200',
        'price' => '20000',
        'label' => 'PREMIUM'
    ],

    5 => [
        'id' => 6,
        'result' => '280',
        'price' => '25000',
        'label' => 'PREMIUM'
    ],

    6 => [
        'id' => 7,
        'result' => '399',
        'price' => '30000',
        'label' => 'PREMIUM'
    ],

    7 => [
        'id' => 8,
        'result' => '500',
        'price' => '50000',
        'label' => 'PREMIUM'
    ]
];