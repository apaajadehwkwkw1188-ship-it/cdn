// api/send.js
// Kirim Magic Link ke email user
// Semua kredensial diambil dari Environment Variables Vercel, tidak terekspos ke client

const axios = require('axios');
const crypto = require('crypto');

const HEADERS = {
  "Content-Type": "application/json",
  "X-Android-Package": "com.alightcreative.motion",
  "X-Android-Cert": process.env.AM_ANDROID_CERT,
  "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 15; 23127PN0CC Build/BP1A.250505.005)"
};

module.exports = async (req, res) => {
  // CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ success: false, error: "Method not allowed" });

  const { email } = req.body || {};
  if (!email || !email.includes("@")) {
    return res.status(400).json({ success: false, error: "Email tidak valid." });
  }

  const API_KEY = process.env.AM_API_KEY;

  try {
    // Step 1: createAuthUri (ping dulu biar session valid)
    await axios.post(
      `https://www.googleapis.com/identitytoolkit/v3/relyingparty/createAuthUri?key=${API_KEY}`,
      { identifier: email, continueUri: "http://localhost" },
      { headers: HEADERS }
    );

    // Step 2: kirim magic link ke email
    await axios.post(
      `https://www.googleapis.com/identitytoolkit/v3/relyingparty/getOobConfirmationCode?key=${API_KEY}`,
      {
        requestType: 6,
        email: email,
        androidInstallApp: true,
        canHandleCodeInApp: true,
        continueUrl: "https://alightcreative.com?ui_sid=0366624874&ui_sd=0",
        iosBundleId: "com.alightcreative.motion",
        androidPackageName: "com.alightcreative.motion",
        androidMinimumVersion: "585",
        clientType: "CLIENT_TYPE_ANDROID"
      },
      { headers: HEADERS }
    );

    return res.status(200).json({ success: true, message: "Magic Link berhasil dikirim ke email." });
  } catch (error) {
    const errMsg = error.response?.data
      ? (typeof error.response.data === "object"
          ? JSON.stringify(error.response.data)
          : error.response.data)
      : error.message;
    return res.status(500).json({ success: false, error: errMsg });
  }
};
