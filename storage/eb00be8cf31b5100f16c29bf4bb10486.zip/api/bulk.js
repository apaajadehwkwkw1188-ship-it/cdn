// api/bulk.js
// Generate bulk temp email pakai scrape generator.email
// Domain diambil live dari site, username random setiap generate

const axios = require('axios');
const cheerio = require('cheerio');

const BASE_URL = 'https://generator.email';
const FALLBACK_DOMAINS = ['fboxmail.com', 'cunan.store', 'sds-awe.top', 'mengundang.live', 'kintil.buzz', 'ketua.id'];

// Cache domain biar ga scrape tiap request
let cachedDomains = [];
let domainsFetchedAt = 0;
const CACHE_TTL = 5 * 60 * 1000; // 5 menit

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

async function getActiveDomains() {
  const now = Date.now();
  if (cachedDomains.length > 0 && (now - domainsFetchedAt < CACHE_TTL)) {
    return cachedDomains;
  }

  try {
    // Step 1: ambil api-token dari meta tag
    const homeRes = await axios.get(BASE_URL + '/', {
      headers: { 'User-Agent': UA, 'Accept': 'text/html', 'Accept-Language': 'en-US,en;q=0.9' },
      timeout: 10000,
      validateStatus: () => true
    });

    const $ = cheerio.load(homeRes.data);
    const token = $('meta[name="api-token"]').attr('content');

    if (!token) throw new Error('api-token not found');

    // Ambil cookies dari response
    const rawCookies = homeRes.headers['set-cookie'] || [];
    const cookieStr = rawCookies.map(c => c.split(';')[0]).join('; ');

    // Step 2: hit domains API
    const domRes = await axios.get(BASE_URL + '/api/domains.php', {
      headers: {
        'User-Agent': UA,
        'X-API-Token': token,
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': BASE_URL + '/',
        'Cookie': cookieStr
      },
      timeout: 10000,
      validateStatus: () => true
    });

    if (domRes.status === 200 && Array.isArray(domRes.data) && domRes.data.length > 0) {
      const domains = domRes.data
        .map(d => typeof d === 'object' ? (d.ascii || d.display) : null)
        .filter(Boolean)
        .map(d => d.trim().toLowerCase());

      if (domains.length > 0) {
        cachedDomains = domains;
        domainsFetchedAt = now;
        return cachedDomains;
      }
    }
  } catch (_) {
    // fallback
  }

  cachedDomains = FALLBACK_DOMAINS;
  domainsFetchedAt = Date.now();
  return cachedDomains;
}

function randomUsername() {
  // random string 8-12 karakter alfanumerik
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  const len = 8 + Math.floor(Math.random() * 5);
  let result = '';
  for (let i = 0; i < len; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

async function generateEmails(count) {
  const domains = await getActiveDomains();
  const emails = [];
  for (let i = 0; i < count; i++) {
    const domain = domains[Math.floor(Math.random() * domains.length)];
    const username = randomUsername();
    emails.push({ index: i + 1, email: `${username}@${domain}` });
  }
  return emails;
}

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ success: false, error: 'Method not allowed' });

  let { total } = req.body || {};
  total = parseInt(total);
  if (isNaN(total) || total < 1 || total > 100) {
    return res.status(400).json({ success: false, error: 'Total harus antara 1 sampai 100.' });
  }

  try {
    const accounts = await generateEmails(total);
    return res.status(200).json({ success: true, total: accounts.length, accounts });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
};
