// api/auto-bulk.js
// FIXED: polling dipindah ke frontend — server hanya send magic link + 1x poll per request
// Frontend yang loop panggil /api/auto-bulk?action=poll setiap 6 detik
const axios   = require('axios');
const cheerio = require('cheerio');
const crypto  = require('crypto');

const BASE_GEN   = 'https://generator.email';
const UA_BROWSER = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';
const UA_APP     = 'Dalvik/2.1.0 (Linux; U; Android 15; 23127PN0CC Build/BP1A.250505.005)';

const AM_HEADERS = {
  'Content-Type': 'application/json',
  'X-Android-Package': 'com.alightcreative.motion',
  'X-Android-Cert': process.env.AM_ANDROID_CERT,
  'User-Agent': UA_APP
};

const WHITELIST_DOMAINS = [
  'fboxmail.com', 'cunan.store', 'mengundang.live', 'kintil.buzz',
  'enayu.com', 'fexpost.com', 'kurzepost.de', 'objectmail.com', 'rvb.ro',
  'stringness.de', 'wegwerfmail.de', 'wegwerfmail.net', 'wegwerfmail.org',
  'yopmail.com', 'guerrillamail.com', 'sharklasers.com', 'guerrillamailblock.com',
  'grr.la', 'guerrillamail.info', 'guerrillamail.biz', 'guerrillamail.de',
  'guerrillamail.net', 'guerrillamail.org', 'spam4.me',
  'trashmail.com', 'trashmail.me', 'trashmail.net',
  'dispostable.com', 'mailnull.com', 'spamgourmet.com',
  'croscam.com', 'sds-awe.top', 'ketua.id',
  'mellified.men', 'binkmail.com', 'bobmail.info', 'chammy.info',
  'letthemeatspam.com', 'spamavert.com', 'mailnew.com',
];

const BLOCKED_PATTERNS = [
  /youtube-com/i, /watch-/i, /\.cyou$/i, /\.click$/i,
  /\.top$/i, /\.xyz$/i, /\.live$/i, /\.online$/i, /\.site$/i,
  /\.fun$/i, /\.icu$/i, /\.monster$/i, /\.work$/i, /\d{4,}/,
  /polysolext/i, /steadyhabit/i, /cuscuscus/i,
];

function isDomainAllowed(domain) {
  if (WHITELIST_DOMAINS.includes(domain)) return true;
  if (BLOCKED_PATTERNS.some(p => p.test(domain))) return false;
  const safeTlds = ['.com', '.net', '.org', '.de', '.info', '.me', '.store', '.id'];
  return safeTlds.some(t => domain.endsWith(t));
}

const FALLBACK_DOMAINS = ['fboxmail.com', 'cunan.store', 'mengundang.live', 'enayu.com', 'wegwerfmail.de'];

let _cachedDomains = [];
let _domainTs      = 0;
let _sessionCookie = '';
let _genToken      = '';

async function refreshSession() {
  try {
    const res = await axios.get(BASE_GEN + '/', {
      headers: { 'User-Agent': UA_BROWSER, 'Accept': 'text/html,*/*' },
      timeout: 8000, validateStatus: () => true, maxRedirects: 5
    });
    const $ = cheerio.load(res.data);
    _genToken      = $('meta[name="api-token"]').attr('content') || '';
    _sessionCookie = (res.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ');
    return true;
  } catch (_) { return false; }
}

async function getActiveDomains() {
  if (_cachedDomains.length && Date.now() - _domainTs < 3 * 60 * 1000) return _cachedDomains;
  for (let i = 0; i < 2; i++) {
    try {
      if (!_genToken) await refreshSession();
      const r = await axios.get(BASE_GEN + '/api/domains.php', {
        headers: { 'User-Agent': UA_BROWSER, 'X-API-Token': _genToken, 'X-Requested-With': 'XMLHttpRequest', 'Referer': BASE_GEN + '/', 'Cookie': _sessionCookie },
        timeout: 8000, validateStatus: () => true
      });
      if (r.status === 200 && Array.isArray(r.data) && r.data.length) {
        const doms = r.data.map(d => typeof d === 'object' ? (d.ascii || d.unicode || d.display || '') : String(d))
          .map(d => d.trim().toLowerCase())
          .filter(d => d.includes('.') && isDomainAllowed(d));
        if (doms.length) { _cachedDomains = doms; _domainTs = Date.now(); return _cachedDomains; }
      }
    } catch (_) {}
    await refreshSession();
  }
  _cachedDomains = FALLBACK_DOMAINS; _domainTs = Date.now();
  return _cachedDomains;
}

function randUsername() {
  const c = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let s = 'user_';
  for (let i = 0; i < 8; i++) s += c[Math.floor(Math.random() * c.length)];
  return s;
}

function extractMagicLink(html) {
  const patterns = [
    /href=["'](https:\/\/alight-creative\.firebaseapp\.com[^"'<>\s\\]+)/gi,
    /href=["'](https:\/\/alightcreative\.com\/auth_action[^"'<>\s\\]+)/gi,
    /(https:\/\/alight-creative\.firebaseapp\.com[^\s"'<>\\]+)/gi,
    /(https:\/\/alightcreative\.com\/auth_action[^\s"'<>\\]+)/gi,
    /(https?:\/\/[^\s"'<>\]]+oobCode=[a-zA-Z0-9_%-]+[^\s"'<>\]]*)/gi,
  ];
  for (const pat of patterns) {
    pat.lastIndex = 0;
    const m = pat.exec(html);
    if (m) return m[1].replace(/&amp;/g, '&').replace(/[)\]>]+$/, '');
  }
  return null;
}

// Poll inbox SEKALI saja — dipanggil berulang dari frontend
async function pollInboxOnce(email) {
  const [username, domain] = email.split('@');
  const inboxCtx = encodeURIComponent(`${domain}/${username}/`);
  const surl     = `${domain}/${username}`;
  const embx     = encodeURIComponent(JSON.stringify([email]));
  const inboxCookies = `inbox_ctx=${inboxCtx}; surl=${surl}; embx=${embx}`;
  const fullCookie   = _sessionCookie ? `${_sessionCookie}; ${inboxCookies}` : inboxCookies;

  const urls = [
    `${BASE_GEN}/${domain}/${username}`,
    `${BASE_GEN}/inbox1/`,
  ];

  for (const url of urls) {
    try {
      const res = await axios.get(url, {
        headers: {
          'User-Agent': UA_BROWSER, 'Accept': 'text/html,*/*',
          'Referer': BASE_GEN + '/', 'Cookie': fullCookie
        },
        timeout: 6000, validateStatus: () => true, maxRedirects: 10
      });
      if (res.status !== 200) continue;
      const html = res.data || '';

      const directLink = extractMagicLink(html);
      if (directLink) return directLink;

      // Cek pesan individual
      const $ = cheerio.load(html);
      const msgLinks = [];
      $('[onclick*="loadInboxClientSide"]').each((_, el) => {
        const m = ($(el).attr('onclick') || '').match(/loadInboxClientSide\(['"'](.+?)['"']\)/);
        if (m) msgLinks.push(m[1]);
      });
      $('a[href]').each((_, el) => {
        const href = $(el).attr('href') || '';
        if (href.includes(`/${domain}/${username}/`) || href.includes('/read/')) msgLinks.push(href);
      });

      for (const msgPath of [...new Set(msgLinks)].slice(0, 3)) {
        try {
          const msgUrl = msgPath.startsWith('http') ? msgPath : `${BASE_GEN}/${domain}/${username}/${msgPath.replace(/^\//, '')}`;
          const mr = await axios.get(msgUrl, {
            headers: { 'User-Agent': UA_BROWSER, 'Accept': 'text/html,*/*', 'Referer': url, 'Cookie': fullCookie },
            timeout: 5000, validateStatus: () => true, maxRedirects: 5
          });
          if (mr.status === 200) {
            const link = extractMagicLink(mr.data || '');
            if (link) return link;
          }
        } catch (_) {}
      }
    } catch (_) {}
  }
  return null;
}

async function sendMagicLink(email) {
  const K = process.env.AM_API_KEY;
  await axios.post(
    `https://www.googleapis.com/identitytoolkit/v3/relyingparty/createAuthUri?key=${K}`,
    { identifier: email, continueUri: 'https://alightcreative.com/' },
    { headers: AM_HEADERS, timeout: 12000 }
  );
  await axios.post(
    `https://www.googleapis.com/identitytoolkit/v3/relyingparty/getOobConfirmationCode?key=${K}`,
    {
      requestType: 6, email,
      androidInstallApp: true, canHandleCodeInApp: true,
      continueUrl: 'https://alightcreative.com?ui_sid=0366624874&ui_sd=0',
      iosBundleId: 'com.alightcreative.motion',
      androidPackageName: 'com.alightcreative.motion',
      androidMinimumVersion: '585',
      clientType: 'CLIENT_TYPE_ANDROID'
    },
    { headers: AM_HEADERS, timeout: 12000 }
  );
}

function extractOobCode(url) {
  try {
    let u = url.replace(/&amp;/g, '&');
    try { u = decodeURIComponent(u); } catch (_) {}
    const obj = new URL(u);
    let code = obj.searchParams.get('oobCode');
    if (!code) {
      for (const p of ['link', 'q', 'url', 'deep_link_id']) {
        const nested = obj.searchParams.get(p);
        if (nested) { try { code = new URL(nested).searchParams.get('oobCode'); if (code) break; } catch (_) {} }
      }
    }
    if (code) return code.replace(/[^a-zA-Z0-9_-]/g, '');
  } catch (_) {}
  const m = url.match(/oobCode=([a-zA-Z0-9_%-]+)/i);
  return m ? decodeURIComponent(m[1]) : null;
}

async function activatePremium(email, magicLink) {
  const K   = process.env.AM_API_KEY;
  const oob = extractOobCode(magicLink);
  if (!oob) throw new Error('oobCode tidak ditemukan di magic link');
  const sr = await axios.post(
    `https://www.googleapis.com/identitytoolkit/v3/relyingparty/emailLinkSignin?key=${K}`,
    { email, oobCode: oob, clientType: 'CLIENT_TYPE_ANDROID' },
    { headers: AM_HEADERS, timeout: 12000 }
  );
  const idToken = sr.data?.idToken;
  if (!idToken) throw new Error('idToken tidak diterima');
  const codeorder = crypto.randomInt(10000, 99999).toString();
  await axios.post(
    'https://us-central1-alight-creative.cloudfunctions.net/verifyPurchase',
    { data: { productId: process.env.AM_PRODUCT_ID, token: process.env.AM_TOKEN, skuType: 'subs', orderId: `${process.env.AM_ORDER_ID}-${codeorder}` } },
    {
      headers: {
        authorization: 'Bearer ' + idToken,
        'firebase-instance-id-token': process.env.AM_FIREBASE_INSTANCE_TOKEN,
        'content-type': 'application/json; charset=utf-8',
        'accept-encoding': 'gzip', 'user-agent': 'okhttp/3.12.1'
      },
      timeout: 20000
    }
  );
  return codeorder;
}

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  // ── ACTION: poll — dipanggil frontend tiap 6 detik ─────────────────────────
  // POST { action: 'poll', email: '...' }
  if (req.method === 'POST' && req.body?.action === 'poll') {
    const { email } = req.body;
    if (!email || !email.includes('@'))
      return res.status(400).json({ success: false, message: 'Email tidak valid' });
    try {
      if (!_sessionCookie) await refreshSession();
      const link = await pollInboxOnce(email);
      if (link) return res.status(200).json({ success: true, link });
      return res.status(200).json({ success: false, message: 'Belum ada email' });
    } catch (err) {
      return res.status(200).json({ success: false, message: err.message });
    }
  }

  // ── ACTION: activate — dipanggil frontend setelah dapat link ───────────────
  // POST { action: 'activate', email: '...', link: '...' }
  if (req.method === 'POST' && req.body?.action === 'activate') {
    const { email, link } = req.body;
    if (!email || !link)
      return res.status(400).json({ success: false, message: 'Email dan link diperlukan' });
    try {
      await activatePremium(email, link);
      return res.status(200).json({ success: true });
    } catch (err) {
      return res.status(500).json({ success: false, message: err.message });
    }
  }

  // ── GET: generate email + kirim magic link via SSE ─────────────────────────
  // Frontend subscribe EventSource, server kirim: domains → start (email) → sent → done/error
  if (req.method === 'GET') {
    const total = parseInt(req.query?.total || '1');
    if (isNaN(total) || total < 1 || total > 100)
      return res.status(400).json({ success: false, error: 'Total harus antara 1–100.' });

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    function sse(event, data) {
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    }

    await refreshSession();
    const domains = await getActiveDomains();
    sse('domains', { domains: domains.slice(0, 5) });

    for (let i = 0; i < total; i++) {
      const domain   = domains[Math.floor(Math.random() * domains.length)];
      const username = randUsername();
      const email    = `${username}@${domain}`;
      const idx      = i + 1;

      sse('progress', { index: idx, email, status: 'sending', msg: 'Mengirim magic link...' });

      try {
        await sendMagicLink(email);
        // Kirim event 'sent' — frontend yang akan polling inbox
        sse('sent', { index: idx, email, status: 'sent', msg: 'Magic link terkirim. Frontend akan polling inbox...' });
      } catch (err) {
        const errMsg = err.response?.data
          ? (typeof err.response.data === 'object' ? JSON.stringify(err.response.data) : err.response.data)
          : err.message;
        sse('progress', { index: idx, email, status: 'failed', msg: `Gagal kirim: ${errMsg}`, error: errMsg });
      }
    }

    // Server selesai mengirim semua magic link
    // Frontend yang akan polling dan aktivasi
    sse('send_done', { success: true, total, msg: 'Semua magic link terkirim. Frontend polling inbox...' });
    res.end();
    return;
  }

  return res.status(405).json({ success: false, error: 'Method not allowed' });
};
