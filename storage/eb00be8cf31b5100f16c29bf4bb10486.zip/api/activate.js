// api/activate.js
// Verifikasi oobCode dari Magic Link, lalu apply Premium ke akun
// Semua kredensial dari Environment Variables Vercel

const axios = require('axios');
const crypto = require('crypto');

const HEADERS = {
  "Content-Type": "application/json",
  "X-Android-Package": "com.alightcreative.motion",
  "X-Android-Cert": process.env.AM_ANDROID_CERT,
  "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 15; 23127PN0CC Build/BP1A.250505.005)"
};

function extractOobCode(fullUrl) {
  if (!fullUrl) return null;
  try {
    let cleanUrl = fullUrl.replace(/&amp;/g, '&');
    try { cleanUrl = decodeURIComponent(cleanUrl); } catch(e) {}

    try {
      const urlObj = new URL(cleanUrl);
      let oobCode = urlObj.searchParams.get('oobCode');
      if (!oobCode) {
        const nestedLink = urlObj.searchParams.get('link') || urlObj.searchParams.get('q') || urlObj.searchParams.get('url');
        if (nestedLink) {
          try {
            const innerUrlObj = new URL(nestedLink);
            oobCode = innerUrlObj.searchParams.get('oobCode');
          } catch (e) {}
        }
      }
      if (oobCode) return oobCode.replace(/[^a-zA-Z0-9_-]/g, '');
    } catch (e) {}

    const match = cleanUrl.match(/[?&]oobCode=([a-zA-Z0-9_-]+)/i) || cleanUrl.match(/oobCode=([a-zA-Z0-9_-]+)/i);
    if (match && match[1]) return match[1];
    return null;
  } catch (e) {
    return null;
  }
}

module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ success: false, error: "Method not allowed" });

  const { email, magicLink } = req.body || {};
  if (!email || !magicLink) {
    return res.status(400).json({ success: false, error: "Email dan Magic Link wajib diisi." });
  }

  const API_KEY      = process.env.AM_API_KEY;
  const TOKEN        = process.env.AM_TOKEN;
  const PRODUCT_ID   = process.env.AM_PRODUCT_ID;
  const ORDER_ID     = process.env.AM_ORDER_ID;
  const FB_INST_TOKEN = process.env.AM_FIREBASE_INSTANCE_TOKEN;
  const SKU_TYPE     = "subs";

  try {
    // Step 1: extract oobCode dari magic link
    const oobCode = extractOobCode(magicLink);
    if (!oobCode) {
      return res.status(400).json({ success: false, error: "Gagal mengekstrak oobCode dari Magic Link." });
    }

    // Step 2: signin pakai oobCode
    const signinRes = await axios.post(
      `https://www.googleapis.com/identitytoolkit/v3/relyingparty/emailLinkSignin?key=${API_KEY}`,
      { email, oobCode, clientType: "CLIENT_TYPE_ANDROID" },
      { headers: HEADERS }
    );
    const idToken = signinRes.data.idToken;

    // Step 3: apply premium
    const codeorder = crypto.randomInt(10000, 99999).toString();
    const premiumRes = await axios.post(
      "https://us-central1-alight-creative.cloudfunctions.net/verifyPurchase",
      {
        data: {
          productId: PRODUCT_ID,
          token: TOKEN,
          skuType: SKU_TYPE,
          orderId: `${ORDER_ID}-${codeorder}`
        }
      },
      {
        headers: {
          "authorization": "Bearer " + idToken,
          "firebase-instance-id-token": FB_INST_TOKEN,
          "content-type": "application/json; charset=utf-8",
          "accept-encoding": "gzip",
          "user-agent": "okhttp/3.12.1"
        }
      }
    );

    return res.status(200).json({
      success: true,
      message: "Aktivasi Premium berhasil!",
      data: premiumRes.data,
      codeorder
    });
  } catch (error) {
    const errMsg = error.response?.data
      ? (typeof error.response.data === "object"
          ? JSON.stringify(error.response.data)
          : error.response.data)
      : error.message;
    return res.status(500).json({ success: false, error: errMsg });
  }
};
