// api/debug-inbox.js — debug detail: baca isi pesan satu per satu
const axios   = require('axios');
const cheerio = require('cheerio');

const BASE_GEN   = 'https://generator.email';
const UA_BROWSER = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const email = req.query.email;
  if (!email || !email.includes('@')) return res.status(400).json({ error: 'param ?email= required' });

  const [username, domain] = email.split('@');

  // Step 1: ambil session
  let sessionCookie = '';
  let genToken = '';
  try {
    const home = await axios.get(BASE_GEN + '/', {
      headers: { 'User-Agent': UA_BROWSER }, timeout: 10000, validateStatus: () => true
    });
    const $ = cheerio.load(home.data);
    genToken = $('meta[name="api-token"]').attr('content') || '';
    sessionCookie = (home.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ');
  } catch(e) {}

  const inboxCtx  = encodeURIComponent(`${domain}/${username}/`);
  const surl      = `${domain}/${username}`;
  const embx      = encodeURIComponent(JSON.stringify([email]));
  const inboxCookies = `inbox_ctx=${inboxCtx}; surl=${surl}; embx=${embx}`;
  const fullCookie   = sessionCookie ? `${sessionCookie}; ${inboxCookies}` : inboxCookies;

  // Coba semua inbox 1-10
  const inboxResults = {};
  for (let n = 1; n <= 10; n++) {
    try {
      const r = await axios.get(`${BASE_GEN}/inbox${n}/`, {
        headers: { 'User-Agent': UA_BROWSER, 'Accept': 'text/html,*/*', 'Referer': BASE_GEN+'/', 'Cookie': fullCookie },
        timeout: 8000, validateStatus: () => true, maxRedirects: 0
      });
      if (r.status !== 200) continue;

      const $ = cheerio.load(r.data);
      const msgs = [];
      $('[onclick*="loadInboxClientSide"]').each((_, el) => {
        const m = ($(el).attr('onclick') || '').match(/loadInboxClientSide\(['"](.+?)['"]\)/);
        const from = $(el).find('[class*="from"]').text().trim() || $(el).text().trim().substring(0,50);
        if (m) msgs.push({ path: m[1], from });
      });

      // Cek num_mess dari script
      let numMess = 0;
      $('script').each((_, el) => {
        const t = $(el).html() || '';
        const m = t.match(/num_mess['":\s]+(\d+)/);
        if (m) numMess = parseInt(m[1]);
      });

      if (msgs.length > 0 || numMess > 0) {
        // Baca isi tiap pesan
        const msgDetails = [];
        for (const msg of msgs.slice(0, 3)) {
          try {
            const msgUrl = `${BASE_GEN}/${domain}/${username}/${msg.path}`;
            const mc = `inbox_ctx=${encodeURIComponent(`${domain}/${username}/${msg.path}`)}; surl=${surl}; embx=${embx}`;
            const mr = await axios.get(msgUrl, {
              headers: { 'User-Agent': UA_BROWSER, 'Accept': 'text/html,*/*', 'Referer': `${BASE_GEN}/inbox${n}/`, 'Cookie': sessionCookie ? `${sessionCookie}; ${mc}` : mc },
              timeout: 8000, validateStatus: () => true
            });
            const html = mr.data || '';
            msgDetails.push({
              path: msg.path,
              from: msg.from,
              hasOobCode: html.includes('oobCode'),
              hasFirebase: html.includes('firebaseapp'),
              hasAlightCreative: html.includes('alightcreative'),
              // Extract link langsung
              magicLinks: (html.match(/https?:\/\/[^\s"'<>]+oobCode=[^\s"'<>]*/gi) || []).slice(0,2),
              firebaseLinks: (html.match(/https?:\/\/alight-creative\.firebaseapp\.com[^\s"'<>]*/gi) || []).slice(0,2),
              htmlSnippet: html.substring(2000, 3000) // tengah html biasanya ada link
            });
          } catch(e) { msgDetails.push({ path: msg.path, error: e.message }); }
        }
        inboxResults[`inbox${n}`] = { numMess, msgs, msgDetails };
      }
    } catch(_) {}
  }

  // Direct URL
  let directResult = {};
  try {
    const r = await axios.get(`${BASE_GEN}/${domain}/${username}`, {
      headers: { 'User-Agent': UA_BROWSER, 'Accept': 'text/html,*/*', 'Referer': BASE_GEN+'/', 'Cookie': fullCookie },
      timeout: 8000, validateStatus: () => true, maxRedirects: 10
    });
    const html = r.data || '';
    const $ = cheerio.load(html);
    const msgs = [];
    $('[onclick*="loadInboxClientSide"]').each((_, el) => {
      const m = ($(el).attr('onclick') || '').match(/loadInboxClientSide\(['"](.+?)['"]\)/);
      if (m) msgs.push(m[1]);
    });
    directResult = {
      status: r.status,
      finalUrl: r.request?.res?.responseUrl || 'unknown',
      msgs,
      hasOobCode: html.includes('oobCode'),
      magicLinks: (html.match(/https?:\/\/[^\s"'<>]+oobCode=[^\s"'<>]*/gi) || []).slice(0,3),
    };
  } catch(e) { directResult = { error: e.message }; }

  return res.status(200).json({ email, genToken: genToken ? genToken.substring(0,20)+'...' : 'none', inboxResults, directResult });
};
