// app.js — Ayakamotion Frontend Logic

const AD_REDIRECT_URL = "https://underminestudiedboot.com/jxxpm0yg?key=a9f31f36fe1ae253596407b4bf6c59b4";
const QRIS_URL = "https://u.pone.rs/taijsvjp.jpg";
const VIDEO_URL = "https://u.pone.rs/ggnzwlll.mp4";

let currentPage = 'dashboard';

// ===== NAVIGATION =====
function switchPage(page) {
  currentPage = page;
  document.querySelectorAll('.page-view').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.bottom-tab').forEach(el => el.classList.remove('active'));

  const pageMap = {
    dashboard:   { page: 'pageDashboard',   tab: 'tabDash',     nav: 0 },
    genV1:       { page: 'pageGenV1',        tab: 'tabAktivasi', nav: 1 },
    genV2:       { page: 'pageGenV2',        tab: 'tabAktivasi', nav: 2 },
    genV3:       { page: 'pageGenV3',        tab: 'tabAktivasi', nav: 3 },
    genV4:       { page: 'pageGenV4',        tab: 'tabAktivasi', nav: 4 },
    autoTempMail:{ page: 'pageAutoTempMail', tab: 'tabAktivasi', nav: 5 },
    tutorial:    { page: 'pageTutorial',     tab: 'tabTutorial', nav: 6 },
    dukung:      { page: 'pageDukung',       tab: 'tabDukung',   nav: 7 },
  };

  const target = pageMap[page];
  if (!target) return;

  document.getElementById(target.page)?.classList.add('active');
  document.getElementById(target.tab)?.classList.add('active');

  const navItems = document.querySelectorAll('.nav-item');
  if (navItems[target.nav]) navItems[target.nav].classList.add('active');

  const pathMap = {
    dashboard: '/', genV1: '/generator-v1', genV2: '/generator-v2',
    genV3: '/generator-v3', genV4: '/generator-v4',
    autoTempMail: '/bulk', tutorial: '/tutorial', dukung: '/dukung'
  };
  history.pushState({ page }, '', pathMap[page] || '/');
  closeSidebar();
  window.scrollTo(0, 0);
}

window.addEventListener('popstate', (e) => {
  switchPage(e.state?.page || 'dashboard');
});

// ===== SIDEBAR =====
function openSidebarFn() {
  document.getElementById('sidebar').classList.add('active');
  document.getElementById('sidebarOverlay').classList.add('active');
}
function closeSidebar() {
  const s = document.getElementById('sidebar');
  const o = document.getElementById('sidebarOverlay');
  if (s) s.classList.remove('active');
  if (o) o.classList.remove('active');
}

// ===== MODAL QRIS =====
function toggleQrisModal(show) {
  document.getElementById('qrisModal').classList.toggle('active', show);
}

// ===== PING =====
async function checkRealPing() {
  const start = performance.now();
  try {
    await fetch('/api/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ _ping: true, email: 'ping@ping.com' }),
      cache: 'no-store',
      signal: AbortSignal.timeout(5000)
    });
  } catch (_) {}
  const ms = Math.round(performance.now() - start);
  const txt = ms + ' ms';
  const pv = document.getElementById('pingVal');
  const tp = document.getElementById('topPing');
  if (pv) pv.innerText = txt;
  if (tp) tp.innerText = txt;
}

// ===== VISITOR COUNTER (localStorage-based, countapi mati) =====
function setupVisitorCounter() {
  const DEVICE_KEY = 'ayakamotion_device_registered';
  const COUNT_KEY  = 'ayakamotion_visitor_count';
  const el = document.getElementById('userVal');
  if (!el) return;

  let count = parseInt(localStorage.getItem(COUNT_KEY)) || 0;
  if (!localStorage.getItem(DEVICE_KEY)) {
    count++;
    localStorage.setItem(COUNT_KEY, count);
    localStorage.setItem(DEVICE_KEY, 'true');
  }
  el.innerText = count;
}

function fetchGeneratedCount() {
  const el = document.getElementById('generatedVal');
  if (!el) return;
  el.innerText = localStorage.getItem('ayakamotion_gen_fallback') || '0';
}

function triggerAccountGenerated() {
  const el = document.getElementById('generatedVal');
  const lock = 'ayakamotion_gen_counted_device';
  if (!sessionStorage.getItem(lock)) {
    let c = parseInt(localStorage.getItem('ayakamotion_gen_fallback')) || 0;
    c++;
    localStorage.setItem('ayakamotion_gen_fallback', c);
    if (el) el.innerText = c;
    sessionStorage.setItem(lock, 'true');
  }
}

// ===== STEP INDICATOR =====
function updateStepIndicator(vId, activeStep, currentAd = 0) {
  for (let i = 1; i <= 3; i++) {
    const box = document.getElementById(`stepBoxV${vId}_${i}`);
    if (!box) continue;
    box.classList.remove('inactive');
    if (i === activeStep) {
      box.style.background = 'rgba(255,255,255,0.7)';
      box.style.opacity = '1';
      box.style.boxShadow = '2px 2px 0px #000';
    } else if (i < activeStep) {
      box.style.background = 'rgba(220,252,231,0.8)';
      box.style.opacity = '0.9';
      box.style.boxShadow = 'none';
    } else {
      box.style.background = 'rgba(255,255,255,0.3)';
      box.style.opacity = '0.7';
      box.style.boxShadow = 'none';
    }
  }
  const counterEl = document.getElementById(`adCountV${vId}`);
  if (counterEl) counterEl.innerText = currentAd;
}

// ===== ADS SEQUENCE =====
function runSequentialAdsAndVerify(vId, onComplete) {
  let adIndex = 0;
  const total = 5;
  updateStepIndicator(vId, 2, adIndex);
  function nextAd() {
    if (adIndex < total) {
      adIndex++;
      updateStepIndicator(vId, 2, adIndex);
      window.open(AD_REDIRECT_URL, '_blank');
      if (adIndex < total) {
        setTimeout(nextAd, 2500);
      } else {
        updateStepIndicator(vId, 3, total);
        onComplete();
      }
    }
  }
  nextAd();
}

// ===== HELPER MSG =====
function showMsg(boxEl, text, type = 'error') {
  const icon = type === 'success'
    ? '<i class="fas fa-circle-check"></i>'
    : '<i class="fas fa-circle-exclamation"></i>';
  boxEl.innerHTML = icon + '<span>' + text + '</span>';
  boxEl.className = 'message show ' + type;
}
function hideMsg(boxEl) {
  boxEl.className = 'message';
  boxEl.innerHTML = '';
}

// ===== GENERATOR FACTORY =====
function setupGenerator(vId) {
  const emailInput  = document.getElementById(`emailInputV${vId}`);
  const magicInput  = document.getElementById(`magicInputV${vId}`);
  const sendBtn     = document.getElementById(`sendBtnV${vId}`);
  const activateBtn = document.getElementById(`activateBtnV${vId}`);
  const btnText     = document.getElementById(`btnTextV${vId}`);
  const msgBox      = document.getElementById(`msgBoxV${vId}`);
  const resetBtn    = document.getElementById(`resetFormBtnV${vId}`);
  if (!emailInput) return;
  let cachedEmail = '';

  const iconMap  = { 1: 'fa-shield-halved', 2: 'fa-bolt', 3: 'fa-shield-halved', 4: 'fa-bolt' };
  const labelMap = { 1: 'Verifikasi & Aktifkan', 2: `Aktifkan V${vId}`, 3: `Aktifkan V${vId}`, 4: `Aktifkan V${vId}` };
  const defaultBtnHtml = `<i class="fas ${iconMap[vId]}"></i> ${labelMap[vId]}`;

  sendBtn.addEventListener('click', async () => {
    const email = emailInput.value.trim();
    if (!email || !email.includes('@')) {
      showMsg(msgBox, 'Masukkan alamat email yang valid.', 'error'); return;
    }
    sendBtn.innerHTML = '<div class="loader"></div>';
    sendBtn.disabled = true;
    hideMsg(msgBox);
    try {
      const res = await fetch('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      if (data.success) {
        cachedEmail = email;
        showMsg(msgBox, 'Magic Link berhasil dikirim. Silakan cek inbox email kamu.', 'success');
        updateStepIndicator(vId, 1, 0);
      } else {
        showMsg(msgBox, data.error || 'Gagal mengirim Magic Link.', 'error');
      }
    } catch (err) {
      showMsg(msgBox, 'Koneksi gagal. Periksa internet kamu.', 'error');
    }
    sendBtn.innerHTML = 'Kirim';
    sendBtn.disabled = false;
  });

  activateBtn.addEventListener('click', () => {
    const email = emailInput.value.trim();
    const magic = magicInput.value.trim();
    if (!email || !magic) {
      showMsg(msgBox, 'Email dan Magic Link wajib diisi.', 'error'); return;
    }
    activateBtn.disabled = true;
    btnText.innerHTML = '<div class="loader"></div> Menonton Iklan (0/5)...';
    hideMsg(msgBox);
    runSequentialAdsAndVerify(vId, async () => {
      btnText.innerHTML = '<div class="loader"></div> Memproses Aktivasi...';
      try {
        const res = await fetch('/api/activate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: cachedEmail || email, magicLink: magic })
        });
        const data = await res.json();
        if (data.success) {
          btnText.innerHTML = '<i class="fas fa-circle-check"></i> Premium Aktif!';
          showMsg(msgBox, `Lisensi V${vId} berhasil diaktifkan menjadi Premium!`, 'success');
          triggerAccountGenerated();
          resetBtn.style.display = 'inline-flex';
        } else {
          showMsg(msgBox, data.error || 'Gagal melakukan aktivasi.', 'error');
          btnText.innerHTML = defaultBtnHtml;
          activateBtn.disabled = false;
          updateStepIndicator(vId, 1, 0);
        }
      } catch (err) {
        showMsg(msgBox, 'Koneksi gagal. Periksa internet kamu.', 'error');
        btnText.innerHTML = defaultBtnHtml;
        activateBtn.disabled = false;
        updateStepIndicator(vId, 1, 0);
      }
    });
  });

  resetBtn.addEventListener('click', () => {
    emailInput.value = '';
    magicInput.value = '';
    cachedEmail = '';
    hideMsg(msgBox);
    btnText.innerHTML = defaultBtnHtml;
    activateBtn.disabled = false;
    resetBtn.style.display = 'none';
    updateStepIndicator(vId, 1, 0);
    emailInput.focus();
  });
}

// ===== AUTO BULK — SSE real-time pipeline =====
function setupBulk() {
  const bulkCountInput  = document.getElementById('bulkCountInput');
  const generateBulkBtn = document.getElementById('generateBulkBtn');
  const msgBoxBulk      = document.getElementById('msgBoxBulk');
  const progressWrap    = document.getElementById('bulkProgressWrap');
  const progressList    = document.getElementById('bulkProgressList');
  const resultWrap      = document.getElementById('bulkResultWrap');
  const resultList      = document.getElementById('bulkResultList');
  const copyBulkBtn     = document.getElementById('copyBulkBtn');
  const downloadBulkBtn = document.getElementById('downloadBulkBtn');
  if (!generateBulkBtn) return;

  let lastResults = [];
  let activeES    = null;

  const STATUS_CFG = {
    pending:  { icon: 'fa-clock',            color: '#aaa' },
    sending:  { icon: 'fa-paper-plane',      color: '#a855f7' },
    sent:     { icon: 'fa-paper-plane',      color: '#a855f7' },
    polling:  { icon: 'fa-rotate',           color: '#f59e0b' },
    got_link: { icon: 'fa-link',             color: '#3b82f6' },
    success:  { icon: 'fa-circle-check',     color: '#22c55e' },
    timeout:  { icon: 'fa-clock-rotate-left',color: '#ec4899' },
    failed:   { icon: 'fa-circle-xmark',     color: '#ec4899' },
  };

  function getOrCreateProgCard(index) {
    let el = document.getElementById(`prog-${index}`);
    if (!el) {
      el = document.createElement('div');
      el.id = `prog-${index}`;
      el.style.cssText = 'background:rgba(255,255,255,.6);border-radius:10px;padding:9px 12px;font-size:12px;border:1.5px solid rgba(0,0,0,.07);transition:background .3s;';
      progressList.appendChild(el);
    }
    return el;
  }

  function updateProgCard(data) {
    const cfg = STATUS_CFG[data.status] || STATUS_CFG.pending;
    const spinning = ['sending','polling'].includes(data.status) ? ' fa-spin' : '';
    const el = getOrCreateProgCard(data.index);
    el.innerHTML = `<div style="display:flex;align-items:center;gap:9px;">
      <i class="fas ${cfg.icon}${spinning}" style="color:${cfg.color};font-size:15px;width:16px;text-align:center;flex-shrink:0;"></i>
      <div style="flex:1;min-width:0;">
        <div style="font-weight:700;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${data.email || 'Membuat email...'}</div>
        <div style="color:${cfg.color};font-size:10px;font-weight:600;margin-top:1px;">${data.msg || data.status}</div>
      </div>
      <span style="font-size:10px;opacity:.4;flex-shrink:0;">#${data.index}</span>
    </div>`;
    if (data.status === 'success') el.style.background = 'rgba(220,252,231,.8)';
    else if (['timeout','failed'].includes(data.status)) el.style.background = 'rgba(254,226,226,.8)';
  }

  function addResultCard(r) {
    // Hanya tambah sekali per index
    if (document.getElementById(`result-${r.index}`)) return;
    const loginUrl = r.loginUrl || `https://generator.email/${r.email}`;
    const card = document.createElement('div');
    card.id = `result-${r.index}`;

    if (r.status === 'success') {
      card.style.cssText = 'background:rgba(220,252,231,.75);border:2px solid rgba(34,197,94,.35);border-radius:12px;padding:12px 14px;';
      card.innerHTML = `
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:7px;">
          <i class="fas fa-circle-check" style="color:#22c55e;"></i>
          <span style="font-weight:800;font-size:12px;">AKUN #${r.index} — PREMIUM AKTIF</span>
        </div>
        <div style="font-size:12px;margin-bottom:9px;">
          <span style="opacity:.55;font-size:10px;font-weight:600;">EMAIL</span><br>
          <b style="word-break:break-all;">${r.email}</b>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
          <a href="${loginUrl}" target="_blank" rel="noopener"
             style="display:flex;align-items:center;justify-content:center;gap:5px;background:#a855f7;color:#fff;border-radius:8px;padding:8px 4px;font-size:11px;font-weight:700;text-decoration:none;">
            <i class="fas fa-inbox"></i> Buka Inbox
          </a>
          <button onclick="navigator.clipboard.writeText('${r.email}');this.textContent='✓ Disalin!';setTimeout(()=>this.innerHTML='<i class=\\'fas fa-copy\\'></i> Salin Email',1500)"
             style="display:flex;align-items:center;justify-content:center;gap:5px;background:rgba(0,0,0,.09);color:#222;border:none;border-radius:8px;padding:8px 4px;font-size:11px;font-weight:700;cursor:pointer;">
            <i class="fas fa-copy"></i> Salin Email
          </button>
        </div>`;
    } else {
      card.style.cssText = 'background:rgba(254,226,226,.65);border:1.5px solid rgba(239,68,68,.2);border-radius:12px;padding:11px 14px;';
      card.innerHTML = `
        <div style="display:flex;align-items:center;gap:6px;">
          <i class="fas fa-circle-xmark" style="color:#ec4899;"></i>
          <div>
            <div style="font-weight:700;font-size:11px;">AKUN #${r.index} — ${r.status === 'timeout' ? 'TIMEOUT' : 'GAGAL'}</div>
            <div style="font-size:10px;color:#ec4899;word-break:break-all;">${r.email}</div>
            ${r.error ? `<div style="font-size:10px;opacity:.7;margin-top:2px;">${r.error}</div>` : ''}
          </div>
        </div>`;
    }
    resultList.appendChild(card);
  }

  function startBulk(count) {
    if (activeES) { activeES.close(); activeES = null; }

    hideMsg(msgBoxBulk);
    generateBulkBtn.innerHTML = '<div class="loader"></div> Proses berjalan...';
    generateBulkBtn.disabled = true;
    progressList.innerHTML = '';
    resultList.innerHTML = '';
    progressWrap.style.display = 'block';
    resultWrap.style.display = 'none';
    lastResults = [];

    for (let i = 1; i <= count; i++) {
      updateProgCard({ index: i, email: '', status: 'pending', msg: 'Menunggu antrian...' });
    }

    // ── FIXED: polling dilakukan frontend, bukan server ──────────────────────
    // Server hanya kirim magic link (cepat), frontend loop poll tiap 6 detik
    const POLL_INTERVAL_MS  = 6000;
    const MAX_POLL_ATTEMPTS = 20; // 20 x 6s = 120 detik max per akun
    let sentCount = 0;
    let doneCount = 0;

    function finishAccount(index, email, status, error) {
      const entry = { index, email, status, error: error || null };
      updateProgCard({ ...entry, msg: status === 'success' ? 'PREMIUM AKTIF!' : (error || status) });
      addResultCard(entry);
      resultWrap.style.display = 'block';
      const ri = lastResults.findIndex(r => r.index === index);
      if (ri >= 0) lastResults[ri] = entry; else lastResults.push(entry);
      doneCount++;
      if (doneCount >= count) {
        const ok   = lastResults.filter(r => r.status === 'success').length;
        const fail = count - ok;
        if (ok > 0) {
          showMsg(msgBoxBulk, ok + ' akun berhasil premium' + (fail > 0 ? ', ' + fail + ' gagal/timeout' : '') + '.', 'success');
        } else {
          showMsg(msgBoxBulk, 'Semua akun gagal. Inbox tidak terbaca — coba lagi.', 'error');
        }
        generateBulkBtn.innerHTML = '<i class="fas fa-bolt"></i> Jalankan Auto Aktivasi';
        generateBulkBtn.disabled = false;
      }
    }

    function startPolling(index, email) {
      let attempts = 0;
      updateProgCard({ index, email, status: 'polling', msg: 'polling (percobaan 1)' });
      const timer = setInterval(async () => {
        attempts++;
        updateProgCard({ index, email, status: 'polling', msg: 'polling (percobaan ' + attempts + ')' });
        if (attempts > MAX_POLL_ATTEMPTS) {
          clearInterval(timer);
          finishAccount(index, email, 'timeout', 'Magic link tidak masuk dalam 2 menit');
          return;
        }
        try {
          const r = await fetch('/api/auto-bulk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'poll', email })
          });
          const d = await r.json();
          if (d.success && d.link) {
            clearInterval(timer);
            updateProgCard({ index, email, status: 'got_link', msg: 'Magic link diterima, aktivasi...' });
            try {
              const ar = await fetch('/api/auto-bulk', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'activate', email, link: d.link })
              });
              const ad = await ar.json();
              finishAccount(index, email, ad.success ? 'success' : 'failed', ad.success ? null : (ad.message || 'Gagal aktivasi'));
            } catch (e) {
              finishAccount(index, email, 'failed', 'Error aktivasi: ' + e.message);
            }
          }
        } catch (_) {}
      }, POLL_INTERVAL_MS);
    }

    const es = new EventSource('/api/auto-bulk?total=' + count);
    activeES = es;

    es.addEventListener('progress', (e) => {
      try { const d = JSON.parse(e.data); updateProgCard(d); } catch (_) {}
    });

    es.addEventListener('sent', (e) => {
      try {
        const d = JSON.parse(e.data);
        updateProgCard(d);
        sentCount++;
        startPolling(d.index, d.email);
      } catch (_) {}
    });

    es.addEventListener('send_done', () => {
      es.close(); activeES = null;
    });

    es.addEventListener('error', () => {
      if (es.readyState === EventSource.CLOSED) {
        es.close(); activeES = null;
        if (sentCount === 0) {
          showMsg(msgBoxBulk, 'Koneksi SSE terputus sebelum magic link terkirim.', 'error');
          generateBulkBtn.innerHTML = '<i class="fas fa-bolt"></i> Jalankan Auto Aktivasi';
          generateBulkBtn.disabled = false;
        }
      }
    });
  }

  generateBulkBtn.addEventListener('click', () => {
    let count = parseInt(bulkCountInput.value);
    if (isNaN(count) || count < 1 || count > 100) {
      showMsg(msgBoxBulk, 'Masukkan angka antara 1 sampai 100.', 'error'); return;
    }
    startBulk(count);
  });

  copyBulkBtn.addEventListener('click', () => {
    if (!lastResults.length) { showMsg(msgBoxBulk, 'Belum ada hasil.', 'error'); return; }
    const lines = lastResults.map(r =>
      r.status === 'success'
        ? `Akun #${r.index} | ${r.email} | Inbox: ${r.loginUrl} | PREMIUM AKTIF`
        : `Akun #${r.index} | ${r.email} | ${r.status.toUpperCase()}: ${r.error || '-'}`
    ).join('\n');
    navigator.clipboard.writeText(lines);
    showMsg(msgBoxBulk, 'Berhasil disalin!', 'success');
  });

  downloadBulkBtn.addEventListener('click', () => {
    const success = lastResults.filter(r => r.status === 'success');
    if (!success.length) { showMsg(msgBoxBulk, 'Belum ada akun sukses untuk di-download.', 'error'); return; }
    const txt = [
      '==============================',
      '  AYAKAMOTION — AKUN PREMIUM',
      '==============================',
      '',
      ...success.map(r => [
        `Akun    : #${r.index}`,
        `Email   : ${r.email}`,
        `Inbox   : ${r.loginUrl || 'https://generator.email/' + r.email}`,
        `Status  : PREMIUM AKTIF`,
        ''
      ].join('\n')),
      '==============================',
      `Total   : ${success.length} akun premium`,
      `Generate: ${new Date().toLocaleString('id-ID')}`,
      '=============================='
    ].join('\n');
    const blob = new Blob([txt], { type: 'text/plain;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = `ayakamotion-premium-${Date.now()}.txt`;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
    showMsg(msgBoxBulk, 'File .txt berhasil di-download!', 'success');
  });
}

// ===== INIT — setelah DOM ready =====
document.addEventListener('DOMContentLoaded', () => {
  // Sidebar
  document.getElementById('openSidebar').addEventListener('click', openSidebarFn);
  document.getElementById('closeSidebar').addEventListener('click', closeSidebar);
  document.getElementById('sidebarOverlay').addEventListener('click', closeSidebar);

  // QRIS modal close on backdrop
  const qrisModal = document.getElementById('qrisModal');
  qrisModal.addEventListener('click', (e) => { if (e.target === qrisModal) toggleQrisModal(false); });

  // Set QRIS image
  document.getElementById('qrisImg').src = QRIS_URL;

  // Set video source
  const videoEl = document.querySelector('#pageTutorial video source');
  if (videoEl) {
    videoEl.src = VIDEO_URL;
    videoEl.parentElement.load();
  }

  // Init page dari URL
  const initPathMap = {
    '/': 'dashboard', '/generator-v1': 'genV1', '/generator-v2': 'genV2',
    '/generator-v3': 'genV3', '/generator-v4': 'genV4',
    '/bulk': 'autoTempMail', '/tutorial': 'tutorial', '/dukung': 'dukung'
  };
  switchPage(initPathMap[location.pathname] || 'dashboard');

  // Ping & counters
  checkRealPing();
  setInterval(checkRealPing, 5000);
  setupVisitorCounter();
  fetchGeneratedCount();

  // Generators & bulk
  [1, 2, 3, 4].forEach(v => setupGenerator(v));
  setupBulk();
});
