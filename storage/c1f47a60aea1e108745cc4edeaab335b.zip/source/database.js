/*

🌟 DILARANG HAPUS WM INI 🌟
  - Ini adalah script franki, jika ingin menghapus wm ini silahkan order pt sc ke franki agar bebas rename sc
  - jika tetap menghapus maka kamu akan terkena hak cipta dan tidak akan dapat mengakses script ini
  - Dilarang memperjual belikan sc ini, jika ketauan maka terkena denda Rp 500.000, jika tidak di tebus siap siap akan diblacklist dari semua group bot WhatsApp dan Hosting dan siap siap Hytam dan Viral nomor lu
  
💖 Terima kasih telah menghargai karya kami! 💖

╭━━┳━┳━━┳━┳┳┳┳━━╮
┃━┳┫╋┃╭╮┃┃┃┃╭┻┃┃╯
┃╭╯┃╮┫┣┫┃┃┃┃╰┳┃┃╮
╰╯╱╰┻┻╯╰┻┻━┻┻┻━━╯

CONTACT DEVELOPER JIKA INGIN MEMBELI NO ENC
  -  WHATSAPP: wa.me/6285136472024
  -  TELEGRAM: https://t.me/xjsjkakajsi
  -  DISCORD: https://discord.gg/5eWnt9jk
  -  YOUTUBE: https://youtube.com/@zfranzxoffc?si=LGafElhuKGkLd4Kf
  -  INSTAGRAM: https://www.instagram.com/zfranzxkaciw_?igsh=MXNxNzV1cTJ6YTBobw==
  
  - ADA KELUHAN ATAU SCRIPT ERROR BISA HUBUNGI FRANKI SEGERA. 
  
  
•• DEVELOPER SCRIPT INI 
• FRANKI
• SOLO PLAYER

*/

require('../settings');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const mongoose = require('mongoose');
let DataBase;

if (/mongo/.test("database.json")) {
	DataBase = class mongoDB {
		constructor(url, options = { useNewUrlParser: true, useUnifiedTopology: true }) {
			this.url = url
			this.data = {}
			this._model = {}
			this.options = options
		}
		
		read = async () => {
			mongoose.connect(this.url, { ...this.options })
			this.connection = mongoose.connection
			try {
				const schema = new mongoose.Schema({
					data: {
						type: Object,
						required: true,
						default: {},
					}
				})
				this._model = mongoose.model('data', schema)
			} catch {
				this._model = mongoose.model('data')
			}
			this.data = await this._model.findOne({})
			if (!this.data) {
				new this._model({ data: {} }).save()
				this.data = await this._model.findOne({})
			} else return this?.data?.data || this?.data
		}
		
		write = async (data) => {
			if (this.data && !this.data.data) return (new this._model({ data })).save()
			this._model.findById(this.data._id, (err, docs) => {
				if (!err) {
					if (!docs.data) docs.data = {}
					docs.data = data
					return docs.save()
				}
			})
		}
	}
} else if (/json/.test("database.json")) {
	DataBase = class dataBase {
		data = {}
		file = path.join(process.cwd(), 'library/database', "database.json");
		
		read = async () => {
			let data;
			if (fs.existsSync(this.file)) {
				data = JSON.parse(fs.readFileSync(this.file))
			} else {
				fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2))
				data = this.data
			}
			return data
		}
		
		write = async (data) => {
			this.data = !!data ? data : global.db
			let dirname = path.dirname(this.file)
			if (!fs.existsSync(dirname)) fs.mkdirSync(dirname, { recursive: true })
			fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2))
			return this.file
		}
	}
}

module.exports = DataBase


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});