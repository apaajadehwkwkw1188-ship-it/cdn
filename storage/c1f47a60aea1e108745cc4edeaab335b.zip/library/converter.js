/*

🌟 DILARANG HAPUS WM INI 🌟
  - Ini adalah script franki, jika ingin menghapus wm ini silahkan order pt sc ke franki agar bebas rename sc
  - jika tetap menghapus maka kamu akan terkena hak cipta dan tidak akan dapat mengakses script ini
  - Dilarang memperjual belikan sc ini, jika ketauan maka terkena denda Rp 500.000, jika tidak di tebus siap siap akan diblacklist dari semua group bot WhatsApp dan Hosting dan siap siap Hytam dan Viral nomor lu
  
💖 Terima kasih telah menghargai karya kami! 💖

╭━━┳━┳━━┳━┳┳┳┳━━╮
┃━┳┫╋┃╭╮┃┃┃┃╭┻┃┃╯
┃╭╯┃╮┫┣┫┃┃┃┃╰┳┃┃╮
╰╯╱╰┻┻╯╰┻┻━┻┻┻━━╯

CONTACT DEVELOPER JIKA INGIN MEMBELI NO ENC
  -  WHATSAPP: wa.me/6285136472024
  -  TELEGRAM: https://t.me/xjsjkakajsi
  -  DISCORD: https://discord.gg/5eWnt9jk
  -  YOUTUBE: https://youtube.com/@zfranzxoffc?si=LGafElhuKGkLd4Kf
  -  INSTAGRAM: https://www.instagram.com/zfranzxkaciw_?igsh=MXNxNzV1cTJ6YTBobw==
  
  - ADA KELUHAN ATAU SCRIPT ERROR BISA HUBUNGI FRANKI SEGERA. 
  
  
•• DEVELOPER SCRIPT INI 
• FRANKI
• SOLO PLAYER

*/

const fs = require('fs')
const path = require('path')
const { spawn } = require('child_process')

function ffmpeg(buffer, args = [], ext = '', ext2 = '') {
  return new Promise(async (resolve, reject) => {
    try {
      let tmp = path.join(__dirname, '../library/database/sampah', + new Date + '.' + ext)
      let out = tmp + '.' + ext2
      await fs.promises.writeFile(tmp, buffer)
      spawn('ffmpeg', [
        '-y',
        '-i', tmp,
        ...args,
        out
      ])
        .on('error', reject)
        .on('close', async (code) => {
          try {
            await fs.promises.unlink(tmp)
            if (code !== 0) return reject(code)
            resolve(await fs.promises.readFile(out))
            await fs.promises.unlink(out)
          } catch (e) {
            reject(e)
          }
        })
    } catch (e) {
      reject(e)
    }
  })
}

/**
 * Convert Audio to Playable WhatsApp Audio
 * @param {Buffer} buffer Audio Buffer
 * @param {String} ext File Extension 
 */
function toAudio(buffer, ext) {
  return ffmpeg(buffer, [
    '-vn',
    '-ac', '2',
    '-b:a', '128k',
    '-ar', '44100',
    '-f', 'mp3'
  ], ext, 'mp3')
}

/**
 * Convert Audio to Playable WhatsApp PTT
 * @param {Buffer} buffer Audio Buffer
 * @param {String} ext File Extension 
 */
function toPTT(buffer, ext) {
  return ffmpeg(buffer, [
    '-vn',
    '-c:a', 'libopus',
    '-b:a', '128k',
    '-vbr', 'on',
    '-compression_level', '10'
  ], ext, 'opus')
}

/**
 * Convert Audio to Playable WhatsApp Video
 * @param {Buffer} buffer Video Buffer
 * @param {String} ext File Extension 
 */
function toVideo(buffer, ext) {
  return ffmpeg(buffer, [
    '-c:v', 'libx264',
    '-c:a', 'aac',
    '-ab', '128k',
    '-ar', '44100',
    '-crf', '32',
    '-preset', 'slow'
  ], ext, 'mp4')
}

module.exports = {
  toAudio,
  toPTT,
  toVideo,
  ffmpeg,
}
