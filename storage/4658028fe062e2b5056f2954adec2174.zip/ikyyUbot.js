/*
   Script Ini Masih Polos Jadi Bisa Kalian Kembangin Sendiri Yaw
   

NOTE: Gaboleh Di Jual Kalo Belum Di Kembangin
*/
const { TelegramClient } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const input = require("input");
const fs = require("fs");

// === API ID & API HASH ===
const apiId = 25683949;
const apiHash = "5a0f1b821252088fe36c523c01c82533";

// Lokasi file session & blacklist
const SESSION_FILE = "session.json";
const BLACKLIST_FILE = "blacklist.json";

// === FOOTER ===
const withFooter = (text) => {
  return `${text}\n\nMy Ubot: @Ikyydevxy`;
};

// Load blacklist
let blacklist = [];
if (fs.existsSync(BLACKLIST_FILE)) {
  try {
    blacklist = JSON.parse(fs.readFileSync(BLACKLIST_FILE));
  } catch (e) {
    console.log("❌ File blacklist corrupt, buat baru");
    blacklist = [];
  }
}
const saveBlacklist = () => {
  fs.writeFileSync(BLACKLIST_FILE, JSON.stringify(blacklist, null, 2));
};

// Baca session dari file
let savedSession = "";
if (fs.existsSync(SESSION_FILE)) {
  try {
    const data = JSON.parse(fs.readFileSync(SESSION_FILE));
    savedSession = data.session || "";
  } catch (e) {
    console.log("❌ Session corrupt, login ulang diperlukan");
  }
}
const stringSession = new StringSession(savedSession);

// === Variabel AFK ===
let isAfk = false;
let afkReason = "";

(async () => {
  console.log("=== Telegram UserBot Start ===");

  const client = new TelegramClient(stringSession, apiId, apiHash, {
    connectionRetries: 5,
  });

  if (!savedSession) {
    await client.start({
      phoneNumber: async () => {
        console.log("=== LOGIN TELEGRAM ===");
        console.log("📱 Silakan masukkan nomor telepon Anda (+62xxx):");
        return await input.text("> Nomor: ");
      },
      phoneCode: async () => {
        console.log("📩 Telegram sudah mengirimkan kode OTP ke akun Anda.");
        console.log("Silakan masukkan kode OTP (biasanya 5 digit):");
        return await input.text("> OTP: ");
      },
      password: async () => {
        console.log("🔑 Akun Anda menggunakan verifikasi dua langkah (2FA).");
        console.log("Masukkan sandi/password 2FA:");
        return await input.text("> Password 2FA: ");
      },
      onError: (err) => console.log("❌ Error:", err),
    });

    fs.writeFileSync(
      SESSION_FILE,
      JSON.stringify({ session: client.session.save() }, null, 2)
    );
    console.log("💾 Session baru disimpan ke", SESSION_FILE);
  } else {
    await client.connect();
    console.log("✅ Auto-login pakai session.json");
  }

  const me = await client.getMe();
  const myId = me.id.toString();

  await client.sendMessage("me", { message: withFooter("UserBot aktif 🚀") });

  client.addEventHandler(
    async (event) => {
      const msg = event.message;
      if (!msg || !msg.message) return;
      const text = msg.message.trim();


      if (msg.senderId.toString() === myId) {
        // .afk <alasan>
        if (text.startsWith(".afk")) {
          const reason = text.split(" ").slice(1).join(" ") || "Tidak ada keterangan";
          isAfk = true;
          afkReason = reason;
          await client.sendMessage(msg.chatId, {
            message: withFooter(`✅ Mode AFK diaktifkan!\nKeterangan: ${reason}`),
            replyTo: msg.id,
          });
          return;
        }

        // .unafk
        if (text === ".unafk") {
          isAfk = false;
          afkReason = "";
          await client.sendMessage(msg.chatId, {
            message: withFooter("✅ Mode AFK dinonaktifkan!"),
            replyTo: msg.id,
          });
          return;
        }
      } else {
        if (isAfk) {
          let shouldReply = false;

          if (msg.isReply) {
            const replyMsg = await msg.getReplyMessage();
            if (replyMsg && replyMsg.senderId.toString() === myId) {
              shouldReply = true;
            }
          }

          if (msg.chatId.toString() === msg.senderId.toString()) {
            shouldReply = true;
          }

          if (shouldReply) {
            await client.sendMessage(msg.chatId, {
              message: withFooter(`💤 SEDANG AFK\n📝 KETERANGAN: ${afkReason}`),
              replyTo: msg.id,
            });
          }
        }
      }

      // ---------------- COMMANDS ----------------
      if (msg.senderId.toString() !== myId) return;

      // .ping
      if (text === ".ping") {
        const start = Date.now();
        let sent = await client.sendMessage(msg.chatId, {
          message: withFooter("Loading..."),
          replyTo: msg.id,
        });

        setTimeout(async () => {
          try {
            await client.editMessage(sent.chatId, { message: sent.id, text: withFooter("Loading......") });
          } catch {}
        }, 300);

        setTimeout(async () => {
          try {
            await client.editMessage(sent.chatId, { message: sent.id, text: withFooter("Loading.........") });
          } catch {}
        }, 600);

        setTimeout(async () => {
          const latency = Date.now() - start;
          try {
            await client.editMessage(sent.chatId, {
              message: sent.id,
              text: withFooter(`Selesai Hasil\n⚡ ${latency} ms`),
            });
          } catch {}
        }, 900);

        return;
      }

      // .addbl
      if (text.startsWith(".addbl")) {
        if (!msg.isGroup) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Hanya di grup!"), replyTo: msg.id });
          return;
        }
        const groupName = msg.chat.title || "Group";
        if (!blacklist.includes(msg.chatId.toString())) {
          blacklist.push(msg.chatId.toString());
          saveBlacklist();
          await client.sendMessage(msg.chatId, {
            message: withFooter(`✅ Grup *${groupName}* ditambahkan ke blacklist.`),
            parseMode: "md",
            replyTo: msg.id,
          });
        } else {
          await client.sendMessage(msg.chatId, {
            message: withFooter(`⚠️ Grup *${groupName}* sudah ada di blacklist.`),
            parseMode: "md",
            replyTo: msg.id,
          });
        }
        return;
      }

      // .deladdbl
      if (text.startsWith(".deladdbl")) {
        if (!msg.isGroup) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Hanya di grup!"), replyTo: msg.id });
          return;
        }
        const groupName = msg.chat.title || "Group";
        if (blacklist.includes(msg.chatId.toString())) {
          blacklist = blacklist.filter((id) => id !== msg.chatId.toString());
          saveBlacklist();
          await client.sendMessage(msg.chatId, {
            message: withFooter(`✅ Grup *${groupName}* dihapus dari blacklist.`),
            parseMode: "md",
            replyTo: msg.id,
          });
        } else {
          await client.sendMessage(msg.chatId, {
            message: withFooter(`⚠️ Grup *${groupName}* tidak ada di blacklist.`),
            parseMode: "md",
            replyTo: msg.id,
          });
        }
        return;
      }

      // .cfdgroup
      if (text === ".cfdgroup") {
        if (!msg.replyTo) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Harus reply pesan!"), replyTo: msg.id });
          return;
        }
        const replyMsg = await msg.getReplyMessage();
        const dialogs = await client.getDialogs();
        let count = 0;
        for (const dialog of dialogs) {
          if (dialog.isGroup && !blacklist.includes(dialog.id.toString())) {
            try {
              await client.forwardMessages(dialog.id, { messages: replyMsg.id, fromPeer: msg.chatId });
              count++;
            } catch {}
          }
        }
        await client.sendMessage(msg.chatId, {
          message: withFooter(`✅ Pesan diteruskan ke ${count} grup.`),
          replyTo: msg.id,
        });
        return;
      }
      if (text === ".jpmch") {
  if (!msg.replyTo) {
    await client.sendMessage(msg.chatId, { 
      message: withFooter("⚠️ Harus reply pesan!"), 
      replyTo: msg.id 
    });
    return;
  }

  const replyMsg = await msg.getReplyMessage();
  const dialogs = await client.getDialogs();

  let count = 0;

  for (const dialog of dialogs) {
    // Filter CHANNEL only
    if (dialog.isChannel && !dialog.isGroup) {
      // Optional: blacklist channel ID
      if (blacklist.includes(dialog.id.toString())) continue;

      try {
        await client.forwardMessages(dialog.id, {
          messages: replyMsg.id,
          fromPeer: msg.chatId
        });

        count++;
      } catch (err) {
        // Biar gak nge-crash
      }
    }
  }

  await client.sendMessage(msg.chatId, {
    message: withFooter(`📡 Pesan berhasil diteruskan ke ${count} channel.`),
    replyTo: msg.id,
  });

  return;
}

if (text === ".listgc") {
  try {
    const dialogs = await client.getDialogs();
    const groupList = dialogs.filter((d) => d.isGroup);

    if (!groupList.length) {
      await client.sendMessage(msg.chatId, {
        message: withFooter("⚠️ Tidak ada grup yang terdeteksi."),
        replyTo: msg.id,
      });
      return;
    }

    let teks = "📋 *DAFTAR GRUP YANG TERGABUNG*\n\n";
    groupList.forEach((gc, i) => {
      const name = gc.title || "Tanpa Nama";
      const id = gc.id;
      const members = gc.participantsCount || "??";
      teks += `${i + 1}. *${name}*\n   🆔 \`${id}\`\n   👥 Anggota: ${members}\n\n`;
    });

    await client.sendMessage(msg.chatId, {
      message: withFooter(teks),
      parseMode: "markdown",
      replyTo: msg.id,
    });
  } catch (e) {
    console.error("❌ Error .listgc:", e);
    await client.sendMessage(msg.chatId, {
      message: withFooter("❌ Terjadi kesalahan saat mengambil daftar grup."),
      replyTo: msg.id,
    });
  }
  return;
}

if (text.startsWith(".play")) {
  try {
    const q = text.split(" ").slice(1).join(" ");
    if (!q) {
      await client.sendMessage(msg.chatId, {
        message: withFooter("📻 Contoh: *.play dj doa untukmu sayang*"),
        replyTo: msg.id,
      });
      return;
    }

    const url = `https://api-ikyyofficiall-latest.vercel.app/download/play?apikey=kyzz&query=${encodeURIComponent(q)}`;
    const res = await fetch(url);
    const data = await res.json();

    if (!data.status || !data.result) {
      await client.sendMessage(msg.chatId, {
        message: withFooter("❌ Tidak ditemukan. Coba judul lain."),
        replyTo: msg.id,
      });
      return;
    }

    const r = data.result;

    // Kirim thumbnail + info
    await client.sendFile(msg.chatId, {
      file: r.thumbnail,
      caption: withFooter(
        `🎵 *${r.title}*\n` +
        `⏱️ Durasi: ${r.duration}s\n` +
        `🆔 ID: ${r.id}`
      ),
      parseMode: "markdown",
      replyTo: msg.id,
    });

    // Kirim audio
    await client.sendFile(msg.chatId, {
      file: r.mp3,
      caption: withFooter(`🎧 *${r.title}*`),
      mimetype: "audio/mpeg",
      replyTo: msg.id,
    });

  } catch (err) {
    console.error("❌ Error .play:", err);
    await client.sendMessage(msg.chatId, {
      message: withFooter("❌ Error saat memproses lagu."),
      replyTo: msg.id,
    });
  }
  return;
}

if (text === ".restart") {
  await client.sendMessage(msg.chatId, {
    message: withFooter("♻️ Sedang melakukan *Restart Userbot...*"),
    parseMode: "markdown",
    replyTo: msg.id,
  });

  setTimeout(async () => {
    try {
      await client.disconnect();
      process.exit(0);
    } catch (e) {
      console.error("❌ Error saat restart:", e);
      await client.sendMessage(msg.chatId, {
        message: withFooter("❌ Gagal restart. Coba manual lewat terminal."),
        replyTo: msg.id,
      });
    }
  }, 1500);
  return;
}

if (text.startsWith(".tagall")) {
  if (!msg.isGroup) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("⚠️ Fitur ini hanya bisa digunakan di grup!"),
      replyTo: msg.id,
    });
    return;
  }

  const groupName = msg.chat?.title || "Grup ini";
  const extraText = text.split(" ").slice(1).join(" ") || "👋 Halo semua!";

  await client.sendMessage(msg.chatId, {
    message: withFooter(`📣 TagAll dimulai di *${groupName}*...\n\n${extraText}`),
    parseMode: "markdown",
    replyTo: msg.id,
  });

  try {
    const participants = await client.getParticipants(msg.chatId);
    const batchSize = 10; // mention 10 orang per pesan
    let batch = [];

    for (let i = 0; i < participants.length; i++) {
      const user = participants[i];
      if (!user.username && !user.firstName) continue;

      const mention = `[${user.firstName || "User"}](tg://user?id=${user.id})`;
      batch.push(mention);

      if (batch.length >= batchSize || i === participants.length - 1) {
        const messageText = `${extraText}\n\n${batch.join(" ")}`;
        await client.sendMessage(msg.chatId, {
          message: withFooter(messageText),
          parseMode: "markdown",
        });
        batch = [];
        await new Promise((r) => setTimeout(r, 1200)); // delay 1.2 detik biar aman
      }
    }

    await client.sendMessage(msg.chatId, {
      message: withFooter("✅ Selesai mention semua member!"),
      replyTo: msg.id,
    });
  } catch (e) {
    console.log("❌ Error TagAll:", e);
    await client.sendMessage(msg.chatId, {
      message: withFooter("❌ Terjadi kesalahan saat mengambil daftar member."),
      replyTo: msg.id,
    });
  }

  return;
}

      // .gikes
      if (text === ".gikes") {
        if (!msg.replyTo) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Harus reply pesan!"), replyTo: msg.id });
          return;
        }
        const replyMsg = await msg.getReplyMessage();
        if (!replyMsg || !replyMsg.message) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Tidak ada teks!"), replyTo: msg.id });
          return;
        }
        const copyText = replyMsg.message;
        const dialogs = await client.getDialogs();
        let count = 0;
        for (const dialog of dialogs) {
          if (dialog.isGroup && !blacklist.includes(dialog.id.toString())) {
            try {
              await client.sendMessage(dialog.id, { message: withFooter(copyText) });
              count++;
            } catch {}
          }
        }
        await client.sendMessage(msg.chatId, {
          message: withFooter(`✅ Pesan dikirim ke ${count} grup.`),
          replyTo: msg.id,
        });
        return;
      }

      // .spam jumlah
      if (text.startsWith(".spam")) {
        if (!msg.replyTo) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Harus reply pesan!"), replyTo: msg.id });
          return;
        }
        const parts = text.split(" ");
        if (parts.length < 2 || isNaN(parts[1])) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Format salah!\n.spam jumlah"), replyTo: msg.id });
          return;
        }
        const count = parseInt(parts[1]);
        const replyMsg = await msg.getReplyMessage();
        if (!replyMsg) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Tidak ada pesan!"), replyTo: msg.id });
          return;
        }
        for (let i = 0; i < count; i++) {
          try {
            if (replyMsg.media) {
              await client.forwardMessages(msg.chatId, { messages: replyMsg.id, fromPeer: msg.chatId });
            } else if (replyMsg.message) {
              await client.sendMessage(msg.chatId, { message: withFooter(replyMsg.message) });
            }
          } catch {}
        }
        await client.sendMessage(msg.chatId, {
          message: withFooter(`✅ Spam selesai! ${count}x terkirim.`),
          replyTo: msg.id,
        });
        return;
      }


if (text.startsWith(".help")) {
  const args = text.split(" ")[1];

  const THUMBNAIL_URL = "https://files.catbox.moe/3lw2wv.jpg"; // ganti jg

  const makeHelpText = (title, list) => {
    let msg = `📖 *MENU ${title.toUpperCase()}*\n\n`;
    list.forEach((f, i) => {
      msg += `${i + 1}. \`${f.cmd}\`\n   ➤ ${f.desc}\n\n`;
    });
    msg += `🧭 Ketik *.help* untuk kembali ke menu utama.\n`;
    return withFooter(msg);
  };

  const userCmd = [
    { cmd: ".ping", desc: "Cek kecepatan respon UserBot" },
    { cmd: ".afk <alasan>", desc: "Aktifkan mode AFK dengan alasan" },
    { cmd: ".unafk", desc: "Nonaktifkan mode AFK" },
    { cmd: ".addbl", desc: "Tambah grup ke blacklist" },
    { cmd: ".deladdbl", desc: "Hapus grup dari blacklist" },
    { cmd: ".cfdgroup", desc: "Forward pesan reply ke semua grup" },
    { cmd: ".jpmch", desc: "Forward pesan reply ke semua channel" },
    { cmd: ".gikes", desc: "Copy teks reply & kirim ke semua grup" },
    { cmd: ".spam <jumlah>", desc: "Spam pesan reply sesuai jumlah" },
  ];

  const ownerCmd = [
    { cmd: ".restart", desc: "Restart userbot (reconnect)" },
    { cmd: ".eval <kode>", desc: "Jalankan kode JS langsung dari chat (dev only)" },
    { cmd: ".listgc", desc: "Tampilkan daftar grup aktif" },
  ];
  
  const downloader = [
    { cmd: ".play", desc: "Memutar Music" }
  ];

  const toolsCmd = [
    { cmd: ".tagall <pesan>", desc: "Mention semua anggota grup" },
    { cmd: ".whois", desc: "Tampilkan info user / grup" },
    { cmd: ".clone <@username>", desc: "Salin profil orang lain" },
  ];

  if (args === "user") {
    await client.sendFile(msg.chatId, {
      file: THUMBNAIL_URL,
      caption: makeHelpText("USER", userCmd),
      parseMode: "markdown",
      replyTo: msg.id,
    });
    return;
  }
  
    if (args === "download") {
    await client.sendFile(msg.chatId, {
      file: THUMBNAIL_URL,
      caption: makeHelpText("DOWNLOADER", downloader),
      parseMode: "markdown",
      replyTo: msg.id,
    });
    return;
  }

  if (args === "owner") {
    await client.sendFile(msg.chatId, {
      file: THUMBNAIL_URL,
      caption: makeHelpText("OWNER", ownerCmd),
      parseMode: "markdown",
      replyTo: msg.id,
    });
    return;
  }

  if (args === "tools") {
    await client.sendFile(msg.chatId, {
      file: THUMBNAIL_URL,
      caption: makeHelpText("TOOLS", toolsCmd),
      parseMode: "markdown",
      replyTo: msg.id,
    });
    return;
  }

  const menuText = `
🧰 *HELP MENU*  
Pilih kategori bantuan di bawah ini:

👤 \`.help user\`  → Command User  
👑 \`.help owner\` → Command Owner  
🧩 \`.help tools\` → Command Tools  
🧩 \`.help download\` → Command Downloader

🌐 Owner: @Ikyydevxy
`;

  await client.sendFile(msg.chatId, {
    file: THUMBNAIL_URL,
    caption: withFooter(menuText),
    parseMode: "markdown",
    replyTo: msg.id,
  });
  return;
}
}, new NewMessage({}));
})();