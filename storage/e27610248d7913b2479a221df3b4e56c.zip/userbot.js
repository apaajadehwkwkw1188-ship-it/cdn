
const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const input = require("input");
const fs = require("fs");
const axios = require("axios");
const FormData = require("form-data");

const apiId = 22668429;
const apiHash = "50e8aab3bb28e84990890054576919b7";

const MENU_PHOTO = "https://files.catbox.moe/pgkj7k.jpg";
const MENU_GRUP_PHOTO = "https://litter.catbox.moe/2c38r6.jpg";
const MENU_TOOLS_PHOTO = "https://litter.catbox.moe/fkgwlq.jpg";
const MENU_AFk_PHOTO = "https://litter.catbox.moe/2b8lr2.jpg";
const MENU_PAYMENT_PHOTO = "https://litter.catbox.moe/209rw8.jpg";

const SESSION_FILE = "session.json";
const BLACKLIST_FILE = "blacklist.json";
const PAY_FILE = "pay.json";

let payMethods = [];
if (fs.existsSync(PAY_FILE)) { try { payMethods = JSON.parse(fs.readFileSync(PAY_FILE)); } catch (e) { payMethods = []; } }
const savePayMethods = () => { fs.writeFileSync(PAY_FILE, JSON.stringify(payMethods, null, 2)); };

const withFooter = (text) => `${text}\n\nUSERBOT BY @King_ubott`;

let blacklist = [];
if (fs.existsSync(BLACKLIST_FILE)) { try { blacklist = JSON.parse(fs.readFileSync(BLACKLIST_FILE)); } catch (e) { blacklist = []; } }
const saveBlacklist = () => { fs.writeFileSync(BLACKLIST_FILE, JSON.stringify(blacklist, null, 2)); };

let savedSession = "";
if (fs.existsSync(SESSION_FILE)) { try { const data = JSON.parse(fs.readFileSync(SESSION_FILE)); savedSession = data.session || ""; } catch (e) {} }
const stringSession = new StringSession(savedSession);

let isAfk = false; let afkReason = ""; let afkTime = 0;

(async () => {
  const client = new TelegramClient(stringSession, apiId, apiHash, { connectionRetries: 5 });

  if (!savedSession) {
    await client.start({
      phoneNumber: async () => await input.text("> Nomor: "),
      phoneCode: async () => await input.text("> OTP: "),
      password: async () => await input.text("> Password 2FA: "),
      onError: (err) => console.log(err),
    });
    fs.writeFileSync(SESSION_FILE, JSON.stringify({ session: client.session.save() }, null, 2));
  } else { await client.connect(); }

  const me = await client.getMe();
  const myId = me.id.toString();

  client.addEventHandler(async (event) => {
    const msg = event.message;
    if (!msg || !msg.message || msg.senderId.toString() !== myId) return;
    const text = msg.message.trim();

    if (text === ".ping") {
      await client.sendMessage(msg.chatId, { message: withFooter("Pong!") });
    }
  }, new NewMessage({}));
})();
