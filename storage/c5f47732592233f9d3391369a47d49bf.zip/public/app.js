'use strict';
/* =========================================================================================
   public/app.js — ZYNX CONTROL client engine
   Menangani: alur auth (bootstrap owner pertama / login), dashboard chat (list kontak, mini
   chat dengan reply/emoji/foto/stiker), broadcast, tab kontak, dan tab setelan (koneksi bot).
   Semua komunikasi lewat endpoint /api/* di domain sendiri (bukan langsung ke Telegram/Firebase
   dari browser) -- kredensial bot & Firebase tidak pernah menyentuh browser sama sekali.
   ========================================================================================= */

/* ============================== STATE GLOBAL ============================== */
const state = {
  me: null,               // { username, role, puzzleUnlocked }
  contacts: {},            // chatId -> contact object
  cursor: -1,               // cursor global untuk tahu kapan perlu refresh daftar kontak
  activeChatId: null,
  activeChatMessages: [],   // array pesan chat yang sedang dibuka (in-memory, urut waktu naik)
  activeTab: 'chat',
  replyTarget: null,
  pendingImage: null,        // { base64, previewUrl } saat user pilih gambar sebelum kirim
  settings: { sound: true, typingIndicator: true },
  pollTimer: null,
};

let typingDebounce = null;

/* ============================== UTILITAS ============================== */
function escapeHtml(str) {
  return String(str || '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function initials(name) {
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  return (parts[0][0] + (parts[1] ? parts[1][0] : '')).toUpperCase();
}
const AVATAR_COLORS = ['#e17076','#eda86c','#a695e7','#7bc862','#6ec9cb','#65aadd','#ee7aae','#5eb96a'];
function avatarColor(seed) {
  let hash = 0; const str = String(seed);
  for (let i = 0; i < str.length; i++) hash = (hash * 31 + str.charCodeAt(i)) | 0;
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}
function formatTime(ts) { const d = new Date(ts); return d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0'); }
function formatDayLabel(ts) {
  const d = new Date(ts), now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Hari ini';
  const yest = new Date(now); yest.setDate(now.getDate()-1);
  if (d.toDateString() === yest.toDateString()) return 'Kemarin';
  return d.toLocaleDateString('id-ID', { day:'numeric', month:'long', year:'numeric' });
}
function formatRelativeShort(ts) {
  if (!ts) return '';
  const diff = Date.now() - ts, min = Math.floor(diff/60000);
  if (min < 1) return 'baru saja';
  if (min < 60) return min + 'm';
  const hr = Math.floor(min/60);
  if (hr < 24) return hr + 'j';
  return Math.floor(hr/24) + 'h';
}
function fullName(c) { return (c.firstName + ' ' + (c.lastName || '')).trim() || ('Kontak ' + c.chatId); }
function insertAtCursor(el, text) {
  const start = el.selectionStart, end = el.selectionEnd;
  el.value = el.value.slice(0, start) + text + el.value.slice(end);
  el.selectionStart = el.selectionEnd = start + text.length;
  el.dispatchEvent(new Event('input'));
  el.focus();
}
function wrapSelection(el, wrapChar) {
  const start = el.selectionStart, end = el.selectionEnd;
  const selected = el.value.slice(start, end) || 'teks';
  el.value = el.value.slice(0, start) + wrapChar + selected + wrapChar + el.value.slice(end);
  el.selectionStart = start + wrapChar.length;
  el.selectionEnd = start + wrapChar.length + selected.length;
  el.focus();
}
function autoGrow(el) { el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 110) + 'px'; }

/* ============================== TOAST & MODAL ============================== */
function showToast(msg, type) {
  const wrap = document.getElementById('toast-wrap');
  const el = document.createElement('div');
  el.className = 'toast' + (type ? ' ' + type : '');
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}
function showModal(title, body, onConfirm, confirmLabel) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').textContent = body;
  document.getElementById('modal-confirm-btn').textContent = confirmLabel || 'Ya, Lanjutkan';
  document.getElementById('modal-overlay').classList.add('show');
  const confirmBtn = document.getElementById('modal-confirm-btn');
  const cancelBtn = document.getElementById('modal-cancel-btn');
  function close() { document.getElementById('modal-overlay').classList.remove('show'); confirmBtn.onclick = null; cancelBtn.onclick = null; }
  confirmBtn.onclick = () => { close(); onConfirm(); };
  cancelBtn.onclick = close;
}

/* ============================== SOUND NOTIFIKASI ============================== */
let audioCtx;
function playNotifSound() {
  if (!state.settings.sound) return;
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.type = 'sine'; o.frequency.value = 880;
    g.gain.value = 0.08;
    o.connect(g); g.connect(audioCtx.destination);
    o.start();
    o.frequency.exponentialRampToValueAtTime(1200, audioCtx.currentTime + 0.09);
    g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);
    o.stop(audioCtx.currentTime + 0.26);
  } catch (e) {}
}

/* ============================== API WRAPPER ============================== */
async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin', // WAJIB: supaya cookie sesi httpOnly ikut terkirim
    body: body ? JSON.stringify(body) : undefined,
  });
  return res.json();
}

/* ============================== AUTH FLOW ============================== */
async function initAuth() {
  const me = await api('GET', '/api/auth/me');
  if (me.loggedIn) {
    state.me = me;
    enterDashboard();
    return;
  }
  const bs = await api('GET', '/api/auth/bootstrap-status');
  if (bs.needsBootstrap) {
    document.getElementById('login-form').classList.add('hidden');
    document.getElementById('bootstrap-form').classList.remove('hidden');
    document.getElementById('login-title').textContent = 'Setup Awal';
    document.getElementById('login-sub').textContent = 'Belum ada akun sama sekali. Buat akun owner pertama.';
    refreshBootstrapCaptcha();
  }
  loadPuzzleClue3(); // clue #3 (console) publik, tetap dimuat walau belum login
}

let bootstrapCaptchaToken = null;
async function refreshBootstrapCaptcha() {
  const result = await api('GET', '/api/captcha/generate');
  bootstrapCaptchaToken = result.token;
  document.getElementById('bs-captcha-img').innerHTML = result.svg;
}

async function submitBootstrap() {
  const username = document.getElementById('bs-username').value.trim();
  const password = document.getElementById('bs-password').value;
  const captchaAnswer = document.getElementById('bs-captcha-answer').value;
  const errEl = document.getElementById('login-error');
  const btn = document.getElementById('bootstrap-submit-btn');
  const label = document.getElementById('bootstrap-submit-label');
  errEl.textContent = '';

  if (!username || !password) { errEl.textContent = 'Username dan password wajib diisi.'; return; }

  btn.disabled = true;
  label.innerHTML = '<span class="spinner"></span> Membuat akun...';
  const result = await api('POST', '/api/auth/bootstrap', { username, password, captchaToken: bootstrapCaptchaToken, captchaAnswer });
  btn.disabled = false;
  label.textContent = 'Buat Akun Owner';

  if (!result.ok) {
    errEl.textContent = result.message || 'Gagal membuat akun.';
    refreshBootstrapCaptcha();
    document.getElementById('bs-captcha-answer').value = '';
    return;
  }

  showToast('Akun owner berhasil dibuat, selamat datang!', 'success');
  state.me = { username: result.username, role: result.role, puzzleUnlocked: false };
  enterDashboard();
}

async function submitLogin() {
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  const errEl = document.getElementById('login-error');
  const btn = document.getElementById('login-submit-btn');
  const label = document.getElementById('login-submit-label');
  errEl.textContent = '';

  if (!username || !password) { errEl.textContent = 'Username dan password wajib diisi.'; return; }

  btn.disabled = true;
  label.innerHTML = '<span class="spinner"></span> Masuk...';
  const result = await api('POST', '/api/auth/login', { username, password });
  btn.disabled = false;
  label.textContent = 'Masuk';

  if (!result.ok) {
    const input = document.getElementById('login-password');
    input.classList.add('shake'); setTimeout(() => input.classList.remove('shake'), 400);
    errEl.textContent = result.message || 'Login gagal.';
    return;
  }

  state.me = { username: result.username, role: result.role, puzzleUnlocked: false };
  enterDashboard();
}

async function loadPuzzleClue3() {
  try {
    const result = await api('GET', '/api/puzzle/clue3');
    if (result.ok) console.log('%c#// ' + result.c3 + ' (3)', 'color:#2AABEE;font-weight:bold;font-size:14px;');
  } catch (e) {}
}
async function loadPuzzleClue4IfNeeded(query) {
  if (query.trim().toLowerCase() !== 'keyzynx') return;
  const result = await api('GET', '/api/puzzle/clue4');
  if (result.ok) {
    const listEl = document.getElementById('chat-list');
    listEl.innerHTML = `<div class="empty-state" style="padding:40px 20px;"><div class="big-icon">🧩</div><p style="font-family:monospace;font-size:16px;color:var(--accent);letter-spacing:2px;">#// ${escapeHtml(result.c4)} (4)</p><p>Clue ke-4 ditemukan. Hapus pencarian untuk kembali ke daftar kontak.</p></div>`;
  }
}

/* ============================== MASUK DASHBOARD ============================== */
function enterDashboard() {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('app-shell').classList.add('active');
  document.getElementById('me-username').textContent = state.me.username;
  document.getElementById('me-role').textContent = state.me.role;
  applyRoleVisibility();

  loadBotStatus();
  startPolling();
  renderChatList();
}

/* ============================== POLLING STATE ============================== */
function startPolling() {
  pollOnce();
  state.pollTimer = setInterval(pollOnce, 3000);
}

async function pollOnce() {
  const params = new URLSearchParams({ cursor: state.cursor });
  if (state.activeChatId) {
    params.set('activeChatId', state.activeChatId);
    const lastMsg = state.activeChatMessages[state.activeChatMessages.length - 1];
    params.set('sinceTime', lastMsg ? lastMsg.time : 0);
  }

  let result;
  try {
    result = await api('GET', '/api/telegram/state?' + params.toString());
  } catch (e) { return; }
  if (!result.ok) return;

  state.cursor = result.cursor;

  if (result.contacts) {
    state.contacts = {};
    result.contacts.forEach(c => { state.contacts[c.chatId] = c; });
    renderChatList();
    renderContactsTable();
    renderTabBadge();
  }

  if (result.newMessages && result.newMessages.length) {
    const isFreshLoad = state.activeChatMessages.length === 0;
    result.newMessages.forEach(m => {
      state.activeChatMessages.push(m);
      if (!isFreshLoad && m.from === 'user') playNotifSound();
    });
    if (state.activeChatId) {
      if (isFreshLoad) renderMessages();
      else result.newMessages.forEach(m => appendMessageToView(m));
      scrollMessagesToBottom();
    }
  }
}

/* ============================== RENDER: DAFTAR KONTAK ============================== */
function getContactsSorted() {
  return Object.values(state.contacts).sort((a,b) => (b.lastMessageTime||0) - (a.lastMessageTime||0));
}
function renderTabBadge() {
  const totalUnread = 0; // (unread per-kontak belum dilacak server-side di build ini; lihat README batasan)
  const badge = document.getElementById('chat-tab-badge');
  if (totalUnread > 0) { badge.classList.remove('hidden'); badge.textContent = totalUnread; }
  else badge.classList.add('hidden');
}

function renderChatList(filterText) {
  const listEl = document.getElementById('chat-list');
  const q = (filterText !== undefined ? filterText : document.getElementById('chat-search').value).toLowerCase().trim();

  if (q === 'keyzynx') { loadPuzzleClue4IfNeeded(q); return; }

  const contacts = getContactsSorted();
  const filtered = q ? contacts.filter(c => fullName(c).toLowerCase().includes(q) || (c.username||'').toLowerCase().includes(q)) : contacts;

  if (!filtered.length) {
    listEl.innerHTML = `<div class="empty-state" style="padding:40px 20px;"><div class="big-icon">👋</div><p>${contacts.length === 0 ? 'Belum ada kontak. Daftar akan terisi otomatis saat ada yang chat bot ini.' : 'Tidak ada hasil.'}</p></div>`;
    return;
  }

  listEl.innerHTML = filtered.map(c => {
    const selected = state.activeChatId === c.chatId;
    const name = escapeHtml(fullName(c));
    const snippet = escapeHtml((c.lastMessageText || 'Belum ada pesan').slice(0, 38));
    const time = formatRelativeShort(c.lastMessageTime);
    return `<div class="chat-list-item ${selected?'selected':''}" data-chat-id="${c.chatId}">
      <div class="avatar" style="background:${avatarColor(c.chatId)}">${initials(name)}</div>
      <div class="chat-list-body">
        <div class="chat-list-top"><span class="chat-list-name">${name}</span><span class="chat-list-time">${time}</span></div>
        <div class="chat-list-snippet">${snippet}</div>
      </div>
    </div>`;
  }).join('');

  listEl.querySelectorAll('.chat-list-item').forEach(el => el.addEventListener('click', () => openChat(el.dataset.chatId)));
}

/* ============================== BUKA CHAT ============================== */
function openChat(chatId) {
  state.activeChatId = chatId;
  state.activeChatMessages = [];
  cancelReply();
  cancelPendingImage();

  const c = state.contacts[chatId];
  if (!c) return;

  document.getElementById('chat-empty-state').style.display = 'none';
  document.getElementById('chat-view-content').style.display = 'flex';
  document.getElementById('cv-avatar').textContent = initials(fullName(c));
  document.getElementById('cv-avatar').style.background = avatarColor(c.chatId);
  document.getElementById('cv-name').textContent = fullName(c);
  document.getElementById('cv-sub').textContent = (c.username ? '@'+c.username+' · ' : '') + 'ID ' + c.chatId;
  document.getElementById('messages-scroll').innerHTML = '';

  renderChatList();
  pollOnce(); // langsung tarik histori chat ini
}

/* ============================== RENDER PESAN (teks/foto/stiker) ============================== */
function renderMessages() {
  const scrollEl = document.getElementById('messages-scroll');
  scrollEl.innerHTML = '';
  let lastDay = null;
  state.activeChatMessages.forEach(msg => {
    const dayLabel = formatDayLabel(msg.time);
    if (dayLabel !== lastDay) {
      lastDay = dayLabel;
      const sep = document.createElement('div');
      sep.className = 'day-separator';
      sep.innerHTML = `<span>${dayLabel}</span>`;
      scrollEl.appendChild(sep);
    }
    scrollEl.appendChild(buildMessageRow(msg));
  });
}

function appendMessageToView(msg) {
  const scrollEl = document.getElementById('messages-scroll');
  const lastSep = scrollEl.querySelector('.day-separator:last-of-type');
  const todayLabel = formatDayLabel(msg.time);
  if (!lastSep || lastSep.textContent !== todayLabel) {
    const sep = document.createElement('div');
    sep.className = 'day-separator';
    sep.innerHTML = `<span>${todayLabel}</span>`;
    scrollEl.appendChild(sep);
  }
  scrollEl.appendChild(buildMessageRow(msg));
}

function buildMessageRow(msg) {
  const row = document.createElement('div');
  row.className = 'msg-row ' + (msg.from === 'bot' ? 'out' : 'in');

  const actions = document.createElement('div');
  actions.className = 'msg-hover-actions';
  actions.innerHTML = `<button title="Balas" class="act-reply">↩</button>`;

  const bubbleWrap = document.createElement('div');
  bubbleWrap.style.display = 'flex';
  bubbleWrap.style.flexDirection = 'column';
  bubbleWrap.style.alignItems = msg.from === 'bot' ? 'flex-end' : 'flex-start';

  const bubble = buildBubbleContent(msg);

  const meta = document.createElement('div');
  meta.className = 'msg-meta';
  let statusIcon = '';
  if (msg.from === 'bot') statusIcon = msg.status === 'failed' ? '<span class="msg-status failed">⚠ gagal</span>' : '✓✓';
  meta.innerHTML = `<span>${formatTime(msg.time)}</span> ${statusIcon}`;

  bubbleWrap.appendChild(bubble);
  bubbleWrap.appendChild(meta);
  if (msg.from === 'bot') { row.appendChild(actions); row.appendChild(bubbleWrap); }
  else { row.appendChild(bubbleWrap); row.appendChild(actions); }

  actions.querySelector('.act-reply').addEventListener('click', () => setReplyTarget(msg));
  return row;
}

function buildBubbleContent(msg) {
  const bubble = document.createElement('div');
  bubble.className = 'msg-bubble';

  let replyHtml = '';
  if (msg.replyPreview) {
    replyHtml = `<div class="msg-reply-preview"><b>${escapeHtml(msg.replyPreview.from)}</b>${escapeHtml(msg.replyPreview.text)}</div>`;
  }

  if (msg.type === 'photo') {
    bubble.classList.add('media-bubble');
    bubble.innerHTML = replyHtml + (msg.mediaUrl ? `<img class="msg-image" src="${msg.mediaUrl}" alt="foto" loading="lazy">` : '') + (msg.text ? `<div class="msg-caption">${escapeHtml(msg.text)}</div>` : '');
    return bubble;
  }

  if (msg.type === 'sticker') {
    bubble.classList.add('sticker-bubble');
    if (msg.stickerAnimated || !msg.mediaUrl) {
      bubble.innerHTML = `<div class="sticker-placeholder"><div class="emoji">${escapeHtml(msg.stickerEmoji || '🧩')}</div><div class="label">Stiker animasi<br>(pratinjau tidak didukung)</div></div>`;
    } else if (msg.stickerVideo) {
      bubble.innerHTML = `<video class="msg-sticker-video" src="${msg.mediaUrl}" autoplay loop muted playsinline></video>`;
    } else {
      bubble.innerHTML = `<img class="msg-sticker-img" src="${msg.mediaUrl}" alt="${escapeHtml(msg.stickerEmoji||'stiker')}" loading="lazy">`;
    }
    return bubble;
  }

  bubble.innerHTML = replyHtml + escapeHtml(msg.text);
  return bubble;
}

function scrollMessagesToBottom() {
  const el = document.getElementById('messages-scroll');
  requestAnimationFrame(() => { el.scrollTop = el.scrollHeight; });
}

/* ============================== REPLY ============================== */
function setReplyTarget(msg) {
  state.replyTarget = { tgMessageId: msg.tgMessageId, text: msg.text || '[media]', from: msg.from === 'bot' ? 'Anda' : 'Kontak' };
  document.getElementById('reply-bar').classList.add('show');
  document.getElementById('reply-bar-text').innerHTML = `<b>${state.replyTarget.from}</b>${escapeHtml(state.replyTarget.text.slice(0,60))}`;
  document.getElementById('chat-input').focus();
}
function cancelReply() {
  state.replyTarget = null;
  document.getElementById('reply-bar').classList.remove('show');
}

/* ============================== KIRIM PESAN TEKS ============================== */
async function sendChatMessage() {
  if (state.pendingImage) return sendPendingImage();

  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  const chatId = state.activeChatId;
  if (!text || !chatId) return;

  const replySnapshot = state.replyTarget;
  input.value = ''; autoGrow(input);
  cancelReply();

  const optimistic = { tgMessageId:null, from:'bot', type:'text', text, time:Date.now(), status:'pending',
    replyPreview: replySnapshot ? { from: replySnapshot.from, text: replySnapshot.text } : null };
  state.activeChatMessages.push(optimistic);
  appendMessageToView(optimistic);
  scrollMessagesToBottom();

  const result = await api('POST', '/api/telegram/send', { chatId, text, replyToTgMessageId: replySnapshot ? replySnapshot.tgMessageId : undefined });
  if (!result.ok) {
    showToast('Gagal mengirim: ' + (result.message || 'error'), 'error');
  }
  // biarkan polling berikutnya menampilkan versi final (status sent) dari server -- sederhana & konsisten
  state.activeChatMessages = [];
  document.getElementById('messages-scroll').innerHTML = '';
  pollOnce();
}

/* ============================== KIRIM GAMBAR (dengan kompresi canvas) ============================== */
document.getElementById('image-attach-btn').addEventListener('click', () => document.getElementById('image-file-input').click());
document.getElementById('image-file-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')) { showToast('File harus berupa gambar', 'error'); return; }

  try {
    const compressedBase64 = await compressImageToBase64(file, 360, 0.70);
    state.pendingImage = compressedBase64;
    document.getElementById('ip-thumb').src = compressedBase64;
    document.getElementById('image-preview-bar').classList.add('show');
    document.getElementById('chat-input').placeholder = 'Tulis keterangan gambar (opsional)...';
  } catch (err) {
    showToast('Gagal memproses gambar', 'error');
  }
  e.target.value = '';
});

function compressImageToBase64(file, maxDim, quality) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = maxDim / Math.max(width, height);
          width = Math.round(width * scale); height = Math.round(height * scale);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width; canvas.height = height;
        canvas.getContext('2d').drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = reject;
      img.src = reader.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function cancelPendingImage() {
  state.pendingImage = null;
  document.getElementById('image-preview-bar').classList.remove('show');
  document.getElementById('chat-input').placeholder = 'Tulis pesan...';
}
document.getElementById('ip-cancel-btn').addEventListener('click', cancelPendingImage);

async function sendPendingImage() {
  const chatId = state.activeChatId;
  const input = document.getElementById('chat-input');
  const caption = input.value.trim();
  const imageBase64 = state.pendingImage;
  if (!chatId || !imageBase64) return;

  const replySnapshot = state.replyTarget;
  cancelPendingImage();
  input.value = ''; autoGrow(input);
  cancelReply();

  const optimistic = { tgMessageId:null, from:'bot', type:'photo', text:caption, mediaUrl:imageBase64, time:Date.now(), status:'pending', replyPreview:null };
  state.activeChatMessages.push(optimistic);
  appendMessageToView(optimistic);
  scrollMessagesToBottom();

  const result = await api('POST', '/api/telegram/send-photo', { chatId, imageBase64, caption, replyToTgMessageId: replySnapshot ? replySnapshot.tgMessageId : undefined });
  if (!result.ok) showToast('Gagal mengirim gambar: ' + (result.message || 'error'), 'error');

  state.activeChatMessages = [];
  document.getElementById('messages-scroll').innerHTML = '';
  pollOnce();
}

/* ============================== TYPING INDICATOR ============================== */
function triggerTypingIndicator() {
  if (!state.settings.typingIndicator || !state.activeChatId) return;
  if (typingDebounce) return;
  typingDebounce = setTimeout(() => { typingDebounce = null; }, 4000);
  api('POST', '/api/telegram/typing', { chatId: state.activeChatId });
}

/* ============================== BROADCAST ============================== */
function getBroadcastTargets() {
  const excludeChecked = document.getElementById('broadcast-exclude-checkbox').checked;
  return Object.values(state.contacts).filter(c => !(excludeChecked && c.excluded));
}
function renderBroadcastTargetCount() {
  document.getElementById('broadcast-target-count').textContent = getBroadcastTargets().length;
}

async function sendBroadcast() {
  const textarea = document.getElementById('broadcast-textarea');
  const text = textarea.value.trim();
  if (!text) { showToast('Tulis pesan broadcast dulu', 'error'); return; }
  const targets = getBroadcastTargets();
  if (!targets.length) { showToast('Tidak ada target kontak', 'error'); return; }

  showModal('Kirim Broadcast?', `Pesan akan dikirim ke ${targets.length} kontak. Lanjutkan?`, () => runBroadcast(text, targets), 'Ya, Kirim');
}

async function runBroadcast(text, targets) {
  const sendBtn = document.getElementById('broadcast-send-btn');
  sendBtn.disabled = true;
  const progressWrap = document.getElementById('broadcast-progress-wrap');
  progressWrap.classList.add('show');
  const fill = document.getElementById('broadcast-progress-fill');
  const progressText = document.getElementById('broadcast-progress-text');
  const progressFail = document.getElementById('broadcast-progress-fail');

  let success = 0, failed = 0;
  for (let i = 0; i < targets.length; i++) {
    const result = await api('POST', '/api/telegram/send', { chatId: targets[i].chatId, text });
    if (result.ok) success++; else failed++;
    const pct = Math.round(((i+1)/targets.length)*100);
    fill.style.width = pct + '%';
    progressText.textContent = `Mengirim ${i+1} / ${targets.length}`;
    progressFail.textContent = failed ? `${failed} gagal` : '';
    await sleep(45);
  }

  const historyEl = document.getElementById('broadcast-history-list');
  const entry = document.createElement('div');
  entry.className = 'broadcast-history-item';
  entry.innerHTML = `<div class="bh-icon">📨</div><div class="bh-body"><div class="bh-text">${escapeHtml(text)}</div><div class="bh-stats">${success} berhasil${failed?' · '+failed+' gagal':''} dari ${targets.length} target</div></div><div class="bh-time">baru saja</div>`;
  historyEl.prepend(entry);

  sendBtn.disabled = false;
  textarea.value = '';
  showModal('Broadcast Selesai', `Terkirim ke ${success} dari ${targets.length} kontak.${failed ? ' '+failed+' gagal.' : ''}`, () => {}, 'Tutup');
  showToast(`Broadcast selesai: ${success} berhasil, ${failed} gagal`, failed ? 'error' : 'success');
  setTimeout(() => { progressWrap.classList.remove('show'); fill.style.width='0%'; }, 1200);
}

/* ============================== TAB KONTAK ============================== */
function renderContactsTable(filterText) {
  const tbody = document.getElementById('contacts-table-body');
  const q = (filterText !== undefined ? filterText : (document.getElementById('contacts-search')?.value || '')).toLowerCase().trim();
  let contacts = getContactsSorted();
  if (q) contacts = contacts.filter(c => fullName(c).toLowerCase().includes(q) || (c.username||'').toLowerCase().includes(q) || c.chatId.includes(q));

  if (!contacts.length) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:var(--text-dim);padding:26px;">Belum ada kontak.</td></tr>`;
    return;
  }
  tbody.innerHTML = contacts.map(c => `
    <tr>
      <td><div class="name-cell"><div class="mini-avatar" style="background:${avatarColor(c.chatId)}">${initials(fullName(c))}</div>
        <div><div>${escapeHtml(fullName(c))}${c.excluded?'<span class="excluded-tag">dikecualikan</span>':''}</div>
        <div style="font-size:10.5px;color:var(--text-dim);">${c.username?'@'+escapeHtml(c.username):'—'}</div></div></div></td>
      <td style="color:var(--text-dim);">${c.chatId}</td>
      <td>${c.messageCount||0}</td>
      <td style="color:var(--text-dim);">${formatRelativeShort(c.lastSeen)} lalu</td>
      <td><button class="row-btn act-open" data-id="${c.chatId}">Chat</button></td>
    </tr>
  `).join('');
  tbody.querySelectorAll('.act-open').forEach(btn => btn.addEventListener('click', () => { switchTab('chat'); openChat(btn.dataset.id); }));
}

function exportContactsCsv() {
  const contacts = getContactsSorted();
  if (!contacts.length) { showToast('Tidak ada data untuk diekspor', 'error'); return; }
  const rows = [['Nama','Username','Chat ID','Jumlah Pesan','Pertama Kali Chat','Terakhir Aktif']];
  contacts.forEach(c => rows.push([fullName(c), c.username||'', c.chatId, c.messageCount||0, new Date(c.firstSeen).toLocaleString('id-ID'), new Date(c.lastSeen).toLocaleString('id-ID')]));
  const csv = rows.map(r => r.map(cell => `"${String(cell).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type:'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'kontak-zynx-' + Date.now() + '.csv';
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

/* ============================== SETELAN: KONEKSI BOT ============================== */
async function loadBotStatus() {
  const result = await api('GET', '/api/telegram/status');
  const statusText = document.getElementById('bot-status-text');
  if (result.connected) {
    statusText.innerHTML = `Terhubung ke <b>@${escapeHtml(result.botUsername)}</b> (${escapeHtml(result.tokenMasked)})`;
    document.getElementById('bot-connect-btn').textContent = 'Ganti Bot';
  } else {
    statusText.textContent = 'Belum ada bot terhubung. Masukkan token dari @BotFather di bawah.';
  }
}

document.getElementById('bot-connect-btn').addEventListener('click', async () => {
  const token = document.getElementById('bot-token-input').value.trim();
  if (!token) { showToast('Masukkan token bot dulu', 'error'); return; }
  const btn = document.getElementById('bot-connect-btn');
  btn.disabled = true; btn.textContent = 'Menghubungkan...';
  const result = await api('POST', '/api/telegram/setup', { token });
  btn.disabled = false;
  if (!result.ok) { showToast(result.message || 'Gagal menghubungkan bot', 'error'); btn.textContent = 'Hubungkan Bot'; return; }
  showToast('Bot berhasil terhubung: @' + result.botInfo.username, 'success');
  document.getElementById('bot-token-input').value = '';
  loadBotStatus();
});

function applyRoleVisibility() {
  const adminCard = document.getElementById('admin-access-card');
  if (adminCard) adminCard.style.display = (state.me && state.me.role === 'owner') ? 'block' : 'none';
}

/* ============================== EMOJI PICKER ============================== */
const EMOJI_DATA = {
  '😀': ['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','😊','😇','🙃','😉','😌','😍','🥰','😘','😗','😙','😚','😋','😛','😝','😜','🤪','🤨','🧐','🤓','😎','🥳','😏','😒','😞','😔','😟','😕','☹️','😣','😖','😫','😩','🥺','😢','😭','😤','😠','😡','🤯','😱','😨','😰','😥','😓','🤗','🤔','🤭','🤫','🤥','😶'],
  '👋': ['👋','🤚','🖐️','✋','👌','🤏','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','👇','☝️','👍','👎','✊','👊','👏','🙌','👐','🙏','✍️','💅','🤳','💪'],
  '❤️': ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗','💖','💘','💝','💯','🔥','✨','⭐','💫','💥'],
  '🎉': ['🎉','🎊','🎈','🎁','🏆','🥇','🎗️','🎫','🎪','🤹','🎭','🎨','🎬','🎤','🎧','🎵','🎮','🎲','🎯'],
  '🍔': ['🍏','🍎','🍌','🍉','🍇','🍓','🍒','🍑','🥑','🍅','🌽','🥕','🍞','🧀','🍳','🥓','🍔','🍟','🍕','☕','🍵','🍺'],
  '🚀': ['🚗','🚕','🚙','🚌','🏎️','🚑','🚒','🛵','🏍️','🚲','✈️','🚀','🚁','⛵','🚢','🗺️','🗽','🏰','🎡'],
  '🔥': ['✅','❌','⚠️','❗','❓','💡','🔔','🔒','🔑','🔎','💰','💳','💎','🔧','🔨','⚙️','🔫','💊','🧪','📦','📌','📍','✂️','🗑️'],
};
const EMOJI_CATS = [{key:'😀',label:'Wajah'},{key:'👋',label:'Gestur'},{key:'❤️',label:'Hati'},{key:'🎉',label:'Acara'},{key:'🍔',label:'Makanan'},{key:'🚀',label:'Transport'},{key:'🔥',label:'Simbol'}];

function buildEmojiPicker(pickerEl, targetTextarea) {
  const catsHtml = EMOJI_CATS.map((c,i) => `<button data-cat="${c.key}" class="${i===0?'active':''}" title="${c.label}">${c.key}</button>`).join('');
  pickerEl.innerHTML = `<div class="emoji-cats">${catsHtml}</div><div class="emoji-grid"></div>`;
  const grid = pickerEl.querySelector('.emoji-grid');
  function renderCat(key) {
    grid.innerHTML = EMOJI_DATA[key].map(e => `<button>${e}</button>`).join('');
    grid.querySelectorAll('button').forEach(btn => btn.addEventListener('click', () => insertAtCursor(targetTextarea, btn.textContent)));
  }
  renderCat(EMOJI_CATS[0].key);
  pickerEl.querySelectorAll('.emoji-cats button').forEach(btn => btn.addEventListener('click', () => {
    pickerEl.querySelectorAll('.emoji-cats button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active'); renderCat(btn.dataset.cat);
  }));
}
function toggleEmojiPicker(pickerEl) {
  document.querySelectorAll('.emoji-picker').forEach(p => { if (p !== pickerEl) p.classList.remove('show'); });
  pickerEl.classList.toggle('show');
}

/* ============================== NAVIGASI TAB ============================== */
function switchTab(tabName) {
  state.activeTab = tabName;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tabName));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  const panel = document.getElementById('tab-' + tabName);
  panel.classList.add('active');
  panel.style.display = 'flex';
  if (tabName === 'broadcast') renderBroadcastTargetCount();
  if (tabName === 'contacts') renderContactsTable();
  if (tabName === 'settings') loadBotStatus();
}

/* ============================== WIRING EVENT ============================== */
function wireEvents() {
  // Auth
  document.getElementById('login-submit-btn').addEventListener('click', submitLogin);
  document.getElementById('login-password').addEventListener('keydown', e => { if (e.key === 'Enter') submitLogin(); });
  document.getElementById('bootstrap-submit-btn').addEventListener('click', submitBootstrap);
  document.getElementById('bs-captcha-refresh').addEventListener('click', refreshBootstrapCaptcha);
  document.getElementById('logout-btn').addEventListener('click', async () => {
    await api('POST', '/api/auth/logout');
    window.location.href = '/';
  });

  // Tabs
  document.querySelectorAll('.tab-btn').forEach(btn => btn.addEventListener('click', () => switchTab(btn.dataset.tab)));

  // Chat search (juga jalur clue #4)
  document.getElementById('chat-search').addEventListener('input', e => renderChatList(e.target.value));

  // Composer
  const chatInput = document.getElementById('chat-input');
  chatInput.addEventListener('input', () => { autoGrow(chatInput); triggerTypingIndicator(); });
  chatInput.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMessage(); } });
  document.getElementById('send-btn').addEventListener('click', sendChatMessage);
  document.getElementById('reply-cancel-btn').addEventListener('click', cancelReply);
  document.getElementById('cv-clear-btn').addEventListener('click', () => {
    if (!state.activeChatId) return;
    showModal('Hapus Riwayat Chat?', 'Ini menghapus seluruh riwayat pesan kontak ini dari database secara permanen.', async () => {
      await api('POST', '/api/admin/contacts/delete', { chatId: state.activeChatId }).catch(()=>{});
      showToast('Riwayat dihapus'); state.activeChatMessages = []; document.getElementById('messages-scroll').innerHTML = ''; pollOnce();
    }, 'Ya, Hapus');
  });

  // Format toolbar
  document.getElementById('cv-format-toggle').addEventListener('click', () => document.getElementById('format-toolbar').classList.toggle('show'));
  document.querySelectorAll('#format-toolbar button').forEach(btn => btn.addEventListener('click', () => wrapSelection(chatInput, btn.dataset.wrap)));

  // Emoji (chat)
  const emojiPickerChat = document.getElementById('emoji-picker-chat');
  buildEmojiPicker(emojiPickerChat, chatInput);
  document.getElementById('emoji-toggle-btn').addEventListener('click', () => toggleEmojiPicker(emojiPickerChat));

  // Broadcast
  const broadcastTextarea = document.getElementById('broadcast-textarea');
  document.getElementById('broadcast-send-btn').addEventListener('click', sendBroadcast);
  document.getElementById('broadcast-preview-btn').addEventListener('click', () => {
    const text = broadcastTextarea.value.trim();
    if (!text) { showToast('Tulis pesan dulu', 'error'); return; }
    showModal('Pratinjau Broadcast', text, () => {}, 'Tutup');
  });
  document.getElementById('broadcast-exclude-checkbox').addEventListener('change', renderBroadcastTargetCount);
  document.querySelectorAll('#broadcast-format-toolbar button[data-wrap]').forEach(btn => btn.addEventListener('click', () => wrapSelection(broadcastTextarea, btn.dataset.wrap)));
  const emojiPickerBroadcast = document.getElementById('emoji-picker-broadcast');
  buildEmojiPicker(emojiPickerBroadcast, broadcastTextarea);
  document.getElementById('broadcast-emoji-btn').addEventListener('click', () => toggleEmojiPicker(emojiPickerBroadcast));

  // Kontak
  document.getElementById('contacts-search').addEventListener('input', e => renderContactsTable(e.target.value));
  document.getElementById('export-csv-btn').addEventListener('click', exportContactsCsv);

  // Tutup emoji picker saat klik luar
  document.addEventListener('click', e => {
    document.querySelectorAll('.emoji-picker.show').forEach(p => {
      if (!p.contains(e.target) && e.target.id !== 'emoji-toggle-btn' && e.target.id !== 'broadcast-emoji-btn') p.classList.remove('show');
    });
  });
}

/* ============================== BOOTSTRAP ============================== */
wireEvents();
initAuth();
