ZynxControl By:

ZZZZZZZZ   YY     YY  NN     NN  XX     XX  TTTTTTTT  EEEEEEEE   AAAA    MM       MM
ZZZZZZZZ    YY   YY   NNN    NN   XX   XX      TT     EE        AAAAAA   MMM     MMM
     ZZ      YY YY    NN N   NN    XX XX       TT     EEEEE    AA    AA  MM M   M MM
    ZZ        YYY     NN  N  NN     XXX        TT     EE       AAAAAAAA  MM  M M  MM
   ZZ         YY      NN   NNNN    XX XX       TT     EE       AA    AA  MM   M   MM
ZZZZZZZZ      YY      NN    NNN  XX     XX     TT     EEEEEEEE AA    AA  MM       MM

# Zynx Control

Panel web ala Telegram buat ngontrol bot telegram secara statis. Gak usah banyak tanya, kodingan udah kelar, fitur jalan semua, firebase udah kehubung. Tinggal deploy.

---

## ⚡ Fitur Utama

- **Telegram Web UI**: Tampilan chat, list kontak, bubble chat, preview reply.
- **Kompresi Gambar Auto (360p)**: Gambar nge-compress otomatis di client biar gak makan bandwidth server.
- **Support Sticker & Media**: Stiker sama gambar yang masuk tetep kebaca.
- **Broadcast**: Kirim pesan massal ke semua user bot sekali tekan.
- **Login Slug & Credential**: Login paki kredensial buatan admin atau auto-login via URL unik (misal `/oapwbd`).
- **Protected Admin Gate**: Panel admin dilindungi enkripsi token dinamis & verifikasi kredensial.
- **Serverless Backend**: Jalur API dipisah ke Vercel Functions biar Private Key Firebase gak bocor.

---

## 📂 Struktur File Singkat

- `public/index.html` - UI utama chat & interface dashboard.
- `public/admin.html` - Panel admin buat bikin akun & pantau database.
- `public/app.js` - Logic frontend, handler telegram API, kompresi 360p.
- `api/` - Endpoint serverless backend.
- `lib/firebaseAdmin.js` - Koneksi Firebase SDK server-side.
- `.env` - Rahasia kredensial backend (jangan di-commit).

---

## 🚀 Cara Run (Gak Pake Ribet)

1. Clone repo terus install dependensi:
   ```bash
   git clone [https://github.com/username/zynx-control.git](https://github.com/username/zynx-control.git)
   cd zynx-control
   npm install

   © Copyright ZynxTeam 2026. All rights reserved. Gak tidur semaleman, kelar juga akhirnya.
   © Copyright ZynxTeam 2026. All rights reserved. Gak tidur semaleman, kelar juga akhirnya.
   © Copyright ZynxTeam 2026. All rights reserved. Gak tidur semaleman, kelar juga akhirnya.
   © Copyright ZynxTeam 2026. All rights reserved. Gak tidur semaleman, kelar juga akhirnya.