import { db } from '../../lib/firebaseAdmin.js';

/* =========================================================================================
   api/auth/bootstrap-status.js  (GET, publik)
   Dipanggil halaman login untuk tahu: apakah ini pertama kali sistem dipakai (belum ada akun
   sama sekali)? Kalau iya, frontend menampilkan form "Buat Akun Owner Pertama" alih-alih form
   login biasa. Setelah owner pertama dibuat, endpoint bootstrap.js akan menolak permintaan
   berikutnya selamanya -- jadi ini bukan celah untuk membuat owner baru kapan saja.
   ========================================================================================= */

export default async function handler(req, res) {
  try {
    const snap = await db().collection('accounts').limit(1).get();
    return res.status(200).json({ ok: true, needsBootstrap: snap.empty });
  } catch (err) {
    return res.status(500).json({ ok: false, error: 'SERVER_ERROR', message: err.message });
  }
}
