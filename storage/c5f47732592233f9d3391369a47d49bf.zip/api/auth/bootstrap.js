import { db } from '../../lib/firebaseAdmin.js';
import { hashPassword } from '../../lib/password.js';
import { verifyCaptcha } from '../../lib/captcha.js';
import { signSession, setSessionCookie } from '../../lib/session.js';

/* =========================================================================================
   api/auth/bootstrap.js  (POST, publik -- TAPI hanya berfungsi sekali)
   Mengatasi masalah "ayam-telur": sistem "no register, cuma login pakai akun buatan admin",
   jadi siapa yang membuat akun ADMIN pertama? Endpoint ini mengizinkan pembuatan SATU akun
   owner pertama HANYA jika koleksi `accounts` masih benar-benar kosong. Setelah itu, endpoint
   ini permanen menolak (403) -- pembuatan akun berikutnya wajib lewat admin.html.
   ========================================================================================= */

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });

  const { username, password, captchaToken, captchaAnswer } = req.body || {};
  if (!username || !password || !captchaToken || !captchaAnswer) {
    return res.status(400).json({ ok: false, error: 'BAD_REQUEST', message: 'Semua field wajib diisi.' });
  }
  if (username.length < 3 || password.length < 6) {
    return res.status(400).json({ ok: false, error: 'BAD_REQUEST', message: 'Username minimal 3 karakter, password minimal 6 karakter.' });
  }
  if (!verifyCaptcha(captchaToken, captchaAnswer)) {
    return res.status(400).json({ ok: false, error: 'CAPTCHA_FAILED', message: 'Captcha salah atau kedaluwarsa.' });
  }

  const accountsRef = db().collection('accounts');
  const existing = await accountsRef.limit(1).get();
  if (!existing.empty) {
    return res.status(403).json({ ok: false, error: 'ALREADY_BOOTSTRAPPED', message: 'Akun owner sudah pernah dibuat. Gunakan halaman login biasa.' });
  }

  const passwordHash = await hashPassword(password);
  const loginSlug = generateSlug();
  const docRef = accountsRef.doc();
  const account = {
    username: username.trim(),
    passwordHash,
    role: 'owner',
    loginSlug,
    tokenVersion: 0,
    active: true,
    createdAt: Date.now(),
    createdBy: 'bootstrap',
  };
  await docRef.set(account);

  const token = signSession({ accountId: docRef.id, tokenVersion: 0, puzzleUnlocked: false });
  setSessionCookie(res, token);

  return res.status(200).json({ ok: true, username: account.username, role: 'owner', loginSlug });
}

function generateSlug() {
  const chars = 'abcdefghijkmnopqrstuvwxyz23456789';
  let out = '';
  for (let i = 0; i < 8; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}
