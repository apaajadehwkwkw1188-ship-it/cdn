import { clearSessionCookie } from '../../lib/session.js';

/* =========================================================================================
   api/auth/logout.js  (POST)
   Menghapus cookie sesi di browser. Tidak perlu sentuh Firestore karena sesi berbasis JWT
   stateless -- cukup buang cookienya, JWT lama otomatis tidak terpakai lagi.
   ========================================================================================= */

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  clearSessionCookie(res);
  return res.status(200).json({ ok: true });
}
