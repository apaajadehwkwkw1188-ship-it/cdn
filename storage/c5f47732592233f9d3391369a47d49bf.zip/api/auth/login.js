import { db } from '../../lib/firebaseAdmin.js';
import { verifyPassword } from '../../lib/password.js';
import { signSession, setSessionCookie } from '../../lib/session.js';

/* =========================================================================================
   api/auth/login.js  (POST, publik)
   Login manual pakai username+password (untuk kredensial yang dibuat owner lewat admin.html).
   Pesan error sengaja digeneralisasi ("username atau password salah") untuk username yang
   tidak ada MAUPUN password yang salah -- supaya endpoint ini tidak bisa dipakai untuk
   menebak-nebak username mana saja yang terdaftar.
   ========================================================================================= */

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });

  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ ok: false, error: 'BAD_REQUEST', message: 'Username dan password wajib diisi.' });
  }

  const snap = await db().collection('accounts').where('username', '==', username.trim()).limit(1).get();
  const genericError = { ok: false, error: 'INVALID_CREDENTIALS', message: 'Username atau password salah.' };
  if (snap.empty) return res.status(401).json(genericError);

  const doc = snap.docs[0];
  const account = doc.data();
  if (!account.active) return res.status(401).json({ ok: false, error: 'ACCOUNT_DISABLED', message: 'Akun ini dinonaktifkan.' });

  const valid = await verifyPassword(password, account.passwordHash);
  if (!valid) return res.status(401).json(genericError);

  const token = signSession({ accountId: doc.id, tokenVersion: account.tokenVersion || 0, puzzleUnlocked: false });
  setSessionCookie(res, token);

  return res.status(200).json({ ok: true, username: account.username, role: account.role });
}
