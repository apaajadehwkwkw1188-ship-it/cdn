import { getValidSession } from '../../lib/session.js';

/* =========================================================================================
   api/auth/me.js  (GET)
   Dipanggil frontend saat load untuk tahu: sudah login belum, sebagai siapa, role apa, dan
   apakah puzzle admin sudah pernah dipecahkan di sesi ini. Tidak error kalau belum login --
   cukup balas { ok:true, loggedIn:false } supaya frontend bisa menampilkan form login dengan mulus.
   ========================================================================================= */

export default async function handler(req, res) {
  const session = await getValidSession(req);
  if (!session) return res.status(200).json({ ok: true, loggedIn: false });
  return res.status(200).json({
    ok: true,
    loggedIn: true,
    username: session.username,
    role: session.role,
    puzzleUnlocked: session.puzzleUnlocked,
  });
}
