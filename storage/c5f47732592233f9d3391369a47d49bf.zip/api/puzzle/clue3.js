import { getTodayPuzzle } from '../../lib/puzzle.js';

/* =========================================================================================
   api/puzzle/clue3.js  (GET, publik)
   Dipanggil oleh script di halaman login (index/render.js) untuk mengambil huruf ke-3 hari
   ini, lalu ditulis ke console.log oleh app.js. Publik (tidak butuh login) karena memang
   dimaksudkan bisa ditemukan siapa saja yang membuka DevTools di halaman login -- sama seperti
   clue 1 & 2 yang sudah ada langsung di HTML.
   ========================================================================================= */

export default async function handler(req, res) {
  const puzzle = await getTodayPuzzle();
  return res.status(200).json({ ok: true, c3: puzzle.c3 });
}
