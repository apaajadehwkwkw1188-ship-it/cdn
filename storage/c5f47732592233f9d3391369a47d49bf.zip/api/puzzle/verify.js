import { verifyPuzzleInput } from '../../lib/puzzle.js';
import { requireOwner, signSession, setSessionCookie } from '../../lib/session.js';

/* =========================================================================================
   api/puzzle/verify.js  (POST, WAJIB login sebagai owner)
   Dipanggil dari admin.html saat submit ke-4 huruf gabungan. Kalau benar, sesi login yang
   sedang aktif di-reissue dengan klaim tambahan `puzzleUnlocked:true` -- klaim ini dicek
   ULANG secara server-side oleh requireOwnerWithPuzzle() di setiap endpoint admin lainnya
   (create-user, kelola akun, kelola kontak). Jadi ini bukan sekadar toggle tampilan di
   browser; API-nya sendiri benar-benar menolak permintaan kalau klaim ini belum ada.
   ========================================================================================= */

export default requireOwner(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const { input } = req.body || {};
  const correct = await verifyPuzzleInput(input);
  if (!correct) {
    return res.status(400).json({ ok: false, error: 'WRONG_KEY', message: 'Key salah. Coba cari ulang ke-4 clue-nya.' });
  }

  const token = signSession({
    accountId: req.session.accountId,
    tokenVersion: req.session.account.tokenVersion || 0,
    puzzleUnlocked: true,
  });
  setSessionCookie(res, token);

  return res.status(200).json({ ok: true });
});
