import { getTodayPuzzle } from '../../lib/puzzle.js';
import { requireSession } from '../../lib/session.js';

/* =========================================================================================
   api/puzzle/clue4.js  (GET, WAJIB login -- role apapun, owner maupun buyer)
   Huruf ke-4 baru bisa diambil setelah user sudah login (search bar tempat clue ini muncul
   memang cuma ada di dashboard chat, bukan di halaman login). Efek sampingnya bagus: orang
   yang sama sekali tidak punya kredensial akun tidak akan pernah bisa merakit key lengkap,
   walau sudah tahu clue 1-2-3 dari halaman login publik.
   ========================================================================================= */

export default requireSession(async (req, res) => {
  const puzzle = await getTodayPuzzle();
  return res.status(200).json({ ok: true, c4: puzzle.c4 });
});
