import { db } from '../../../lib/firebaseAdmin.js';
import { requireOwnerWithPuzzle } from '../../../lib/session.js';

/* =========================================================================================
   api/admin/accounts/list.js  (GET, WAJIB owner + puzzle)
   passwordHash SENGAJA tidak pernah dikirim ke frontend, walau owner sekalipun -- tidak ada
   alasan legit UI perlu tahu hash-nya, dan mengurangi blast radius kalau response ini pernah
   ter-log di suatu tempat.
   ========================================================================================= */

export default requireOwnerWithPuzzle(async (req, res) => {
  const snap = await db().collection('accounts').orderBy('createdAt', 'desc').get();
  const accounts = snap.docs.map(doc => {
    const d = doc.data();
    return {
      id: doc.id,
      username: d.username,
      role: d.role,
      loginSlug: d.loginSlug,
      active: d.active,
      createdAt: d.createdAt,
      createdBy: d.createdBy,
    };
  });
  return res.status(200).json({ ok: true, accounts });
});
