import { db } from '../../../lib/firebaseAdmin.js';
import { hashPassword } from '../../../lib/password.js';
import { requireOwnerWithPuzzle } from '../../../lib/session.js';

/* =========================================================================================
   api/admin/accounts/update.js  (POST, WAJIB owner + puzzle)
   Body: { accountId, patch: { role?, active?, newPassword? } }
   - Mengubah role/active langsung menulis field terkait.
   - newPassword akan di-hash ulang.
   - SETIAP perubahan menaikkan tokenVersion +1, otomatis membuat semua sesi login lama akun
     tsb tidak valid lagi (logout paksa) -- penting terutama saat reset password atau
     menonaktifkan akun supaya efeknya langsung terasa, bukan menunggu token lama kedaluwarsa.
   ========================================================================================= */

export default requireOwnerWithPuzzle(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const { accountId, patch } = req.body || {};
  if (!accountId || !patch) return res.status(400).json({ ok: false, error: 'BAD_REQUEST' });

  const ref = db().collection('accounts').doc(accountId);
  const snap = await ref.get();
  if (!snap.exists) return res.status(404).json({ ok: false, error: 'NOT_FOUND' });

  const current = snap.data();
  const update = { tokenVersion: (current.tokenVersion || 0) + 1 };

  if (patch.role === 'owner' || patch.role === 'buyer') update.role = patch.role;
  if (typeof patch.active === 'boolean') update.active = patch.active;
  if (patch.newPassword) {
    if (patch.newPassword.length < 6) return res.status(400).json({ ok: false, error: 'BAD_REQUEST', message: 'Password minimal 6 karakter.' });
    update.passwordHash = await hashPassword(patch.newPassword);
  }

  await ref.update(update);
  return res.status(200).json({ ok: true });
});
