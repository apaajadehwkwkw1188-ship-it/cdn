import { db } from '../../../lib/firebaseAdmin.js';
import { requireOwnerWithPuzzle } from '../../../lib/session.js';

/* =========================================================================================
   api/admin/accounts/delete.js  (POST, WAJIB owner + puzzle)
   Ada dua pengaman supaya owner tidak tidak sengaja mengunci diri sendiri dari sistem:
   1. Tidak bisa menghapus akun sendiri yang sedang dipakai login.
   2. Tidak bisa menghapus owner TERAKHIR yang tersisa (harus selalu ada minimal 1 owner aktif).
   ========================================================================================= */

export default requireOwnerWithPuzzle(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const { accountId } = req.body || {};
  if (!accountId) return res.status(400).json({ ok: false, error: 'BAD_REQUEST' });

  if (accountId === req.session.accountId) {
    return res.status(400).json({ ok: false, error: 'CANNOT_DELETE_SELF', message: 'Tidak bisa menghapus akun yang sedang Anda pakai login.' });
  }

  const ref = db().collection('accounts').doc(accountId);
  const snap = await ref.get();
  if (!snap.exists) return res.status(404).json({ ok: false, error: 'NOT_FOUND' });

  if (snap.data().role === 'owner') {
    const ownersSnap = await db().collection('accounts').where('role', '==', 'owner').where('active', '==', true).get();
    if (ownersSnap.size <= 1) {
      return res.status(400).json({ ok: false, error: 'LAST_OWNER', message: 'Tidak bisa menghapus owner terakhir yang tersisa.' });
    }
  }

  await ref.delete();
  return res.status(200).json({ ok: true });
});
