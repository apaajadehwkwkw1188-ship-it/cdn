import { db } from '../../lib/firebaseAdmin.js';
import { hashPassword } from '../../lib/password.js';
import { verifyCaptcha } from '../../lib/captcha.js';
import { requireOwnerWithPuzzle } from '../../lib/session.js';

/* =========================================================================================
   api/admin/create-user.js  (POST, WAJIB owner + puzzle terpecahkan)
   Membuat akun baru. Otomatis membuat `loginSlug` acak untuk link auto-login
   (zynxcontrol.vercel.app/<loginSlug>), dikembalikan sekali di response ini -- owner harus
   menyalinnya sekarang juga karena tidak ditampilkan lagi setelah ini (hanya slug-nya yang
   tersimpan, dipakai ulang untuk auto-login, tapi link lengkapnya baiknya dicatat oleh owner).
   ========================================================================================= */

export default requireOwnerWithPuzzle(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });

  const { username, password, role, captchaToken, captchaAnswer } = req.body || {};
  if (!username || !password || !captchaToken || !captchaAnswer) {
    return res.status(400).json({ ok: false, error: 'BAD_REQUEST', message: 'Semua field wajib diisi.' });
  }
  if (username.length < 3 || password.length < 6) {
    return res.status(400).json({ ok: false, error: 'BAD_REQUEST', message: 'Username minimal 3 karakter, password minimal 6 karakter.' });
  }
  const finalRole = role === 'owner' ? 'owner' : 'buyer';
  if (!verifyCaptcha(captchaToken, captchaAnswer)) {
    return res.status(400).json({ ok: false, error: 'CAPTCHA_FAILED', message: 'Captcha salah atau kedaluwarsa.' });
  }

  const accountsRef = db().collection('accounts');
  const dupe = await accountsRef.where('username', '==', username.trim()).limit(1).get();
  if (!dupe.empty) {
    return res.status(409).json({ ok: false, error: 'USERNAME_TAKEN', message: 'Username sudah dipakai.' });
  }

  const passwordHash = await hashPassword(password);
  const loginSlug = generateSlug();
  const docRef = accountsRef.doc();
  await docRef.set({
    username: username.trim(),
    passwordHash,
    role: finalRole,
    loginSlug,
    tokenVersion: 0,
    active: true,
    createdAt: Date.now(),
    createdBy: req.session.username,
  });

  return res.status(200).json({
    ok: true,
    account: { id: docRef.id, username: username.trim(), role: finalRole, loginSlug },
  });
});

function generateSlug() {
  const chars = 'abcdefghijkmnopqrstuvwxyz23456789';
  let out = '';
  for (let i = 0; i < 8; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}
