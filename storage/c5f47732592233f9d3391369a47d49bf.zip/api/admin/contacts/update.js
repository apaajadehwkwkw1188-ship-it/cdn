import { db } from '../../../lib/firebaseAdmin.js';
import { requireOwnerWithPuzzle } from '../../../lib/session.js';

export default requireOwnerWithPuzzle(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const { chatId, patch } = req.body || {};
  if (!chatId || !patch) return res.status(400).json({ ok: false, error: 'BAD_REQUEST' });

  const ref = db().collection('contacts').doc(String(chatId));
  const snap = await ref.get();
  if (!snap.exists) return res.status(404).json({ ok: false, error: 'NOT_FOUND' });

  const update = {};
  if (typeof patch.excluded === 'boolean') update.excluded = patch.excluded;
  await ref.update(update);

  return res.status(200).json({ ok: true });
});
