import { db } from '../../../lib/firebaseAdmin.js';
import { requireOwnerWithPuzzle } from '../../../lib/session.js';

/* =========================================================================================
   api/admin/contacts/list.js  (GET, WAJIB owner + puzzle)
   Tampilan database untuk koleksi `contacts` (orang-orang yang pernah chat bot) dalam bentuk
   yang gampang dibaca -- ini yang dimaksud "bukan struktur membosankan di Firebase console".
   ========================================================================================= */

export default requireOwnerWithPuzzle(async (req, res) => {
  const snap = await db().collection('contacts').orderBy('lastSeen', 'desc').get();
  const contacts = snap.docs.map(doc => doc.data());
  return res.status(200).json({ ok: true, contacts });
});
