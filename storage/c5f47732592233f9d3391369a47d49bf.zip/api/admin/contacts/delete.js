import { db } from '../../../lib/firebaseAdmin.js';
import { requireOwnerWithPuzzle } from '../../../lib/session.js';

/* =========================================================================================
   api/admin/contacts/delete.js  (POST, WAJIB owner + puzzle)
   Menghapus dokumen kontak DAN seluruh subcollection pesan chat-nya. Ini hanya menghapus data
   di database kita -- tidak menghapus/memblokir apapun di sisi Telegram.
   ========================================================================================= */

export default requireOwnerWithPuzzle(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const { chatId } = req.body || {};
  if (!chatId) return res.status(400).json({ ok: false, error: 'BAD_REQUEST' });

  const firestore = db();
  const messagesSnap = await firestore.collection('chats').doc(String(chatId)).collection('messages').get();
  const batch = firestore.batch();
  messagesSnap.docs.forEach(doc => batch.delete(doc.ref));
  batch.delete(firestore.collection('contacts').doc(String(chatId)));
  await batch.commit();

  return res.status(200).json({ ok: true });
});
