import { generateCaptcha } from '../../lib/captcha.js';

/* =========================================================================================
   api/captcha/generate.js  (GET, publik)
   Dipakai di: (1) form buat akun owner pertama, (2) form create-user di admin.html --
   keduanya butuh captcha mini untuk mencegah spam pembuatan akun.
   ========================================================================================= */

export default function handler(req, res) {
  const { svg, token } = generateCaptcha();
  return res.status(200).json({ ok: true, svg, token });
}
