import { db } from '../../lib/firebaseAdmin.js';
import { tgCall } from '../../lib/telegram.js';
import { requireOwner } from '../../lib/session.js';

/* =========================================================================================
   api/telegram/setup.js  (POST, WAJIB login sebagai owner)
   Berbeda dari versi purely-client-side sebelumnya: token bot SEKARANG disimpan di Firestore
   (settings/telegram), bukan cuma di localStorage browser. Ini konsekuensi wajar dari memakai
   webhook asli -- Telegram bisa mengirim update KAPAN SAJA tanpa ada browser yang terbuka,
   jadi server butuh akses ke token itu sendiri untuk memproses pesan masuk (download foto,
   dsb), bukan cuma menerima teks pasif.

   Hanya SATU bot per deployment (disederhanakan dari skenario multi-bot). Kalau butuh banyak
   bot sekaligus, struktur `settings/telegram` perlu diubah jadi per-workspace -- di luar
   cakupan build ini, dicatat sebagai batasan yang disengaja.
   ========================================================================================= */

export default requireOwner(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const { token } = req.body || {};
  if (!token) return res.status(400).json({ ok: false, error: 'BAD_REQUEST', message: 'Token wajib diisi.' });

  let botInfo;
  try {
    botInfo = await tgCall(token, 'getMe');
  } catch (err) {
    return res.status(400).json({ ok: false, error: 'INVALID_TOKEN', message: err.message });
  }

  const proto = req.headers['x-forwarded-proto'] || 'https';
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  const webhookSecret = process.env.WEBHOOK_SECRET || 'zynx-webhook';
  const webhookUrl = `${proto}://${host}/api/telegram/webhook`;

  try {
    await tgCall(token, 'setWebhook', {
      url: webhookUrl,
      secret_token: webhookSecret,
      drop_pending_updates: false,
      allowed_updates: ['message'],
    });
  } catch (err) {
    return res.status(500).json({ ok: false, error: 'WEBHOOK_SETUP_FAILED', message: err.message });
  }

  await db().collection('settings').doc('telegram').set({
    token,
    botId: botInfo.id,
    botUsername: botInfo.username,
    botFirstName: botInfo.first_name,
    connectedAt: Date.now(),
    connectedBy: req.session.username,
  });

  return res.status(200).json({ ok: true, botInfo });
});
