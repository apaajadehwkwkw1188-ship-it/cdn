import { db } from '../../lib/firebaseAdmin.js';
import { tgCall } from '../../lib/telegram.js';
import { requireSession } from '../../lib/session.js';

/* api/telegram/typing.js (POST, WAJIB login) -- proxy sendChatAction supaya kontak lihat "sedang mengetik...". */

export default requireSession(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const { chatId } = req.body || {};
  if (!chatId) return res.status(400).json({ ok: false });

  const settingsSnap = await db().collection('settings').doc('telegram').get();
  if (!settingsSnap.exists) return res.status(200).json({ ok: true });
  const { token } = settingsSnap.data();

  try { await tgCall(token, 'sendChatAction', { chat_id: Number(chatId), action: 'typing' }); } catch (e) { /* abaikan */ }
  return res.status(200).json({ ok: true });
});
