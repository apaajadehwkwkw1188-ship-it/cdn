import { db, bucket } from '../../lib/firebaseAdmin.js';
import { tgSendPhoto } from '../../lib/telegram.js';
import { requireSession } from '../../lib/session.js';

/* =========================================================================================
   api/telegram/send-photo.js  (POST, WAJIB login)
   Body: { chatId, imageBase64 (data URL atau base64 murni), caption?, replyToTgMessageId? }
   Catatan batasan: request body di Vercel Serverless Functions punya batas ukuran (umumnya
   beberapa MB) -- untuk foto besar dari kamera HP, frontend sudah mengecilkan resolusinya
   dulu lewat <canvas> sebelum dikirim ke sini (lihat app.js), supaya tetap aman di bawah batas.
   ========================================================================================= */

const MAX_BYTES = 4 * 1024 * 1024; // 4MB, sisakan headroom di bawah limit payload Vercel

export default requireSession(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const { chatId, imageBase64, caption, replyToTgMessageId } = req.body || {};
  if (!chatId || !imageBase64) return res.status(400).json({ ok: false, error: 'BAD_REQUEST' });

  const firestore = db();
  const settingsSnap = await firestore.collection('settings').doc('telegram').get();
  if (!settingsSnap.exists) return res.status(400).json({ ok: false, error: 'BOT_NOT_CONNECTED' });
  const { token } = settingsSnap.data();

  const base64Data = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
  const buffer = Buffer.from(base64Data, 'base64');
  if (buffer.length > MAX_BYTES) {
    return res.status(400).json({ ok: false, error: 'FILE_TOO_LARGE', message: 'Gambar terlalu besar (maks 4MB setelah kompresi).' });
  }

  let result;
  try {
    result = await tgSendPhoto(token, chatId, buffer, {
      caption: caption || undefined,
      replyToMessageId: replyToTgMessageId || undefined,
      mimeType: 'image/jpeg',
      filename: 'photo.jpg',
    });
  } catch (err) {
    return res.status(200).json({ ok: false, error: 'SEND_FAILED', message: err.message });
  }

  const now = Date.now();
  const storagePath = `telegram-media/${chatId}/${result.message_id}-out.jpg`;
  const file = bucket().file(storagePath);
  await file.save(buffer, { metadata: { contentType: 'image/jpeg' }, public: true, validation: false });
  const mediaUrl = `https://storage.googleapis.com/${bucket().name}/${storagePath}`;

  const message = {
    tgMessageId: result.message_id, from: 'bot', type: 'photo', text: caption || '',
    time: now, status: 'sent', mediaUrl, replyPreview: null,
  };
  const msgRef = await firestore.collection('chats').doc(String(chatId)).collection('messages').add(message);

  await firestore.collection('contacts').doc(String(chatId)).set(
    { lastMessageText: '📷 [Foto]' + (caption ? ' ' + caption : ''), lastMessageTime: now }, { merge: true }
  );
  await firestore.collection('system').doc('cursor').set({ value: now }, { merge: true });

  return res.status(200).json({ ok: true, message: { id: msgRef.id, ...message } });
});
