import { db, bucket } from '../../lib/firebaseAdmin.js';
import { tgDownloadFile, guessMimeFromPath, nonTextPlaceholder } from '../../lib/telegram.js';

/* =========================================================================================
   api/telegram/webhook.js  (POST -- dipanggil server Telegram, BUKAN oleh frontend)
   Ini yang bikin sistem tetap "hidup" walau tidak ada satupun tab browser terbuka: Telegram
   akan mem-POST setiap pesan baru ke sini kapan saja, dan semuanya langsung tersimpan ke
   Firestore + Firebase Storage (untuk foto/stiker) -- jadi saat dashboard dibuka lagi nanti,
   semua histori (termasuk kontak yang chat saat dashboard sedang tutup) sudah lengkap.

   Penanganan media:
   - Foto (msg.photo)   -> diunduh dari Telegram, diupload ke Firebase Storage, disimpan URL publiknya.
   - Stiker statis/video (msg.sticker, webp/webm) -> sama, diunduh & disimpan, bisa dirender <img>/<video>.
   - Stiker animasi lawas format .tgs (Lottie terkompresi) -> SENGAJA tidak dirender penuh
     (butuh library Lottie terpisah, di luar cakupan build ini) -- disimpan sebagai placeholder
     berisi emoji stiker tsb, ditandai `stickerAnimated:true` supaya frontend tahu harus
     menampilkan kartu placeholder, bukan mencoba me-load gambar yang tidak ada.
   ========================================================================================= */

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(200).json({ ok: true });

  const expectedSecret = process.env.WEBHOOK_SECRET || 'zynx-webhook';
  const secretHeader = req.headers['x-telegram-bot-api-secret-token'];
  if (secretHeader !== expectedSecret) return res.status(401).json({ ok: false });

  const firestore = db();
  const settingsSnap = await firestore.collection('settings').doc('telegram').get();
  if (!settingsSnap.exists) return res.status(200).json({ ok: true }); // belum ada bot ter-setup, abaikan
  const { token } = settingsSnap.data();

  const update = req.body;
  const msg = update && update.message;
  if (!msg || !msg.chat || msg.chat.type !== 'private') return res.status(200).json({ ok: true });

  const chatId = String(msg.chat.id);
  const now = Date.now();

  try {
    const built = await buildMessageFromTelegram(token, msg, bucket(), chatId);

    // upsert kontak
    const contactRef = firestore.collection('contacts').doc(chatId);
    const contactSnap = await contactRef.get();
    const existing = contactSnap.exists ? contactSnap.data() : null;
    await contactRef.set({
      chatId,
      firstName: msg.chat.first_name || (existing && existing.firstName) || '',
      lastName: msg.chat.last_name || (existing && existing.lastName) || '',
      username: msg.chat.username || (existing && existing.username) || '',
      firstSeen: existing ? existing.firstSeen : now,
      lastSeen: now,
      lastMessageText: built.previewText,
      lastMessageTime: now,
      messageCount: (existing ? existing.messageCount || 0 : 0) + 1,
      excluded: existing ? !!existing.excluded : false,
    }, { merge: true });

    // simpan pesan ke subcollection
    await firestore.collection('chats').doc(chatId).collection('messages').add(built.message);

    // cursor global untuk polling ringan di frontend
    await firestore.collection('system').doc('cursor').set({ value: now }, { merge: true });
  } catch (err) {
    // Jangan lempar 500 ke Telegram supaya tidak retry berulang-ulang untuk error yang sama;
    // cukup catat di log function (bisa dilihat di Vercel dashboard -> Logs) untuk debugging.
    console.error('[webhook] gagal memproses pesan:', err);
  }

  return res.status(200).json({ ok: true });
}

async function buildMessageFromTelegram(token, msg, storageBucket, chatId) {
  const base = {
    tgMessageId: msg.message_id,
    from: 'user',
    time: msg.date ? msg.date * 1000 : Date.now(),
    status: 'received',
    replyPreview: msg.reply_to_message ? {
      from: msg.reply_to_message.from && msg.reply_to_message.from.is_bot ? 'Bot' : 'Kontak',
      text: (msg.reply_to_message.text || msg.reply_to_message.caption || '').slice(0, 80),
    } : null,
  };

  if (msg.photo && msg.photo.length) {
    const largest = msg.photo[msg.photo.length - 1];
    const { buffer, filePath } = await tgDownloadFile(token, largest.file_id);
    const url = await uploadToStorage(storageBucket, buffer, `telegram-media/${chatId}/${msg.message_id}.jpg`, 'image/jpeg');
    return {
      previewText: '📷 [Foto]' + (msg.caption ? ' ' + msg.caption : ''),
      message: { ...base, type: 'photo', text: msg.caption || '', mediaUrl: url },
    };
  }

  if (msg.sticker) {
    const st = msg.sticker;
    if (st.is_animated) {
      // format .tgs (Lottie gzip) -- tidak dirender, simpan placeholder emoji saja
      return {
        previewText: (st.emoji || '🧩') + ' [Stiker animasi]',
        message: { ...base, type: 'sticker', text: '', stickerEmoji: st.emoji || '🧩', stickerAnimated: true, mediaUrl: null },
      };
    }
    const { buffer, filePath } = await tgDownloadFile(token, st.file_id);
    const ext = st.is_video ? 'webm' : 'webp';
    const mime = guessMimeFromPath(`x.${ext}`);
    const url = await uploadToStorage(storageBucket, buffer, `telegram-media/${chatId}/${msg.message_id}.${ext}`, mime);
    return {
      previewText: (st.emoji || '🧩') + ' [Stiker]',
      message: { ...base, type: 'sticker', text: '', stickerEmoji: st.emoji || '🧩', stickerAnimated: false, stickerVideo: !!st.is_video, mediaUrl: url },
    };
  }

  const text = msg.text || msg.caption || nonTextPlaceholder(msg);
  return {
    previewText: text,
    message: { ...base, type: 'text', text, mediaUrl: null },
  };
}

async function uploadToStorage(storageBucket, buffer, path, contentType) {
  const file = storageBucket.file(path);
  await file.save(buffer, { metadata: { contentType }, public: true, validation: false });
  return `https://storage.googleapis.com/${storageBucket.name}/${path}`;
}
