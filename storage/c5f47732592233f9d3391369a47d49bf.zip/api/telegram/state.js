import { db } from '../../lib/firebaseAdmin.js';
import { requireSession } from '../../lib/session.js';

/* =========================================================================================
   api/telegram/state.js  (GET, WAJIB login)
   Dipoll frontend tiap beberapa detik. Ini polling ke Firestore MILIK KITA SENDIRI (bukan
   long-polling ke Telegram yang lambat/boros), jadi murah dan responsif. Kontak hanya
   dikirim ulang kalau ada perubahan global (dibanding lewat `cursor`); pesan chat aktif
   hanya yang BARU (query where time > sinceTime, bukan seluruh histori tiap polling).
   ========================================================================================= */

export default requireSession(async (req, res) => {
  const firestore = db();

  const cursorParam = req.query.cursor ? Number(req.query.cursor) : -1;
  const activeChatId = req.query.activeChatId || null;
  const sinceTime = req.query.sinceTime ? Number(req.query.sinceTime) : 0;

  const cursorSnap = await firestore.collection('system').doc('cursor').get();
  const cursor = cursorSnap.exists ? cursorSnap.data().value || 0 : 0;

  let contacts = null;
  if (cursor !== cursorParam) {
    const contactsSnap = await firestore.collection('contacts').orderBy('lastMessageTime', 'desc').limit(500).get();
    contacts = contactsSnap.docs.map(d => d.data());
  }

  let newMessages = [];
  if (activeChatId) {
    const msgsRef = firestore.collection('chats').doc(activeChatId).collection('messages');
    if (sinceTime > 0) {
      // Polling lanjutan: ambil HANYA pesan yang benar-benar baru sejak terakhir kali frontend tahu.
      const msgsSnap = await msgsRef.where('time', '>', sinceTime).orderBy('time', 'asc').limit(200).get();
      newMessages = msgsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    } else {
      // Pembukaan chat pertama kali: ambil N pesan TERBARU (bukan tertua), lalu balik urutan
      // supaya tampil kronologis lama->baru seperti biasa.
      const msgsSnap = await msgsRef.orderBy('time', 'desc').limit(200).get();
      newMessages = msgsSnap.docs.map(d => ({ id: d.id, ...d.data() })).reverse();
    }
  }

  return res.status(200).json({ ok: true, cursor, contacts, newMessages });
});
