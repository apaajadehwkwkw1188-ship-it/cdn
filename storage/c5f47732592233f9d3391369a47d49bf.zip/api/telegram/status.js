import { db } from '../../lib/firebaseAdmin.js';
import { requireSession } from '../../lib/session.js';

export default requireSession(async (req, res) => {
  const snap = await db().collection('settings').doc('telegram').get();
  if (!snap.exists) return res.status(200).json({ ok: true, connected: false });

  const s = snap.data();
  return res.status(200).json({
    ok: true,
    connected: true,
    botUsername: s.botUsername,
    botFirstName: s.botFirstName,
    connectedAt: s.connectedAt,
    tokenMasked: maskToken(s.token),
  });
});

function maskToken(t) {
  if (!t) return '';
  const parts = t.split(':');
  if (parts.length < 2) return t.slice(0, 4) + '••••••••';
  return parts[0] + ':' + parts[1].slice(0, 4) + '••••••••••••••••';
}
