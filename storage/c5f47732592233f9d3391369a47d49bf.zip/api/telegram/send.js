import { db } from '../../lib/firebaseAdmin.js';
import { tgCall } from '../../lib/telegram.js';
import { requireSession } from '../../lib/session.js';

/* =========================================================================================
   api/telegram/send.js  (POST, WAJIB login)
   Dipakai untuk balas chat satu-per-satu MAUPUN dipanggil berulang oleh frontend saat proses
   broadcast (satu request per target). Loop broadcast sengaja TIDAK dilakukan di satu function
   call server-side -- Vercel membatasi durasi maksimum tiap eksekusi, jadi broadcast ke
   ratusan kontak sekaligus bisa timeout kalau dipaksa jadi satu request panjang. Dengan
   pendekatan "satu pesan = satu request" dari browser, batas durasi itu tidak relevan sama sekali.
   ========================================================================================= */

export default requireSession(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const { chatId, text, replyToTgMessageId } = req.body || {};
  if (!chatId || !text) return res.status(400).json({ ok: false, error: 'BAD_REQUEST' });

  const firestore = db();
  const settingsSnap = await firestore.collection('settings').doc('telegram').get();
  if (!settingsSnap.exists) return res.status(400).json({ ok: false, error: 'BOT_NOT_CONNECTED' });
  const { token } = settingsSnap.data();

  let result;
  try {
    const params = { chat_id: Number(chatId), text, parse_mode: 'Markdown' };
    if (replyToTgMessageId) params.reply_to_message_id = replyToTgMessageId;
    try {
      result = await tgCall(token, 'sendMessage', params);
    } catch (e) {
      delete params.parse_mode;
      result = await tgCall(token, 'sendMessage', params);
    }
  } catch (err) {
    return res.status(200).json({ ok: false, error: 'SEND_FAILED', message: err.message });
  }

  const now = Date.now();
  const message = {
    tgMessageId: result.message_id, from: 'bot', type: 'text', text,
    time: now, status: 'sent', mediaUrl: null, replyPreview: null,
  };
  const msgRef = await firestore.collection('chats').doc(String(chatId)).collection('messages').add(message);

  await firestore.collection('contacts').doc(String(chatId)).set(
    { lastMessageText: text, lastMessageTime: now }, { merge: true }
  );
  await firestore.collection('system').doc('cursor').set({ value: now }, { merge: true });

  return res.status(200).json({ ok: true, message: { id: msgRef.id, ...message } });
});
