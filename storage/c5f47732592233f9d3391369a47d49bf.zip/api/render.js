import { db } from '../lib/firebaseAdmin.js';
import { getTodayPuzzle } from '../lib/puzzle.js';
import { signSession, setSessionCookie } from '../lib/session.js';

/* =========================================================================================
   api/render.js  (GET, publik -- ini adalah "index.html"-nya, tapi diberi nama .js karena
   harus dieksekusi sebagai function, bukan disajikan sebagai file statis. Alasannya: file
   statis SELALU menang atas rewrite rule di Vercel (dikonfirmasi lewat riset sebelum build
   ini dimulai) -- jadi kalau index.html taruh sebagai file biasa, clue #1 dan #2 yang harus
   berubah tiap hari tidak akan pernah bisa di-inject secara dinamis ke dalamnya.

   Menangani DUA route lewat vercel.json rewrites:
     GET /          -> tampilkan shell (login kalau belum ada sesi, dashboard kalau sudah)
     GET /:slug     -> kalau slug cocok dengan loginSlug akun manapun, AUTO-LOGIN (set cookie
                       sesi) sebelum halaman dikirim, lalu tampilkan dashboard langsung.
                       Kalau slug tidak cocok apapun, diam-diam jatuh ke perilaku normal
                       (tidak membocorkan slug mana yang valid lewat pesan error).
   ========================================================================================= */

export default async function handler(req, res) {
  const slug = req.query.slug || null;

  if (slug) {
    try {
      const snap = await db().collection('accounts').where('loginSlug', '==', slug).limit(1).get();
      if (!snap.empty) {
        const doc = snap.docs[0];
        const account = doc.data();
        if (account.active) {
          const token = signSession({ accountId: doc.id, tokenVersion: account.tokenVersion || 0, puzzleUnlocked: false });
          setSessionCookie(res, token);
        }
      }
    } catch (e) {
      // Firestore belum ter-setup dsb -- biarkan halaman tetap tampil sebagai login biasa.
      console.error('[render] auto-login slug error:', e.message);
    }
  }

  let clue1 = '?', clue2 = '?';
  try {
    const puzzle = await getTodayPuzzle();
    clue1 = puzzle.c1;
    clue2 = puzzle.c2;
  } catch (e) {
    console.error('[render] gagal ambil puzzle:', e.message);
  }

  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.status(200).send(renderPage(clue1, clue2));
}

function renderPage(clue1, clue2) {
  return PAGE_TEMPLATE
    .replace('__CLUE1__', clue1)
    .replace('__CLUE2__', clue2);
}

const PAGE_TEMPLATE = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ZYNX CONTROL</title>
<style>
  :root {
    --bg: #0e1621; --bg-2: #17212b; --bg-3: #1e2a35; --bg-hover: #202b36; --border: #263340;
    --text: #e4e8ec; --text-dim: #7d8b99; --accent: #2AABEE; --accent-2: #229ED9;
    --accent-grad: linear-gradient(135deg, #2AABEE, #229ED9);
    --bubble-out: linear-gradient(135deg, #2b5278, #1d3f5c); --bubble-in: #202b36;
    --danger: #e35c5c; --success: #4fbf7f; --warn: #e8b23c;
    --radius: 14px; --shadow: 0 8px 30px rgba(0,0,0,0.35);
  }
  * { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
  html, body { height:100%; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; background: var(--bg); color: var(--text); overflow:hidden; }
  ::-webkit-scrollbar { width:8px; height:8px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius:8px; }
  button { font-family: inherit; cursor: pointer; border: none; }
  input, textarea { font-family: inherit; }
  .hidden { display:none !important; }

  /* ===== LOGIN / BOOTSTRAP SCREEN ===== */
  #login-screen { position:fixed; inset:0; display:flex; align-items:center; justify-content:center; background: radial-gradient(circle at 30% 20%, #17324a 0%, #0e1621 55%); z-index:100; }
  .login-card { width:420px; max-width:92vw; background: var(--bg-2); border:1px solid var(--border); border-radius:20px; padding:34px 30px; box-shadow: var(--shadow); animation: slideUp .4s cubic-bezier(.2,.8,.2,1); }
  .login-logo { width:60px; height:60px; border-radius:50%; background: var(--accent-grad); display:flex; align-items:center; justify-content:center; margin:0 auto 16px; font-size:28px; box-shadow:0 6px 20px rgba(42,171,238,0.4); }
  .login-title { text-align:center; font-size:20px; font-weight:800; letter-spacing:1px; margin-bottom:4px; }
  .login-sub { text-align:center; color:var(--text-dim); font-size:12.5px; margin-bottom:22px; }
  .field-label { font-size:11.5px; color:var(--text-dim); margin-bottom:5px; display:block; font-weight:600; }
  .field-group { margin-bottom:14px; }
  .text-input {
    width:100%; padding:11px 13px; border-radius:9px; border:1.5px solid var(--border); background: var(--bg-3);
    color:var(--text); font-size:13.5px; outline:none; transition: border-color .2s, box-shadow .2s;
  }
  .text-input:focus { border-color: var(--accent); box-shadow:0 0 0 3px rgba(42,171,238,0.15); }
  .text-input.shake { animation: shake .4s; border-color: var(--danger); }
  .captcha-row { display:flex; gap:8px; align-items:center; margin-bottom:14px; }
  .captcha-img-wrap { border-radius:8px; overflow:hidden; border:1px solid var(--border); flex-shrink:0; }
  .captcha-refresh { width:38px; height:38px; border-radius:8px; background:var(--bg-3); border:1px solid var(--border); color:var(--text-dim); font-size:15px; flex-shrink:0; }
  .captcha-refresh:hover { color:var(--text); }
  .primary-btn {
    width:100%; padding:12px; border-radius:9px; background:var(--accent-grad); color:#fff; font-weight:700;
    font-size:14px; display:flex; align-items:center; justify-content:center; gap:8px; transition: all .15s;
  }
  .primary-btn:hover { transform:translateY(-1px); box-shadow:0 6px 16px rgba(42,171,238,0.3); }
  .primary-btn:disabled { opacity:.55; transform:none; box-shadow:none; }
  .login-error { color:var(--danger); font-size:12px; margin-top:10px; text-align:center; min-height:16px; }
  .login-toggle { text-align:center; margin-top:16px; font-size:12px; color:var(--text-dim); }
  .login-toggle a { color:var(--accent); cursor:pointer; text-decoration:none; }
  .spinner { width:15px; height:15px; border-radius:50%; border:2px solid rgba(255,255,255,0.35); border-top-color:#fff; animation: spin .7s linear infinite; display:inline-block; }

  /* ===== APP SHELL ===== */
  #app-shell { display:none; height:100vh; flex-direction:column; }
  #app-shell.active { display:flex; animation: fadeIn .3s ease; }
  #topbar { height:58px; flex-shrink:0; display:flex; align-items:center; gap:12px; padding:0 18px; background:var(--bg-2); border-bottom:1px solid var(--border); }
  .brand { font-weight:800; font-size:14.5px; letter-spacing:.5px; display:flex; align-items:center; gap:8px; }
  .brand .brand-dot { width:9px; height:9px; border-radius:50%; background:var(--accent); box-shadow:0 0 8px var(--accent); }
  .topbar-spacer { flex:1; }
  .role-badge { font-size:10.5px; font-weight:700; padding:3px 9px; border-radius:7px; background:rgba(42,171,238,0.15); color:var(--accent); text-transform:uppercase; letter-spacing:.4px; }
  .topbar-user { font-size:12.5px; color:var(--text-dim); }
  #logout-btn { background:transparent; border:1px solid var(--border); color:var(--text-dim); padding:7px 13px; border-radius:8px; font-size:12px; transition:all .15s; }
  #logout-btn:hover { border-color:var(--danger); color:var(--danger); }

  #main { flex:1; display:flex; overflow:hidden; }
  #tabs-sidebar { width:76px; flex-shrink:0; background:var(--bg-2); border-right:1px solid var(--border); display:flex; flex-direction:column; align-items:center; padding-top:12px; gap:4px; }
  .tab-btn { width:58px; padding:9px 4px; border-radius:12px; background:transparent; color:var(--text-dim); display:flex; flex-direction:column; align-items:center; gap:3px; font-size:9.5px; font-weight:600; transition:all .15s; position:relative; }
  .tab-btn .tab-icon { font-size:18px; }
  .tab-btn:hover { background:var(--bg-hover); color:var(--text); }
  .tab-btn.active { background:rgba(42,171,238,0.15); color:var(--accent); }
  .tab-badge { position:absolute; top:3px; right:8px; background:var(--danger); color:#fff; font-size:9px; min-width:14px; height:14px; border-radius:8px; display:flex; align-items:center; justify-content:center; padding:0 3px; }

  #tab-content { flex:1; overflow:hidden; position:relative; }
  .tab-panel { position:absolute; inset:0; display:none; }
  .tab-panel.active { display:flex; animation: fadeIn .2s ease; }

  /* Chat list */
  .chat-list-pane { width:310px; flex-shrink:0; background:var(--bg-2); border-right:1px solid var(--border); display:flex; flex-direction:column; }
  .pane-header { padding:14px 14px 8px; }
  .pane-title { font-size:15px; font-weight:700; margin-bottom:9px; }
  .search-box { display:flex; align-items:center; gap:7px; background:var(--bg-3); border:1px solid var(--border); border-radius:9px; padding:8px 11px; }
  .search-box input { flex:1; background:transparent; border:none; outline:none; color:var(--text); font-size:12.5px; }
  #chat-list { flex:1; overflow-y:auto; padding:4px 7px 12px; }
  .chat-list-item { display:flex; gap:9px; padding:9px 7px; border-radius:11px; cursor:pointer; transition: background .15s; }
  .chat-list-item:hover { background:var(--bg-hover); }
  .chat-list-item.selected { background:rgba(42,171,238,0.14); }
  .avatar { width:42px; height:42px; border-radius:50%; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-weight:700; color:#fff; font-size:15px; }
  .chat-list-body { flex:1; min-width:0; }
  .chat-list-top { display:flex; justify-content:space-between; align-items:baseline; gap:6px; }
  .chat-list-name { font-weight:600; font-size:13px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .chat-list-time { font-size:10px; color:var(--text-dim); flex-shrink:0; }
  .chat-list-snippet { font-size:11.5px; color:var(--text-dim); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:2px; }
  .unread-badge { background:var(--accent); color:#fff; font-size:10px; font-weight:700; min-width:18px; height:18px; border-radius:10px; display:flex; align-items:center; justify-content:center; padding:0 5px; flex-shrink:0; }
  .empty-state { flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center; color:var(--text-dim); gap:9px; padding:36px; text-align:center; }
  .empty-state .big-icon { font-size:44px; opacity:.5; }
  .empty-state p { font-size:12.5px; max-width:270px; line-height:1.6; }

  .chat-view-pane { flex:1; display:flex; flex-direction:column; background:var(--bg); min-width:0; }
  .chat-view-header { height:60px; flex-shrink:0; display:flex; align-items:center; gap:11px; padding:0 16px; background:var(--bg-2); border-bottom:1px solid var(--border); }
  .chat-view-meta { flex:1; line-height:1.3; min-width:0; }
  .chat-view-name { font-weight:700; font-size:14px; }
  .chat-view-sub { font-size:11px; color:var(--text-dim); }
  .icon-btn { width:33px; height:33px; border-radius:9px; background:transparent; color:var(--text-dim); display:flex; align-items:center; justify-content:center; font-size:15px; transition:all .15s; }
  .icon-btn:hover { background:var(--bg-hover); color:var(--text); }

  #messages-scroll { flex:1; overflow-y:auto; padding:16px 20px; display:flex; flex-direction:column; gap:2px; }
  .day-separator { text-align:center; margin:14px 0; }
  .day-separator span { background:var(--bg-2); color:var(--text-dim); font-size:10.5px; padding:4px 11px; border-radius:10px; border:1px solid var(--border); }
  .msg-row { display:flex; margin:3px 0; animation: msgIn .25s ease; }
  .msg-row.out { justify-content:flex-end; }
  .msg-bubble { max-width:62%; padding:8px 12px; border-radius:15px; font-size:13px; line-height:1.5; word-wrap:break-word; white-space:pre-wrap; }
  .msg-row.in .msg-bubble { background:var(--bubble-in); border-bottom-left-radius:4px; }
  .msg-row.out .msg-bubble { background:var(--bubble-out); border-bottom-right-radius:4px; }
  .msg-bubble.media-bubble { padding:5px; }
  .msg-bubble img.msg-image, .msg-bubble video.msg-sticker-video { max-width:220px; max-height:260px; border-radius:11px; display:block; }
  .msg-bubble .msg-caption { padding:6px 5px 2px; font-size:12.5px; }
  .sticker-bubble { background:transparent !important; padding:0 !important; }
  .sticker-bubble img.msg-sticker-img { width:120px; height:120px; object-fit:contain; }
  .sticker-placeholder { width:120px; height:120px; border-radius:16px; background:var(--bg-3); border:1px solid var(--border); display:flex; flex-direction:column; align-items:center; justify-content:center; gap:4px; }
  .sticker-placeholder .emoji { font-size:38px; }
  .sticker-placeholder .label { font-size:9.5px; color:var(--text-dim); }
  .msg-reply-preview { border-left:2.5px solid var(--accent); padding:3px 8px; margin-bottom:5px; opacity:.8; font-size:11.5px; border-radius:4px; background:rgba(255,255,255,0.04); }
  .msg-reply-preview b { display:block; font-size:10.5px; color:var(--accent); }
  .msg-meta { display:flex; align-items:center; gap:4px; justify-content:flex-end; margin-top:3px; opacity:.65; font-size:10px; }
  .msg-status.failed { color:var(--danger); cursor:pointer; }
  .msg-row:hover .msg-hover-actions { opacity:1; }
  .msg-hover-actions { opacity:0; transition:opacity .15s; display:flex; gap:2px; align-items:center; margin:0 6px; }
  .msg-hover-actions button { background:var(--bg-2); border:1px solid var(--border); width:25px; height:25px; border-radius:8px; color:var(--text-dim); font-size:11px; display:flex; align-items:center; justify-content:center; }
  .msg-hover-actions button:hover { color:var(--text); background:var(--bg-hover); }

  #reply-bar { display:none; align-items:center; gap:10px; padding:7px 16px; background:var(--bg-2); border-top:1px solid var(--border); font-size:12px; }
  #reply-bar.show { display:flex; }
  #reply-bar .bar-icon { color:var(--accent); }
  #reply-bar .bar-text { flex:1; color:var(--text-dim); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  #reply-bar .bar-text b { color:var(--text); }

  #image-preview-bar { display:none; align-items:center; gap:10px; padding:8px 16px; background:var(--bg-2); border-top:1px solid var(--border); }
  #image-preview-bar.show { display:flex; }
  #image-preview-bar img { width:46px; height:46px; object-fit:cover; border-radius:8px; }
  #image-preview-bar .ip-text { flex:1; font-size:11.5px; color:var(--text-dim); }

  #format-toolbar { display:none; gap:4px; padding:6px 16px 0; }
  #format-toolbar.show { display:flex; }
  #format-toolbar button { background:var(--bg-3); border:1px solid var(--border); color:var(--text-dim); width:27px; height:25px; border-radius:7px; font-size:11.5px; font-weight:700; }

  .composer { display:flex; align-items:flex-end; gap:7px; padding:11px 16px; background:var(--bg-2); border-top:1px solid var(--border); position:relative; }
  .composer textarea { flex:1; resize:none; background:var(--bg-3); border:1px solid var(--border); border-radius:14px; padding:10px 13px; color:var(--text); font-size:13px; outline:none; max-height:110px; line-height:1.4; }
  .composer textarea:focus { border-color: var(--accent); }
  .composer .icon-btn { flex-shrink:0; margin-bottom:1px; }
  #send-btn { width:38px; height:38px; border-radius:50%; background:var(--accent-grad); color:#fff; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-size:15px; transition: transform .12s; }
  #send-btn:disabled { opacity:.5; }
  #image-file-input { display:none; }

  .emoji-picker { display:none; position:absolute; bottom:60px; right:16px; width:310px; height:300px; background:var(--bg-2); border:1px solid var(--border); border-radius:14px; box-shadow:var(--shadow); flex-direction:column; overflow:hidden; z-index:50; animation: popUp .18s ease; }
  .emoji-picker.show { display:flex; }
  .emoji-cats { display:flex; border-bottom:1px solid var(--border); flex-shrink:0; }
  .emoji-cats button { flex:1; padding:7px 0; background:transparent; color:var(--text-dim); font-size:14px; }
  .emoji-cats button.active { color:var(--accent); border-bottom:2px solid var(--accent); }
  .emoji-grid { flex:1; overflow-y:auto; display:grid; grid-template-columns:repeat(7,1fr); gap:2px; padding:7px; align-content:flex-start; }
  .emoji-grid button { background:transparent; font-size:18px; border-radius:8px; padding:4px 0; }
  .emoji-grid button:hover { background:var(--bg-hover); }

  /* Broadcast */
  .broadcast-pane { flex:1; overflow-y:auto; padding:24px 28px; display:flex; justify-content:center; }
  .broadcast-inner { width:100%; max-width:620px; display:flex; flex-direction:column; gap:16px; }
  .card { background:var(--bg-2); border:1px solid var(--border); border-radius:var(--radius); padding:19px; }
  .card-title { font-size:14.5px; font-weight:700; margin-bottom:4px; display:flex; align-items:center; gap:7px; }
  .card-sub { font-size:11.5px; color:var(--text-dim); margin-bottom:13px; }
  #broadcast-textarea { width:100%; min-height:110px; background:var(--bg-3); border:1px solid var(--border); border-radius:12px; padding:12px; color:var(--text); font-size:13px; outline:none; resize:vertical; line-height:1.5; }
  .broadcast-toolrow { display:flex; align-items:center; gap:8px; margin-top:9px; }
  .broadcast-toolrow .spacer { flex:1; }
  .checkbox-row { display:flex; align-items:center; gap:8px; font-size:12px; color:var(--text-dim); margin-top:11px; }
  .checkbox-row input { accent-color: var(--accent); width:14px; height:14px; }
  .target-count { font-size:12px; color:var(--text-dim); }
  .target-count b { color: var(--accent); }
  .btn-primary { padding:10px 18px; border-radius:10px; background:var(--accent-grad); color:#fff; font-weight:700; font-size:12.5px; display:flex; align-items:center; gap:7px; transition: all .15s; }
  .btn-primary:disabled { opacity:.5; }
  .btn-secondary { padding:10px 16px; border-radius:10px; background:var(--bg-3); border:1px solid var(--border); color:var(--text); font-weight:600; font-size:12.5px; transition: all .15s; }
  .btn-secondary:hover { background:var(--bg-hover); }
  #broadcast-progress-wrap { display:none; margin-top:13px; }
  #broadcast-progress-wrap.show { display:block; }
  .progress-bar-bg { height:7px; background:var(--bg-3); border-radius:6px; overflow:hidden; }
  .progress-bar-fill { height:100%; background:var(--accent-grad); width:0%; transition: width .2s; }
  .progress-label { font-size:11px; color:var(--text-dim); margin-top:6px; display:flex; justify-content:space-between; }
  .broadcast-history-item { display:flex; gap:11px; padding:11px 0; border-bottom:1px solid var(--border); font-size:12px; }
  .broadcast-history-item:last-child { border-bottom:none; }
  .bh-icon { width:30px; height:30px; border-radius:9px; background:var(--bg-3); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
  .bh-body { flex:1; min-width:0; }
  .bh-text { color:var(--text); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .bh-stats { color:var(--text-dim); font-size:10.5px; margin-top:2px; }
  .bh-time { color:var(--text-dim); font-size:10.5px; flex-shrink:0; }

  /* Kontak tab */
  .contacts-pane { flex:1; overflow-y:auto; padding:20px 24px; }
  .contacts-toolrow { display:flex; align-items:center; gap:12px; margin-bottom:14px; }
  .contacts-toolrow .search-box { width:270px; }
  table.data-table { width:100%; border-collapse:collapse; font-size:12.5px; }
  table.data-table th { text-align:left; color:var(--text-dim); font-size:10.5px; font-weight:600; padding:8px 11px; border-bottom:1px solid var(--border); text-transform:uppercase; letter-spacing:.4px; }
  table.data-table td { padding:9px 11px; border-bottom:1px solid var(--border); vertical-align:middle; }
  table.data-table tr:hover td { background:var(--bg-hover); }
  .name-cell { display:flex; align-items:center; gap:9px; }
  .mini-avatar { width:28px; height:28px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:11px; font-weight:700; color:#fff; flex-shrink:0; }
  .row-btn { padding:5px 9px; border-radius:7px; background:var(--bg-3); border:1px solid var(--border); color:var(--text-dim); font-size:11px; }
  .row-btn:hover { color:var(--text); }
  .excluded-tag { font-size:9.5px; color:var(--warn); border:1px solid var(--warn); padding:1px 5px; border-radius:6px; margin-left:5px; }

  /* Setelan tab */
  .settings-pane { flex:1; overflow-y:auto; padding:24px 28px; display:flex; justify-content:center; }
  .settings-inner { width:100%; max-width:540px; display:flex; flex-direction:column; gap:15px; }
  .setting-row { display:flex; align-items:center; justify-content:space-between; padding:13px 0; border-bottom:1px solid var(--border); }
  .setting-row:last-child { border-bottom:none; }
  .setting-row-label { font-size:13px; font-weight:600; }
  .setting-row-desc { font-size:11px; color:var(--text-dim); margin-top:2px; }
  .switch { width:40px; height:23px; border-radius:14px; background:var(--bg-3); border:1px solid var(--border); position:relative; transition: background .2s; flex-shrink:0; }
  .switch.on { background: var(--accent); border-color: var(--accent); }
  .switch::after { content:''; position:absolute; width:17px; height:17px; border-radius:50%; background:#fff; top:2px; left:2px; transition: left .2s; }
  .switch.on::after { left:19px; }
  .token-display { display:flex; align-items:center; gap:8px; font-family:monospace; font-size:12px; background:var(--bg-3); padding:9px 11px; border-radius:9px; border:1px solid var(--border); }
  .admin-link-box { display:flex; align-items:center; justify-content:space-between; gap:10px; background:var(--bg-3); border:1px solid var(--border); border-radius:10px; padding:12px 14px; margin-top:8px; }

  /* Toast + Modal */
  #toast-wrap { position:fixed; top:16px; left:50%; transform:translateX(-50%); z-index:300; display:flex; flex-direction:column; gap:7px; align-items:center; }
  .toast { background:var(--bg-2); border:1px solid var(--border); color:var(--text); padding:9px 16px; border-radius:10px; font-size:12px; box-shadow:var(--shadow); display:flex; align-items:center; gap:8px; }
  .toast.success { border-color: rgba(79,191,127,0.4); }
  .toast.error { border-color: rgba(227,92,92,0.4); }

  #modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.55); display:none; align-items:center; justify-content:center; z-index:200; }
  #modal-overlay.show { display:flex; }
  .modal-box { width:370px; max-width:90vw; background:var(--bg-2); border:1px solid var(--border); border-radius:16px; padding:20px; box-shadow:var(--shadow); }
  .modal-title { font-size:15px; font-weight:700; margin-bottom:7px; }
  .modal-body { font-size:12.5px; color:var(--text-dim); line-height:1.6; margin-bottom:16px; }
  .modal-actions { display:flex; gap:9px; justify-content:flex-end; }

  @keyframes fadeIn { from{opacity:0} to{opacity:1} }
  @keyframes slideUp { from{opacity:0; transform:translateY(14px)} to{opacity:1; transform:translateY(0)} }
  @keyframes shake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-6px)} 75%{transform:translateX(6px)} }
  @keyframes spin { to{transform:rotate(360deg)} }
  @keyframes msgIn { from{opacity:0; transform:translateY(5px)} to{opacity:1; transform:translateY(0)} }
  @keyframes popUp { from{opacity:0; transform:translateY(8px) scale(.97)} to{opacity:1; transform:translateY(0) scale(1)} }

  @media (max-width: 860px) {
    .chat-list-pane { width:100%; position:absolute; inset:0; z-index:5; }
    .chat-list-pane.hidden-mobile { display:none; }
    .chat-view-pane.hidden-mobile { display:none; }
    #tabs-sidebar { width:60px; }
    .tab-btn { width:46px; }
  }
</style>
</head>
<body>

<!-- ============================== LOGIN / BOOTSTRAP SCREEN ============================== -->
<div id="login-screen">
  <div class="login-card">
    <div class="login-logo">🔐<!-- #// __CLUE2__ (2) --></div>
    <div class="login-title" id="login-title">ZYNX CONTROL</div>
    <div class="login-sub" id="login-sub">Masuk dengan kredensial yang diberikan owner.</div>

    <div id="login-form">
      <div class="field-group"><label class="field-label">Username</label><input type="text" id="login-username" class="text-input" autocomplete="username"></div>
      <div class="field-group"><label class="field-label">Password</label><input type="password" id="login-password" class="text-input" autocomplete="current-password"></div>
      <button id="login-submit-btn" class="primary-btn"><span id="login-submit-label">Masuk</span></button>
    </div>

    <div id="bootstrap-form" class="hidden">
      <div class="field-group"><label class="field-label">Username Owner</label><input type="text" id="bs-username" class="text-input" autocomplete="off"></div>
      <div class="field-group"><label class="field-label">Password Owner</label><input type="password" id="bs-password" class="text-input" autocomplete="new-password"></div>
      <div class="field-group">
        <label class="field-label">Captcha</label>
        <div class="captcha-row">
          <div class="captcha-img-wrap" id="bs-captcha-img"></div>
          <button class="captcha-refresh" id="bs-captcha-refresh" title="Ganti captcha">↻</button>
          <input type="text" id="bs-captcha-answer" class="text-input" placeholder="Ketik kode" style="flex:1;">
        </div>
      </div>
      <button id="bootstrap-submit-btn" class="primary-btn"><span id="bootstrap-submit-label">Buat Akun Owner</span></button>
    </div>

    <div class="login-error" id="login-error"></div>
  </div>
</div>

<!-- ============================== APP SHELL (DASHBOARD) ============================== -->
<div id="app-shell">
  <div id="topbar">
    <div class="brand"><span class="brand-dot"></span>ZYNX CONTROL</div>
    <div class="topbar-spacer"></div>
    <span class="role-badge" id="me-role">-</span>
    <span class="topbar-user" id="me-username">-</span>
    <button id="logout-btn">Keluar</button>
  </div>

  <div id="main">
    <div id="tabs-sidebar">
      <button class="tab-btn active" data-tab="chat"><span class="tab-icon">💬</span>Chat<span class="tab-badge hidden" id="chat-tab-badge">0</span></button>
      <button class="tab-btn" data-tab="broadcast"><span class="tab-icon">📢</span>Broadcast</button>
      <button class="tab-btn" data-tab="contacts"><span class="tab-icon">👥</span>Kontak</button>
      <button class="tab-btn" data-tab="settings"><span class="tab-icon">⚙️</span>Setelan</button>
    </div>

    <div id="tab-content">
      <div class="tab-panel active" id="tab-chat" style="display:flex;">
        <div class="chat-list-pane" id="chat-list-pane">
          <div class="pane-header">
            <div class="pane-title">Semua Kontak</div>
            <div class="search-box"><span>🔍</span><input type="text" id="chat-search" placeholder="Cari nama, username, atau ketik keyzynx..."></div>
          </div>
          <div id="chat-list"></div>
        </div>
        <div class="chat-view-pane" id="chat-view-pane">
          <div class="empty-state" id="chat-empty-state">
            <div class="big-icon">💬</div>
            <p>Pilih kontak di sebelah kiri untuk mulai membalas. Semua orang yang pernah chat bot akan selalu muncul di daftar, walau belum pernah kamu balas.</p>
          </div>
          <div id="chat-view-content" style="display:none; flex-direction:column; height:100%;">
            <div class="chat-view-header">
              <div class="avatar" id="cv-avatar">?</div>
              <div class="chat-view-meta"><div class="chat-view-name" id="cv-name">—</div><div class="chat-view-sub" id="cv-sub">—</div></div>
              <button class="icon-btn" id="cv-format-toggle" title="Format teks">Aa</button>
              <button class="icon-btn" id="cv-clear-btn" title="Hapus riwayat">🗑</button>
            </div>
            <div id="messages-scroll"></div>
            <div id="format-toolbar">
              <button data-wrap="*">B</button><button data-wrap="_" style="font-style:italic;">I</button><button data-wrap="&#96;">{ }</button>
            </div>
            <div id="image-preview-bar">
              <img id="ip-thumb" src="" alt="preview">
              <div class="ip-text">Gambar siap dikirim — tulis keterangan (opsional) lalu kirim.</div>
              <button class="icon-btn" id="ip-cancel-btn" style="width:24px;height:24px;">✕</button>
            </div>
            <div id="reply-bar">
              <span class="bar-icon">↩</span><div class="bar-text" id="reply-bar-text"></div>
              <button class="icon-btn" id="reply-cancel-btn" style="width:24px;height:24px;">✕</button>
            </div>
            <div class="composer">
              <button class="icon-btn" id="image-attach-btn" title="Kirim gambar">🖼</button>
              <input type="file" id="image-file-input" accept="image/*">
              <button class="icon-btn" id="emoji-toggle-btn">🙂</button>
              <textarea id="chat-input" placeholder="Tulis pesan..." rows="1"></textarea>
              <button id="send-btn">➤</button>
              <div class="emoji-picker" id="emoji-picker-chat"></div>
            </div>
          </div>
        </div>
      </div>

      <div class="tab-panel" id="tab-broadcast">
        <div class="broadcast-pane">
          <div class="broadcast-inner">
            <div class="card">
              <div class="card-title">📢 Broadcast Pengumuman</div>
              <div class="card-sub">Dikirim satu per satu ke seluruh kontak yang pernah chat bot ini.</div>
              <textarea id="broadcast-textarea" placeholder="Tulis pesan pengumuman..."></textarea>
              <div id="broadcast-format-toolbar" class="broadcast-toolrow" style="margin-top:7px;">
                <button data-wrap="*" style="width:27px;height:25px;border-radius:7px;background:var(--bg-3);border:1px solid var(--border);color:var(--text-dim);font-weight:700;font-size:11.5px;">B</button>
                <button data-wrap="_" style="width:27px;height:25px;border-radius:7px;background:var(--bg-3);border:1px solid var(--border);color:var(--text-dim);font-style:italic;font-size:11.5px;">I</button>
                <button id="broadcast-emoji-btn" class="icon-btn" style="width:27px;height:25px;">🙂</button>
                <div class="spacer"></div>
                <span class="target-count">Target: <b id="broadcast-target-count">0</b> kontak</span>
              </div>
              <div class="emoji-picker" id="emoji-picker-broadcast" style="bottom:auto; top:100%; right:0; margin-top:6px;"></div>
              <label class="checkbox-row"><input type="checkbox" id="broadcast-exclude-checkbox"> Kecualikan kontak yang ditandai dikecualikan</label>
              <div class="broadcast-toolrow" style="margin-top:15px;">
                <button class="btn-primary" id="broadcast-send-btn">Kirim Sekarang</button>
                <button class="btn-secondary" id="broadcast-preview-btn">Pratinjau</button>
              </div>
              <div id="broadcast-progress-wrap">
                <div class="progress-bar-bg"><div class="progress-bar-fill" id="broadcast-progress-fill"></div></div>
                <div class="progress-label"><span id="broadcast-progress-text">Mengirim 0 / 0</span><span id="broadcast-progress-fail"></span></div>
              </div>
            </div>
            <div class="card">
              <div class="card-title">🕓 Riwayat Broadcast</div>
              <div id="broadcast-history-list"></div>
            </div>
          </div>
        </div>
      </div>

      <div class="tab-panel" id="tab-contacts">
        <div class="contacts-pane">
          <div class="contacts-toolrow">
            <div class="search-box"><span>🔍</span><input type="text" id="contacts-search" placeholder="Cari kontak..."></div>
            <div style="flex:1;"></div>
            <button class="btn-secondary" id="export-csv-btn">⬇ Ekspor CSV</button>
          </div>
          <table class="data-table">
            <thead><tr><th>Kontak</th><th>Chat ID</th><th>Pesan</th><th>Terakhir Aktif</th><th>Aksi</th></tr></thead>
            <tbody id="contacts-table-body"></tbody>
          </table>
        </div>
      </div>

      <div class="tab-panel" id="tab-settings">
        <div class="settings-pane">
          <div class="settings-inner">
            <div class="card">
              <div class="card-title">🤖 Koneksi Bot Telegram</div>
              <div class="card-sub" id="bot-status-text">Memeriksa status koneksi...</div>
              <div class="field-group"><label class="field-label">Token Bot (dari @BotFather)</label><input type="text" id="bot-token-input" class="text-input" placeholder="123456789:AA..."></div>
              <button class="btn-primary" id="bot-connect-btn">Hubungkan Bot</button>
            </div>
            <div class="card">
              <div class="card-title">⚙️ Preferensi</div>
              <div class="setting-row"><div><div class="setting-row-label">Suara notifikasi</div><div class="setting-row-desc">Bunyi saat pesan baru masuk</div></div><div class="switch on" id="switch-sound"></div></div>
              <div class="setting-row"><div><div class="setting-row-label">Status "sedang mengetik"</div><div class="setting-row-desc">Kirim indikator mengetik ke kontak</div></div><div class="switch on" id="switch-typing"></div></div>
            </div>
            <div class="card" id="admin-access-card">
              <div class="card-title">🛡 Akses Admin</div>
              <div class="card-sub">Panel admin (kelola akun & database) hanya untuk role owner, dan tetap butuh key puzzle harian.</div>
              <div class="admin-link-box"><span style="font-size:12.5px;">admin.html</span><a href="/admin.html" class="btn-secondary" style="text-decoration:none;">Buka Admin →</a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="modal-overlay">
  <div class="modal-box">
    <div class="modal-title" id="modal-title">Konfirmasi</div>
    <div class="modal-body" id="modal-body">Apakah Anda yakin?</div>
    <div class="modal-actions">
      <button class="btn-secondary" id="modal-cancel-btn">Batal</button>
      <button class="btn-primary" id="modal-confirm-btn">Ya, Lanjutkan</button>
    </div>
  </div>
</div>

<div id="toast-wrap"></div>

<script src="/app.js"></script>
</body>
</html>
<!-- #// __CLUE1__ (1) -->
`;
