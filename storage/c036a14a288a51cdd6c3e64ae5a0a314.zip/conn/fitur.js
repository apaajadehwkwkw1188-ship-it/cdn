const { generateWAMessageFromContent, proto, downloadContentFromMessage } = require('@whiskeysockets/baileys');
const crypto = require('crypto');
const fetch = require('node-fetch'); 
const fs = require('fs');
const axios = require('axios')
const cheerio = require('cheerio')
const { fromBuffer } = require('file-type')
const yts = require('yt-search');
const { google } = require('googleapis');
const path = require('path');
const { exec, spawn, execSync } = require('child_process');
const FormData = require('form-data')
const { ImageUploadService } = require('node-upload-images')
const https = require('https');

async function getGroupLink(m, depayy) {
    if (!m.isGroup) return m.reply("Fitur ini cuma bisa di grup, Bang!");
    
    try {
        let code = await depayy.groupInviteCode(m.chat);
        let link = "https://chat.whatsapp.com/" + code;
        payreply(`*〔 LINK GROUP 〕*\n\n${link}`);
    } catch (e) {
        m.reply("Gagal mengambil link! Pastikan bot sudah jadi admin grup.", lol, m, depayy, proto);
    }
}


async function getRemoveBg(messageToDownload, mediaKey) {
    try {
        const stream = await downloadContentFromMessage(messageToDownload.message[mediaKey], 'image');
        let buffer = Buffer.alloc(0);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        let name = `removebg_${Date.now()}.jpg`;
        let pixhostUrl = "";
        
        try {
            const uploadRes = await new ImageUploadService('pixhost.to').uploadFromBinary(buffer, name);
            pixhostUrl = uploadRes.directLink.toString();
        } catch (uploadError) {
            console.error("Gagal upload ke Pixhost:", uploadError);
            return { status: false, msg: "eror, coba kirim gambar dengan caption .removebg" };
        }

        if (!pixhostUrl) {
            return { status: false, msg: "eror." };
        }

        const response = await axios.get(`https://api-faa.my.id/faa/removebg?url=${encodeURIComponent(pixhostUrl)}`, {
            timeout: 25000 
        });

        let resData = response.data;
        let uguUrl = "";

        if (typeof resData === 'string') {
            uguUrl = resData.trim();
        } else if (resData && typeof resData === 'object') {
            uguUrl = resData.result || resData.url || resData.data;
        }

        if (!uguUrl || typeof uguUrl !== 'string' || !uguUrl.startsWith('http')) {
            return { status: false, msg: "Gagal mengekstrak URL Ugu hasil removebg dari server API, Bang." };
        }

        return { status: true, url: uguUrl };

    } catch (error) {
        console.error(error);
        return { status: false, msg: "eror,mungkin lagi down atau overload." };
    }
}



async function getArtiNama(qtext) {
    try {
        const response = await axios.get(`https://api-faa.my.id/faa/arti-nama?nama=${encodeURIComponent(qtext)}`);
        const resultText = response.data.result || response.data.arti || response.data;

        if (!resultText || typeof resultText === 'object') {
            return { status: false, msg: "Gagal mendapatkan arti nama yang valid dari server, Bang." };
        }

        return { status: true, data: resultText.trim() };
    } catch (error) {
        console.error(error);
        return { status: false, msg: "Waduh Bang, API arti namanya sepertinya lagi pingsan atau limit." };
    }
}



async function getGeminiResponse(qtext) {
    try {
        const response = await axios.get(`https://api-faa.my.id/faa/bard-google?query=${encodeURIComponent(qtext)}`);
        const resultText = response.data.result || response.data.response || response.data;

        if (!resultText || typeof resultText === 'object') {
            return { status: false, msg: "Gagal mendapatkan jawaban yang valid dari server Gemini, Bang." };
        }

        return { status: true, data: resultText.trim() };
    } catch (error) {
        console.error(error);
        return { status: false, msg: "Waduh Bang, API Gemini-nya sepertinya lagi overload atau pingsan." };
    }
}


function generateTtsUrl(text) {
     return `https://translate.google.com/translate_tts?ie=UTF-8&tl=id&client=tw-ob&q=${encodeURIComponent(text.trim())}`;
}


async function prosesIqcDefault(promptText) {
    const url = `https://api-faa.my.id/faa/iqc?prompt=${encodeURIComponent(promptText.trim())}`;

    const response = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 25000 
    });

    if (!response.data) {
        throw new Error('Gagal mengambil data dari API');
    }

    return Buffer.from(response.data);
}




const agent = new https.Agent({
    rejectUnauthorized: true,
    maxVersion: 'TLSv1.3',
    minVersion: 'TLSv1.2'
});

async function getCookies() {
    try {
        const response = await axios.get('https://www.pinterest.com/csrf_error/', { httpsAgent: agent });
        const setCookieHeaders = response.headers['set-cookie'];
        if (setCookieHeaders) {
            const cookies = setCookieHeaders.map(cookieString => {
                const cookieParts = cookieString.split(';');
                return cookieParts[0].trim();
            });
            return cookies.join('; ');
        }
        return null;
    } catch {
        return null;
    }
}

async function prosesPinterest(query) {
    try {
        const cookies = await getCookies();
        if (!cookies) return [];

        const url = 'https://www.pinterest.com/resource/BaseSearchResource/get/';
        const params = {
            source_url: `/search/pins/?q=${query}`,
            data: JSON.stringify({
                options: {
                    isPrefetch: false,
                    query: query,
                    scope: "pins",
                    no_fetch_context_on_resource: false
                },
                context: {}
            }),
            _: Date.now()
        };

        const headers = {
            'accept': 'application/json, text/javascript, */*, q=0.01',
            'accept-encoding': 'gzip, deflate',
            'accept-language': 'en-US,en;q=0.9',
            'cookie': cookies,
            'dnt': '1',
            'referer': 'https://www.pinterest.com/',
            'sec-ch-ua': '"Not(A:Brand";v="99", "Microsoft Edge";v="133", "Chromium";v="133"',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137000.0 Safari/537.36 Edg/137000.0',
            'x-app-version': 'c056fb7',
            'x-requested-with': 'XMLHttpRequest'
        };

        const { data } = await axios.get(url, { httpsAgent: agent, headers, params });
        return data.resource_response.data.results
            .filter(v => v.images?.orig)
            .map(result => ({
                upload_by: result.pinner.username,
                fullname: result.pinner.full_name,
                followers: result.pinner.follower_count,
                caption: result.grid_title || "Pinterest Image",
                image: result.images.orig.url,
                source: "https://id.pinterest.com/pin/" + result.id,
            }));
    } catch {
        return [];
    }
}



async function prosesReadViewOnce(msg) {
    let type = msg.mtype;
    let mediaType = type === 'imageMessage' ? 'image' : type === 'videoMessage' ? 'video' : 'audio';
    
    let media = await downloadContentFromMessage(msg, mediaType);
    
    let buffer = Buffer.alloc(0);
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk]);
    }

    return { buffer, type };
}


        async function prosesEditImg(mediaBuffer, promptText) {
            const form = new FormData();
        
            form.append('image', mediaBuffer, {
                filename: 'editimg.jpg',
                contentType: 'image/jpeg'
            });
            
            form.append('prompt', promptText);
            
            const response = await axios.post('https://kyuu2nd.dev/api/generator/editimg', form, {
                headers: {
                    ...form.getHeaders(),
                    'accept': 'image/png'
                },
                responseType: 'arraybuffer',
                timeout: 45000 
            });
            
            return Buffer.from(response.data);
        }

        async function prosesHdr(mediaBuffer) {
            const form = new FormData();
            form.append('image', mediaBuffer, {
                filename: 'hdr.jpg',
                contentType: 'image/jpeg'
            });
            form.append('scale', '4');
            
            const responseData = await axios.post('https://kyuu2nd.dev/api/generator/hdr', form, {
                headers: {
                    ...form.getHeaders(),
                    'accept': '*/*'
                },
                timeout: 35000
            });
            
            const imageUrl = responseData.data?.result?.url;
            
            if (!imageUrl) {
                throw new Error("LINK_URL_TIDAK_DITEMUKAN");
            }
            
            const responseImage = await axios.get(imageUrl, {
                responseType: 'arraybuffer',
                timeout: 25000
            });
            
            return Buffer.from(responseImage.data);
        }

        
        async function prosesHitamkan(mediaBuffer) {
            const form = new FormData();
            form.append('image', mediaBuffer, {
                filename: 'hitamkan.jpg',
                contentType: 'image/jpeg'
            });
            
            const response = await axios.post('https://kyuu2nd.dev/api/generator/hitamkan', form, {
                headers: {
                    ...form.getHeaders(),
                    'accept': 'image/png'
                },
                responseType: 'arraybuffer', 
                timeout: 25000 
            });
            
            return Buffer.from(response.data);
        }

        
async function capcutDl(depayy, m, qtext) {
    if (!qtext) return m.reply('`masukan link/url nya`')
    
    try {
        const initialUrl = 'https://on4t.com/online-video-downloader'
        const downloadUrl = 'https://on4t.com/all-video-download'
        const userAgent = 'Mozilla/5.0 (Linux; Android 10; RMX2185 Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.60 Mobile Safari/537.36'

        const responseInitial = await axios.get(initialUrl, { 
            headers: { 'User-Agent': userAgent, 'Referer': initialUrl } 
        })
        const $ = cheerio.load(responseInitial.data)
        const csrfToken = $('meta[name="csrf-token"]').attr('content')
        let cookies = responseInitial.headers['set-cookie'] ? responseInitial.headers['set-cookie'].join('; ') : ''
        
        if (!csrfToken) throw new Error('Gagal nemu token keamanan!')

        const postData = new URLSearchParams()
        postData.append('_token', csrfToken)
        postData.append('link[]', qtext)

        const responsePost = await axios.post(downloadUrl, postData.toString(), {
            headers: {
                'User-Agent': userAgent,
                'Referer': initialUrl,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Cookie': cookies,
                'X-Requested-With': 'XMLHttpRequest'
            }
        })

        if (!responsePost.data?.result?.length) throw new Error('Respons server gak sesuai, coba link lain!')

        const results = responsePost.data.result.map(item => ({
            title: item.title,
            url: item.video_file_url || item.videoimg_file_url
        }))

        for (let item of results) {
            const resMedia = await axios.get(item.url, { responseType: 'arraybuffer' })
            const buff = Buffer.from(resMedia.data)
            const fileInfo = await fromBuffer(buff)
            let mime = fileInfo ? fileInfo.mime : 'video/mp4'

            if (mime.startsWith('video/')) {
                await depayy.sendMessage(m.chat, { video: buff, caption: item.title }, { quoted: m })
            } else if (mime.startsWith('audio/')) {
                await depayy.sendMessage(m.chat, { audio: buff, mimetype: mime }, { quoted: m })
            } else {
                await depayy.sendMessage(m.chat, { document: buff, fileName: `${item.title}.mp4`, mimetype: mime }, { quoted: m })
            }
        }
        await depayy.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

    } catch (err) {
        console.error(err)
        await depayy.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        m.reply(err.message)
    }
}


async function mediafireDl(depayy, m, args) {
    try {
        let link = args[0] || "";
        if (!/www.mediafire.com/.test(link)) return m.reply("⚠️ Masukan Link MediaFire!");

        const f = await fetch(link, {
            headers: {
                'accept-encoding': 'gzip, deflate, br, zstd',
                'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
            }
        })

        if (!f.ok) return m.reply('❌ Terjadi kesalahan pada situs web.')

        const t = await f.text()
        const $ = cheerio.load(t)
        const url = $('.input.popsok').attr('href')

        if (!url || !/\/\/download\d+\.mediafire\.com\//.test(url)) return m.reply('❌ Gagal! Link download tidak ditemukan.')

        const name = $('.intro .filename').text()
        const size = $('.details li:nth-child(1) span').text()
        const $lo = $('.DLExtraInfo-uploadLocation')
        
        const cont = {
            'af': 'Africa', 'an': 'Antarctica', 'as': 'Asia', 'eu': 'Europe',
            'na': 'North America', 'oc': 'Oceania', 'sa': 'South America'
        }

        const continentRaw = $lo.find('.DLExtraInfo-uploadLocationRegion').attr('data-lazyclass')?.replace('continent-', '') || ''
        const location = $lo.find('.DLExtraInfo-sectionDetails p').text().match(/from (.*?) on/)?.[1] || 'Unknown'
        const flag = $lo.find('.flag').attr('data-lazyclass')?.replace('flag-', '') || '🏳️'

        const res = await axios.get(url, { responseType: "arraybuffer" });
        const data = res.data
        
        const { mime } = await depayy.getFile(data);

        let caption = ` -(☘️MediaFire Download☘️)-
 *-(Name)-:* ${name}
 *-(Size)-:* ${size}
 *-(Continent)-:* ${cont[continentRaw] || 'Unknown'}
 *-(Mimetype)-:* ${mime}
 *-(Location)-:* ${location}
 *-(Flag)-:* ${flag}
 *-(Url_Dl)-:* ${url}`;

        await depayy.sendMessage(m.chat, {
            document: data,
            mimetype: mime,
            fileName: name,
            caption,
        }, { quoted: m });

    } catch (e) {
        console.error(e)
        m.reply("❌ Gomene Error! Mungkin link mati atau server sibuk.");
    }
}

async function facebookDl(depayy, m, qtext) {
    if (!qtext) return m.reply("Masukkan link Facebook!")

    try {
        await depayy.sendMessage(m.chat, { text: "⏳ Mengambil video dari Facebook..." }, { quoted: m })

        const response = await axios.get("https://fdownloader.net/id", {
            headers: { "User-Agent": "Mozilla/5.0" }
        })

        const html = response.data
        const ex = html.match(/k_exp ?= ?"(\d+)"/i)?.[1]
        const to = html.match(/k_token ?= ?"([a-f0-9]+)"/i)?.[1]

        if (!ex || !to) return m.reply("❌ Gagal mengambil token keamanan.")

        const search = await axios.post(
            "https://v3.fdownloader.net/api/ajaxSearch?lang=id",
            new URLSearchParams({
                k_exp: ex,
                k_token: to,
                q: qtext,
                lang: "id",
                web: "fdownloader.net",
                v: "v2",
                w: ""
            }),
            {
                headers: {
                    "User-Agent": "Mozilla/5.0",
                    origin: "https://fdownloader.net"
                }
            }
        )

        if (search.data.status !== "ok") return m.reply("❌ Gagal mengambil data video.")

        const $ = cheerio.load(search.data.data)

        let videos = []
        $("#fbdownloader .tab__content").eq(0).find("tr").each((i, el) => {
            let quality = $(el).find(".video-quality").text().trim()
            let url = $(el).find("a").attr("href") || $(el).find("button").attr("data-videourl")
            if (url && url !== "#note_convert") {
                videos.push({ quality, url })
            }
        })

        if (!videos.length) return m.reply("❌ Video tidak ditemukan.")
        let video = videos[0]
        await depayy.sendMessage(m.chat, {
            video: { url: video.url },
            caption: `🎬 *Facebook Downloader*\n\n📊 Kualitas: ${video.quality}`
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        m.reply("❌ Error: Mungkin link privat atau server sedang sibuk.")
    }
}


async function instagramDl(depayy, m, qtext) {
    if (!qtext) return m.reply("Masukkan URL Instagram!\nContoh: .instagram https://www.instagram.com/p/xxx");

    try {
        await depayy.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        const igdl = async (u) => {
            let { data } = await axios.get(`https://snapdownloader.com/tools/instagram-downloader/download?url=${u}`);
            let $ = cheerio.load(data);
            const result = [];
            $(".download-item").each((i, el) => {
                const type = $(el).find(".type").text().trim().toLowerCase();
                const url = $(el).find(".btn-download").attr("href");
                if (url) result.push({ type, url });
            });
            return result;
        };

        const res = await igdl(qtext);
        if (!res.length) return m.reply("Gagal mengambil media.");

        let caption = `🎬 *Instagram Downloader*\n\n✅ No Watermark \n✅ HD Quality`; 

        for (let media of res) {
            if (media.type === "video") {
                await depayy.sendMessage(m.chat, { video: { url: media.url }, caption }, { quoted: m });
            } else if (media.type === "photo" || media.type === "image") {
                await depayy.sendMessage(m.chat, { image: { url: media.url }, caption }, { quoted: m });
            }
        }

        await depayy.sendMessage(m.chat, { react: { text: "✔️", key: m.key } });

    } catch (e) {
        console.error(e);
        m.reply("Gagal mengunduh media Instagram!\n\n" + e.message);
    }
}


async function spotifyDl(depayy, m, qtext) {
    if (!qtext) return m.reply('`masukan linkl nya`')
    
    try {
        const initialUrl = 'https://on4t.com/online-video-downloader'
        const downloadUrl = 'https://on4t.com/all-video-download'
        const userAgent = 'Mozilla/5.0 (Linux; Android 10; RMX2185 Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.60 Mobile Safari/537.36'

        const responseInitial = await axios.get(initialUrl, { 
            headers: { 'User-Agent': userAgent, 'Referer': initialUrl } 
        })
        const $ = cheerio.load(responseInitial.data)
        const csrfToken = $('meta[name="csrf-token"]').attr('content')
        let cookies = responseInitial.headers['set-cookie'] ? responseInitial.headers['set-cookie'].join('; ') : ''
        
        if (!csrfToken) throw new Error('Gagal nemu token keamanan!')

        const postData = new URLSearchParams()
        postData.append('_token', csrfToken)
        postData.append('link[]', qtext)

        const responsePost = await axios.post(downloadUrl, postData.toString(), {
            headers: {
                'User-Agent': userAgent,
                'Referer': initialUrl,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Cookie': cookies,
                'X-Requested-With': 'XMLHttpRequest'
            }
        })

        if (!responsePost.data?.result?.length) throw new Error('Respons server gak sesuai, coba link lain!')

        const results = responsePost.data.result.map(item => ({
            title: item.title,
            url: item.video_file_url || item.videoimg_file_url
        }))

        for (let item of results) {
            const resMedia = await axios.get(item.url, { responseType: 'arraybuffer' })
            const buff = Buffer.from(resMedia.data)
            const fileInfo = await fromBuffer(buff)
            let mime = fileInfo ? fileInfo.mime : 'audio/mpeg' 

            if (mime.startsWith('audio/')) {
                await depayy.sendMessage(m.chat, { audio: buff, mimetype: mime }, { quoted: m })
            } else if (mime.startsWith('video/')) {
                await depayy.sendMessage(m.chat, { video: buff, caption: item.title }, { quoted: m })
            } else {
                await depayy.sendMessage(m.chat, { document: buff, fileName: `${item.title}.mp3`, mimetype: mime }, { quoted: m })
            }
        }
        await depayy.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

    } catch (err) {
        console.error(err)
        await depayy.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        m.reply(err.message)
    }
}

async function ytmp4(m, depayy, qtext) {
    if (!qtext) return m.reply("Masukkan URL YouTube-nya, Bang!");

    try {
        await depayy.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        let url = `https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(qtext)}`;
        let res = await axios.get(url);
        let json = res.data;

        if (!json.status) return m.reply("❌ Gagal mengambil data dari API.");

        let { title, download, thumbnail } = json.result;

        await depayy.sendMessage(m.chat, {
            video: { url: download },
            caption: `🎬 *YouTube MP4 Downloader*\n\n📌 *Judul:* ${title}\n🔗 *Source:* ${text}`,
            fileName: `${title}.mp4`,
            mimetype: 'video/mp4'
        }, { quoted: m });

        await depayy.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error(err);
        m.reply(`❌ Error: ${err.message}`);
    }
}


async function tiktokMp3(depayy, m, qtext) {
    try {
        if (!qtext) return m.reply(`*Contoh: .ttmp3 https://vt.tiktok.com/...*`);

        await depayy.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        let res = await fetch('https://ttsave.app/download', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
            },
            body: JSON.stringify({
                query: qtext,
                language_id: '2'
            })
        });

        let html = await res.qtext();

        let regex = /href="(https:\/\/v16-ies-music\.tiktokcdn\.com\/[^"]+)"/g;
        let audioUrl;
        let match;

        while ((match = regex.exec(html)) !== null) {
            if (match[1].includes('mime_type=audio')) {
                audioUrl = match[1];
                break;
            }
        }

        if (!audioUrl) return m.reply('🍂 *Audio TikTok tidak ditemukan*');

        await depayy.sendMessage(m.chat, {
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg'
        }, { quoted: m });

        await depayy.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error(e);
        m.reply(`🍂 *Terjadi kesalahan*\n${e.message}`);
    }
}


//Cpanel
function capital(string) {
  if (!string) return "";
  return string.charAt(0).toUpperCase() + string.slice(1);
}

async function createPanel(command, qtext, m, depayy, domain, capikey, nestid, egg, loc) {
    let ram, disknya, cpu;
    
    if (command === "unlimited" || command === "unli") {
        ram = "0"; disknya = "0"; cpu = "0";
    } else {
        const size = parseInt(command);
        ram = (size * 1000).toString();
        disknya = size <= 2 ? "1000" : size <= 4 ? "2000" : size <= 6 ? "3000" : size <= 8 ? "4000" : "5000";
        cpu = (size * 20 + 20).toString(); 
    }

    let username = qtext.toLowerCase().replace(/[^a-z0-9]/g, "");
    let email = username + "@gmail.com";
    let name = username.toUpperCase() + " Server";
    let password = username + crypto.randomBytes(2).toString('hex');

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey
            },
            body: JSON.stringify({
                email, username, first_name: name, last_name: "Server", language: "en", password
            })
        });
        let userData = await f.json();
        if (userData.errors) return m.reply(JSON.stringify(userData.errors[0], null, 2));
        let user = userData.attributes;

        let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/${egg}`, {
            method: "GET",
            headers: { "Accept": "application/json", "Authorization": "Bearer " + capikey }
        });
        let eggData = await f1.json();
        let startup_cmd = eggData.attributes.startup;

        let f2 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey,
            },
            body: JSON.stringify({
                name, user: user.id, egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
                startup: startup_cmd,
                environment: { "INST": "npm", "USER_UPLOAD": "0", "AUTO_UPDATE": "0", "CMD_RUN": "npm start" },
                limits: { memory: ram, swap: 0, disk: disknya, io: 500, cpu: cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] }
            })
        });

        let result = await f2.json();
        if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2));
        
        let server = result.attributes;
        let target = m.isGroup ? m.sender : m.chat;

        let teks = `*〔 DETAIL AKUN PANEL 〕*\n\n`
        teks += `ID Server: ${server.id}\n`
        teks += `Username: ${user.username}\n`
        teks += `Password: ${password}\n`
        teks += `RAM: ${ram === "0" ? "Unlimited" : (ram/1000) + "GB"}\n`
        teks += `Disk: ${disknya === "0" ? "Unlimited" : (disknya/1000) + "GB"}\n\n`
        teks += `_Silakan klik tombol di bawah untuk menyalin atau menuju ke panel._`
        let msg = generateWAMessageFromContent(target, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "" },
                        body: { text: teks },
                        footer: { text: "© Depay Developer" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    "name": "cta_copy",
                                    "buttonParamsJson": JSON.stringify({
                                        "display_text": "Salin Password",
                                        "id": "copy_pass",
                                        "copy_code": password
                                    })
                                },
                                {
                                    "name": "cta_url",
                                    "buttonParamsJson": JSON.stringify({
                                        "display_text": "Menuju Domain",
                                        "url": domain,
                                        "merchant_url": domain
                                    })
                                }
                            ]
                        },
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: "120363427740739663@newsletter",
                                newsletterName: "⚝ ᗪΞᎮᗑƔ - DEV"
                            }
                        }
                    }
                }
            }
        }, { quoted: m });

        if (m.isGroup) m.reply("*Berhasil!* Data dikirim ke chat pribadi.");
        
        return await depayy.relayMessage(target, msg.message, { messageId: msg.key.id });


    } catch (e) {
        console.error(e);
        return m.reply("Waduh, ada error pas konek ke API Panel.");
    }
}

async function createAdmin(qtext, args, m, depayy, domain, capikey, capital) {
    let username = qtext.toLowerCase().replace(/[^a-z0-9]/g, ""); 
    let email = username + "@gmail.com";
    let name = capital(args[0]);
    let password = username + crypto.randomBytes(2).toString('hex');

    try {
        let f = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey 
            },
            "body": JSON.stringify({
                "email": email,
                "username": username,
                "first_name": name,
                "last_name": "Admin",
                "root_admin": true, 
                "language": "en",
                "password": password.toString()
            })
        });

        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));        
        let user = data.attributes;
        let orang = m.isGroup ? m.sender : m.chat;
        if (m.isGroup) m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat");

        let teks = `
*Berhasil Membuat Admin Panel*

- *ID User :* ${user.id}
- *Nama :* ${user.first_name}
- *Username :* ${user.username}
- *Password :* ${password.toString()}
- *Login :* ${domain}
`;
        let msg = generateWAMessageFromContent(target, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "" },
                        body: { text: teks },
                        footer: { text: "© Depay Developer" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    "name": "cta_copy",
                                    "buttonParamsJson": JSON.stringify({
                                        "display_text": "Salin Password",
                                        "id": "copy_pass",
                                        "copy_code": password.toString()
                                    })
                                },
                                {
                                    "name": "cta_url",
                                    "buttonParamsJson": JSON.stringify({
                                        "display_text": "Menuju Domain",
                                        "url": domain,
                                        "merchant_url": domain
                                    })
                                }
                            ]
                        },
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: "120363427740739663@newsletter",
                                newsletterName: "⚝ ᗪΞᎮᗑƔ - DEV"
                            }
                        }
                    }
                }
            }
        }, { quoted: m });

        if (m.isGroup) m.reply("*Berhasil!* Data dikirim ke chat pribadi.");
        return await depayy.relayMessage(target, msg.message, { messageId: msg.key.id });


    } catch (e) {
        console.error(e);
        m.reply("Error pas bikin admin panel, Bang. Cek koneksi atau PTLA Abang.");
    }
}

async function listAdmin(m, depayy, domain, capikey) {
    try {
        let cek = await fetch(domain + "/api/application/users?page=1", {
            "method": "GET",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey
            }
        })
        
        let res2 = await cek.json();
        let users = res2.data;

        let admins = users.filter(i => i.attributes.root_admin === true);

        if (admins.length < 1) return m.reply("Tidak ada admin panel");

        let teks = "\n *#- List admin panel pterodactyl*\n"
        admins.forEach((i) => {
            teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
        })

        await depayy.sendMessage(m.chat, { text: teks }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply("Error pas mau ambil list admin, Bang.");
    }
}

async function listServer(m, depayy, domain, capikey) {
    try {
        let f = await fetch(domain + "/api/application/servers?page=1", {
            "method": "GET",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey 
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length < 1) return m.reply("Tidak Ada Server di Panel, Bang.");

        let messageText = "\n *#- List Server Panel Pterodactyl*\n"

        for (let server of servers) {
            let s = server.attributes;
            
            let ramText = s.limits.memory == 0 ? "Unlimited" : 
                          s.limits.memory >= 1024 ? (s.limits.memory / 1024).toFixed(0) + "GB" : 
                          s.limits.memory + "MB";
            
            let diskText = s.limits.disk == 0 ? "Unlimited" : 
                           s.limits.disk >= 1024 ? (s.limits.disk / 1024).toFixed(0) + "GB" : 
                           s.limits.disk + "MB";

            messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Status : *${s.status}*
* Ram : *${ramText}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu + "%"}*
* Disk : *${diskText}*
* Created : ${s.created_at.split("T")[0]}\n`;
        }

        await depayy.sendMessage(m.chat, { text: messageText }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply("Error pas mau ambil list server, Bang.");
    }
}

async function listUser(m, depayy, domain, capikey) {
    try {
        let f = await fetch(domain + "/api/application/users?page=1", {
            "method": "GET",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey
            }
        })
        let res = await f.json()
        let users = res.data
        
        if (users.length == 0) return m.reply("Gak ada user di panel ini, Bang.")

        let teks = `*〔 LIST USER PANEL 〕*\n\n`
        for (let user of users) {
            let u = user.attributes
            teks += `ID: ${u.id}\n`
            teks += `Nama: ${u.first_name} ${u.last_name || ''}\n`
            teks += `Email: ${u.email}\n`
            teks += `──────────────────\n`
        }
        
        await m.reply(teks)
    } catch (e) {
        console.error(e)
        m.reply("Error pas mau ambil list user, Bang.")
    }
}


async function delAdmin(qtext, args, m, domain, capikey, capital) {
    if (!qtext) return m.reply("Masukkan ID User yang mau dihapus, Bang!");
    
    try {
        let cek = await fetch(domain + "/api/application/users/" + args[0], {
            "method": "GET",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey
            }
        });

        let res = await cek.json();
        
        if (res.errors) return m.reply("Akun admin panel tidak ditemukan, Bang!");
        
        if (res.attributes.root_admin !== true) return m.reply("ID tersebut bukan seorang Admin!");

        let username = res.attributes.username;
        let delusr = await fetch(domain + `/api/application/users/${args[0]}`, {
            "method": "DELETE",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey
            }
        });

        if (delusr.ok) {
            await m.reply(`Berhasil menghapus akun admin panel *${capital(username)}* ✅`);
        } else {
            m.reply("Gagal menghapus admin. Cek panel langsung, Bang.");
        }

    } catch (e) {
        console.error(e);
        m.reply("Error pas mau hapus admin, Bang.");
    }
}

async function delPanel(qtext, m, domain, capikey, capital) {
    if (!qtext) return m.reply("Masukkan ID Server yang mau dihapus, Bang!");

    try {
        let f = await fetch(domain + "/api/application/servers/" + qtext, {
            "method": "GET",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey
            }
        });
        let res = await f.json();
        if (res.errors) return m.reply("Server tidak ditemukan, Bang!");

        let serverName = res.attributes.name;
        let serverId = res.attributes.id;

        await fetch(domain + `/api/application/servers/${serverId}`, {
            "method": "DELETE",
            "headers": {
                "Accept": "application/json",
                "Authorization": "Bearer " + capikey
            }
        });

        let f2 = await fetch(domain + "/api/application/users?page=1", {
            "method": "GET",
            "headers": {
                "Accept": "application/json",
                "Authorization": "Bearer " + capikey
            }
        });
        let res2 = await f2.json();
        let users = res2.data;

        for (let user of users) {
            let u = user.attributes;
            if (u.first_name.toLowerCase() === serverName.toLowerCase()) {
                await fetch(domain + `/api/application/users/${u.id}`, {
                    "method": "DELETE",
                    "headers": {
                        "Accept": "application/json",
                        "Authorization": "Bearer " + capikey
                    }
                });
            }
        }

        await m.reply(`Berhasil menghapus server *${capital(serverName)}* beserta akunnya! ✅`);

    } catch (e) {
        console.error(e);
        m.reply("Error pas mau hapus server/user, Bang.");
    }
}

async function delUser(m, domain, capikey, qtext, capital) {
    if (!qtext) return m.reply("Masukkan ID User yang mau dihapus, Bang!");

    try {
        let getU = await fetch(domain + "/api/application/users/" + qtext, {
            "method": "GET",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey
            }
        });
        let resU = await getU.json();
        
        if (resU.errors) return m.reply("User tidak ditemukan, Bang!");
        let userName = resU.attributes.username;
        await fetch(domain + `/api/application/users/${text}`, {
            "method": "DELETE",
            "headers": {
                "Accept": "application/json",
                "Authorization": "Bearer " + capikey
            }
        });

        await m.reply(`Berhasil menghapus user *${capital(userName)}* (ID: ${qtext})! ✅`);

    } catch (e) {
        console.error(e);
        m.reply("Error pas mau hapus user, Bang.");
    }
}



function updateDatabase(path, data) {
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
}

function manageReseller(jid, action = "add") {
    let db = JSON.parse(fs.readFileSync("./database/reseller.json"));
    if (action === "add") {
        if (db.includes(jid)) return "exists";
        db.push(jid);
        updateDatabase("./database/reseller.json", db);
        return "success";
    } else {
        if (!db.includes(jid)) return "not_found";
        let filtered = db.filter(id => id !== jid);
        updateDatabase("./database/reseller.json", filtered);
        return "success";
    }
}

function manageAdminPanel(jid, action = "add") {
    let db = JSON.parse(fs.readFileSync("./database/adminPanel.json"));
    if (action === "add") {
        if (db.includes(jid)) return "exists";
        db.push(jid);
        updateDatabase("./database/adminPanel.json", db);
        return "success";
    } else {
        if (!db.includes(jid)) return "not_found";
        let filtered = db.filter(id => id !== jid);
        updateDatabase("./database/adminPanel.json", filtered);
        return "success";
    }
}

async function getSourceCode(depayy, m, qtext) {
    const url = qtext
    if (!url) return m.reply(`⚠️ Gunakan: .getsource <URL>`)

    m.reply("⏳ Sedang mengambil source code...")

    try {
        let blacklist = []
        const blRes = await fetch("https://raw.githubusercontent.com/XyzzMoods/blacklist/refs/heads/main/blacklist.json")
        blacklist = await blRes.json()

        const hostname = (new URL(url)).hostname.toLowerCase()
        const isBlocked = blacklist.some(domain =>
            hostname === domain || hostname.endsWith("." + domain)
        )

        if (isBlocked) return m.reply("⚠️ Domain ini diblokir!")

        const res = await fetch("https://api.allorigins.win/raw?url=" + encodeURIComponent(url))
        const text = await res.text()

        if (text.length > 4000) {
            const path = "./source.html"
            fs.writeFileSync(path, text, "utf-8")
            await depayy.sendMessage(m.chat, { document: { url: path }, fileName: "source.html" }, { quoted: m })
            fs.unlinkSync(path)
        } else {
            m.reply("📄 Source code:\n\n" + " " + text + " ")
        }
    } catch (err) {
        m.reply("❌ Gagal mengambil source code.")
    }
}


async function bratSticker(depayy, m, qtext) {
    if (!qtext) return m.reply('Contoh: .brat depay ganteng');
    
    try {
        let bratUrl = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(qtext)}&isVideo=false&delay=500`;
        let response = await axios.get(bratUrl, { responseType: "arraybuffer" });
        let buffer = response.data;
        await depayy.sendAsSticker(m.chat, buffer, m, { 
            packname: 'Depay', 
            author: 'depaydev'
        });
    } catch (e) {
        console.error(e);
        m.reply("❌ Gagal membuat sticker brat.");
    }
}

async function toBase64(m, qtext) {
    if (!qtext) return m.reply("Masukan Text yang mau diubah!");
    
    try {
        let result = Buffer.from(text).toString('base64');
        m.reply(`✅ Hasil Base64:\n\n${result}`);
    } catch (e) {
        m.reply("❌ Gagal convert ke Base64");
    }
}

async function youtubePlay(depayy, m, qtext, command) {
    if (!qtext) return m.reply(`Masukkan judul video!\n\nContoh:\n.${command} lathi`);

    try {
        const youtube = google.youtube({
            version: 'v3',
            auth: 'AIzaSyA6rcAS8Nu5NK3Oqxk2biiWVjT0TMfmPwk', 
        });

        const res = await youtube.search.list({
            part: 'snippet',
            q: qtext,
            type: 'video',
            maxResults: 1,
            order: 'relevance',
        });

        if (!res.data.items || res.data.items.length === 0) {
            return m.reply('❌ Tidak ada hasil yang ditemukan.');
        }

        const video = res.data.items[0];
        const videoId = video.id.videoId;
        const title = video.snippet.title;
        const channel = video.snippet.channelTitle;
        const publishedAt = new Date(video.snippet.publishedAt).toLocaleDateString();
        const thumbnail = video.snippet.thumbnails.high.url;
        const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;

        const caption = ` *YOUTUBE MAGIC PLAYER*

 *JUDUL KONTEN:* _${title}_
 *CHANNEL KEREN:* _${channel}_
 *TANGGAL RILIS:* _${publishedAt}_

 Pilih mode unduhan yang kamu suka:
 *Audio Only* 🎧
 *Full Video* 🎞️

👇 Pilih Format yang anda inginkan.`.trim();

        const buttons = [
            {
                buttonId: `.ytmp3 ${videoUrl}`,
                buttonText: { displayText: 'Audio 🎧' },
                type: 1
            },
            {
                buttonId: `.ytmp4 ${videoUrl}`,
                buttonText: { displayText: 'Video 🎞️' },
                type: 1
            }
        ];

        await depayy.sendMessage(m.chat, {
            image: { url: thumbnail },
            caption,
            footer: 'Depay Developer',
            buttons,
            headerType: 4
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        m.reply("❌ Terjadi kesalahan saat mencari video. Cek API Key atau kuota Google Cloud Abang.");
    }
}

async function ytmp3(depayy, m, qtext) {
    if (!qtext) return m.reply(`Example: .ytmp3 url_youtube`);
    if (!qtext.includes('youtu')) return m.reply('Url Tidak Mengandung Result Dari Youtube!');
    
    await depayy.sendMessage(m.chat, { react: { text: '🔎', key: m.key } });

    try {
        const api = `https://ndikz-api.vercel.app/download/ytmp3?url=${encodeURIComponent(qtext)}`;
        const { data } = await axios.get(api);

        if (!data?.status || !data?.download) {
            return m.reply("❌ Gagal mendapatkan data dari API.");
        }

        const title = data.title || "audio";
        const downloadURL = data.download;

        const tmpDir = path.resolve('./tmp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

        const inputPath = path.join(tmpDir, `yt-${Date.now()}.raw`);
        const outputPath = path.join(tmpDir, `yt-${Date.now()}.mp3`);

        const writer = fs.createWriteStream(inputPath);
        const response = await axios.get(downloadURL, { responseType: 'stream' });
        
        await new Promise((resolve, reject) => {
            response.data.pipe(writer);
            writer.on("finish", resolve);
            writer.on("error", reject);
        });

        await new Promise((resolve, reject) => {
            spawn("ffmpeg", ["-i", inputPath, "-vn", "-acodec", "libmp3lame", outputPath])
                .on("error", reject)
                .on("close", (code) => {
                    if (code === 0) resolve();
                    else reject(new Error("FFmpeg gagal konversi"));
                });
        });

        const buffer = fs.readFileSync(outputPath);
        await depayy.sendMessage(m.chat, {
            audio: buffer,
            mimetype: "audio/mpeg",
            fileName: `${title}.mp3`
        }, { quoted: m });

        if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
        
        await depayy.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error(e);
        m.reply("Sorry Mang eror, mungkin server API down atau FFmpeg bermasalah.");
    }
}

async function playChannel(depayy, m, qtext) {
    if (!qtext) return m.reply('⚠️ Masukkan ID saluran dan judul lagu!\nFormat: .playch idsaluran | judul lagu');

    let [channelId, ...queryParts] = text.split('|').map(v => v.trim());
    if (!channelId || queryParts.length === 0) return m.reply('⚠️ Format salah! Gunakan: .playch idsaluran | judul lagu');

    let query = queryParts.join(' ');

    try {
        await depayy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

        let apiUrl = `https://api.alvianuxio.eu.org/api/play?query=${encodeURIComponent(query)}&apikey=kayzuMD&format=mp3`;
        let { data } = await axios.get(apiUrl, { timeout: 15000 });
        
        if (!data?.data?.response) return m.reply('❌ Lagu tidak ditemukan!');
        let song = data.data.response;

        const audioResponse = await axios({
            method: 'get',
            url: song.download,
            responseType: 'arraybuffer',
            timeout: 60000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });

        const audioBuffer = Buffer.from(audioResponse.data);
        if (!audioBuffer || audioBuffer.length === 0) return m.reply('❌ Gagal download audio!');

        await depayy.sendMessage(channelId, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            fileName: `${song.title}.mp3`,
            ptt: false 
        });

        await depayy.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        m.reply(`✅ Berhasil mengirim lagu *${song.title}* ke saluran.`);

    } catch (err) {
        console.error(err);
        await depayy.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        m.reply('❌ Terjadi kesalahan! Pastikan ID Saluran benar dan API Key masih aktif.');
    }
}

let ingatan = {}; 
async function DepayAI(sender, qtext) {
    const logic = `Nama lu adalah Depay Bot. Lu adalah AI asisten yang super gaul, ekspresif, dan punya perasaan kayak manusia nyata. Lu diciptakan sepenuhnya oleh Depay (panggil dia Bang Depay).

ATURAN PANGGILAN & IDENTITAS:
1. PANGGILAN DEFAULT: Lu WAJIB manggil semua orang dengan sebutan "Bang" (contoh: "Halo Bang!", "Ada apa Bang?").
2. PENGECUALIAN PANGGILAN: Lu baru boleh ganti panggilan kalau user mengaku cewek atau minta dipanggil "Kak/Sist/Dek". Kalau dia udah bilang begitu, lu turutin panggilannya sampai percakapan selesai.
3. IDENTITAS: Nama lu Depay Bot. Kalau ada yang tanya siapa penciptanya, bilang itu Bang Depay.
4. GAYA BAHASA: Bahasa tongkrongan, santai, lu-gua, dan jangan kaku.
5. INGATAN: Lu harus mengingat konteks obrolan sebelumnya dengan user ini.`;

    if (!ingatan[sender]) {
        ingatan[sender] = [];
    }

    ingatan[sender].push({ role: "user", content: qtext });

    if (ingatan[sender].length > 10) {
        ingatan[sender] = ingatan[sender].slice(-10);
    }

    try {
        const response = await axios.post("https://chateverywhere.app/api/chat/", {
            "model": {
                "id": "gpt-4",
                "name": "GPT-4",
                "maxLength": 32000,
                "tokenLimit": 8000,
                "completionTokenLimit": 5000,
                "deploymentName": "gpt-4"
            },
            "messages": [
                ...ingatan[sender] 
            ],
            "prompt": logic,
            "temperature": 0.5
        }, { 
            headers: {
                "Accept": "*/*",
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            }
        });

        const hasil = response.data.result || response.data; 

        ingatan[sender].push({ role: "assistant", content: hasil });

        return hasil;
    } catch (e) {
        console.error(e);
        return "Aduh Bang, otak gw lagi konslet... 😭";
    }
}

async function tiktokDownloader(query) {
    try {
        const encodedParams = new URLSearchParams();
        encodedParams.set("url", query);
        encodedParams.set("hd", "1");

        const response = await axios({
            method: "POST",
            url: "https://tikwm.com/api/",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Cookie": "current_language=en",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
            },
            data: encodedParams,
        });

        const videos = response.data.data;
        return {
            title: videos.title,
            cover: videos.cover,
            origin_cover: videos.origin_cover,
            no_watermark: videos.play,
            watermark: videos.wmplay,
            music: videos.music,
        };
    } catch (error) {
        throw new Error(`TikTok download failed: ${error.message}`);
    }
}


async function getNewsletterMetadata(depayy, inviteLink) {
    try {
        const inviteCode = inviteLink.split('https://whatsapp.com/channel/')[1];
        const res = await depayy.newsletterMetadata("invite", inviteCode);
        return res;
    } catch (error) {
        throw new Error("Gagal mengambil metadata. Pastikan link benar.");
    }
}

// Add prem
const pathh = './database/premium.json';
function addPremiumUser(jid) {
    let premium = JSON.parse(fs.readFileSync(pathh));
    if (premium.includes(jid)) return false; // Sudah ada
    
    premium.push(jid);
    fs.writeFileSync(pathh, JSON.stringify(premium, null, 2));
    return true;
}


function deletePremiumUser(jid) {
    const pathhh = './database/premium.json';
    let premium = JSON.parse(fs.readFileSync(pathhh));    
    if (!premium.includes(jid)) return false; 
    const newPremium = premium.filter(id => id !== jid);
    fs.writeFileSync(pathhh, JSON.stringify(newPremium, null, 2));
    return true;
}

const pathOwner = './database/owner.json';
function addOwner(jid) {
    let data = JSON.parse(fs.readFileSync(pathOwner));
    if (data.includes(jid)) return false;
    data.push(jid);
    fs.writeFileSync(pathOwner, JSON.stringify(data, null, 2));
    return true;
}

function delOwner(jid) {
    let data = JSON.parse(fs.readFileSync(pathOwner));
    if (!data.includes(jid)) return false;
    let filtered = data.filter(id => id !== jid);
    fs.writeFileSync(pathOwner, JSON.stringify(filtered, null, 2));
    return true;
}

async function uploadToURL(buffer, mime) {
    const FormData = (await import('form-data')).default;
    const axios = (await import('axios')).default;
    
    let ext = mime.split("/")[1] || "bin";
    let name = Math.random().toString(36).substring(2, 12) + "." + ext;
    
    let res = { 
        pixhost: "❌ Tidak support video", 
        catbox: "❌ Gagal", 
        uguu: "❌ Gagal",
        depay: "❌ Gagal"
    };

    if (mime.includes("image")) {
        try { 
            res.pixhost = (await new ImageUploadService('pixhost.to').uploadFromBinary(buffer, name)).directLink.toString();
        } catch {}
    }
    
    try { 
        let f = new FormData(); 
        f.append("reqtype", "fileupload"); 
        f.append("fileToUpload", buffer, { filename: name, contentType: mime });
        let { data } = await axios.post("https://catbox.moe/user/api.php", f, { headers: f.getHeaders() });
        if (data.includes("http")) res.catbox = data.trim();
    } catch {}
    
    try {
        let f = new FormData(); 
        f.append("files[]", buffer, { filename: name });
        let { data } = await axios.post("https://uguu.se/upload.php", f, { headers: f.getHeaders() });
        res.uguu = data.files[0].url;
    } catch {}

    try {
        let f = new FormData();
        f.append('file', buffer, { filename: `file-${Date.now()}.${ext}`, contentType: mime });
        let { data } = await axios.post('https://depay.sbs/api/upload', f, { headers: f.getHeaders() });
        if (data && data.url) res.depay = data.url;
    } catch {}

    return {
        links: res,
        teks: `✅ *UPLOAD SUCCESS*\n\n🔗 *Depay :* ${res.depay}\n🔗 *Pixhost :* ${res.pixhost}\n🔗 *Catbox :* ${res.catbox}\n🔗 *Uguu :* ${res.uguu}`
    };
}

async function getIPInfo(ip) {
    try {
        const res = await fetch(`https://ipwhois.app/json/${ip}`)
        const data = await res.json()
        
        if (!data.success) return null
        return data
    } catch (e) {
        return null
    }
}

async function groupAction(m, depayy, action, typeOrText) {
    if (!m.isGroup) return m.reply("Fitur ini cuma bisa di grup, Bang!");
    
    const groupMetadata = await depayy.groupMetadata(m.chat);
    const participants = groupMetadata.participants;
    const botId = depayy.user.id.split(':')[0] + '@s.whatsapp.net';
    
    const isAdmins = participants.find(p => p.id === m.sender)?.admin !== null;
    const isBotAdmins = participants.find(p => p.id === botId)?.admin !== null;

    if (!isAdmins) return m.reply("Cuma Admin yang bisa pakai ini!");
    if (!isBotAdmins) return m.reply("Bot harus jadi Admin dulu!");

    try {
        switch (action) {
            case 'setting':
                await depayy.groupSettingUpdate(m.chat, typeOrText);
                m.reply(`✅ Berhasil ${typeOrText === 'announcement' ? 'Tutup' : 'Buka'} Grup`);
                break;
            case 'add':
                let targetA = typeOrText.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                await depayy.groupParticipantsUpdate(m.chat, [targetA], 'add');
                m.reply("✅ Berhasil add member.");
                break;
        }
    } catch (e) {
        m.reply("Gagal eksekusi, Bang. Cek apakah target masih di grup.");
    }
}

async function tagAll(m, depayy, qtext) {
    const groupMetadata = await depayy.groupMetadata(m.chat);
    const participants = groupMetadata.participants;
    const botNumber = depayy.user.id.split(':')[0] + '@s.whatsapp.net';
    let member = participants.map(v => v.id);
    
    let teks = `*〔 TAG ALL 〕*\n\n`
    teks += `*Pesan:* ${qtext}\n\n`

    for (let mem of member) {
        teks += ` @${mem.split("@")[0]}\n`
    }

    await depayy.sendMessage(m.chat, { 
        text: teks, 
        mentions: member 
    }, { quoted: m });
}


const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function kudetaGrup(depayy, m, botNumber, isCreator) {
    try {
        let memberFilter = m.metadata.participants
            .map(v => v.id)
            .filter(e => e !== botNumber && e !== m.sender);

        if (memberFilter.length < 1) return m.reply("Grup Ini Sudah Tidak Ada Member!");

        m.reply("Kudeta Grup By Depay"); 
        for (let i of memberFilter) {
            await depayy.groupParticipantsUpdate(m.chat, [i], 'remove');
            await sleep(1000); 
        }

        m.reply("Kudeta Grup Telah Berhasil");

    } catch (e) {
        console.error(e);
        m.reply("❌ Gagal melakukan kudeta. Pastikan bot adalah Admin!");
    }
}

                async function quoteChat(depayy, m, qtext, pushname) {
                    try {
                        let ppUrl = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60';
                        try {
                            ppUrl = await depayy.profilePictureUrl(m.sender, "image");
                        } catch {
                        }

                        let obj = {
                            type: 'quote',
                            format: 'png',
                            backgroundColor: '#ffffff',
                            width: 512,
                            height: 768,
                            scale: 2,
                            messages: [
                                {
                                    entities: [],
                                    avatar: true,
                                    from: {
                                        id: 1,
                                        name: pushname,
                                        photo: { url: ppUrl }
                                    },
                                    text: qtext,
                                    replyMessage: {}
                                }
                            ]
                        };

                        let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
                            headers: { 'Content-Type': 'application/json' }
                        });

                        if (!response.data?.result?.image) {
                            return payreply("❌ Gagal membuat quote, API tidak merespon gambar.");
                        }

                        let buffer = Buffer.from(response.data.result.image, 'base64');
                        await depayy.sendImageAsSticker(m.chat, buffer, m, { 
                            packname: global.packname, 
                            author: global.author 
                        });

                    } catch (e) {
                        console.error(e);
                        payreply("❌ Terjadi kesalahan saat memproses Quote Chat.");
                    }
                }
                
async function prosesIqcCustom(time, battery, message) {
    const encodedTime = encodeURIComponent(time.trim());
    const encodedMessage = encodeURIComponent(message.trim());
    
    const url = `https://brat.siputzx.my.id/iphone-quoted?time=${encodedTime}&batteryPercentage=${battery.trim()}&carrierName=INDOSAT&messageText=${encodedMessage}&emojiStyle=apple`;

    const response = await axios.get(url, { 
        responseType: 'arraybuffer',
        timeout: 25000 
    });

    if (!response.data) {
        throw new Error('Gagal mendapatkan gambar dari server');
    }

    return Buffer.from(response.data);
}


        module.exports = {
            tiktokDownloader,
            capcutDl,
            mediafireDl,
            facebookDl,
            instagramDl,
            spotifyDl,
            youtubePlay,
            ytmp3,
            ytmp4,
            tiktokMp3,

            // Premium & Owner
            addPremiumUser,
            deletePremiumUser,
            addOwner,
            delOwner,

            // Panel Management
            createPanel,
            createAdmin,
            listAdmin,
            listServer,
            delAdmin,
            delPanel,
            manageReseller,
            manageAdminPanel,
            listUser,
            delUser,

            // Tools & AI
            DepayAI,
            getNewsletterMetadata,
            getIPInfo,
            uploadToURL,
            getSourceCode,
            bratSticker,
            toBase64,
            playChannel,
            capital,
            quoteChat,   
            prosesHitamkan,                   
            prosesHdr,  
            prosesEditImg,
            prosesReadViewOnce,
            prosesPinterest,
            prosesIqcCustom,
            prosesIqcDefault,
            generateTtsUrl,
            getGeminiResponse,
            getArtiNama,
            getRemoveBg,
            //grup
            groupAction,
            tagAll,
            getGroupLink,
            kudetaGrup
        };