const fs = require('fs')

// Settings Bot
global.owner = ["6285134642187"]
global.namaowner = "depayy"
global.publik = true
global.prefa = ["!", ".", ",", "🐤", "🗿"];
global.groupOnly = false; 



// Mess
global.mess = {
	owner: `ini khusus owner aja`,
	admin: `ini khusus admin aja`,
	botAdmin: `bot harus jadi admin dulu jir`,
	group: `ini fitur khusus dalam grup doang`,
	private: `fitur ini cuman bisa di lakukan di private chat`,
	murbug: `khusus Premium/Murbug doang`
}

// stiker
global.packname = 'depay.dev'
global.author = 'Depay Developer'

// End Settings
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
