const axios = require('axios');
const crypto = require("crypto");
const yts = require("yt-search");
const savetube = {
  api: {
    base: "https://media.savetube.me/api",
    cdn: "/random-cdn",
    info: "/v2/info",
    download: "/download",
  },
  headers: {
    accept: "*/*",
    "content-type": "application/json",
    origin: "https://yt.savetube.me",
    referer: "https://yt.savetube.me/",
    "user-agent": "Postify/1.0.0",
  },
  formats: ["144", "240", "360", "480", "720", "1080", "mp3"],
  crypto: {
    hexToBuffer: (hexString) => {
      const matches = hexString.match(/.{1,2}/g);
      return Buffer.from(matches.join(""), "hex");
    },
    decrypt: async (enc) => {
      try {
        const secretKey = "C5D58EF67A7584E4A29F6C35BBC4EB12";
        const data = Buffer.from(enc, "base64");
        const iv = data.slice(0, 16);
        const content = data.slice(16);
        const key = savetube.crypto.hexToBuffer(secretKey);
        const decipher = crypto.createDecipheriv("aes-128-cbc", key, iv);
        let decrypted = decipher.update(content);
        decrypted = Buffer.concat([decrypted, decipher.final()]);
        return JSON.parse(decrypted.toString());
      } catch (error) {
        throw new Error(error);
      }
    },
  },
  youtube: (url) => {
    if (!url) return null;
    const a = [
      /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
      /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    ];
    for (let b of a) {
      if (b.test(url)) return url.match(b)[1];
    }
    return null;
  },
  request: async (endpoint, data = {}, method = "post") => {
    try {
      const { data: response } = await axios({
        method,
        url: `${
          endpoint.startsWith("http") ? "" : savetube.api.base
        }${endpoint}`,
        data: method === "post" ? data : undefined,
        params: method === "get" ? data : undefined,
        headers: savetube.headers,
      });
      return {
        status: true,
        code: 200,
        data: response,
      };
    } catch (error) {
      throw new Error(error);
    }
  },
  getCDN: async () => {
    const response = await savetube.request(savetube.api.cdn, {}, "get");
    if (!response.status) throw new Error(response);
    return {
      status: true,
      code: 200,
      data: response.data.cdn,
    };
  },
  download: async (link, format) => {
    if (!link) {
      return {
        status: false,
        code: 400,
        error: "Linknya mana? Yakali download kagak ada linknya 🗿",
      };
    }
    if (!format || !savetube.formats.includes(format)) {
      return {
        status: false,
        code: 400,
        error:
          "Formatnya kagak ada bree, pilih yang udah disediain aja yak, jangan nyari yang gak ada 🗿",
        available_fmt: savetube.formats,
      };
    }
    const id = savetube.youtube(link);
    if (!id) throw new Error("invalid link");
    try {
      const cdnx = await savetube.getCDN();
      if (!cdnx.status) return cdnx;
      const cdn = cdnx.data;
      const result = await savetube.request(
        `https://${cdn}${savetube.api.info}`,
        {
          url: `https://www.youtube.com/watch?v=${id}`,
        }
      );
      if (!result.status) return result;
      const decrypted = await savetube.crypto.decrypt(result.data.data);
      var dl;
      try {
        dl = await savetube.request(`https://${cdn}${savetube.api.download}`, {
          id: id,
          downloadType: format === "mp3" ? "audio" : "video",
          quality: format === "mp3" ? "128" : format,
          key: decrypted.key,
        });
      } catch (error) {
        throw new Error(error);
      }
      return {
        status: true,
        code: 200,
        result: {
          title: decrypted.title || "Gak tau 🤷🏻",
          type: format === "mp3" ? "audio" : "video",
          format: format,
          thumbnail:
            decrypted.thumbnail || `https://i.ytimg.com/vi/${id}/0.jpg`,
          download: dl.data.data.downloadUrl,
          id: id,
          key: decrypted.key,
          duration: decrypted.duration,
          quality: format === "mp3" ? "128" : format,
          downloaded: dl.data.data.downloaded,
        },
      };
    } catch (error) {
      throw new Error(error);
    }
  },
};
function convertDuration(durationMs) {
  const seconds = Math.floor((durationMs / 1000) % 60);
  const minutes = Math.floor((durationMs / (1000 * 60)) % 60);
  const hours = Math.floor((durationMs / (1000 * 60 * 60)) % 24);

  let result = '';
  if (hours > 0) {
    result += hours + ' jam ';
  }
  if (minutes > 0) {
    result += minutes + ' menit ';
  }
  if (seconds > 0) {
    result += seconds + ' detik';
  }

  return result.trim();
}

async function spotifyDown(url) {
  const linkRegex = /https:\/\/open\.spotify\.com\/track\/[0-9A-Za-z]+/i;
  try {
    // Validasi URL lebih ketat
    if (!url || !linkRegex.test(url)) {
      return {
        status: false,
        message: '❌ Format URL tidak valid!'
      };
    }

    const response = await axios.get(`https://api.fabdl.com/spotify/get?url=${encodeURIComponent(url)}`);
    
    // Handle response API error
    if (!response.data?.result) {
      return {
        status: false,
        message: '🚫 Track tidak ditemukan'
      };
    }

    const { id, name, artists, image, duration_ms, gid } = response.data.result;
    const curl = await axios.get(`https://api.fabdl.com/spotify/mp3-convert-task/${gid}/${id}`);

    // Validasi download URL
    if (!curl.data?.result?.download_url) {
      return {
        status: false,
        message: '🔍 Gagal mendapatkan link download'
      };
    }

    return {
      status: true,
      data: {
        title: name,
        artist: artists, // Handle array artists
        duration: convertDuration(duration_ms),
        thumbnail: image,
        url: `https://api.fabdl.com${curl.data.result.download_url}`
      }
    };

  } catch(error) {
    console.error('SpotifyDown Error:', error);
    return {
      status: false,
      message: '⚠️ Terjadi kesalahan server'
    };
  }
}
async function tiktokDownloader(query) {
  try {
    const encodedParams = new URLSearchParams();
    encodedParams.set("url", query);
    encodedParams.set("hd", "1");

    const response = await axios({
      method: "POST",
      url: "https://tikwm.com/api/",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Cookie": "current_language=en",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
      },
      data: encodedParams,
    });

    const videos = response.data.data;
    return {
      title: videos.title,
      cover: videos.cover,
      origin_cover: videos.origin_cover,
      no_watermark: videos.play,
      watermark: videos.wmplay,
      music: videos.music,
    };
  } catch (error) {
    throw new Error(`TikTok download failed: ${error.message}`);
  }
}

		
module.exports = { spotifyDown, savetube, tiktokDownloader }