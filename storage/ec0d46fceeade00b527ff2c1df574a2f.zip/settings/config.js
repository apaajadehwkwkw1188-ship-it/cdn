module.exports = {
  TELEGRAM_TOKEN: `8911858222:AAEt5sW0dpAD3yCw9_QTwqrr3Y-co8Ghkuo`,
  TELEGRAM_ID: `5082460888`,

  GITHUB_TOKEN: `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`,
  GITHUB_OWNER: `Malzz`,
  GITHUB_REPO: `ObZugdkdizvzksbzxvysvrkaocpq/Malzz`,
  GITHUB_PATH: `tokens.json`,

  ROLES_FILE: `./database/roles.json`
}