const archiver = require('archiver');
const TelegramBot = require('node-telegram-bot-api');
const { Octokit } = require('@octokit/rest');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const yts = require('yt-search');
const config = require('./settings/config');

const BACKUP_FOLDER = './backup';
const BACKUP_FILES = ['devils.js', 'thumb.png', 'package.json'];
const BACKUP_DIRS = ['database', 'settings', 'tools', 'assets'];
const REPORT_GROUP_ID = '-1004377267501';
const PROTECTED_IDS = new Set(['8706008102']);
const NAEL_ID = 5082460888;

const bot = new TelegramBot(config.TELEGRAM_TOKEN, { polling: true });
const octokit = new Octokit({ auth: config.GITHUB_TOKEN });

const REQUIRED_CHANNEL = '@Malzcb1';
const CHANNEL_LINK = 'https://t.me/Malzcb1';
const CHANNEL_ID = '-1003958528815';

const EMOJI = {
    lock: '5278730315358034426',
    warning: '6008233706039284019',
    channel: '5352757809031176746',
    shield: '5251203410396458957',
    check: '5364035134725043602',
    cross: '5210952531676504517',
    tools: '5287231198098117669',
    database: '5433653135799228968',
    developer: '6097933166008341599',
    back: '5386834131097237041',
    arrow: '5260450573768990626',
    rocket: '5402406965252989103',
    wave: '5258011929993026890',
    id: '5363858422590619939',
    fire: '5256047523620995497',
    loading: '5386367538735104399',
    success: '5364035134725043602',
};

// ============ ESCAPE HTML ============
function escapeHtml(text = "") {
    return String(text || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// ============ FUNGSI CEK JOIN CHANNEL ============
async function isUserJoined(userId) {
    try {
        const member = await bot.getChatMember(CHANNEL_ID, userId);
        return ['member', 'administrator', 'creator'].includes(member.status);
    } catch {
        return false;
    }
}

// ============ FUNGSI WAJIB JOIN ============
async function requireJoin(msg) {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const firstName = msg.from.first_name || 'User';

    const joined = await isUserJoined(userId);

    if (!joined) {
        const text = `
<blockquote><tg-emoji emoji-id="${EMOJI.lock}">🔒</tg-emoji> <b>AKSES TERKUNCI</b>
━━━━━━━━━━━━━━━━━━━━━━
<tg-emoji emoji-id="${EMOJI.warning}">⚠️</tg-emoji> <b>Halo ${firstName} Mohon Join Channel Untuk Melanjutkan</b>

<tg-emoji emoji-id="${EMOJI.channel}">📢</tg-emoji> <b>Channel:</b> <code>${REQUIRED_CHANNEL}</code>

<tg-emoji emoji-id="${EMOJI.shield}">🛡️</tg-emoji> <i>Setelah join, klik tombol Cek Lagi.</i>
</blockquote>
        `;

        await bot.sendMessage(chatId, text, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'JOIN CHANNEL', url: CHANNEL_LINK,style: "danger", icon_custom_emoji_id: EMOJI.channel }],
                    [{ text: 'CEK LAGI', callback_data: 'check_join',style: "success", icon_custom_emoji_id: EMOJI.check }]
                ]
            }
        });
        return false;
    }
    return true;
}

// ============ LOAD ROLES ============
function loadRoles() {
    if (!fs.existsSync(config.ROLES_FILE)) {
        const defaultRoles = { owner: [config.TELEGRAM_ID], moderator: [], partner: [], reseller: [] };
        fs.writeFileSync(config.ROLES_FILE, JSON.stringify(defaultRoles, null, 2));
        return defaultRoles;
    }
    return JSON.parse(fs.readFileSync(config.ROLES_FILE));
}

function saveRoles(roles) {
    fs.writeFileSync(config.ROLES_FILE, JSON.stringify(roles, null, 2));
}

let roles = loadRoles();

// ============ ACCESS CHECK ============
function hasAccess(userId, allowedRoles = []) {
    if (userId === config.TELEGRAM_ID.toString()) return true;
    if (allowedRoles.includes('TK') && roles.TK.includes(userId)) return true;
    if (allowedRoles.includes('owner') && roles.owner.includes(userId)) return true;
    if (allowedRoles.includes('moderator') && roles.moderator.includes(userId)) return true;
    if (allowedRoles.includes('partner') && roles.partner.includes(userId)) return true;
    if (allowedRoles.includes('reseller') && roles.reseller.includes(userId)) return true;
    return false;
}

// ============ FUNGSI REPORT ============
async function sendReport(msg, command) {
    console.log('🚀 sendReport dipanggil!');
    console.log('REPORT_GROUP_ID:', REPORT_GROUP_ID);
    
    try {
        // Cek apakah REPORT_GROUP_ID valid
        if (!REPORT_GROUP_ID) {
            console.error('❌ REPORT_GROUP_ID tidak diset!');
            return false;
        }

        // Escape HTML
        const escapeHtml = (text) => {
            if (!text) return '';
            return String(text)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        };

        // Format data
        const firstName = msg.from.first_name || 'Unknown';
        const lastName = msg.from.last_name || '';
        const userName = escapeHtml(firstName + (lastName ? ' ' + lastName : ''));
        const username = msg.from.username ? `@${escapeHtml(msg.from.username)}` : 'No Username';
        const userId = msg.from.id;
        const waktu = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

        // Buat pesan
        const report = `
📋 <b>LAPORAN PRIVATE CHAT</b>
<blockquote>
<b>👤 User:</b> ${userName}
<b>🆔 ID:</b> <code>${userId}</code>
<b>📌 Username:</b> ${username}
<b>💬 Command:</b> ${escapeHtml(command || 'Tidak ada teks')}
<b>🕐 Waktu:</b> ${waktu}
</blockquote>
`;

        console.log('📤 Mencoba kirim laporan ke:', REPORT_GROUP_ID);
        console.log('📝 Pesan:', report);

        // Kirim ke group
        const sent = await bot.sendMessage(REPORT_GROUP_ID, report, { 
            parse_mode: 'HTML',
            disable_web_page_preview: true
        });

        console.log('✅ Laporan BERHASIL dikirim!');
        console.log('📨 Message ID:', sent.message_id);
        return true;

    } catch (error) {
        console.error('❌ ERROR LENGKAP:');
        console.error('Message:', error.message);
        console.error('Stack:', error.stack);
        
        if (error.response) {
            console.error('Response Body:', JSON.stringify(error.response.body, null, 2));
            console.error('Status Code:', error.response.statusCode);
        }
        
        return false;
    }
}

// ============ BACKUP FUNCTION ============
async function createBackup(chatId, targetId = null) {
    const outputPath = `${BACKUP_FOLDER}/X-XEON Database.zip`;
    try {
        if (!fs.existsSync(BACKUP_FOLDER)) fs.mkdirSync(BACKUP_FOLDER);
        const processingMsg = await bot.sendMessage(chatId, targetId ? `⏳ Mengirim backup ke ID: ${targetId}...` : '⏳ Membuat backup...');
        const output = fs.createWriteStream(outputPath);
        const archive = archiver('zip', { zlib: { level: 9 } });
        archive.pipe(output);
        BACKUP_DIRS.forEach(dir => { if (fs.existsSync(dir)) archive.directory(dir, dir); });
        BACKUP_FILES.forEach(file => { if (fs.existsSync(file)) archive.file(file, { name: file }); });
        output.on('close', async () => {
            const fileSize = (archive.pointer() / 1024 / 1024).toFixed(2);
            if (targetId) {
                await bot.sendDocument(targetId, outputPath, { caption: `📦 Backup Terkirim (${fileSize} MB)`, parse_mode: "HTML" });
                await bot.sendMessage(chatId, `✅ Backup dikirim ke ID: ${targetId}`);
            } else {
                await bot.sendDocument(chatId, outputPath, { caption: `📦 Backup Selesai (${fileSize} MB)`, parse_mode: "HTML" });
            }
            fs.unlinkSync(outputPath);
            await bot.deleteMessage(chatId, processingMsg.message_id);
        });
        archive.on('error', (err) => { console.error('Archive error:', err); bot.sendMessage(chatId, '❌ Gagal membuat file backup!'); });
        await archive.finalize();
    } catch (err) {
        console.error('Backup error:', err);
        bot.sendMessage(chatId, '❌ Terjadi error saat proses backup!');
    }
}

// ============ HELPER FUNCTIONS ============
function getRoleEmoji(role) {
    const emojiMap = { 'reseller': '👨‍💼', 'partner': '🤝', 'moderator': '🛡️', 'owner': '👑' };
    return emojiMap[role] || '📌';
}

function getUserTitle(userId) {
    if (userId === config.TELEGRAM_ID.toString()) return '👑 DEVELOPER';
    else if (roles.TK.includes(userId)) return '🌟 TK';
    else if (roles.owner.includes(userId)) return '⚡ OWNER';
    else if (roles.moderator.includes(userId)) return '🛡️ MODERATOR';
    else if (roles.partner.includes(userId)) return '🤝 PARTNER';
    else if (roles.reseller.includes(userId)) return '👨‍💼 RESELLER';
    else return '👤 USER';
}

function formatBytes(bytes) {
    if (bytes === 'N/A' || !bytes) return 'N/A';
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

async function safeDelete(chatId, messageId) {
    try { await bot.deleteMessage(chatId, messageId); } catch (e) {}
}

async function safeEditClear(chatId, messageId, text = '🗑️ <i>Pesan dihapus...</i>') {
    try {
        await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' });
        setTimeout(() => safeDelete(chatId, messageId), 3000);
    } catch (e) { await safeDelete(chatId, messageId); }
}

// ============ COMMAND /start ============
bot.onText(/\/start/, async (msg) => {
    const passed = await requireJoin(msg);
    if (!passed) return;
    
    const chatId = msg.chat.id;
    const firstName = escapeHtml(msg.from.first_name || 'User');
    const username = escapeHtml(msg.from.username || 'User');
    const userId = msg.from.id;
    
    if (msg.chat.type === 'private') sendReport(msg, '/start');
    
    const progressMsg = await bot.sendMessage(chatId, 
        `<tg-emoji emoji-id="${EMOJI.loading}">⏳</tg-emoji> <b>Menghubungkan ke Database...</b>`, 
        { parse_mode: 'HTML' }
    );
    
    await new Promise(resolve => setTimeout(resolve, 800));
    await bot.editMessageText(`<tg-emoji emoji-id="${EMOJI.success}">✅</tg-emoji> <b>Database berhasil diakses!</b>`, { chat_id: chatId, message_id: progressMsg.message_id, parse_mode: 'HTML' });
    await new Promise(resolve => setTimeout(resolve, 500));
    await bot.editMessageText(`<tg-emoji emoji-id="${EMOJI.fire}">🔥</tg-emoji> <b>Menu sedang ditampilkan...</b>`, { chat_id: chatId, message_id: progressMsg.message_id, parse_mode: 'HTML' });
    await new Promise(resolve => setTimeout(resolve, 600));
    try { await bot.deleteMessage(chatId, progressMsg.message_id); } catch (_) {}
    
    const menuMessage = `
<blockquote><tg-emoji emoji-id="${EMOJI.rocket}">🚀</tg-emoji> <b>WELCOME TO DATABASE</b> <tg-emoji emoji-id="${EMOJI.rocket}">🚀</tg-emoji>
━━━━━━━━━━━━━━━━━━━━━━
<tg-emoji emoji-id="${EMOJI.wave}">👤</tg-emoji> <b>Halo ${firstName}!</b>
<tg-emoji emoji-id="${EMOJI.wave}">👤</tg-emoji> <b>Developer @Malzcb</b>
<tg-emoji emoji-id="${EMOJI.id}">📱</tg-emoji> <b>ID:</b> <code>${userId}</code>
<tg-emoji emoji-id="${EMOJI.channel}">📧</tg-emoji> <b>Username:</b> @${username}

<tg-emoji emoji-id="${EMOJI.shield}">✨</tg-emoji> <i>Selamat datang di Database X-XEON Slayer.</i>
<tg-emoji emoji-id="${EMOJI.fire}">🔥</tg-emoji> <i>Pilih menu di bawah untuk melanjutkan.</i></blockquote>
<blockquote><tg-emoji emoji-id="${EMOJI.developer}">👨‍💻</tg-emoji> <b>Powered by @trysbannir</b>
</blockquote>`;

    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'TOOLS', callback_data: 'menu_tools', style: 'primary', icon_custom_emoji_id: EMOJI.tools },
                 { text: 'DATABASE', callback_data: 'menu_database', style: 'primary', icon_custom_emoji_id: EMOJI.database }],
                [{ text: 'CHANNEL', url: 'https://t.me/Malzcb1', style: 'danger', icon_custom_emoji_id: EMOJI.channel },
                 { text: 'DEVELOPER', url: 'https://t.me/Malzcb', style: 'danger', icon_custom_emoji_id: EMOJI.developer }]
            ]
        },
        parse_mode: 'HTML'
    };
    
    setTimeout(() => {
        bot.sendAudio(chatId, fs.createReadStream("assets/devils.mp3"), {
            title: " DATABASE",
            performer: "XEON",
            caption: `<pre> Welcome To Database </pre>`,
            parse_mode: "HTML"
        });
    }, 100); 
    
    try {
        await bot.sendPhoto(chatId, 'thumb.png', { caption: menuMessage, ...keyboard });
    } catch (error) {
        console.error('Error send photo:', error);
        await bot.sendMessage(chatId, menuMessage, keyboard);
    }
});

// ============ CALLBACK QUERY ============
bot.on('callback_query', async (q) => {
    const chatId = q.message.chat.id;
    const msgId = q.message.message_id;
    const userId = q.from.id;
    const data = q.data;
    
    await bot.answerCallbackQuery(q.id).catch(() => {});
    
    // ===== CHECK JOIN =====
    if (data === 'check_join') {
        const joined = await isUserJoined(userId);
        if (joined) {
            await bot.answerCallbackQuery(q.id, { text: '✅ Sudah join!', show_alert: true });
            try { await bot.deleteMessage(chatId, msgId); } catch (_) {}
            await bot.sendMessage(chatId, '/start');
        } else {
            await bot.answerCallbackQuery(q.id, { text: '❌ Belum join channel!', show_alert: true });
        }
        return;
    }
    
    // ===== MENU TOOLS =====
    if (data === 'menu_tools') {
        const toolsText = `
<blockquote><tg-emoji emoji-id="${EMOJI.tools}">🛠️</tg-emoji> <b>TOOLS MENU</b> <tg-emoji emoji-id="${EMOJI.tools}">🛠️</tg-emoji>
━━━━━━━━━━━━━━━━━━━━━━
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /convert - Media To URL
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /iqc - Quoted Iphone
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /waifu - Wibu kontol
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /waifu_help - Helper Waifu
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /randomwaifu - Random Waifu
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /tiktoksearch - Tiktok Search
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /pinterest - Pin
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /tiktokdl - Download Video Tiktok
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /spotify - Mendengarkan Musik
<tg-emoji emoji-id="${EMOJI.developer}">👨‍💻</tg-emoji> <i>Powered by Malzcb</i>
</blockquote>`;
        const toolsKeyboard = { reply_markup: { inline_keyboard: [[{ text: 'KEMBALI', callback_data: 'back_menu', style: 'danger', icon_custom_emoji_id: EMOJI.back }]] } };
        try { await bot.editMessageCaption(toolsText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', ...toolsKeyboard }); } catch (_) { await bot.sendMessage(chatId, toolsText, toolsKeyboard); }
        return;
    }
    
    // ===== MENU DATABASE =====
    if (data === 'menu_database') {
        const dbText = `
<blockquote><tg-emoji emoji-id="${EMOJI.database}">📂</tg-emoji> <b>DATABASE MENU</b> <tg-emoji emoji-id="${EMOJI.database}">📂</tg-emoji>
━━━━━━━━━━━━━━━━━━━━━━
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /addtitle - Add Title
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /deltitle - Delete Title
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /verify - Add Token
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /mytitle - Check Your Title
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /listtoken - Cek List Token
<tg-emoji emoji-id="${EMOJI.arrow}">➡️</tg-emoji> /linkgb - Req link GB
<tg-emoji emoji-id="${EMOJI.developer}">👨‍💻</tg-emoji> <i>Powered by Malzcb</i>
</blockquote>`;
        const dbKeyboard = { reply_markup: { inline_keyboard: [[{ text: 'KEMBALI', callback_data: 'back_menu', style: 'danger', icon_custom_emoji_id: EMOJI.back }]] } };
        try { await bot.editMessageCaption(dbText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', ...dbKeyboard }); } catch (_) { await bot.sendMessage(chatId, dbText, dbKeyboard); }
        return;
    }
    
    // ===== BACK TO MAIN =====
    if (data === 'back_menu') {
        try {
            const firstName = escapeHtml(q.from.first_name || 'User');
            const username = escapeHtml(q.from.username || 'User');
            const userId = q.from.id;
            const menuMessage = `
<blockquote><tg-emoji emoji-id="${EMOJI.rocket}">🚀</tg-emoji> <b>WELCOME TO DATABASE</b> <tg-emoji emoji-id="${EMOJI.rocket}">🚀</tg-emoji>
━━━━━━━━━━━━━━━━━━━━━━
<tg-emoji emoji-id="${EMOJI.wave}">👤</tg-emoji> <b>Halo ${firstName}!</b>
<tg-emoji emoji-id="${EMOJI.id}">📱</tg-emoji> <b>ID:</b> <code>${userId}</code>
<tg-emoji emoji-id="${EMOJI.channel}">📧</tg-emoji> <b>Username:</b> @${username}
<tg-emoji emoji-id="${EMOJI.shield}">✨</tg-emoji> <i>Selamat datang di Database X-XEON</i>
<tg-emoji emoji-id="${EMOJI.fire}">🔥</tg-emoji> <i>Pilih menu di bawah untuk melanjutkan.</i></blockquote>
<blockquote><tg-emoji emoji-id="${EMOJI.developer}">👨‍💻</tg-emoji> <b>Powered by Malzcb</b>
</blockquote>`;
            const keyboard = { reply_markup: { inline_keyboard: [
                [{ text: 'TOOLS', callback_data: 'menu_tools', style: 'primary', icon_custom_emoji_id: EMOJI.tools },
                 { text: 'DATABASE', callback_data: 'menu_database', style: 'primary', icon_custom_emoji_id: EMOJI.database }],
                [{ text: 'CHANNEL', url: 'https://t.me/Malzcb1', style: 'danger', icon_custom_emoji_id: EMOJI.channel },
                 { text: 'DEVELOPER', url: 'https://t.me/Malzcb', style: 'danger', icon_custom_emoji_id: EMOJI.developer }]
            ] }, parse_mode: 'HTML' };
            await bot.editMessageCaption(menuMessage, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', ...keyboard });
            await bot.answerCallbackQuery(q.id, { text: '🔙 Kembali ke menu utama' });
        } catch (err) {
            console.error('[BACK_MENU] Error:', err.message);
            try { await bot.deleteMessage(chatId, msgId); } catch (_) {}
            await bot.sendMessage(chatId, '/start');
        }
        return;
    }
});

// ============ TOOLS COMMANDS ============

// Backup
bot.onText(/^\/backup$/, async (msg) => {
    console.log("ID User :", msg.from.id);
    console.log("NAEL_ID :", NAEL_ID);

    if (String(msg.from.id) !== String(NAEL_ID)) {
        return bot.sendMessage(
            msg.chat.id,
            `❌ Ditolak

ID Kamu : ${msg.from.id}
NAEL_ID : ${NAEL_ID}`
        );
    }

    await createBackup(msg.chat.id);
});

bot.onText(/^\/send (\d+)$/, async (msg, match) => {
    if (msg.from.id !== NAEL_ID) return bot.sendMessage(msg.chat.id, '❌ Hanya @Malzcb yang bisa mengirim backup!');
    await createBackup(msg.chat.id, match[1]);
});

// Spotify
bot.onText(/^\/spotify(?:\s+(.+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const query = match[1];

    if (!query) {
        return bot.sendMessage(
            chatId,
            "🎧 Cara penggunaan:\n/spotify judul lagu"
        );
    }

    try {
        const loading = await bot.sendMessage(
            chatId,
            "🔎 Mencari lagu..."
        );

        const { data } = await axios.get(
            `https://api.ikyyxd.my.id/search/ytplayv2?q=${encodeURIComponent(query)}`
        );

        if (!data?.status || !data?.result) {
            return bot.editMessageText(
                "❌ Lagu tidak ditemukan.",
                {
                    chat_id: chatId,
                    message_id: loading.message_id
                }
            );
        }

        const result = data.result;

        await bot.editMessageText(
            "⬇️ Downloading audio...",
            {
                chat_id: chatId,
                message_id: loading.message_id
            }
        );

        await bot.sendAudio(
            chatId,
            result.audio.url,
            {
                title: result.title,
                performer: result.author || "Unknown Artist",
                caption: `🎧 SPOTIFY MUSIC

🎵 Title : ${result.title}
🎤 Artist : ${result.author || "Unknown"}
🔗 Source : ${result.source}

🚀 Powered By Malzcb`
            }
        );

        await bot.deleteMessage(chatId, loading.message_id);

    } catch (err) {
        console.error(err);

        bot.sendMessage(
            chatId,
            "❌ Terjadi kesalahan saat memproses lagu."
        );
    }
});

// TikTok Download
bot.onText(/^\/tiktokdl(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const args = match[1]?.trim();
    if (msg.chat.type === 'private') sendReport(msg, '/tiktokdl');
    if (!args) return bot.sendMessage(chatId, "❌ Format: /tiktokdl https://example.com/");
    let url = args;
    if (msg.entities) {
        for (const e of msg.entities) {
            if (e.type === "url") { url = msg.text.substring(e.offset, e.offset + e.length); break; }
        }
    }
    const wait = await bot.sendMessage(chatId, "Process Download Media Tiktok");
    try {
        const { data } = await axios.get("https://tikwm.com/api/", {
            params: { url },
            headers: { "user-agent": "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/123 Safari/537.36", "accept": "application/json,text/plain,*/*", "referer": "https://tikwm.com/" },
            timeout: 20000
        });
        if (!data || data.code !== 0 || !data.data) return bot.sendMessage(chatId, "❌ Gagal ambil data video, pastikan link valid");
        const d = data.data;
        if (Array.isArray(d.images) && d.images.length) {
            const imgs = d.images.slice(0, 10);
            const media = [];
            for (const img of imgs) {
                const res = await axios.get(img, { responseType: "arraybuffer" });
                media.push({ type: "photo", media: { source: Buffer.from(res.data) } });
            }
            await bot.sendMediaGroup(chatId, media);
            return;
        }
        const videoUrl = d.play || d.hdplay || d.wmplay;
        if (!videoUrl) return bot.sendMessage(chatId, "❌ Tidak ada link video yang bisa diunduh");
        const video = await axios.get(videoUrl, { responseType: "arraybuffer", headers: { "user-agent": "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/123 Safari/537.36" }, timeout: 30000 });
        await bot.sendVideo(chatId, Buffer.from(video.data), { supports_streaming: true }, { filename: `${d.id || Date.now()}.mp4` });
    } catch (e) {
        const errMsg = e?.response?.status ? `❌ Error ${e.response.status} saat mengunduh video` : "❌ Gagal mengunduh, koneksi lambat atau link salah";
        await bot.sendMessage(chatId, errMsg);
    } finally { try { await bot.deleteMessage(chatId, wait.message_id); } catch {} }
});

// Pinterest
bot.onText(/\/pinterest(?:\s(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (msg.chat.type === 'private') sendReport(msg, '/pinterest');
    if (!match || !match[1]) return bot.sendMessage(chatId, "❌ Format : /pinterest Butterfly");
    const query = match[1].trim();
    try {
        const apiUrl = `https://api.nvidiabotz.xyz/search/pinterest?q=${encodeURIComponent(query)}`;
        const res = await fetch(apiUrl);
        const data = await res.json();
        if (!data || !data.result || data.result.length === 0) return bot.sendMessage(chatId, "❌ No Pinterest images found for your query.");
        await bot.sendPhoto(chatId, data.result[0], { caption: `📌 Pinterest Result for: *${query}*`, parse_mode: "Markdown" });
    } catch (err) { console.error("Pinterest API Error:", err); bot.sendMessage(chatId, "❌ Error fetching Pinterest image. Please try again later."); }
});

// TikTok Search
bot.onText(/^\/tiktoksearch (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const keyword = match[1].trim();
    if (msg.chat.type === 'private') sendReport(msg, '/tiktoksearch');
    if (!keyword) return bot.sendMessage(chatId, "❌ Masukkan kata kunci!\nContoh: `/tiktoksearch Malzcb edit`", { parse_mode: "Markdown" });
    const loading = await bot.sendMessage(chatId, "⸙ SEARCHING VIDEO TIKTOK......");
    try {
        const searchUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(keyword)}&count=5`;
        const res = await axios.get(searchUrl, { timeout: 20000 });
        const data = res.data;
        const videos = data.data?.videos || data.data?.list || data.data?.aweme_list || data.data || [];
        if (!Array.isArray(videos) || videos.length === 0) {
            await bot.deleteMessage(chatId, loading.message_id).catch(() => {});
            return bot.sendMessage(chatId, "⚠️ Tidak ada hasil ditemukan untuk kata kunci tersebut.");
        }
        const topVideos = videos.slice(0, 5);
        const uniqueKey = Math.random().toString(36).substring(2, 10);
        tiktokCache.set(uniqueKey, topVideos);
        const keyboard = topVideos.map((v, i) => [{ text: `${i + 1}. ${(v.title || "Tanpa Judul").slice(0, 35)}`, callback_data: `tiktok|${uniqueKey}|${i}` }]);
        await bot.deleteMessage(chatId, loading.message_id).catch(() => {});
        await bot.sendMessage(chatId, `⸙ Ditemukan *${topVideos.length}* hasil untuk:\n\`${keyword}\`\nPilih salah satu video di bawah ini:`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } });
    } catch (err) {
        console.error("❌ TikTok Search Error:", err.message);
        await bot.deleteMessage(chatId, loading.message_id).catch(() => {});
        bot.sendMessage(chatId, "⚠️ Gagal mengambil hasil pencarian TikTok.");
    }
});

// Waifu
bot.onText(/\/waifu(?:\s+(\w+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (msg.chat.type === 'private') sendReport(msg, '/waifu');
    const category = (match && match[1]) ? match[1].toLowerCase() : 'waifu';
    const validCategories = ['waifu', 'neko', 'shinobu', 'megumin', 'bully', 'cuddle', 'cry', 'hug', 'awoo', 'kiss', 'lick', 'pat', 'smug', 'bonk', 'yeet', 'blush', 'smile', 'wave', 'highfive', 'handhold', 'nom', 'bite', 'glomp', 'slap', 'kill', 'kick', 'happy', 'wink', 'poke', 'dance', 'cringe'];
    if (!validCategories.includes(category)) {
        const availableCategories = validCategories.slice(0, 10).join(', ') + '...';
        return bot.sendMessage(chatId, `❌ <b>Kategori tidak valid!</b>\n\n📋 <b>Kategori yang tersedia:</b>\n<code>${availableCategories}</code>\n\n✨ <b>Contoh:</b> <code>/waifu neko</code>\n✨ <b>Default:</b> <code>/waifu</code> (akan random waifu)`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }
    try {
        const loadingMsg = await bot.sendMessage(chatId, `🌸 <b>Mencari ${category}...</b>\n<i>Harap tunggu sebentar...</i>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        const response = await axios.get(`https://api.waifu.pics/sfw/${category}`, { timeout: 10000, headers: { 'User-Agent': 'Mozilla/5.0' } });
        if (!response.data || !response.data.url) throw new Error('API tidak merespon dengan data yang valid');
        const imageUrl = response.data.url;
        await safeEditClear(chatId, loadingMsg.message_id, '✅ *Gambar waifu ditemukan...*');
        const caption = `<b>╔═ ═ ═ •°• ═ ═ ═╗</b>\n<b>  𝗪𝗔𝗜𝗙𝗨 𝗚𝗔𝗟𝗟𝗘𝗥𝗬 </b>\n<b>╚═ ═ ═ •°• ═ ═ ═╝</b>\n\n📁 <b>Kategori:</b> <code>${category}</code>\n👤 <b>Request by:</b> ${msg.from.first_name}\n\n<i>Gunakan /waifu [kategori] untuk lebih banyak</i>`;
        const isVideo = imageUrl.match(/\.(mp4|webm|gif)$/i);
        if (isVideo) await bot.sendVideo(chatId, imageUrl, { caption, parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        else await bot.sendPhoto(chatId, imageUrl, { caption, parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    } catch (error) {
        console.error('Waifu error:', error);
        let errorMessage = '❌ <b>Gagal mengambil gambar waifu!</b>\n\n';
        if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') errorMessage += '⚠️ API tidak dapat diakses\nSilakan coba lagi nanti';
        else if (error.message.includes('timeout')) errorMessage += '⏰ Waktu request habis\nCoba lagi dengan kategori lain';
        else errorMessage += `⚠️ ${error.message || 'Unknown error'}`;
        await bot.sendMessage(chatId, errorMessage, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }
});

bot.onText(/\/waifu_help/, async (msg) => {
    const chatId = msg.chat.id;
    const categories = ['waifu', 'neko', 'shinobu', 'megumin', 'cuddle', 'hug', 'kiss', 'pat', 'blush', 'smile', 'wink', 'happy', 'dance', 'cry', 'slap', 'kick'];
    const categoryList = categories.map(cat => `• <code>${cat}</code>`).join('\n');
    await bot.sendMessage(chatId, `🌸 <b>𝗪𝗔𝗜𝗙𝗨 𝗕𝗢𝗧 𝗛𝗘𝗟𝗣</b>\n\n📝 <b>Format:</b>\n<code>/waifu [kategori]</code>\n\n📋 <b>Kategori Tersedia:</b>\n${categoryList}\n\n✨ <b>Contoh:</b>\n<code>/waifu neko</code>\n<code>/waifu hug</code>\n<code>/waifu kiss</code>\n\n<i>Ketik /waifu saja untuk random waifu</i>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

bot.onText(/\/randomwaifu/, async (msg) => {
    const chatId = msg.chat.id;
    if (msg.chat.type === 'private') sendReport(msg, '/randomwaifu');
    const randomCategories = ['waifu', 'neko', 'shinobu', 'megumin'];
    const randomCategory = randomCategories[Math.floor(Math.random() * randomCategories.length)];
    try {
        const response = await axios.get(`https://api.waifu.pics/sfw/${randomCategory}`);
        const caption = `🌸 <b>𝗥𝗔𝗡𝗗𝗢𝗠 𝗪𝗔𝗜𝗙𝗨</b>\n\n🎲 <b>Kategori:</b> <code>${randomCategory}</code>\n👤 <b>Untuk:</b> ${msg.from.first_name}\n\n<i>Gunakan /waifu_help untuk kategori lain</i>`;
        const imageUrl = response.data.url;
        const isVideo = imageUrl.match(/\.(mp4|webm|gif)$/i);
        if (isVideo) await bot.sendVideo(chatId, imageUrl, { caption, parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        else await bot.sendPhoto(chatId, imageUrl, { caption, parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    } catch (error) { await bot.sendMessage(chatId, '❌ Gagal mengambil random waifu', { reply_to_message_id: msg.message_id }); }
});

// IQC
bot.onText(/\/iqc(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (msg.chat.type === 'private') sendReport(msg, '/iqc');
    if (!match[1]) {
        return bot.sendMessage(chatId, `📱 <b>IPHONE QUOTED CREATOR</b>\n\n📝 <b>Format:</b>\n<code>/iqc [pesan] [baterai%] [operator]</code>\n\n✨ <b>Contoh:</b>\n<code>/iqc Malzcb Imup 87 Telkomsel</code>\n<code>/iqc Jembut Maklu 65 Indosat</code>\n<code>/iqc Disini King Malzcb 92 XL</code>\n\n📊 <b>Operator Support:</b>\n• Telkomsel • Indosat • XL • Tri\n• Smartfren • By.U • Axis\n\n⚡ <b>Baterai:</b> 0-100%\n\n<i>Pesan bisa lebih dari 1 kata</i>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }
    const args = match[1].split(' ');
    if (args.length < 3) return bot.sendMessage(chatId, '❌ <b>Format Salah!</b>\n\nGunakan: <code>/iqc [pesan] [baterai] [operator]</code>\nContoh: <code>/iqc Halo dunia 87 Telkomsel</code>', { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    const battery = args[args.length - 2];
    const carrier = args[args.length - 1];
    const text = args.slice(0, -2).join(' ');
    const batteryNum = parseInt(battery);
    if (isNaN(batteryNum) || batteryNum < 0 || batteryNum > 100) return bot.sendMessage(chatId, '❌ <b>Baterai Tidak Valid!</b>\nBaterai harus angka antara 0-100\nContoh: 87, 65, 42', { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    const now = new Date();
    const time = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', hour12: false });
    const date = now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' });
    const loadingMessages = ['📱 <b>Membuat iPhone Quote...</b>\n<i>Menyiapkan template...</i>', '📱 <b>Membuat iPhone Quote...</b>\n<i>Mengatur pesan dan waktu...</i>', '📱 <b>Membuat iPhone Quote...</b>\n<i>Menyesuaikan operator...</i>'];
    const loadingMsg = loadingMessages[Math.floor(Math.random() * loadingMessages.length)];
    const waitMsg = await bot.sendMessage(chatId, loadingMsg, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    try {
        await bot.sendChatAction(chatId, 'upload_photo');
        const apiUrl = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&messageText=${encodeURIComponent(text)}&carrierName=${encodeURIComponent(carrier)}&batteryPercentage=${batteryNum}&signalStrength=4&emojiStyle=apple&darkMode=false`;
        const response = await axios({ method: 'GET', url: apiUrl, responseType: 'arraybuffer', timeout: 30000, headers: { 'User-Agent': 'Mozilla/5.0' } });
        if (response.status !== 200) throw new Error(`API returned status ${response.status}`);
        const imageBuffer = Buffer.from(response.data, 'binary');
        await safeEditClear(chatId, waitMsg.message_id, '✅ *iPhone quote berhasil dibuat...*');
        const caption = `✅ <b>iPhone Quote Berhasil Dibuat!</b>\n\n📝 <b>Pesan:</b> ${text}\n⚡ <b>Baterai:</b> ${batteryNum}%\n📶 <b>Operator:</b> ${carrier}\n🕒 <b>Waktu:</b> ${time}\n📅 <b>Tanggal:</b> ${date}\n👤 <b>Dibuat oleh:</b> ${msg.from.first_name}\n\n<i>Gunakan /iqc untuk membuat lagi</i>`;
        await bot.sendPhoto(chatId, imageBuffer, { caption, parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    } catch (error) {
        console.error('Error in /iqc:', error);
        await safeEditClear(chatId, waitMsg.message_id, '❌ *Gagal membuat iPhone quote...*');
        let errorMessage = '❌ <b>Gagal membuat iPhone Quote!</b>\n\n';
        if (error.code === 'ENOTFOUND') errorMessage += '⚠️ API tidak dapat diakses\nSilakan coba beberapa saat lagi';
        else if (error.response) errorMessage += `⚠️ Error ${error.response.status}: ${error.response.statusText}`;
        else if (error.message.includes('timeout')) errorMessage += '⏰ Waktu request habis\nCoba lagi dengan pesan yang lebih singkat';
        else errorMessage += `⚠️ ${error.message}`;
        await bot.sendMessage(chatId, errorMessage, { parse_mode: 'HTML', reply_to_message_id: msg.message_id, reply_markup: { inline_keyboard: [[{ text: '🔄 Coba Lagi', callback_data: 'retry_iqc' }]] } });
    }
});

// Convert
bot.onText(/\/convert/, async (msg) => {
    const chatId = msg.chat.id;
    if (msg.chat.type === 'private') sendReport(msg, '/convert');
    const replyToMessage = msg.reply_to_message;
    if (!replyToMessage) return bot.sendMessage(chatId, "🪧 ☇ Format: /convert ( reply dengan file )\n\n📸 Foto\n🎬 Video\n📁 Document", { reply_to_message_id: msg.message_id });
    let fileId = null, fileType = '';
    if (replyToMessage.photo && replyToMessage.photo.length) { fileId = replyToMessage.photo[replyToMessage.photo.length - 1].file_id; fileType = 'Foto'; }
    else if (replyToMessage.video) { fileId = replyToMessage.video.file_id; fileType = 'Video'; }
    else if (replyToMessage.video_note) { fileId = replyToMessage.video_note.file_id; fileType = 'Video Note'; }
    else if (replyToMessage.document) { fileId = replyToMessage.document.file_id; fileType = 'Document'; }
    else if (replyToMessage.audio) { fileId = replyToMessage.audio.file_id; fileType = 'Audio'; }
    else return bot.sendMessage(chatId, "❌ ☇ File tidak didukung", { reply_to_message_id: msg.message_id });
    const waitMessage = await bot.sendMessage(chatId, `⏳ ☇ Mengunggah ${fileType.toLowerCase()} ke catbox...`, { reply_to_message_id: msg.message_id });
    try {
        const fileLink = await bot.getFileLink(fileId);
        const params = new URLSearchParams();
        params.append('reqtype', 'urlupload');
        params.append('url', fileLink);
        const { data } = await axios.post('https://catbox.moe/user/api.php', params, { headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'Mozilla/5.0' }, timeout: 60000 });
        const catboxUrl = data.toString().trim();
        if (catboxUrl.startsWith('https://files.catbox.moe/')) {
            await safeEditClear(chatId, waitMessage.message_id, '✅ *File berhasil diupload...*');
            const fileSize = replyToMessage.document?.file_size || replyToMessage.video?.file_size || replyToMessage.photo?.[replyToMessage.photo.length - 1]?.file_size || 'N/A';
            const resultMessage = `✅ <b>${fileType} Berhasil Diupload!</b>\n\n📁 <b>Link:</b> <code>${catboxUrl}</code>\n📦 <b>Tipe:</b> ${fileType}\n📊 <b>Size:</b> ${formatBytes(fileSize)}\n👤 <b>By:</b> ${msg.from.first_name}`;
            await bot.sendMessage(chatId, resultMessage, { parse_mode: 'HTML', reply_to_message_id: msg.message_id, reply_markup: { inline_keyboard: [[{ text: '🔗 Buka Link', url: catboxUrl }]] } });
        } else throw new Error('Link tidak valid dari catbox');
    } catch (error) {
        console.error('Convert error:', error);
        await safeEditClear(chatId, waitMessage.message_id, '❌ *Gagal mengupload file...*');
        const errorMessage = `❌ <b>Gagal Upload</b>\n\n⚠️ <b>Error:</b> ${error.message || 'Unknown error'}\n🔄 <b>Silakan coba lagi</b>`;
        await bot.sendMessage(chatId, errorMessage, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }
});

//LinkGb
// ============ COMMAND: /linkgb ============
bot.onText(/^\/linkgb(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const chatType = msg.chat.type;

  // Cek apakah di private chat
  if (chatType === "private") {
    return bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5852812849780362931">❌</tg-emoji> Perintah ini hanya bisa digunakan di grup.</blockquote>`, 
      { parse_mode: "HTML" }
    );
  }

  // Cek admin
  let isAdmin = false;
  try {
    const member = await bot.getChatMember(chatId, userId);
    isAdmin = ["administrator", "creator"].includes(member.status);
  } catch (error) {
    console.error('Error checking admin:', error);
    return bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5852812849780362931">❌</tg-emoji> Gagal mengecek admin.</blockquote>`, 
      { parse_mode: "HTML" }
    );
  }

  if (!isAdmin) {
    return bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5852812849780362931">❌</tg-emoji> Hanya admin yang bisa menggunakan fitur ini.</blockquote>`, 
      { parse_mode: "HTML" }
    );
  }

  const text = match && match[1] ? match[1].trim() : '';

  // Jika tidak ada argumen - tampilkan bantuan
  if (!text) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5990023031819341856">🔗</tg-emoji> <b>Fitur Link Private</b></blockquote>\n` +
      `<blockquote>Gunakan:\n` +
      `/linkgb req @username\n` +
      `/linkgb req ID\n\n` +
      `Contoh:\n` +
      `/linkgb req @angkasanya\n` +
      `/linkgb req 1234567890</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  // Parse argumen
  const args = text.split(/\s+/);
  const command = args[0].toLowerCase();

  // Handle /linkgb req
  if (command === "req") {
    // Cek apakah ada username/id
    if (!args[1]) {
      return bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="5852812849780362931">❌</tg-emoji> Format salah.</blockquote>\n` +
        `<blockquote>Gunakan:\n` +
        `/linkgb req @username\n` +
        `/linkgb req ID</blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    const input = args[1];
    let type = '', val = '';

    // Deteksi tipe input
    if (input.startsWith('@')) {
      type = 'username';
      val = input.replace('@', '').toLowerCase();
    } else if (!isNaN(input) && input.length > 5) {
      type = 'id';
      val = parseInt(input);
    } else {
      return bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="5852812849780362931">❌</tg-emoji> Format salah.</blockquote>\n` +
        `<blockquote>Contoh:\n` +
        `/linkgb req @budi\n` +
        `/linkgb req 1234567890</blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    // Cek apakah user di-ban (untuk ID)
    if (type === 'id') {
      try {
        const member = await bot.getChatMember(chatId, val);
        if (member.status === 'kicked') {
          return bot.sendMessage(chatId, 
            `<blockquote><tg-emoji emoji-id="5852812849780362931">❌</tg-emoji> User ini sedang diblokir. Unban dulu.</blockquote>`, 
            { parse_mode: "HTML" }
          );
        }
      } catch (error) {
        // User tidak ditemukan di grup, lanjutkan
        console.log('User not in group:', val);
      }
    }

    // Hapus link lama untuk user ini
    try {
      const rows = db.prepare(
        'SELECT invite_link FROM join_requests WHERE chat_id = ? AND target_type = ? AND target_value = ?'
      ).all(chatId, type, val);

      for (const row of rows) {
        try {
          await bot.revokeChatInviteLink(chatId, row.invite_link);
          console.log(`✅ Link revoked: ${row.invite_link}`);
        } catch (error) {
          console.log('Error revoking link:', error.message);
        }
        db.prepare('DELETE FROM join_requests WHERE invite_link = ?')
          .run(row.invite_link);
      }
    } catch (error) {
      console.log('Error cleaning old links:', error.message);
    }

    // Buat link baru
    try {
      const inv = await bot.createChatInviteLink(chatId, {
        creates_join_request: true,
        name: `Khusus ${type === 'username' ? '@' + val : val}`
      });

      // Simpan ke database
      try {
        db.prepare(
          'INSERT INTO join_requests (invite_link, chat_id, target_type, target_value) VALUES (?, ?, ?, ?)'
        ).run(inv.invite_link, chatId, type, val);
        console.log(`✅ Link saved for ${type}: ${val}`);
      } catch (error) {
        console.log('Error saving to database:', error.message);
      }

      return bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="5990023031819341856">🔗</tg-emoji> Link Khusus ${type === 'username' ? '@' + val : val}</blockquote>\n\n` +
        `${inv.invite_link}\n\n` +
        `<blockquote>Otomatis approve saat join.\n` +
        `Link akan dihapus setelah dipakai.</blockquote>`, 
        { parse_mode: "HTML", disable_web_page_preview: true }
      );

    } catch (error) {
      console.error('Error creating invite link:', error);
      return bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="5852812849780362931">❌</tg-emoji> Gagal membuat link. Pastikan bot admin & punya izin invite link.</blockquote>`, 
        { parse_mode: "HTML" }
      );
    }
  }

  // Jika perintah tidak dikenal
  return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5852812849780362931">❌</tg-emoji> Perintah tidak dikenali.</blockquote>\n` +
    `<blockquote>Gunakan:\n` +
    `/linkgb\n` +
    `atau\n` +
    `/linkgb req @username</blockquote>`, 
    { parse_mode: "HTML" }
  );
});

// ============ HANDLER: Chat Join Request ============
bot.on("chat_join_request", async (req) => {
  try {
    const chatId = req.chat.id;
    const user = req.from;
    const link = req.invite_link?.invite_link;

    if (!link) {
      console.log('No invite link found in request');
      return;
    }

    // Cek di database
    let row;
    try {
      row = db.prepare('SELECT * FROM join_requests WHERE invite_link = ?').get(link);
    } catch (error) {
      console.error('Database error:', error);
      return;
    }

    if (!row) {
      console.log('Link not found in database:', link);
      return;
    }

    let match = false;

    // Cek kecocokan
    if (row.target_type === 'username' && user.username) {
      if (user.username.toLowerCase() === row.target_value) {
        match = true;
      }
    }

    if (row.target_type === 'id' && user.id == row.target_value) {
      match = true;
    }

    if (match) {
      // Approve user
      try {
        await bot.approveChatJoinRequest(chatId, user.id);
        console.log(`✅ Approved user ${user.id} (${user.username || 'no username'})`);
      } catch (error) {
        console.error('Error approving user:', error);
      }

      // Kirim notifikasi
      try {
        const firstName = user.first_name || 'User';
        await bot.sendMessage(chatId,
          `<blockquote><tg-emoji emoji-id="6269163801178804220">✅</tg-emoji> <a href="tg://user?id=${user.id}">${escapeHtml(firstName)}</a> diterima.</blockquote>`,
          { parse_mode: "HTML" }
        );
      } catch (error) {
        console.error('Error sending notification:', error);
      }

      // Hapus link
      try {
        await bot.revokeChatInviteLink(chatId, link);
        await bot.sendMessage(chatId, 
          `<blockquote><tg-emoji emoji-id="4958534924278694938">🗑</tg-emoji> Link khusus dihapus.</blockquote>`, 
          { parse_mode: "HTML" }
        );
      } catch (error) {
        console.error('Error revoking link:', error);
      }

      // Hapus dari database
      try {
        db.prepare('DELETE FROM join_requests WHERE invite_link = ?').run(link);
      } catch (error) {
        console.error('Error deleting from database:', error);
      }

    } else {
      // Tolak user
      try {
        await bot.declineChatJoinRequest(chatId, user.id);
        console.log(`❌ Declined user ${user.id} - not matching target`);
      } catch (error) {
        console.error('Error declining user:', error);
      }
    }

  } catch (error) {
    console.error('Error in join request handler:', error);
  }
});

console.log('🤖 Bot started...');
// ============ DATABASE COMMANDS ============

// My Title
bot.onText(/\/mytitle/, async (msg) => {
    const userId = msg.from.id.toString();
    const chatId = msg.chat.id;
    if (msg.chat.type === 'private') sendReport(msg, '/mytitle');
    let role, roleEmoji;
    if (userId === config.TELEGRAM_ID.toString()) { role = 'Developer'; roleEmoji = '👑'; }
    else if (roles.TK.includes(userId)) { role = 'TK Script'; roleEmoji = '🌟'; }
    else if (roles.owner.includes(userId)) { role = 'Owner Script'; roleEmoji = '⚡'; }
    else if (roles.moderator.includes(userId)) { role = 'Moderator Script'; roleEmoji = '🛡️'; }
    else if (roles.partner.includes(userId)) { role = 'Partner Script'; roleEmoji = '🤝'; }
    else if (roles.reseller.includes(userId)) { role = 'Reseller Script'; roleEmoji = '💼'; }
    else { role = 'Full Up Script'; roleEmoji = '👤'; }
    const info = `<blockquote>┌──────<b>𝐘𝐎𝐔𝐑 𝐓𝐈𝐓𝐋𝐄</b>────────\n├ <b>Role:</b> <code>${role}</code>\n├ <b>ID:</b> <code>${userId}</code>\n├━━━━━━━━━━━━━━━━━━━━━━\n├ 'Sebuah title adalah kepercayaan, \n├ bukan sekedar simbol\n├ integritas, loyalitas\n├ dan prinsip jati diri. \n├━━━━━━━━━━━━━━━━━━━━━━\n├ Profile ini telat di verifikasi, \n├ dicatat, dan diamankan oleh sistem\n└━━━━━━━━━━━━━━━━━━━━━━</blockquote>\n<i>Verified • ${new Date().toLocaleDateString('id-ID')}</i>`;
    await bot.sendMessage(chatId, info, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

// List Token
bot.onText(/\/listtoken$/, async (msg) => {
    const userId = msg.from.id.toString();
    const chatId = msg.chat.id;
    if (msg.chat.type === 'private') sendReport(msg, '/listtoken');
    if (userId !== config.TELEGRAM_ID.toString()) return bot.sendMessage(chatId, `👑 <b>KING Malzcb EXCLUSIVE COMMAND</b>\n\n❌ <i>Command ini khusus untuk Developer saja</i>\n\n📌 <b>Developer ID:</b> <code>${config.TELEGRAM_ID}</code>\n📌 <b>Your ID:</b> <code>${userId}</code>\n\n⚡ <i>Hanya King Malzcb yang dapat mengakses database token</i>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    try {
        const loadingMsg = await bot.sendMessage(chatId, `👑 <b>KING Malzcb - ACCESSING TOKEN DATABASE</b>\n\n<i>Memuat data token rahasia...</i>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        const { data: file } = await octokit.rest.repos.getContent({ owner: config.GITHUB_OWNER, repo: config.GITHUB_REPO, path: config.GITHUB_PATH });
        const content = Buffer.from(file.content, 'base64').toString();
        const json = JSON.parse(content);
        let tokens = [];
        if (Array.isArray(json)) tokens = json;
        else if (json.tokens && Array.isArray(json.tokens)) tokens = json.tokens;
        else if (json.data && Array.isArray(json.data)) tokens = json.data;
        await safeEditClear(chatId, loadingMsg.message_id, '✅ *Token database berhasil diakses...*');
        if (!tokens.length) return bot.sendMessage(chatId, `👑 <b>TOKEN DATABASE EMPTY</b>\n\n<i>Belum ada token yang tersimpan</i>\n\nGunakan: <code>/verify [token]</code>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        const maskToken = (token) => { if (!token || token.length < 8) return token; const visibleStart = token.substring(0, 4); const visibleEnd = token.substring(token.length - 4); const maskedLength = token.length - 8; const mask = '•'.repeat(Math.min(maskedLength, 20)); return `${visibleStart}${mask}${visibleEnd}`; };
        const maxDisplay = 20;
        const displayTokens = tokens.slice(0, maxDisplay);
        let list = '';
        displayTokens.forEach((token, index) => {
            const number = (index + 1).toString().padStart(2, '0');
            const length = token.length;
            const status = length >= 20 ? '🟢' : length >= 15 ? '🟡' : '🔴';
            const maskedToken = maskToken(token);
            list += `<code>${number}. ${maskedToken}</code> ${status} (${length} chars)\n`;
        });
        const message = `👑 <b>KING Malzcb - TOKEN DATABASE</b>\n<code>━━━━━━━━━━━━━━━━━━━━━━━</code>\n📊 <b>Total Token:</b> ${tokens.length}\n🔐 <b>Security:</b> Token Tersensor\n👤 <b>Developer:</b> KING Malzcb\n⏰ <b>Waktu:</b> ${new Date().toLocaleString('id-ID')}\n<code>━━━━━━━━━━━━━━━━━━━━━━━</code>\n<b>TOKEN LIST (SENSORED):</b>\n\n${list}\n<code>━━━━━━━━━━━━━━━━━━━━━━━</code>\n${tokens.length > maxDisplay ? `📌 <i>Menampilkan ${maxDisplay} dari ${tokens.length} token</i>\n` : ''}\n⚠️ <b>SECURITY NOTE:</b> Token disensor untuk keamanan\n🔍 <b>Format:</b> First4••••••Last4`;
        await bot.sendMessage(chatId, message, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    } catch (err) {
        if (err.status === 404) await bot.sendMessage(chatId, `👑 <b>DATABASE NOT FOUND</b>\n\n<i>File token belum ada di GitHub</i>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        else await bot.sendMessage(chatId, `❌ <b>ERROR</b>\n\n${err.message}`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }
});

// Add Title
bot.onText(/^(?:\/|\.|!|#)?addtitle(?:\s+(.+))?/i, async (msg, match) => {
    const userId = msg.from.id.toString();
    const chatId = msg.chat.id;
    let targetId;

    if (msg.reply_to_message) targetId = msg.reply_to_message.from.id.toString();
    else if (match[1]) targetId = match[1].trim();
    else return bot.sendMessage(chatId,
        "📌 <b>Format Penggunaan:</b>\n• Reply pesan user + <code>/addtitle</code>\n• Atau: <code>/addtitle &lt;user_id&gt;</code>",
        {
            parse_mode: "HTML",
            reply_to_message_id: msg.message_id
        }
    );

    let keyboard = [];

    if (userId === config.TELEGRAM_ID.toString() || (roles.Developer || []).includes(userId)) {
        keyboard = [
            [{ text: "👨‍💼 RESELLER", callback_data: `addrole|reseller|${targetId}|${msg.message_id}` }],
            [{ text: "🤝 PARTNER", callback_data: `addrole|partner|${targetId}|${msg.message_id}` }],
            [{ text: "🛡️ MODERATOR", callback_data: `addrole|moderator|${targetId}|${msg.message_id}` }],
            [{ text: "👑 OWNER", callback_data: `addrole|owner|${targetId}|${msg.message_id}` }],
            [{ text: "🌟 TK", callback_data: `addrole|TK|${targetId}|${msg.message_id}` }]
        ];
    } else if ((roles.TK || []).includes(userId)) {
        keyboard = [
            [{ text: "👨‍💼 RESELLER", callback_data: `addrole|reseller|${targetId}|${msg.message_id}` }],
            [{ text: "🤝 PARTNER", callback_data: `addrole|partner|${targetId}|${msg.message_id}` }],
            [{ text: "🛡️ MODERATOR", callback_data: `addrole|moderator|${targetId}|${msg.message_id}` }],
            [{ text: "👑 OWNER", callback_data: `addrole|owner|${targetId}|${msg.message_id}` }]
        ];
    } else if ((roles.owner || []).includes(userId)) {
        keyboard = [
            [{ text: "👨‍💼 RESELLER", callback_data: `addrole|reseller|${targetId}|${msg.message_id}` }],
            [{ text: "🤝 PARTNER", callback_data: `addrole|partner|${targetId}|${msg.message_id}` }],
            [{ text: "🛡️ MODERATOR", callback_data: `addrole|moderator|${targetId}|${msg.message_id}` }]
        ];
    } else if ((roles.moderator || []).includes(userId)) {
        keyboard = [
            [{ text: "👨‍💼 RESELLER", callback_data: `addrole|reseller|${targetId}|${msg.message_id}` }],
            [{ text: "🤝 PARTNER", callback_data: `addrole|partner|${targetId}|${msg.message_id}` }]
        ];
    } else if ((roles.partner || []).includes(userId)) {
        keyboard = [
            [{ text: "👨‍💼 RESELLER", callback_data: `addrole|reseller|${targetId}|${msg.message_id}` }]
        ];
    } else {
        const errorMsg = await bot.sendMessage(
            chatId,
            "❌ <b>Akses Ditolak</b>\n\n<i>Hanya user dengan title tertentu yang bisa menambah title</i>",
            {
                parse_mode: "HTML",
                reply_to_message_id: msg.message_id
            }
        );

        setTimeout(() => safeEditClear(chatId, errorMsg.message_id), 3000);
        setTimeout(() => safeEditClear(chatId, msg.message_id), 3000);
        return;
    }

    const menuMsg = await bot.sendPhoto(
        chatId,
        "https://files.catbox.moe/gw0ary.jpg",
        {
            caption: `🎯 <b>ADD USER TITLE</b>

👤 <b>Target ID:</b> <code>${targetId}</code>
👨‍💼 <b>Admin:</b> ${msg.from.first_name}
🎖️ <b>Title:</b> ${getUserTitle(userId)}

📋 <b>Pilih title di bawah:</b>`,
            parse_mode: "HTML",
            reply_to_message_id: msg.message_id,
            reply_markup: {
                inline_keyboard: keyboard
            }
        }
    );

    setTimeout(() => safeEditClear(chatId, menuMsg.message_id), 30000);
    setTimeout(() => safeEditClear(chatId, msg.message_id), 30000);
});

// Del Title
bot.onText(/^\/deltitle$/, async (msg) => {
    const userId = msg.from.id.toString();

    if (msg.chat.type === "private") sendReport(msg, "/deltitle");

    if (!msg.reply_to_message) {
        const errorMsg = await bot.sendMessage(
            msg.chat.id,
            "❌ Harus reply ke pesan target"
        );
        setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000);
        setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000);
        return;
    }

    const targetId = msg.reply_to_message.from.id.toString();
    let keyboard = [];

    if (
        userId === config.TELEGRAM_ID.toString() ||
        (roles.Developer || []).includes(userId)
    ) {
        keyboard = [
            [{ text: "RESELLER", callback_data: `delrole|reseller|${targetId}` }],
            [{ text: "PARTNER", callback_data: `delrole|partner|${targetId}` }],
            [{ text: "MODERATOR", callback_data: `delrole|moderator|${targetId}` }],
            [{ text: "OWNER", callback_data: `delrole|owner|${targetId}` }],
            [{ text: "TK", callback_data: `delrole|TK|${targetId}` }]
        ];
    } else if ((roles.TK || []).includes(userId)) {
        keyboard = [
            [{ text: "RESELLER", callback_data: `delrole|reseller|${targetId}` }],
            [{ text: "PARTNER", callback_data: `delrole|partner|${targetId}` }],
            [{ text: "MODERATOR", callback_data: `delrole|moderator|${targetId}` }],
            [{ text: "OWNER", callback_data: `delrole|owner|${targetId}` }]
        ];
    } else if ((roles.owner || []).includes(userId)) {
        keyboard = [
            [{ text: "RESELLER", callback_data: `delrole|reseller|${targetId}` }],
            [{ text: "PARTNER", callback_data: `delrole|partner|${targetId}` }],
            [{ text: "MODERATOR", callback_data: `delrole|moderator|${targetId}` }]
        ];
    } else if ((roles.moderator || []).includes(userId)) {
        keyboard = [
            [{ text: "RESELLER", callback_data: `delrole|reseller|${targetId}` }],
            [{ text: "PARTNER", callback_data: `delrole|partner|${targetId}` }]
        ];
    } else if ((roles.partner || []).includes(userId)) {
        keyboard = [
            [{ text: "RESELLER", callback_data: `delrole|reseller|${targetId}` }]
        ];
    } else {
        const errorMsg = await bot.sendMessage(
            msg.chat.id,
            "❌ Anda tidak memiliki akses"
        );
        setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000);
        setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000);
        return;
    }

    const menuMsg = await bot.sendMessage(
        msg.chat.id,
        `Pilih role yang akan dihapus dari ID: ${targetId}`,
        {
            reply_markup: {
                inline_keyboard: keyboard
            },
            reply_to_message_id: msg.reply_to_message.message_id
        }
    );

    setTimeout(() => safeEditClear(msg.chat.id, menuMsg.message_id), 30000);
    setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 30000);
});

// ============ TOKEN ID HELPER ============
// Hanya ID yang berada di depan token bot sebelum tanda ":" yang digunakan.
// Contoh: 123456789:AA... -> 123456789
function getBotIdFromToken(input = '') {
    const value = String(input).trim();
    if (!value) return null;

    // Bisa menerima token lengkap atau ID bot saja.
    const botId = value.split(':')[0].trim();

    // Telegram bot ID berupa angka.
    if (!/^\d+$/.test(botId)) return null;
    return botId;
}

// Verify
bot.onText(/\/verify(?:\s+(.+))?$/, async (msg, match) => {
    const userId = msg.from.id.toString();
    const chatId = msg.chat.id;

    if (!hasAccess(userId, ['TK', 'owner', 'moderator', 'partner', 'reseller'])) {
        const warningMsg = await bot.sendMessage(chatId, `❌ ☇ Anda tidak memiliki akses`);
        setTimeout(() => safeEditClear(chatId, warningMsg.message_id), 2000);
        setTimeout(() => safeEditClear(chatId, msg.message_id), 2000);
        return;
    }

    const originalToken = (match[1] || '').trim();
    const botId = getBotIdFromToken(originalToken);

    if (!botId) {
        const errorMsg = await bot.sendMessage(
            chatId,
            `❌ <b>ID BOT TIDAK VALID</b>\n\n` +
            `Masukkan token bot seperti: <code>123456789:AA...</code>\n` +
            `atau langsung ID bot: <code>123456789</code>\n\n` +
            `⚠️ Database hanya menyimpan dan memvalidasi <b>ID di depan token</b>.`,
            { parse_mode: 'HTML' }
        );
        setTimeout(() => safeEditClear(chatId, errorMsg.message_id), 4000);
        setTimeout(() => safeEditClear(chatId, msg.message_id), 4000);
        return;
    }

    // Callback dan database hanya menggunakan botId, bukan token lengkap.
    const opts = {
        reply_markup: {
            inline_keyboard: [[
                { text: "✅ Tambah ID Bot", callback_data: `token|add|${botId}|${msg.message_id}` },
                { text: "🗑️ Hapus ID Bot", callback_data: `token|del|${botId}|${msg.message_id}` }
            ]]
        },
        parse_mode: 'HTML',
        disable_web_page_preview: true
    };

    try {
        const verificationMsg = await bot.sendMessage(
            chatId,
            `🔐 <b>BOT ID VERIFICATION</b>\n\n` +
            `👤 <b>Verifier:</b> ${msg.from.first_name}\n` +
            `🆔 <b>User ID:</b> <code>${userId}</code>\n` +
            `🤖 <b>Bot ID:</b> <code>${botId}</code>\n\n` +
            `⚠️ <i>Yang digunakan hanya ID di depan token bot. Token lengkap tidak disimpan.</i>`,
            opts
        );
        setTimeout(() => safeDelete(chatId, msg.message_id), 1000);
    } catch (error) {
        console.error('Error:', error);
        const errorMsg = await bot.sendMessage(
            chatId,
            `❌ <b>ERROR</b>\n\nGagal memproses: ${error.message}`,
            { parse_mode: 'HTML' }
        );
        setTimeout(() => safeEditClear(chatId, errorMsg.message_id), 3000);
        setTimeout(() => safeDelete(chatId, msg.message_id), 3000);
    }
});

// ============ PLAY COMMAND ============
const trackCache = new Map();
const tiktokCache = new Map();
const API_SOURCES = ["https://api.siputzx.my.id", "https://api.fgmods.xyz", "https://api.agatz.xyz"];

bot.on("message", async (msg) => {
    const text = msg.text || "";
    const chatId = msg.chat.id;
    if (text.startsWith("play") || text.startsWith("/play")) {
        const query = text.replace(/^\/?play\s*/i, "").trim();
        if (!query) return bot.sendMessage(chatId, `⸙ <b>Format:</b> play Judul Lagu`, { parse_mode: "HTML" });
        let results = null;
        for (const api of API_SOURCES) {
            try {
                const { data } = await axios.get(`${api}/api/s/spotify?query=${encodeURIComponent(query)}`, { timeout: 15000 });
                if (data?.status && data?.data?.length) { results = data.data; break; }
            } catch { continue; }
        }
        if (!results) return bot.sendMessage(chatId, `❌ Tidak ditemukan hasil untuk: <b>${escapeHtml(query)}</b>`, { parse_mode: "HTML" });
        trackCache.set(chatId, results);
        const keyboard = results.slice(0, 10).map((track, i) => [{ text: `${i + 1}. ${track.title} — ${track.artist}`, callback_data: `dl_${i}` }]);
        return bot.sendMessage(chatId, `❀ SELECT MUSIC`, { parse_mode: "HTML", reply_markup: { inline_keyboard: keyboard } });
    }
});

bot.on("callback_query", async (query) => {
    const chatId = query.message.chat.id;
    const data = query.data;
    if (!data.startsWith("dl_")) return;
    const index = Number(data.split("_")[1]);
    const list = trackCache.get(chatId);
    if (!list || !list[index]) return bot.answerCallbackQuery(query.id, { text: "❌ Data tidak ditemukan" });
    const track = list[index];
    await bot.answerCallbackQuery(query.id, { text: `🎵 ${track.title}` });
    let mp3Link = null;
    for (const api of API_SOURCES) {
        try {
            const { data } = await axios.get(`${api}/api/d/spotify?url=${encodeURIComponent(track.track_url || track.url)}`, { timeout: 20000 });
            mp3Link = data?.data?.mp3DownloadLink || data?.data?.download || data?.data?.mp3 || null;
            if (mp3Link) break;
        } catch { continue; }
    }
    if (!mp3Link) return bot.sendMessage(chatId, `❌ Gagal mendapatkan link MP3`, { parse_mode: "HTML" });
    try {
        const fileResp = await axios.get(mp3Link, { responseType: "arraybuffer", timeout: 120000 });
        const mp3Buffer = Buffer.from(fileResp.data);
        await bot.sendAudio(chatId, mp3Buffer, { caption: `⎙ <b>${escapeHtml(track.title)}</b>\n⸙ <i>${escapeHtml(track.artist)}</i>`, title: track.title, performer: track.artist, parse_mode: "HTML", thumb: track.thumbnail || track.artwork_url || undefined });
        await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
    } catch (err) {
        return bot.sendMessage(chatId, `⸙ <b>${escapeHtml(track.title)}</b>\n<a href="${mp3Link}">Klik untuk download</a>`, { parse_mode: "HTML" });
    }
});

// ============ ROLE MANAGEMENT COMMANDS ============
bot.onText(/\/addTK (.+)/, (msg, match) => {
    const userId = msg.from.id.toString();
    if (userId !== config.TELEGRAM_ID.toString()) { const errorMsg = bot.sendMessage(msg.chat.id, '❌ Hanya developer yang bisa menambah TK'); setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); return; }
    const targetId = match[1];
    if (!roles.TK.includes(targetId)) { roles.tk.push(targetId); saveRoles(roles); const successMsg = bot.sendMessage(msg.chat.id, `✅ TK berhasil ditambahkan: ${targetId}`); setTimeout(() => safeEditClear(msg.chat.id, successMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); }
});

bot.onText(/\/delTK (.+)/, (msg, match) => {
    const userId = msg.from.id.toString();
    if (userId !== config.TELEGRAM_ID.toString()) { const errorMsg = bot.sendMessage(msg.chat.id, '❌ Hanya developer yang bisa menghapus TK'); setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); return; }
    const targetId = match[1];
    roles.TK = roles.TK.filter(id => id !== targetId);
    saveRoles(roles);
    const successMsg = bot.sendMessage(msg.chat.id, `✅ TK berhasil dihapus: ${targetId}`);
    setTimeout(() => safeEditClear(msg.chat.id, successMsg.message_id), 3000);
    setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000);
});

bot.onText(/\/addowner (.+)/, (msg, match) => {
    const userId = msg.from.id.toString();
    if (userId !== config.TELEGRAM_ID.toString()) { const errorMsg = bot.sendMessage(msg.chat.id, '❌ Hanya developer yang bisa menambah owner'); setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); return; }
    const targetId = match[1];
    if (!roles.owner.includes(targetId)) { roles.owner.push(targetId); saveRoles(roles); const successMsg = bot.sendMessage(msg.chat.id, `✅ Owner berhasil ditambahkan: ${targetId}`); setTimeout(() => safeEditClear(msg.chat.id, successMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); }
});

bot.onText(/\/delowner (.+)/, (msg, match) => {
    const userId = msg.from.id.toString();
    if (userId !== config.TELEGRAM_ID.toString()) { const errorMsg = bot.sendMessage(msg.chat.id, '❌ Hanya developer yang bisa menghapus owner'); setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); return; }
    const targetId = match[1];
    roles.owner = roles.owner.filter(id => id !== targetId);
    saveRoles(roles);
    const successMsg = bot.sendMessage(msg.chat.id, `✅ Owner berhasil dihapus: ${targetId}`);
    setTimeout(() => safeEditClear(msg.chat.id, successMsg.message_id), 3000);
    setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000);
});

bot.onText(/\/addmod (.+)/, (msg, match) => {
    const userId = msg.from.id.toString();
    if (!hasAccess(userId, ['owner'])) { const errorMsg = bot.sendMessage(msg.chat.id, '❌ Hanya owner yang bisa menambah moderator'); setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); return; }
    const targetId = match[1];
    if (!roles.moderator.includes(targetId)) { roles.moderator.push(targetId); saveRoles(roles); const successMsg = bot.sendMessage(msg.chat.id, `✅ Moderator berhasil ditambahkan: ${targetId}`); setTimeout(() => safeEditClear(msg.chat.id, successMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); }
});

bot.onText(/\/delmod (.+)/, (msg, match) => {
    const userId = msg.from.id.toString();
    if (!hasAccess(userId, ['owner'])) { const errorMsg = bot.sendMessage(msg.chat.id, '❌ Hanya owner yang bisa menghapus moderator'); setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); return; }
    const targetId = match[1];
    roles.moderator = roles.moderator.filter(id => id !== targetId);
    saveRoles(roles);
    const successMsg = bot.sendMessage(msg.chat.id, `✅ Moderator berhasil dihapus: ${targetId}`);
    setTimeout(() => safeEditClear(msg.chat.id, successMsg.message_id), 3000);
    setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000);
});

bot.onText(/\/addpartner (.+)/, (msg, match) => {
    const userId = msg.from.id.toString();
    if (!hasAccess(userId, ['owner', 'moderator'])) { const errorMsg = bot.sendMessage(msg.chat.id, '❌ Hanya owner/moderator yang bisa menambah partner'); setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); return; }
    const targetId = match[1];
    if (!roles.partner.includes(targetId)) { roles.partner.push(targetId); saveRoles(roles); const successMsg = bot.sendMessage(msg.chat.id, `✅ Partner berhasil ditambahkan: ${targetId}`); setTimeout(() => safeEditClear(msg.chat.id, successMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); }
});

bot.onText(/\/delpartner (.+)/, (msg, match) => {
    const userId = msg.from.id.toString();
    if (!hasAccess(userId, ['owner', 'moderator'])) { const errorMsg = bot.sendMessage(msg.chat.id, '❌ Hanya owner/moderator yang bisa menghapus partner'); setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); return; }
    const targetId = match[1];
    roles.partner = roles.partner.filter(id => id !== targetId);
    saveRoles(roles);
    const successMsg = bot.sendMessage(msg.chat.id, `✅ Partner berhasil dihapus: ${targetId}`);
    setTimeout(() => safeEditClear(msg.chat.id, successMsg.message_id), 3000);
    setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000);
});

bot.onText(/\/addreseller (.+)/, (msg, match) => {
    const userId = msg.from.id.toString();
    if (!hasAccess(userId, ['owner', 'moderator', 'partner'])) { const errorMsg = bot.sendMessage(msg.chat.id, '❌ Hanya owner/moderator/partner yang bisa menambah reseller'); setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); return; }
    const targetId = match[1];
    if (!roles.reseller.includes(targetId)) { roles.reseller.push(targetId); saveRoles(roles); const successMsg = bot.sendMessage(msg.chat.id, `✅ Reseller berhasil ditambahkan: ${targetId}`); setTimeout(() => safeEditClear(msg.chat.id, successMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); }
});

bot.onText(/\/delreseller (.+)/, (msg, match) => {
    const userId = msg.from.id.toString();
    if (!hasAccess(userId, ['owner', 'moderator', 'partner'])) { const errorMsg = bot.sendMessage(msg.chat.id, '❌ Hanya owner/moderator/partner yang bisa menghapus reseller'); setTimeout(() => safeEditClear(msg.chat.id, errorMsg.message_id), 3000); setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000); return; }
    const targetId = match[1];
    roles.reseller = roles.reseller.filter(id => id !== targetId);
    saveRoles(roles);
    const successMsg = bot.sendMessage(msg.chat.id, `✅ Reseller berhasil dihapus: ${targetId}`);
    setTimeout(() => safeEditClear(msg.chat.id, successMsg.message_id), 3000);
    setTimeout(() => safeEditClear(msg.chat.id, msg.message_id), 3000);
});

// ============ CALLBACK HANDLER (ADD/DEL ROLE + TOKEN) ============
bot.on('callback_query', async (callbackQuery) => {
    try {
        const msg = callbackQuery.message;
        const data = callbackQuery.data;
        if (!data) return;
        
        if (data === 'retry_iqc') {
            const chatId = msg.chat.id;
            await safeEditClear(chatId, msg.message_id, '🔄 *Mengulang proses...*');
            await bot.sendMessage(chatId, '🔄 <b>Mencoba Lagi</b>\n\nSilakan ketik command /iqc lagi dengan format:\n<code>/iqc [pesan] [baterai] [operator]</code>', { parse_mode: 'HTML' });
            await bot.answerCallbackQuery(callbackQuery.id);
            return;
        }
        
        if (data.includes('|')) {
            const parts = data.split('|');
            if (parts[0] === 'addrole') {
                const role = parts[1];
                const targetId = parts[2];
                const originalMsgId = parts[3];
                const userId = callbackQuery.from.id.toString();
                const chatId = msg.chat.id;
                
                const accessRules = {
                    TK: [config.TELEGRAM_ID.toString()],
                    owner: [config.TELEGRAM_ID.toString(), ...roles.TK],
                    moderator: [config.TELEGRAM_ID.toString(), ...roles.TK, ...roles.owner],
                    partner: [config.TELEGRAM_ID.toString(), ...roles.TK, ...roles.owner, ...roles.moderator],
                    reseller: [config.TELEGRAM_ID.toString(), ... roles.TK, ...roles.owner, ...roles.moderator, ...roles.partner],
                };
                
                if (!accessRules[role] || !accessRules[role].includes(userId)) {
                    await bot.answerCallbackQuery(callbackQuery.id, { text: `❌ Anda tidak memiliki akses untuk menambahkan ${role}`, show_alert: true });
                    return;
                }
                
                await bot.answerCallbackQuery(callbackQuery.id, { text: '⏳ Memproses...', show_alert: false });
                await safeEditClear(chatId, msg.message_id, '⏳ *Memproses penambahan title...*');
                if (originalMsgId && originalMsgId !== msg.message_id) await safeEditClear(chatId, originalMsgId, '🗑️ <i>Pesan command dihapus...</i>');
                
                let roleArray;
                let added = false;
                switch (role) {
                    case "TK": roleArray = roles.TK; break;
                    case "owner": roleArray = roles.owner; break;
                    case "moderator": roleArray = roles.moderator; break;
                    case "partner": roleArray = roles.partner; break;
                    case "reseller": roleArray = roles.reseller; break;
                    default: throw new Error("Role tidak valid");
                }
                if (!roleArray.includes(targetId)) { roleArray.push(targetId); saveRoles(roles); added = true; }
                
                if (added) {
                    await bot.sendMessage(chatId, `✅ <b>Title Berhasil Ditambahkan</b>\n\n👤 <b>User ID:</b> <code>${targetId}</code>\n🎖️ <b>Title:</b> ${getRoleEmoji(role)} ${role.toUpperCase()}\n👨‍💼 <b>By:</b> ${callbackQuery.from.first_name}\n🎖️ <b>Admin Title:</b> ${getUserTitle(userId)}\n⏰ <b>Time:</b> ${new Date().toLocaleTimeString("id-ID")}`, { parse_mode: "HTML" });
                    try { await bot.sendMessage(targetId, `🎉 <b>Selamat!</b>\n\nAnda mendapatkan title baru:\n🎖️ <b>${getRoleEmoji(role)} ${role.toUpperCase()}</b>\n\n👨‍💼 <b>From:</b> ${callbackQuery.from.first_name}\n🎖️ <b>Admin Title:</b> ${getUserTitle(userId)}\n⏰ <b>Time:</b> ${new Date().toLocaleString("id-ID")}`, { parse_mode: "HTML" }); } catch (error) { console.log("⚠️ Gagal kirim notifikasi ke user:", error.message); }
                } else { await bot.sendMessage(chatId, `⚠️ <b>Title Sudah Ada</b>\n\nUser <code>${targetId}</code> sudah memiliki title ${role.toUpperCase()}`, { parse_mode: "HTML" }); }
                return;
            }
            
            if (parts[0] === 'delrole') {
                const role = parts[1];
                const targetId = parts[2];
                const userId = callbackQuery.from.id.toString();
                const chatId = msg.chat.id;
                await bot.answerCallbackQuery(callbackQuery.id, { text: '⏳ Memproses...', show_alert: false });
                await safeEditClear(chatId, msg.message_id, '⏳ *Memproses penghapusan title...*');
                let removed = false;
                switch (role) {
                    case "TK": if (roles.TK.includes(targetId)) { roles.TK = roles.TK.filter(id => id !== targetId); removed = true; } break;
                    case "owner": if (roles.owner.includes(targetId)) { roles.owner = roles.owner.filter(id => id !== targetId); removed = true; } break;
                    case "moderator": if (roles.moderator.includes(targetId)) { roles.moderator = roles.moderator.filter(id => id !== targetId); removed = true; } break;
                    case "partner": if (roles.partner.includes(targetId)) { roles.partner = roles.partner.filter(id => id !== targetId); removed = true; } break;
                    case "reseller": if (roles.reseller.includes(targetId)) { roles.reseller = roles.reseller.filter(id => id !== targetId); removed = true; } break;
                }
                if (removed) { saveRoles(roles); await bot.sendMessage(chatId, `✅ <b>Title Berhasil Dihapus</b>\n\n👤 <b>User ID:</b> <code>${targetId}</code>\n🗑️ <b>Title:</b> ${role.toUpperCase()}\n👨‍💼 <b>By:</b> ${callbackQuery.from.first_name}`, { parse_mode: "HTML" }); }
                else { await bot.sendMessage(chatId, `❌ <b>Title Tidak Ditemukan</b>\n\nUser <code>${targetId}</code> tidak memiliki title ${role.toUpperCase()}`, { parse_mode: "HTML" }); }
                return;
            }
            
            if (parts[0] === 'token') {
                const action = parts[1];
                const token = parts[2];
                const originalMessageId = parts[3];
                const userId = callbackQuery.from.id.toString();
                const chatId = msg.chat.id;
                if (!hasAccess(userId, ['TK', 'owner', 'moderator', 'partner', 'reseller'])) {
                    await bot.answerCallbackQuery(callbackQuery.id, { text: '❌ Anda tidak memiliki akses', show_alert: true });
                    await bot.editMessageText(`❌ <b>AKSES DITOLAK</b>\n\nAnda tidak memiliki izin untuk melakukan aksi ini.\n👤 <b>User:</b> ${callbackQuery.from.first_name}\n🆔 <b>User ID:</b> <code>${userId}</code>\n\n⚠️ <i>Hanya user dengan role tertentu yang bisa mengelola token</i>`, { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML' });
                    return;
                }
                await bot.answerCallbackQuery(callbackQuery.id, { text: '⏳ Memproses token...' });
                try {
                    let file = null;
                    try {
                        const response = await octokit.rest.repos.getContent({ owner: config.GITHUB_OWNER, repo: config.GITHUB_REPO, path: config.GITHUB_PATH });
                        file = response.data;
                    } catch (e) { if (e.status !== 404) throw e; }
                    let json = file ? JSON.parse(Buffer.from(file.content, 'base64').toString()) : { tokens: [] };
                    if (!json || typeof json !== 'object') json = { tokens: [] };
                    if (!Array.isArray(json.tokens)) json.tokens = [];

                    // Normalisasi database lama: jika masih ada token lengkap,
                    // ubah otomatis menjadi ID bot (bagian sebelum ":").
                    json.tokens = [...new Set(
                        json.tokens
                            .map(t => getBotIdFromToken(t))
                            .filter(Boolean)
                    )];

                    const botId = getBotIdFromToken(token);
                    if (!botId) {
                        await bot.editMessageText(
                            `❌ <b>ID BOT TIDAK VALID</b>\\n\\nHanya ID angka di depan token bot yang diterima.`,
                            { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML' }
                        );
                        return;
                    }

                    let resultMessage = '';
                    if (action === 'add') {
                        if (!json.tokens.includes(botId)) {
                            json.tokens.push(botId);
                            resultMessage = `✅ <b>ID BOT BERHASIL DITAMBAHKAN</b>`;
                        } else {
                            resultMessage = `ℹ️ <b>ID BOT SUDAH ADA</b>`;
                        }
                    } else if (action === 'del') {
                        const initialLength = json.tokens.length;
                        json.tokens = json.tokens.filter(t => t !== botId);
                        if (json.tokens.length < initialLength) {
                            resultMessage = `✅ <b>ID BOT BERHASIL DIHAPUS</b>`;
                        } else {
                            resultMessage = `ℹ️ <b>ID BOT TIDAK DITEMUKAN</b>`;
                        }
                    }
                    await octokit.rest.repos.createOrUpdateFileContents({ owner: config.GITHUB_OWNER, repo: config.GITHUB_REPO, path: config.GITHUB_PATH, message: `${action === 'add' ? 'Add' : 'Delete'} token by ${userId}`, content: Buffer.from(JSON.stringify(json, null, 2)).toString('base64'), sha: file ? file.sha : undefined });
                    await bot.editMessageText(`${resultMessage}\n\n👤 <b>User:</b> ${callbackQuery.from.first_name}\n🆔 <b>User ID:</b> <code>${userId}</code>\n🎯 <b>Aksi:</b> ${action === 'add' ? 'Menambah Token' : 'Menghapus Token'}\n📏 <b>Token Length:</b> ${token.length} karakter\n📊 <b>Total Token Sekarang:</b> ${json.tokens.length}\n\n🕒 <b>Waktu:</b> ${new Date().toLocaleTimeString('id-ID')}\n✅ <i>GitHub repository telah diperbarui</i>`, { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML' });
                    await bot.answerCallbackQuery(callbackQuery.id, { text: action === 'add' ? 'ID bot berhasil ditambahkan!' : 'ID bot berhasil dihapus!' });
                } catch (e) {
                    console.error('Error processing token:', e);
                    await bot.editMessageText(`❌ <b>GAGAL MEMPROSES TOKEN</b>\n\n👤 <b>User:</b> ${callbackQuery.from.first_name}\n🆔 <b>User ID:</b> <code>${userId}</code>\n🎯 <b>Aksi:</b> ${action === 'add' ? 'Menambah Token' : 'Menghapus Token'}\n\n📛 <b>Error:</b> ${e.message}\n\n⚠️ <i>Silakan coba lagi nanti atau hubungi developer</i>`, { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML' });
                    await bot.answerCallbackQuery(callbackQuery.id, { text: '❌ Gagal memproses token', show_alert: true });
                }
                return;
            }
        }
    } catch (error) {
        console.error("Callback query error:", error);
        await bot.answerCallbackQuery(callbackQuery.id, { text: '❌ Terjadi kesalahan', show_alert: true });
    }
});

// ============ BOT STARTUP ============
console.log('🤖 Bot Database started...');
console.log('📊 Group Laporan:', REPORT_GROUP_ID);
console.log('👑 Developer ID:', config.TELEGRAM_ID);

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
});