# DOXRAY Web → APK Test

## Jalankan
1. Node.js 18+.
2. `npm install`
3. `npm start`
4. Buka `http://localhost:3000`

Endpoint test: `GET /api/health`
Build: `POST /api/web-to-apk`

Catatan: build menggunakan layanan Web→APK eksternal.
