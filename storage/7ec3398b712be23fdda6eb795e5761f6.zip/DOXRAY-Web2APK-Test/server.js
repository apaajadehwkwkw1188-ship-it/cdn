const express=require("express");
const axios=require("axios");
const cors=require("cors");
const FormData=require("form-data");

const app=express();
const PORT=process.env.PORT||3000;
const BUILD_API="https://rfweb2apk.rfdevv.com/api/apk/build";

app.use(cors());
app.use(express.json({limit:"1mb"}));
app.use(express.static("public"));

function validPackageName(v){
  return /^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$/.test(v);
}

app.post("/api/web-to-apk",async(req,res)=>{
  const {url,appName,packageName,versionName="1.0",versionCode="1",icon="",orientation="auto"}=req.body||{};
  if(!url||!/^https?:\/\//i.test(url))return res.status(400).json({success:false,message:"URL website tidak valid."});
  if(!appName)return res.status(400).json({success:false,message:"Nama aplikasi wajib diisi."});
  if(!validPackageName(packageName||""))return res.status(400).json({success:false,message:"Package name tidak valid."});

  const form=new FormData();
  form.append("appName",appName);
  form.append("packageName",packageName);
  form.append("versionName",versionName);
  form.append("versionCode",String(versionCode));
  form.append("url",url);
  form.append("splashType","image");
  form.append("orientation",orientation);

  const tinyPng=Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==","base64");
  form.append("icon",tinyPng,{filename:"icon.png",contentType:"image/png"});

  try{
    const response=await axios.post(BUILD_API,form,{
      headers:form.getHeaders(),
      timeout:120000,
      maxContentLength:50*1024*1024,
      maxBodyLength:50*1024*1024
    });
    const d=response.data||{};
    if(!d.success)return res.status(502).json({success:false,message:d.message||"External builder menolak request."});
    const downloadUrl=d.downloadUrl?.startsWith("http")?d.downloadUrl:`https://rfweb2apk.rfdevv.com${d.downloadUrl||""}`;
    res.json({success:true,buildId:d.buildId,fileName:d.fileName,size:d.size,downloadUrl,message:d.message});
  }catch(err){
    console.error(err.response?.data||err.message);
    res.status(502).json({success:false,message:err.response?.data?.message||err.message||"Gagal menghubungi builder."});
  }
});

app.get("/api/health",(req,res)=>res.json({ok:true,service:"DOXRAY Web2APK Test"}));
app.listen(PORT,()=>console.log(`DOXRAY Web2APK Test running on http://localhost:${PORT}`));
