module.exports = {
  BOT_TOKEN: "8985973184:AAF_DShOJVPa3Mi1mn7R4SuXJc84bTJqsCY",
  OWNER_ID: ["8543705474"], 
  NOTIF_ID: "-1003949437676", 
  domain: "https://",
  plta: "ptla_",
  pltc: "ptlc_",
  eggid: "15",
  location: "1",
  nestid: "5",
//  plta,pltc,domain,apidigitalocean ga di isi gpp kalau gapunya
  do_api_key: "ISI_APIKEY_DIGITAL_OCEAN",
    SLUG_PAKASIR: "izanofficial", 
   VERSION: "𝙱𝙴𝚃𝙰 𝚅𝙴𝚁𝚂𝙸𝙾𝙽",
   URL_MENU: "https://files.catbox.moe/f1reii.mp4",   
   OWNER: ["1769278444"],

   NAMA_BOT: "VOID PRIME",
   GROUP_ID: "-1003925906725", 
   CHANNEL_ID: "@wolftzyajabro",
   LINK_INVITE: "https://t.me/wolfpublikk",
   
   BUTTON_DEV: "Gabrieltzyproooool",
   BUTTON_OWN: "Gabrieltzyproooool",
   BUTTON_CH: "wolftzyajabro",
   BUTTON_CHH: "wolftzyajabro",
   BUTTON_ROOM: "https://t.me/wolfpublikk",

   FORCE_JOIN_CHANNELS: [
   "https://t.me/wolftzyajabro"
   ],
   FORCE_JOIN_GROUPS: [
      "https://t.me/wolfpublikk"
   ],

   APIKEY: "XYRAA4SC",
   GEMINI_APIKEY: " ISI API LU SENDIRI YATIM",
   SLUG_PAKASIR: "izanofficial", // FREE BYE GUWA XYRAA 😎
   APIKEY_PAKASIR: "ECi8r8c59zo8G7pBipvDMVkOSxCOhkvO"
};
