module.exports = {
  tokens: "8411178530:AAHCmpYsDPKaBw77uXJLBYTNMR0Pyzk4sDg",  // Masukin Bot token kamu
  owners: "8342823222", // Masukin ID Telegram kamu
  port: "3000", // Masukin Port panel kamu 
  ipvps: "http://satoruxvieraaprivate.badol-official.my.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1995-1996 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/