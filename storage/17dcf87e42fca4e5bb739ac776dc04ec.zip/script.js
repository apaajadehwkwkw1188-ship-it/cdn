const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav-links");

menuButton.addEventListener("click", () => {
  const expanded = menuButton.getAttribute("aria-expanded") === "true";
  menuButton.setAttribute("aria-expanded", String(!expanded));
  menuButton.setAttribute("aria-label", expanded ? "Buka menu" : "Tutup menu");
  nav.classList.toggle("is-open", !expanded);
});

nav.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("is-open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Buka menu");
  });
});

document.querySelector("#year").textContent = new Date().getFullYear();

const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const revealTargets = document.querySelectorAll(".about-grid, .skills-heading, .skills-layout, .projects-heading, .project-empty, .contact-heading, .contact-grid");

revealTargets.forEach(element => element.classList.add("reveal"));

if ("IntersectionObserver" in window && !reduceMotion) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add("is-visible");
      if (entry.target.classList.contains("skills-layout")) {
        entry.target.querySelectorAll(".skill-row").forEach(row => {
          row.querySelector(".skill-fill").style.width = `${row.dataset.level}%`;
        });
      }
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.18 });
  revealTargets.forEach(element => observer.observe(element));
} else {
  revealTargets.forEach(element => element.classList.add("is-visible"));
  document.querySelectorAll(".skill-row").forEach(row => {
    row.querySelector(".skill-fill").style.width = `${row.dataset.level}%`;
  });
}
