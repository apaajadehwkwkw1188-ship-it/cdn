# Arkan — Personal Portfolio

Website portofolio personal bergaya Neo-Brutalism, dibuat dengan HTML, CSS, dan JavaScript vanilla agar ringan dan mudah dipublikasikan.

## Menjalankan secara lokal

Buka `index.html` langsung di browser, atau jalankan server lokal:

```bash
python -m http.server 8080
```

Lalu buka `http://localhost:8080`.

## Mengganti foto profil

1. Siapkan foto asli dengan rasio 1:1.
2. Simpan sebagai `assets/arkan.jpg`.
3. Di `index.html`, cari elemen `div` dengan id `portrait`.
4. Ganti isi elemen tersebut dengan:

```html
<img src="assets/arkan.jpg" alt="Foto profil Muhammad Raditya Arkan">
```

5. Di `styles.css`, tambahkan:

```css
#portrait img {
  width: 100%;
  height: 100%;
  aspect-ratio: 1 / 1;
  object-fit: cover;
  object-position: center;
  display: block;
}
```

Sesuaikan `object-position` bila perlu agar framing wajah tepat.

## Mengubah data personal

Edit tautan dan teks di `index.html`. Kontak saat ini:
- Telegram: https://t.me/Arkanhahaha
- WhatsApp: https://wa.me/6285624184767
- GitHub: https://github.com/muhammadradityaarkan593
- Email: support@arkannhosting.my.id

Instagram sengaja tidak ditampilkan karena belum tersedia.

## Mengubah skill

Ubah `data-level` pada setiap `.skill-row` di `index.html` dan teks persentasenya. Pastikan keduanya menggunakan nilai yang sama.

## Deploy

Folder ini dapat diunggah langsung ke layanan static hosting seperti GitHub Pages, Netlify, atau Cloudflare Pages. Tidak membutuhkan backend atau proses build.
