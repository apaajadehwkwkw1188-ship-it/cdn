module.exports = {
  BOT_TOKEN: "8926438554:AAHo-xZRkjZ0ZQPOJe2Cs3MqcQJOGq0L7v0",
  blockAutoFollowChannels: false,
  OWNER_ID: ["8366103363", "1848342025", "8326790837"],
};