const fs = require("fs");
const archiver = require("archiver");

const output = fs.createWriteStream("apiv2.zip");
const archive = archiver("zip", { zlib: { level: 9 } });

archive.pipe(output);

// SEMUA isi root + subfolder
archive.glob("**/*", {
  ignore: [
    ".cache/**",
    ".npm/**",
    ".pki/**",
    "node/**",
    "node_modules/**",
    ".bashrc",
    ".cloudflare.log",
    "package-lock.json",
    "apiv2.zip" // biar zip gak ngezip dirinya sendiri
  ],
  dot: true
});

archive.finalize();

output.on("close", () => {
  console.log("âœ… ZIP root selesai");
});