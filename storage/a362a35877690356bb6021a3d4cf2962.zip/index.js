const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const path = require('path');
const cors = require('cors');
const fs = require('fs');
const { createCanvas, loadImage } = require('canvas');
const rateLimit = require("express-rate-limit");
const { wrapper } = require('axios-cookiejar-support');
const { CookieJar, Cookie } = require('tough-cookie');
const { v4: uuidv4 } = require('uuid');
const chalk = require("chalk");
const BLOCK_FILE = path.join(__dirname, "blocked-ips.json");

let blockedIPs = new Set();

function loadBlockedIPs() {
    try {
        if (fs.existsSync(BLOCK_FILE)) {
            const data = JSON.parse(fs.readFileSync(BLOCK_FILE));
            blockedIPs = new Set(data);
        }
    } catch {
        blockedIPs = new Set();
    }
}

function saveBlockedIPs() {
    fs.writeFileSync(BLOCK_FILE, JSON.stringify([...blockedIPs], null, 2));
}

loadBlockedIPs();

const app = express();
const PORT = 5102;
const BOT_IP_WHITELIST = [
    "103.190.0.1",
    "127.0.0.1",
    "::1"
];

app.set("trust proxy", 1);
app.set("json spaces", 2);
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cors());

app.use((req, res, next) => {

    const ip = req.ip.replace("::ffff:", "");

    // whitelist selalu lolos
    if (BOT_IP_WHITELIST.includes(ip)) {
        return next();
    }

    if (blockedIPs.has(ip)) {
        return res.status(403).json({
            status: false,
            error: "IP Blocked"
        });
    }

    next();
});

const globalLimiter = rateLimit({
    windowMs: 10 * 1000,
    max: 30,
    standardHeaders: true,
    legacyHeaders: false,

    handler: (req, res) => {

        const ip = req.ip.replace("::ffff:", "");

        if (!blockedIPs.has(ip) && !BOT_IP_WHITELIST.includes(ip)) {

            blockedIPs.add(ip);
            saveBlockedIPs();

            console.log(chalk.red(`🚫 IP AUTO BLOCKED: ${ip}`));

        }

        res.status(429).json({
            status: false,
            error: "Too Many Requests"
        });
    }
});

app.use((req, res, next) => {
    const ip = req.ip.replace("::ffff:", "");

    if (BOT_IP_WHITELIST.includes(ip)) {
        return next();
    }

    return globalLimiter(req, res, next); // USER LAIN → KENA LIMIT
});

// 1. Landing Page (Welcome)
app.use('/', express.static(path.join(__dirname, 'public'), { index: 'welcome.html' }));

// 2. Dokumentasi spesifik
app.get('/docs', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'docs.html'));
});

// 3. Sisanya buat aset statis (CSS/JS/Images)
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// =============================================
const CDN = [
    "https://cdn.ikyyzyyrestapi.my.id/s/upload",
    "https://cdn.ikyyzyyrestapi.my.id/uploads"
];

function randomCDN() {
    return CDN[Math.floor(Math.random() * CDN.length)];
}

/* SEARCH TIKTOK */
async function ttSearch(query) {
    try {
        const { data } = await axios.post(
            "https://tikwm.com/api/feed/search",
            new URLSearchParams({
                keywords: query,
                count: 12,
                cursor: 0,
                web: 1,
                hd: 1
            }),
            {
                headers: {
                    "content-type": "application/x-www-form-urlencoded",
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                }
            }
        );

        if (!data?.data?.videos) return [];

        const base = "https://tikwm.com";

        return data.data.videos.map(v => ({
            id: v.video_id,
            title: v.title || "",
            duration: v.duration,
            play: base + v.play,
            author: v.author.nickname,
            username: v.author.unique_id,
            views: v.play_count,
            likes: v.digg_count
        }));
    } catch (e) {
        return [];
    }
}

/* CDN UPLOAD URL */
async function uploadToCDN(url) {
    try {
        const { data } = await axios.post(
            randomCDN(),
            new URLSearchParams({ url }),
            {
                headers: { "content-type": "application/x-www-form-urlencoded" },
                timeout: 25000 // Kasih nafas dikit buat file gede
            }
        );
        return data.url || null;
    } catch {
        return null;
    }
}

/* PROCESS VIDEO (Mapping data + Upload) */
async function processVideo(v) {
    if (!v.play) return null;

    const uploadedUrl = await uploadToCDN(v.play);
    if (!uploadedUrl) return null;

    return {
        id: v.id,
        title: v.title,
        duration: v.duration,
        video: uploadedUrl, // Link CDN lu
        author: v.author,
        username: v.username,
        views: v.views,
        likes: v.likes
    };
}

/* CONCURRENT WORKER */
async function concurrentMap(arr, limit, fn) {
    let result = [];
    let i = 0;

    async function worker() {
        while (i < arr.length) {
            let current = i++;
            let r = await fn(arr[current]);
            if (r) result.push(r);
        }
    }

    let workers = Array(limit).fill(0).map(worker);
    await Promise.all(workers);
    return result;
}
const APIKEY = "riicode";

/**
 * YouTube Play V2 - Search & Download
 * Path: /search/ytplay
 * Creator: IkyyOfficiall
 */
async function playYT(query) {
    try {
        // 1. 🔍 SEARCHING
        const searchRes = await axios.get("https://riimusic.my.id/api/youtube/search", {
            params: { apikey: APIKEY, query },
            timeout: 15000
        });

        if (!searchRes.data.status || !searchRes.data.data.length) {
            throw new Error("Lagu kagak ketemu, Ky. Coba judul lain!");
        }

        const vid = searchRes.data.data[0]; // Ambil hasil pertama yang paling relevan

        // 2. 🎧 DOWNLOADING (Convert to Audio)
        const downloadRes = await axios.get("https://riimusic.my.id/api/youtube/download", {
            params: { apikey: APIKEY, url: vid.url },
            timeout: 30000 // Kasih waktu lebih buat proses convert
        });

        if (!downloadRes.data.status) throw new Error("Gagal convert audionya!");

        const dl = downloadRes.data.data;

        // 3. 🎯 MAPPING OUTPUT
        return {
            status: true,
            creator: "IkyyOfficiall",
            result: {
                title: vid.title,
                source: vid.url,
                duration: vid.timestamp,
                views: vid.views,
                author: vid.author?.name || "Unknown",
                thumbnail: vid.thumbnail,
                download: {
                    url: dl.url,
                    format: dl.format || "mp3",
                    quality: "128kbps" // Standard audio quality
                }
            }
        };

    } catch (err) {
        throw err;
    }
}

    const FSaver = {
        config: {
            base: "https://fsaver.net",
            agent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
        },

        download: async (videoUrl) => {
            const fetchUrl = `${FSaver.config.base}/download/?url=${encodeURIComponent(videoUrl)}`;

            const { data } = await axios.get(fetchUrl, {
                headers: {
                    "Upgrade-Insecure-Requests": "1",
                    "User-Agent": FSaver.config.agent,
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                    "Referer": "https://fsaver.net/"
                },
                timeout: 15000
            });

            const $ = cheerio.load(data);
            const videoSrc = $(".video__item").attr("src");

            if (!videoSrc) throw new Error("Video resource not found.");

            return videoSrc.startsWith("http")
                ? videoSrc
                : FSaver.config.base + videoSrc;
        }
    };
    
const generateFakeDeviceId = () => uuidv4();
const generateFakeAnonId = () => Math.random().toString(16).substring(2, 18);

async function* chatStream(promptText) {
    const jar = new CookieJar();

    const client = wrapper(axios.create({
        jar,
        withCredentials: true,
        baseURL: 'https://quillbot.com',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'platform-type': 'webapp',
            'webapp-version': '40.75.2',
            'qb-product': 'AI-CHAT'
        }
    }));

    const deviceId = generateFakeDeviceId();
    const anonId = generateFakeAnonId();
    const cookieOptions = { domain: 'quillbot.com', path: '/' };

    await jar.setCookie(new Cookie({ key: 'qbDeviceId', value: deviceId, ...cookieOptions }), 'https://quillbot.com');
    await jar.setCookie(new Cookie({ key: 'anonID', value: anonId, ...cookieOptions }), 'https://quillbot.com');
    await jar.setCookie(new Cookie({ key: 'ajs_anonymous_id', value: deviceId, ...cookieOptions }), 'https://quillbot.com');

    await client.get('/ai-chat');

    const spamCheck = await client.get('/api/auth/spam-check');
    if (spamCheck.data.status !== 200) {
        throw new Error("Spam check rejected by provider.");
    }

    const conversationId = uuidv4();

    const response = await client.post(
        `/api/ai-chat/chat/conversation/${conversationId}`,
        {
            message: {
                content: promptText,
                files: []
            },
            context: {},
            tools: {
                web_search_builtin: {}
            },
            origin: {
                name: "ai-chat.chat",
                url: "https://quillbot.com"
            }
        },
        {
            responseType: 'stream',
            headers: {
                'Accept': 'text/event-stream',
                'useridtoken': 'empty-token'
            }
        }
    );

    for await (const chunk of response.data) {
        const dataString = chunk.toString();
        const lines = dataString.split('\n');

        for (const line of lines) {
            if (line.trim() && line.startsWith('{')) {
                try {
                    const json = JSON.parse(line);
                    if (json.type === 'content') {
                        yield json.content;
                    }
                } catch {}
            }
        }
    }
}

async function gemini(text) {
  try {
    const { data } = await axios.get(`https://www.neoapis.xyz/api/ai/gemini`, {
      params: { text: text },
      timeout: 30000
    });

    if (!data.status || !data.data) {
      throw new Error("Respon API tidak valid atau kosong.");
    }

    // Return cuma answer-nya aja biar enteng
    return {
      status: true,
      creator: "IkyyOfficiall",
      results: data.data.answer
    };

  } catch (err) {
    return {
      status: false,
      creator: "IkyyOfficiall",
      error: err.message
    };
  }
}
//   ============================================= 
const endpoints = [
// MAKER
    {
        name: "Brat Maker",
        path: "/api/maker/brat",
        param: "text",
        category: "Maker",
        isImage: true,
        example: "IkyyXD",
        execute: async (req, res) => {
        const { text } = req.query;
        if (!text) return res.status(400).json({
            status: false,
            error: 'text is required'
        });

        try {
            const { data } = await axios.get(`https://rynnhub-brat.hf.space/api/brat?text=${encodeURIComponent(text)}`, { responseType: 'arraybuffer' });
            res.writeHead(200, {
                'Content-Type': 'image/png',
                'Content-Length': data.length
            });
            res.end(data);
        } catch (error) {
            console.error(error);
            res.json({ status: false, error: error.message });
        }
    }
    },
// DOWNLOADER
    {
        name: "Facebook Downloader",
        path: "/api/download/fb",
        param: "url",
        category: "Downloader",
        example: "https://www.facebook.com/share/r/1DoXHyUaqr/",
        execute: async (req, res) => {
        const { url } = req.query;

        if (!url) return res.status(400).json({ status: false, error: "url is required" });

        try {
            const videoUrl = await FSaver.download(url);

            res.status(200).json({
                status: true,
                creator: "IkyyOfficial",
                result: {
                    title: "Facebook Video Downloader",
                    source: url,
                    video_url: videoUrl,
                    format: "mp4"
                }
            });

        } catch (e) {
            res.json({
                status: false,
                error: e.message
            });
        }
    }
    },
    {
        name: "TikTok Downloader",
        path: "/api/download/tiktok",
        param: "url",
        category: "Downloader",
        example: "https://vt.tiktok.com/ZSuTnFVN9/-",
        execute: async (req) => {
            const { url } = req.query;
            if (!url) throw new Error("URL mana ?");
            const { data } = await axios.get(`https://tikdown.ikyzxz.my.id/api/v1?url=${encodeURIComponent(url)}`);
            return data;
        }
    },
    {
        name: "Spotify Play",
        path: "/api/music/spotify",
        param: "q",
        category: "Downloader",
        example: "Lathi",
        execute: async (req) => {
            const { q } = req.query;
            const { data } = await axios.get(`https://ikyyzyyrestapi.my.id/search/spotifyplay?query=${q}`);
            return data.result;
        }
    },
    {
        name: "YouTube Play",
        path: "/api/music/youtube",
        param: "query",
        category: "Downloader",
        example: "duka",
        execute:  async (req, res) => {        const { query } = req.query;

        if (!query) return res.status(400).json({ 
            status: false, 
            creator: "IkyyOfficiall", 
            message: "Mau dengerin apa? Masukin query-nya!" 
        });

        const start = Date.now();

        try {
            const data = await playYT(query);
            data.runtime = `${Date.now() - start} ms`;
            res.json(data);
        } catch (err) {
            res.status(500).json({
                status: false,
                creator: "IkyyOfficiall",
                error: err.message
            });
        }
    }
    },
// AI
    {
        name: "Gemini 3.1 Pro",
        path: "/api/chat/gemini",
        param: "text",
        category: "AI",
        example: "ini hari apa?",
        execute: async (req, res) => {
    const { text } = req.query;
    if (!text) return res.status(400).json({ status: false, message: "Teksnya mana?" });

    const start = Date.now();
    const result = await gemini(text);
    
    res.json({
      ...result,
      runtime: `${Date.now() - start} ms`
    });
  }
    },
    {
       name: "Quil Chat",
       path: "/api/chat/quilbot",
       param: "prompt",
       category: "AI",
       example: "Kamu Siapa?",
       execute: async (req, res) => {

        const { prompt } = req.query;

        if (!prompt) {
            return res.json({
                status: false,
                code: 400,
                creator: "IkyyOfficial",
                message: "Parameter prompt wajib"
            });
        }

        try {

            let finalText = "";

            for await (const chunk of chatStream(prompt)) {
                finalText += chunk;
            }

            return res.json({
                status: true,
                code: 200,
                creator: "IkyyOfficial",
                prompt,
                result: finalText
            });

        } catch (err) {

            return res.json({
                status: false,
                code: 500,
                creator: "IkyyOfficial",
                message: "Quillbot processing failed",
                error: err.message
            });

        }

    }
    },
// SEARCH
    {
        name: "Tiktok Search",
        path: "/api/search/tiktok",
        param: "query",
        category: "Search",
        example: "meme bahlil",
        execute: async (req, res) => {
        const { query } = req.query;

        if (!query) return res.json({ 
            status: false, 
            creator: "IkyyOfficiall", 
            message: "Masukin query-nya, wok!" 
        });

        try {
            const start = Date.now();
            const results = await ttSearch(query);

            if (results.length === 0) {
                return res.json({ 
                    status: false, 
                    creator: "IkyyOfficiall", 
                    message: "Video gak ketemu." 
                });
            }

            // Ambil 10 video pertama, upload pake 4 worker concurrent
            const finalResult = await concurrentMap(
                results.slice(0, 10),
                4,
                processVideo
            );

            res.json({
                status: true,
                creator: "IkyyOfficiall",
                query,
                total: finalResult.length,
                runtime: `${Date.now() - start} ms`,
                result: finalResult
            });

        } catch (error) {
            res.status(500).json({ 
                status: false, 
                creator: "IkyyOfficiall", 
                error: error.message 
            });
        }
    }
    },
    {
    name: "Search Grup WA",
    path: "/api/search/grupwa",
    param: "text",
    category: "Search",
    example: "cari pacar",
    execute: async (req) => {
        const { text } = req.query;
        if (!text) throw new Error("Text nya mana?");

        const { data } = await axios.get(
            `https://ikyyzyyrestapi.my.id/search/grupwangcap?text=${encodeURIComponent(text)}`
        );

        return {
            status: data.status,
            query: data.query,
            total: data.total,
            result: data.data.map((v, i) => ({
                id: i + 1,
                nama: v.name,
                desc: v.description || "No deskripsi",
                thumbnail: v.thumbnail,
                link: v.join_url
            }))
        };
    }
    },
// INFO
    {
        name: "OkeZone TV",
        path: "/api/info/okezone",
        param: null,
        category: "Info",
        example: "",
        execute: async (req, res) => {
        try {
            const start = Date.now();
            const url = "https://news.okezone.com/nasional";
            
            const { data } = await axios.get(url, {
                headers: {
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                }
            });

            const $ = cheerio.load(data);
            const results = [];

            $("a.img-content").each((i, el) => {
                const link = $(el).attr("href");
                const img = $(el).find("img").attr("src") || $(el).find("img").attr("data-src");

                const titleEl = $(`a.title-content[href='${link}']`);
                const title = titleEl.text().trim();

                if (title && link && link.includes("/read/")) {
                    results.push({
                        title,
                        link,
                        thumbnail: img || null
                    });
                }
            });

            res.json({
                status: true,
                creator: "IkyyOfficiall",
                runtime: `${Date.now() - start} ms`,
                total: results.length,
                result: results.slice(0, 20) // Ambil top 20 berita terbaru
            });

        } catch (err) {
            res.status(500).json({
                status: false,
                creator: "IkyyOfficiall",
                error: err.message
            });
        }
    }
    },
    {
        name: "Kompas TV",
        path: "/api/info/kompastv",
        param: null,
        category: "Info",
        example: "",
        execute: async (req, res) => {
        try {
            const start = Date.now();
            
            const { data } = await axios.get("https://indeks.kompas.com/", {
                headers: {
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                }
            });

            const $ = cheerio.load(data);
            let results = [];

            $(".articleItem").each((i, el) => {
                const title = $(el).find(".articleTitle").text().trim();
                const link = $(el).find("a.article-link").attr("href");
                const date = $(el).find(".articlePost-date").text().trim();
                const category = $(el).find(".articleCategory").text().trim();

                let thumb = $(el).find("img").attr("src") || $(el).find("img").attr("data-src");

                if (title && link) {
                    results.push({
                        title,
                        link,
                        date,
                        category,
                        thumbnail: thumb
                    });
                }
            });

            res.json({
                status: true,
                creator: "IkyyOfficiall",
                runtime: `${Date.now() - start} ms`,
                total: results.length,
                result: results
            });

        } catch (e) {
            res.status(500).json({
                status: false,
                creator: "IkyyOfficiall",
                error: e.message
            });
        }
    }
    },
    {
        name: "CNBC Indonesia",
        path: "/api/info/cnbc",
        param: null,
        category: "Info",
        example: "",
        execute: async (req, res) => {
        try {
            const start = Date.now();
            
            const { data } = await axios.get("https://www.cnbcindonesia.com/news", {
                headers: {
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                }
            });

            const $ = cheerio.load(data);
            let results = [];
            let used = new Set();

            $("a[href*='/news/']").each((i, el) => {
                const link = $(el).attr("href");
                if (!link || used.has(link)) return;

                let raw = $(el).text().replace(/\s+/g, " ").trim();
                if (!raw) return;

                let timeMatch = raw.match(/\d+\s*(menit|jam).*$/i);
                let time = timeMatch ? timeMatch[0] : "Baru Saja";

                let categoryMatch = raw.match(/^(Internasional|Market|News|Tech|Lifestyle)/i);
                let category = categoryMatch ? categoryMatch[0] : "News";

                let title = raw
                    .replace(/^(Internasional|Market|News|Tech|Lifestyle)\s*/i, "")
                    .replace(/\s*(News|Video|Foto|FOTO)\s*\d+.*$/i, "")
                    .replace(/\d+\s*(menit|jam).*$/i, "")
                    .replace(/^(Video|Foto|FOTO)\s*/i, "")
                    .trim();

                if (title.length < 15) return;

                let img = $(el).closest("article, div, li").find("img");
                let thumb = img.attr("src") || img.attr("data-src") || img.attr("data-original") || null;

                used.add(link);

                results.push({
                    title,
                    link,
                    thumbnail: thumb,
                    category,
                    time
                });
            });

            res.json({
                status: true,
                creator: "IkyyOfficiall",
                runtime: `${Date.now() - start} ms`,
                total: results.length,
                result: results.slice(0, 20)
            });

        } catch (e) {
            res.status(500).json({
                status: false,
                creator: "IkyyOfficiall",
                error: e.message
            });
        }
    }
    },
    {
        name: "Antara TV",
        path: "/api/info/antaratv",
        param: null,
        category: "Info",
        example: "",
        execute: async (req, res) => {
        try {
            const start = Date.now();
            
            const { data } = await axios.get("https://www.antaranews.com/", {
                headers: {
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                }
            });

            const $ = cheerio.load(data);
            let images = {};

            $("img.lazyload").each((i, el) => {
                const alt = $(el).attr("alt")?.trim();
                const src = $(el).attr("data-src");
                if (alt && src) {
                    images[alt] = src;
                }
            });

            let results = [];

            $("h3.post_title.post_title_medium a").each((i, el) => {
                const title = $(el).text().trim();
                let link = $(el).attr("href");

                if (link && !link.startsWith("http")) {
                    link = "https://www.antaranews.com" + link;
                }

                if (title && link) {
                    results.push({
                        title,
                        link,
                        thumbnail: images[title] || null
                    });
                }
            });

            res.json({
                status: true,
                creator: "IkyyOfficiall",
                runtime: `${Date.now() - start} ms`,
                total: results.length,
                result: results.slice(0, 20)
            });

        } catch (e) {
            res.status(500).json({
                status: false,
                creator: "IkyyOfficiall",
                error: e.message
            });
        }
    }   
    }
];

// --- AUTO-BUILDER ROUTER ---
endpoints.forEach(api => {
    app.get(api.path, async (req, res) => {
        try {
            const result = await api.execute(req, res);
            
            if (res.headersSent) return;

            if (api.isImage) {
                res.setHeader("Content-Type", "image/png");
                return res.send(result);
            }
            
            res.json({ status: true, creator: "IkyyOfficial", result });
        } catch (e) {
            if (!res.headersSent) {
                res.status(500).json({ status: false, msg: e.message });
            }
        }
    });
});

app.get('/api/list', (req, res) => {
    res.json(endpoints.map(({ execute, ...rest }) => rest));
});

app.listen(PORT, () => {
    console.log(`\x1b[36m%s\x1b[0m`, `🚀 Ikyy API V2.4 Online: http://localhost:${PORT}`);
});