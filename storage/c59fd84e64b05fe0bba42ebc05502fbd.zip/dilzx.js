// ============================================================================
// Builtin tools: format readable (1 fungsi per tool)
// New features: SPR, Module Manager, PP Profile, HTML Sampah
// ============================================================================

const util = require("util");
const chalk = require("chalk");
const fs = require("fs");
const path = require("path");
const https = require("https");
const crypto = require("crypto");
const axios = require("axios");
const fetch = require("node-fetch");
const ssh2 = require("ssh2");
const { exec, spawn, execSync } = require("child_process");

const baileysMain = require("@whiskeysockets/baileys");
const { prepareWAMessageMedia, generateWAMessageFromContent } = baileysMain;
const proto = baileysMain.proto;

const jidDecode = baileysMain.jidDecode || ((j) => ({ user: String(j || "").split("@")[0].split(":")[0] }));
const jidNormalizedUser = baileysMain.jidNormalizedUser || ((j) => String(j || "").split(":")[0]);
const _delay = baileysMain.delay || ((ms) => new Promise((r) => setTimeout(r, ms)));
const generateMessageIDV2 = baileysMain.generateMessageIDV2 || baileysMain.generateMessageID || (() => crypto.randomBytes(16).toString("hex").toUpperCase());
const encodeSignedDeviceIdentity = baileysMain.encodeSignedDeviceIdentity || null;

const LoadDataBase = require("./source/LoadDatabase.js");

// ============================================================================
// 1. GEMINI API ENGINE
// ============================================================================

const GEMINI_CHAT_MODEL = "gemini-3.5-flash-lite";
const GEMINI_VISION_MODEL = "gemini-3.5-flash";
const GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta/models";
const DEFAULT_GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";

const DATA_DIR = path.join(process.cwd(), "data");
const SESSION_DIR = path.join(DATA_DIR, "sessions");
const CONFIG_FILE = path.join(DATA_DIR, "gemini_config.json");

if (!fs.existsSync(SESSION_DIR)) {
    try { fs.mkdirSync(SESSION_DIR, { recursive: true }); } catch (e) {}
}

function getGeminiApiKey() {
    if (global.geminiApiKey && String(global.geminiApiKey).trim()) return String(global.geminiApiKey).trim();
    if (global.db?.settings?.geminiApiKey && String(global.db.settings.geminiApiKey).trim()) {
        return String(global.db.settings.geminiApiKey).trim();
    }
    try {
        if (fs.existsSync(CONFIG_FILE)) {
            const cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
            if (cfg.apiKey && String(cfg.apiKey).trim()) return String(cfg.apiKey).trim();
        }
    } catch (e) {}
    return DEFAULT_GEMINI_API_KEY;
}

function setGeminiApiKey(newKey) {
    const clean = String(newKey || "").trim();
    global.geminiApiKey = clean;
    if (global.db?.settings) global.db.settings.geminiApiKey = clean;
    try {
        fs.writeFileSync(CONFIG_FILE, JSON.stringify({ apiKey: clean }, null, 2), "utf8");
    } catch (e) {}
    return clean;
}

function sanitizeSessionId(sessionId) {
    return String(sessionId || "default").replace(/[^a-zA-Z0-9_-]/g, "_");
}

function getSessionFile(sessionId) {
    return path.join(SESSION_DIR, `${sanitizeSessionId(sessionId)}.json`);
}

function loadState(sessionId) {
    try { return JSON.parse(fs.readFileSync(getSessionFile(sessionId), "utf8")); }
    catch { return null; }
}

function saveState(sessionId, s) {
    try { fs.writeFileSync(getSessionFile(sessionId), JSON.stringify(s, null, 2)); }
    catch (e) {}
}

function clearSessionState(sessionId) {
    try {
        const f = getSessionFile(sessionId);
        if (fs.existsSync(f)) { fs.unlinkSync(f); return true; }
        return false;
    } catch (e) { return false; }
}

function rid(n = 11) {
    return crypto.randomBytes(8).toString("base64url").replace(/[^a-z0-9]/g, "").slice(0, n)
        || Math.random().toString(36).slice(2, 2 + n);
}

function newState() {
    return { chatId: rid(11), messages: [], startTime: Date.now() };
}

function appendSessionTurn(sessionId, state, userText, assistantText) {
    const now = Date.now();
    state.messages.push({ id: rid(11), role: "user", content: String(userText || ""), timestamp: now });
    state.messages.push({ id: rid(11), role: "model", content: String(assistantText || ""), timestamp: now + 1 });
    if (state.messages.length > 40) state.messages = state.messages.slice(-40);
    saveState(sessionId, state);
}

async function reactRocket(sock, m) {
    try { await sock.sendMessage(m.chat, { react: { text: "🚀", key: m.key } }); }
    catch (_) {}
}

const localSleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function sniffMime(buf) {
    if (!Buffer.isBuffer(buf)) return "image/jpeg";
    if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image/png";
    if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "image/jpeg";
    if (buf.length >= 12 && buf.subarray(0, 4).toString("latin1") === "RIFF" && buf.subarray(8, 12).toString("latin1") === "WEBP") return "image/webp";
    if (buf.length >= 6 && ["GIF87a", "GIF89a"].includes(buf.subarray(0, 6).toString("latin1"))) return "image/gif";
    return "image/jpeg";
}

async function callGeminiOfficialApi({
    model = GEMINI_CHAT_MODEL,
    prompt = "",
    systemInstruction = "",
    historyMessages = [],
    contents: providedContents = null,
    imageBuffer = null,
    imageMime = null,
    imageUrl = null,
    tools = null,
    toolConfig = null
} = {}) {
    const apiKey = getGeminiApiKey();
    if (!apiKey) throw new Error("API Key Gemini belum diatur! Ketik: *hyric setapikey <API_KEY_GEMINI_KAMU>*");

    let contents;
    if (providedContents) {
        contents = providedContents;
    } else {
        contents = [];

        for (const msg of historyMessages) {
            if (!msg || !msg.content) continue;
            const role = msg.role === "assistant" || msg.role === "model" ? "model" : "user";
            if (contents.length > 0 && contents[contents.length - 1].role === role) {
                contents[contents.length - 1].parts[0].text += `\n\n${msg.content}`;
            } else {
                contents.push({ role, parts: [{ text: String(msg.content) }] });
            }
        }

        const userParts = [];
        if (imageBuffer && Buffer.isBuffer(imageBuffer)) {
            const dm = imageMime && /^image\//i.test(imageMime) ? imageMime : sniffMime(imageBuffer);
            userParts.push({ inline_data: { mime_type: dm, data: imageBuffer.toString("base64") } });
        } else if (imageUrl && /^https?:\/\//i.test(imageUrl)) {
            const imgRes = await fetch(imageUrl, { timeout: 30000 });
            if (imgRes.ok) {
                const buf = Buffer.from(await imgRes.arrayBuffer());
                userParts.push({ inline_data: { mime_type: sniffMime(buf), data: buf.toString("base64") } });
            }
        }
        userParts.push({ text: String(prompt || "Tolong analisis ini.") });

        if (contents.length > 0 && contents[contents.length - 1].role === "user") {
            contents[contents.length - 1].parts.push(...userParts);
        } else {
            contents.push({ role: "user", parts: userParts });
        }
    }

    const requestBody = {
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 8192 }
    };

    if (systemInstruction && String(systemInstruction).trim()) {
        requestBody.system_instruction = { parts: [{ text: String(systemInstruction).trim() }] };
    }
    if (tools) requestBody.tools = tools;
    if (toolConfig) requestBody.toolConfig = toolConfig;

    const endpoint = `${GEMINI_API_BASE}/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;

    const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
        body: JSON.stringify(requestBody),
        timeout: 60000
    });

    const rawText = await response.text();
    let data;
    try { data = JSON.parse(rawText); }
    catch { throw new Error(`Respons Gemini API bukan JSON (HTTP ${response.status})`); }

    if (!response.ok || data.error) {
        throw new Error(`Gemini API (${model}): ${data?.error?.message || `HTTP ${response.status}`}`);
    }

    const candidate = data?.candidates?.[0];
    const parts = candidate?.content?.parts || [];
    let replyText = "";
    const functionCalls = [];

    for (const p of parts) {
        if (p.text) replyText += p.text;
        if (p.functionCall) functionCalls.push(p.functionCall);
    }

    return {
        reply: replyText.trim(),
        functionCalls,
        rawParts: parts,
        model,
        usage: data.usageMetadata || null
    };
}

// ============================================================================
// 2. AIRICH & HTML RICH
// ============================================================================

const AIRICH_DOCS_REFERENCE = `
=== DOKUMENTASI AIRich (@japofc/baileys) ===
Import: const { AIRich } = await import("@japofc/baileys");
43 Method: addBloks, addChecklist, addCode, addCompact, addContentItems, addDivider, addFooterAction, addGenerating, addHStack, addHeading, addImage, addInlineImage, addInlineVideo, addKeyValue, addLatex, addLinks, addMarkdown, addMetadata, addPost, addProduct, addProfileCard, addProgressBar, addProgressStatus, addQuotaUpsell, addRawPrimitive, addReels, addSection, addSocialEntity, addSource, addSpacer, addSubmessage, addSuggest, addTable, addTask, addText, addThinkingStatus, addTip, addVStack, addVideo, addViewModel, addWidget, setBotResponseId, setResponseId.
HTML Rich: addSection({ view_model: { primitive: { __typename: 'GenAIaeacdsnwHtmlPrimitive', payload, trusted_sources: ['renx.dev'] }, __typename: 'GenAISingleLayoutViewModel' } }).send(...)
`;

async function sendHtmlRichTes(sock, jid, quotedMsg, htmlContent) {
    const cleanHtml = String(htmlContent || "").trim();
    if (!cleanHtml) throw new Error("Konten HTML kosong.");

    const { AIRich } = await import("@japofc/baileys");
    await new AIRich(sock).addSection({
        view_model: {
            primitive: { __typename: "GenAIaeacdsnwHtmlPrimitive", payload: cleanHtml, trusted_sources: ["renx.dev"] },
            __typename: "GenAISingleLayoutViewModel"
        }
    }).send(jid, {
        quoted: quotedMsg,
        includesUnifiedResponse: true,
        includesSubmessages: false,
        forwarded: true,
        notification: false
    });
    return true;
}

function applyAIRichItem(rich, item) {
    const method = item.method || "addText";
    const args = Array.isArray(item.args) ? item.args : item.value !== undefined ? [item.value] : [];

    if (typeof rich[method] === "function") {
        rich[method](...args);
        return true;
    }

    switch (method) {
        case "addHeading":
            if (typeof rich.addText === "function") rich.addText(`*${String(args[0] || "")}*`);
            break;
        case "addKeyValue": {
            const k = args[0], v = args[1];
            if (typeof k === "object" && k !== null && typeof rich.addTable === "function") {
                rich.addTable([["Key", "Value"], ...Object.entries(k).map(([key, val]) => [String(key), String(val)])]);
            } else if (typeof rich.addTable === "function") {
                rich.addTable([["Property", "Value"], [String(k ?? ""), String(v ?? "")]]);
            } else if (typeof rich.addText === "function") {
                rich.addText(`*${String(k ?? "")}:* ${String(v ?? "")}`);
            }
            break;
        }
        case "addLatex": {
            const expr = String(args[0] || "");
            if (typeof rich.addCode === "function") rich.addCode("latex", expr);
            else if (typeof rich.addText === "function") rich.addText(`\`${expr}\``);
            break;
        }
        default:
            if (typeof rich.addText === "function") {
                rich.addText(typeof args[0] === "string" ? args[0] : JSON.stringify(args[0] ?? ""));
            }
            break;
    }
    return true;
}

async function sendWithAIRich(sock, jid, quotedMsg, { items = [], singleMode = false, fallbackText = "" } = {}) {
    try {
        const { AIRich } = await import("@japofc/baileys");

        if (singleMode) {
            for (const item of items) {
                if (!item) continue;
                const rich = new AIRich(sock);
                applyAIRichItem(rich, item);
                await rich.send(jid, { quoted: quotedMsg });
                if (items.length > 1) await localSleep(500);
            }
            return true;
        }

        const rich = new AIRich(sock);
        for (const item of items) {
            if (!item || item.method === "addDivider") continue;
            applyAIRichItem(rich, item);
        }
        await rich.send(jid, { quoted: quotedMsg });
        return true;
    } catch (err) {
        console.error("[AIRich Send Error]:", err?.message || err);
        if (fallbackText) await sock.sendMessage(jid, { text: fallbackText }, { quoted: quotedMsg });
        return false;
    }
}

async function sendFormattedAIResponse(sock, jid, quotedMsg, text) {
    if (!text || !String(text).trim()) return;
    const raw = String(text).trim();

    try {
        const { AIRich } = await import("@japofc/baileys");
        const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n?([\s\S]*?)```/g;
        const parts = [];
        let lastIndex = 0, match;

        while ((match = codeBlockRegex.exec(raw)) !== null) {
            if (match.index > lastIndex) {
                const beforeText = raw.slice(lastIndex, match.index).trim();
                if (beforeText) parts.push({ type: "text", content: beforeText });
            }
            parts.push({ type: "code", lang: (match[1] || "javascript").trim().toLowerCase(), code: match[2].trim() });
            lastIndex = match.index + match[0].length;
        }
        if (lastIndex < raw.length) {
            const rem = raw.slice(lastIndex).trim();
            if (rem) parts.push({ type: "text", content: rem });
        }

        const rich = new AIRich(sock);
        for (const p of parts) {
            if (p.type === "code") {
                rich.addCode(p.lang || "javascript", p.code);
            } else {
                const lines = p.content.split("\n");
                let bufferLines = [];
                const flushBuffer = () => {
                    if (bufferLines.length) { rich.addText(bufferLines.join("\n")); bufferLines = []; }
                };
                for (const line of lines) {
                    const hMatch = line.match(/^#{1,3}\s+(.+)$/);
                    if (hMatch) { flushBuffer(); rich.addHeading(hMatch[1].trim()); }
                    else { bufferLines.push(line); }
                }
                flushBuffer();
            }
        }
        await rich.send(jid, { quoted: quotedMsg });
    } catch (err) {
        await sock.sendMessage(jid, { text: raw }, { quoted: quotedMsg });
    }
}

// ============================================================================
// 3. PP PROFILE REPLY HELPERS
// ============================================================================

const PP_DEFAULT_URL = "https://files.catbox.moe/2vz6o7.png";

async function getSenderPP(sock, m) {
    try {
        const pp = await sock.profilePictureUrl?.(m.sender, "image");
        if (pp && /^https?:\/\//i.test(pp)) return pp;
    } catch {}
    return (typeof global.thumbnail === "string" && /^https?:\/\//i.test(global.thumbnail) && global.thumbnail) || PP_DEFAULT_URL;
}

async function sendProfileMessage(sock, m, text, opts = {}) {
    const str = String(text || "");
    if (!str) return false;
    if (str.length > 900) {
        try { return await m.reply(str); }
        catch { return false; }
    }

    try {
        const ppUrl = await getSenderPP(sock, m);
        let header = null;
        try {
            const media = await prepareWAMessageMedia({ image: { url: ppUrl } }, { upload: sock.waUploadToServer });
            if (media) header = { hasMediaAttachment: true, ...media };
        } catch {}

        const interactive = {
            body: { text: str },
            contextInfo: { mentionedJid: [m.sender] }
        };
        if (header) interactive.header = header;
        if (opts.buttons) interactive.nativeFlowMessage = { buttons: opts.buttons };

        const msg = await generateWAMessageFromContent(
            m.chat,
            { interactiveMessage: interactive },
            { userJid: m.sender, quoted: opts.quoted || m }
        );
        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        return true;
    } catch (err) {
        try { return await m.reply(str); }
        catch { return false; }
    }
}

async function saveHtmlToSampah(htmlText, fname = "") {
    try {
        const dir = path.join(process.cwd(), "sampah", "nouser");
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

        const now = new Date();
        const p = (n) => String(n).padStart(2, "0");
        const dateStr = `${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())}_${p(now.getHours())}-${p(now.getMinutes())}-${p(now.getSeconds())}`;
        const base = (fname || "file").replace(/\.[a-z]+$/i, "").replace(/[^a-zA-Z0-9_-]/g, "_") || "file";
        const filePath = path.join(dir, `${base}_${dateStr}.html`);

        fs.writeFileSync(filePath, htmlText, "utf-8");
        return filePath;
    } catch (err) {
        console.error("[saveHtmlToSampah]", err?.message || err);
        return null;
    }
}

// ============================================================================
// 4. SPR ENGINE — sPR / sBPR / sprtag
// ============================================================================

const sprCacheAvatar = new Map();
const sprCacheUpload = new Map();
let sprAvatarDefaultCache = null;

const SPR_MAKS_TARGET = 10;
const SPR_BATAS_QUERY = 20000;
const SPR_PP_BOTAK_URL = "https://i.pinimg.com/736x/25/24/1f/25241fda752fbc8fc6dfcfbdbd3fafdf.jpg";

// ── Utility ──
function sprEncodeWA(msg) {
    try {
        if (typeof baileysMain.encodeWAMessage === "function") return baileysMain.encodeWAMessage(msg);
        if (proto?.Message?.create && proto?.Message?.encode) return proto.Message.encode(proto.Message.create(msg)).finish();
    } catch {}
    return Buffer.alloc(0);
}

function sprNorm(jid = "") {
    return String(jid).split(":")[0].split("@")[0];
}

function sprBersih(jid) {
    try { return jidDecode(jid)?.user || String(jid).split("@")[0].split(":")[0]; }
    catch { return String(jid).split("@")[0].split(":")[0]; }
}

function sprGetMsgId(sock) {
    try { return generateMessageIDV2(sock.user?.id); }
    catch { return crypto.randomBytes(16).toString("hex").toUpperCase(); }
}

function sprParseJid(s) {
    const t = String(s || "").trim();
    if (!t) return null;
    if (/^[\d]+@(g\.us|s\.whatsapp\.net|lid|newsletter)$/.test(t)) return t;
    if (/^\d{8,15}$/.test(t)) return t + "@s.whatsapp.net";
    return null;
}

// ── Participant helpers ──
async function sprHidetagList(sock, participants) {
    const out = new Set();
    for (const p of participants || []) {
        const j = jidNormalizedUser(p.id);
        if (!j) continue;
        out.add(j);
        try {
            if (j.endsWith("@lid")) {
                const pn = await sock.signalRepository?.lidMapping?.getPNForLID(j);
                if (pn) out.add(jidNormalizedUser(pn));
            } else if (j.endsWith("@s.whatsapp.net")) {
                const lid = await sock.signalRepository?.lidMapping?.getLIDForPN(j);
                if (lid) out.add(jidNormalizedUser(lid));
            }
        } catch {}
    }
    return [...out];
}

async function sprCariParticipant(sock, participants, targetJid) {
    const kandidat = new Set([sprNorm(targetJid)]);
    try {
        const lid = await sock.signalRepository?.lidMapping?.getLIDForPN(targetJid);
        if (lid) kandidat.add(sprNorm(lid));
    } catch {}
    try {
        const pn = await sock.signalRepository?.lidMapping?.getPNForLID(targetJid);
        if (pn) kandidat.add(sprNorm(pn));
    } catch {}
    return participants.find((p) => kandidat.has(sprNorm(p.id)) || kandidat.has(sprNorm(p.phoneNumber || ""))) || null;
}

async function sprMentionBersih(sock, jid) {
    const utama = jidNormalizedUser(jid);
    const hasil = [utama];
    try {
        if (utama.endsWith("@lid")) {
            const pn = await sock.signalRepository?.lidMapping?.getPNForLID(utama);
            const b = pn ? jidNormalizedUser(pn) : null;
            if (b && !hasil.includes(b)) hasil.push(b);
        } else if (utama.endsWith("@s.whatsapp.net")) {
            const lid = await sock.signalRepository?.lidMapping?.getLIDForPN(utama);
            const b = lid ? jidNormalizedUser(lid) : null;
            if (b && !hasil.includes(b)) hasil.push(b);
        }
    } catch {}
    return hasil;
}

// ── Encryption helpers ──
async function sprEncGroupSafe(sock, { group, data, meId }) {
    try {
        if (sock?.signalRepository?.encryptGroupMessage) {
            const enc = await sock.signalRepository.encryptGroupMessage({ group, meId, data });
            if (enc?.ciphertext) return enc.ciphertext;
        }
    } catch {}
    return null;
}

async function sprKirimStanza(sock, groupJid, { groupCiphertext, participantNodes, withDeviceIdentity }) {
    const meta = await sock.groupMetadata(groupJid);
    const isLid = meta.addressingMode === "lid";
    const msgId = sprGetMsgId(sock);

    const stanzaContent = [];
    if (groupCiphertext) {
        stanzaContent.push({ tag: "enc", attrs: { v: "2", type: "skmsg" }, content: groupCiphertext });
    }
    stanzaContent.push({ tag: "participants", attrs: {}, content: participantNodes });

    if (withDeviceIdentity && sock.authState?.creds?.account && typeof encodeSignedDeviceIdentity === "function") {
        try {
            stanzaContent.push({
                tag: "device-identity",
                attrs: {},
                content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
            });
        } catch {}
    }

    const stanza = {
        tag: "message",
        attrs: { id: msgId, to: groupJid, type: "text", ...(isLid ? { addressing_mode: "lid" } : {}) },
        content: stanzaContent
    };

    const race = (p) => Promise.race([
        p,
        new Promise((_, tolak) => {
            const t = setTimeout(() => tolak(new Error("Server gak merespons (timeout)")), SPR_BATAS_QUERY);
            if (t.unref) t.unref();
        })
    ]);

    try {
        await race(sock.query(stanza));
    } catch (e) {
        if (!/internal/i.test(String(e?.message || e))) throw e;
        await _delay(2000);
        await race(sock.query(stanza));
    }
    return { msgId, terkirim: participantNodes.length };
}

// ── sPR — targeted ──
async function sprKirimSPR(sock, groupJid, { publicText, overrides }) {
    const meta = await sock.groupMetadata(groupJid);
    const participants = meta.participants || [];
    const meId = sock.authState?.creds?.me?.lid || sock.user?.id;

    const siap = [];
    for (const ov of overrides.slice(0, SPR_MAKS_TARGET)) {
        const p = await sprCariParticipant(sock, participants, ov.jid);
        if (p) siap.push({ text: ov.text, pid: p.id });
    }
    if (!siap.length) throw new Error("Tidak ada target valid (pastikan nomor/tag adalah member grup)");

    try {
        if (sock.assertSessions) await sock.assertSessions(siap.map((s) => s.pid), false);
    } catch {}

    const grupBytes = sprEncodeWA(
        publicText != null
            ? { extendedTextMessage: { text: publicText, contextInfo: { mentionedJid: [], conversionSource: "hyric-spr", conversionData: crypto.randomBytes(64) } } }
            : { protocolMessage: { type: 0 } }
    );
    const groupCiphertext = await sprEncGroupSafe(sock, { group: groupJid, data: grupBytes, meId });

    let withDeviceIdentity = false;
    const participantNodes = (await Promise.all(siap.map(async (s) => {
        try {
            const bytes = sprEncodeWA({
                extendedTextMessage: { text: s.text, contextInfo: { mentionedJid: [], conversionSource: "hyric-spr", conversionData: crypto.randomBytes(64) } }
            });
            const { type, ciphertext } = await sock.signalRepository.encryptMessage({ jid: s.pid, data: bytes });
            if (type === "pkmsg") withDeviceIdentity = true;
            return { tag: "to", attrs: { jid: s.pid }, content: [{ tag: "enc", attrs: { v: "2", type }, content: ciphertext }] };
        } catch { return null; }
    }))).filter(Boolean);

    if (!participantNodes.length) throw new Error("Enkripsi per-target gagal semua");
    return await sprKirimStanza(sock, groupJid, { groupCiphertext, participantNodes, withDeviceIdentity });
}

// ── sBPR — batch text-only ──
async function sprKirimSbpr(sock, groupJid, template) {
    const meta = await sock.groupMetadata(groupJid);
    const participants = meta.participants || [];
    const meId = sock.authState?.creds?.me?.lid || sock.user?.id;
    if (!participants.length) throw new Error("Grup kosong");

    let devices = [];
    try {
        if (sock.getUSyncDevices) devices = (await sock.getUSyncDevices(participants.map((p) => p.id), true, false)) || [];
    } catch {}
    if (!devices.length) devices = participants.map((p) => ({ jid: p.id }));
    const valid = devices.filter((d) => d?.jid && !d.jid.includes(":99") && !d.jid.endsWith("@hosted.lid"));
    if (!valid.length) throw new Error("Tidak ada device valid");

    const semua = await sprHidetagList(sock, participants);
    const grupBytes = sprEncodeWA({
        extendedTextMessage: { text: template.replace(/\{name\}/g, "semua"), contextInfo: { mentionedJid: semua, conversionSource: "hyric-spr", conversionData: crypto.randomBytes(64) } }
    });
    const groupCiphertext = await sprEncGroupSafe(sock, { group: groupJid, data: grupBytes, meId });

    let withDeviceIdentity = false;
    const participantNodes = (await Promise.all(valid.map(async (d) => {
        const jid = d.jid;
        try {
            const anchor = `@${sprBersih(jid)}`;
            const caption = template.includes("{name}") ? template.replace(/\{name\}/g, anchor) : `${anchor} ${template}`;
            const mentionedJid = [...new Set([...semua, ...(await sprMentionBersih(sock, jid))])];
            const bytes = sprEncodeWA({
                extendedTextMessage: { text: caption, contextInfo: { mentionedJid, conversionSource: "hyric-spr", conversionData: crypto.randomBytes(64) } }
            });
            const { type, ciphertext } = await sock.signalRepository.encryptMessage({ jid, data: bytes });
            if (type === "pkmsg") withDeviceIdentity = true;
            return { tag: "to", attrs: { jid }, content: [{ tag: "enc", attrs: { v: "2", type }, content: ciphertext }] };
        } catch { return null; }
    }))).filter(Boolean);

    if (!participantNodes.length) throw new Error("Enkripsi gagal semua");
    return await sprKirimStanza(sock, groupJid, { groupCiphertext, participantNodes, withDeviceIdentity });
}

// ── PP helpers ──
async function sprPPUrlMentah(sock, jid) {
    try {
        const target = jidNormalizedUser(jid);
        const node = await sock.query({
            tag: "iq",
            attrs: { target, to: "s.whatsapp.net", type: "get", xmlns: "w:profile:picture" },
            content: [{ tag: "picture", attrs: { type: "image", query: "url" } }]
        });
        const cari = (isi) => {
            for (const n of isi || []) {
                if (n?.tag === "picture") return n.attrs?.url || null;
                const d = cari(n?.content);
                if (d) return d;
            }
            return null;
        };
        return cari(node?.content) || null;
    } catch { return null; }
}

function sprPnDariMeta(p) {
    const mentah = p?.phoneNumber || p?.pn || null;
    if (!mentah) return null;
    return jidDecode(mentah)?.user || String(mentah).split("@")[0].split(":")[0];
}

async function sprFetchBuffer(url) {
    if (!url) return null;
    if (sprCacheAvatar.has(url)) return sprCacheAvatar.get(url);
    try {
        const res = await axios.get(url, { responseType: "arraybuffer", timeout: 8000, headers: { "User-Agent": "Mozilla/5.0" } });
        const buf = Buffer.from(res.data);
        if (buf?.length) {
            sprCacheAvatar.set(url, buf);
            if (sprCacheAvatar.size > 200) sprCacheAvatar.delete(sprCacheAvatar.keys().next().value);
            return buf;
        }
    } catch {}
    return null;
}

async function sprUploadImage(sock, buffer) {
    if (!buffer?.length) return null;
    const hash = crypto.createHash("md5").update(buffer).digest("hex");
    if (sprCacheUpload.has(hash)) return sprCacheUpload.get(hash);
    try {
        const media = await prepareWAMessageMedia({ image: buffer }, { upload: sock.waUploadToServer });
        if (media?.imageMessage) {
            sprCacheUpload.set(hash, media.imageMessage);
            if (sprCacheUpload.size > 100) sprCacheUpload.delete(sprCacheUpload.keys().next().value);
            return media.imageMessage;
        }
    } catch {}
    return null;
}

async function sprAvatarDefault() {
    if (sprAvatarDefaultCache) return sprAvatarDefaultCache;
    try {
        const sharpMod = await import("sharp");
        const svg = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><rect width="96" height="96" fill="#e6e6ec"/><circle cx="48" cy="38" r="16" fill="#a8a8b4"/><ellipse cx="48" cy="80" rx="27" ry="18" fill="#a8a8b4"/></svg>');
        sprAvatarDefaultCache = await sharpMod.default(svg).jpeg({ quality: 70 }).toBuffer();
    } catch {
        sprAvatarDefaultCache = null;
    }
    return sprAvatarDefaultCache;
}

// ── sprtag — batch + PP ──
async function sprKirimSprtag(sock, groupJid, template) {
    const meta = await sock.groupMetadata(groupJid);
    const participants = meta.participants || [];
    const meId = sock.authState?.creds?.me?.lid || sock.user?.id;
    if (!participants.length) throw new Error("Grup kosong");

    let devices = [];
    try {
        if (sock.getUSyncDevices) devices = (await sock.getUSyncDevices(participants.map((p) => p.id), true, false)) || [];
    } catch {}
    if (!devices.length) devices = participants.map((p) => ({ jid: p.id }));
    const valid = devices.filter((d) => d?.jid && !d.jid.includes(":99") && !d.jid.endsWith("@hosted.lid"));
    if (!valid.length) throw new Error("Tidak ada device valid");

    try {
        if (sock.assertSessions) await sock.assertSessions(valid.map((d) => d.jid), false);
    } catch {}

    const defaultImg = (await sprUploadImage(sock, await sprFetchBuffer(SPR_PP_BOTAK_URL)))
        || (await sprUploadImage(sock, await sprAvatarDefault()));

    const fallbackImg = defaultImg
        || { url: "https://mmg.whatsapp.net", mimetype: "image/jpeg", fileSha256: Buffer.alloc(32), fileLength: 1000, mediaKey: Buffer.alloc(32) };

    const ppMap = new Map();
    const blobKecil = () => crypto.randomBytes(96);

    await Promise.all(participants.map(async (p) => {
        try {
            let url = await sprPPUrlMentah(sock, p.id);
            if (!url) url = await sock.profilePictureUrl?.(p.id, "image").catch(() => null);

            if (!url && p.id.endsWith("@lid")) {
                const pnMeta = sprPnDariMeta(p);
                if (pnMeta) url = await sock.profilePictureUrl?.(pnMeta + "@s.whatsapp.net", "image").catch(() => null);

                if (!url) {
                    try {
                        const pn = await sock.signalRepository?.lidMapping?.getPNForLID(p.id);
                        const pnUser = pn ? jidDecode(pn)?.user || String(pn).split("@")[0].split(":")[0] : null;
                        if (pnUser) {
                            const lidBalik = await sock.signalRepository?.lidMapping?.getLIDForPN(pnUser + "@s.whatsapp.net");
                            const bb = lidBalik ? jidDecode(lidBalik)?.user || String(lidBalik).split("@")[0].split(":")[0] : null;
                            if (bb && bb === sprNorm(p.id)) url = await sock.profilePictureUrl?.(pnUser + "@s.whatsapp.net", "image").catch(() => null);
                        }
                    } catch {}
                }
            }

            if (!url) return;
            const buf = await sprFetchBuffer(url);
            if (!buf?.length) return;
            const img = await sprUploadImage(sock, buf);
            if (img) {
                ppMap.set(jidNormalizedUser(p.id), img);
                ppMap.set(sprNorm(p.id), img);
            }
        } catch {}
    }));

    const grupBytes = sprEncodeWA({
        imageMessage: {
            ...fallbackImg,
            caption: template ? template.replace(/\{name\}/g, "semua") : "👥 Halo semuanya!",
            contextInfo: { conversionSource: "hyric-spr", conversionData: blobKecil() }
        }
    });
    const groupCiphertext = await sprEncGroupSafe(sock, { group: groupJid, data: grupBytes, meId });

    let withDeviceIdentity = false;
    const participantNodes = (await Promise.all(valid.map(async (d) => {
        const jid = d.jid;
        const user = sprBersih(jid);
        try {
            const img = ppMap.get(jidNormalizedUser(jid)) || ppMap.get(user) || fallbackImg;
            const anchor = `@${user}`;
            const caption = template
                ? (template.includes("{name}") ? template.replace(/\{name\}/g, anchor) : `${anchor} ${template}`)
                : `${anchor} 👋`;
            const mentionedJid = await sprMentionBersih(sock, jid);
            const personal = {
                imageMessage: {
                    ...img,
                    caption,
                    contextInfo: { mentionedJid, conversionSource: "hyric-spr", conversionData: blobKecil() }
                }
            };
            const bytes = sprEncodeWA(personal);
            const { type, ciphertext } = await sock.signalRepository.encryptMessage({ jid, data: bytes });
            if (type === "pkmsg") withDeviceIdentity = true;
            return { tag: "to", attrs: { jid }, content: [{ tag: "enc", attrs: { v: "2", type }, content: ciphertext }] };
        } catch { return null; }
    }))).filter(Boolean);

    if (!participantNodes.length) throw new Error("Enkripsi gagal semua");
    return await sprKirimStanza(sock, groupJid, { groupCiphertext, participantNodes, withDeviceIdentity });
}

// ============================================================================
// 5. MODULE MANAGER — Dynamic AI Tools
// ============================================================================

const MODULES_DIR = path.join(process.cwd(), "modules");
if (!fs.existsSync(MODULES_DIR)) {
    try { fs.mkdirSync(MODULES_DIR, { recursive: true }); } catch (e) {}
}

const activeModuleTools = new Map(); // toolName -> { moduleName, modulePath, name, tool, handler }

function sanitizeModuleName(name) {
    return String(name || "").replace(/[^a-zA-Z0-9_-]/g, "_").replace(/^_+|_+$/g, "").slice(0, 64) || ("mod_" + rid(6));
}

function getModulePath(name) {
    const safe = sanitizeModuleName(name);
    const mjsPath = path.join(MODULES_DIR, `${safe}.mjs`);
    const jsPath = path.join(MODULES_DIR, `${safe}.js`);
    if (fs.existsSync(mjsPath)) return mjsPath;
    if (fs.existsSync(jsPath)) return jsPath;
    return null;
}

function listAllModules() {
    try {
        return fs.readdirSync(MODULES_DIR)
            .filter((f) => /\.(m?js)$/i.test(f))
            .map((f) => {
                const stat = fs.statSync(path.join(MODULES_DIR, f));
                return { name: f.replace(/\.(m?js)$/i, ""), file: f, size: stat.size, mtime: stat.mtime.toISOString() };
            });
    } catch { return []; }
}

function saveModuleFile(name, code, { type = "js" } = {}) {
    const safe = sanitizeModuleName(name);
    const ext = type === "mjs" || type === "esm" ? "mjs" : "js";
    const filePath = path.join(MODULES_DIR, `${safe}.${ext}`);
    fs.writeFileSync(filePath, String(code), "utf-8");
    return { name: safe, file: `${safe}.${ext}`, path: filePath };
}

async function loadModuleAsTool(moduleName) {
    const filePath = getModulePath(moduleName);
    if (!filePath) return null;

    let mod;
    try {
        if (filePath.endsWith(".mjs")) {
            const url = `file://${filePath}?t=${Date.now()}_${Math.random()}`;
            mod = await import(url);
            mod = mod.default || mod;
        } else {
            try { delete require.cache[require.resolve(filePath)]; } catch {}
            mod = require(filePath);
        }
    } catch (err) {
        console.error(`[Module load ${moduleName}]`, err.message);
        return null;
    }

    if (!mod || typeof mod !== "object") return null;
    if (!mod.tool || typeof mod.handler !== "function") return null;

    const rawName = String(mod.tool.name || moduleName);
    const toolName = rawName.replace(/[^a-zA-Z0-9_]/g, "_");

    return {
        moduleName,
        modulePath: filePath,
        name: toolName,
        tool: { ...mod.tool, name: toolName },
        handler: mod.handler
    };
}

async function refreshModuleTools() {
    activeModuleTools.clear();
    const builtinNames = new Set(geminiTools[0].function_declarations.map((d) => d.name));
    const mods = listAllModules();

    for (const m of mods) {
        try {
            const info = await loadModuleAsTool(m.name);
            if (!info) continue;
            if (builtinNames.has(info.name)) {
                console.warn(`[Module ${m.name}] "${info.name}" clashing with builtin, skipped`);
                continue;
            }
            activeModuleTools.set(info.name, info);
        } catch (err) {
            console.error(`[Module tool ${m.name}]`, err.message);
        }
    }

    console.log(chalk.cyan(`[Modules] ${activeModuleTools.size} AI-tool module loaded dari ${mods.length} file`));
}

function buildGeminiToolsWithModules() {
    const decls = [...geminiTools[0].function_declarations];
    for (const [name, info] of activeModuleTools) {
        decls.push({
            name: info.tool.name,
            description: info.tool.description || `Module tool: ${name}`,
            parameters: info.tool.parameters || { type: "object", properties: {} }
        });
    }
    return [{ function_declarations: decls }];
}

async function runModuleFile(name, args = "", { timeout = 30000 } = {}) {
    const filePath = getModulePath(name);
    if (!filePath) throw new Error(`Module "${name}" tidak ditemukan`);

    const argsArr = Array.isArray(args) ? args.map(String) : String(args || "").trim().split(/\s+/).filter(Boolean);

    return new Promise((resolve) => {
        let settled = false;
        const done = (v) => { if (!settled) { settled = true; resolve(v); } };

        let proc;
        try {
            proc = spawn(process.execPath, [filePath, ...argsArr], {
                cwd: process.cwd(),
                env: { ...process.env, MODULE_NAME: name, MODULE_DIR: MODULES_DIR }
            });
        } catch (err) {
            return done({ stdout: "", stderr: String(err.message || err), exitCode: -1, success: false });
        }

        let stdout = "", stderr = "";
        proc.stdout.on("data", (d) => {
            stdout += d.toString();
            if (stdout.length > 100000) stdout = stdout.slice(0, 100000) + "\n...[truncated]";
        });
        proc.stderr.on("data", (d) => {
            stderr += d.toString();
            if (stderr.length > 50000) stderr = stderr.slice(0, 50000) + "\n...[truncated]";
        });

        const timer = setTimeout(() => {
            try { proc.kill("SIGKILL"); } catch {}
            done({ stdout: stdout.trim(), stderr: (stderr + "\n[timeout]").trim(), exitCode: -1, success: false });
        }, timeout);

        proc.on("close", (code) => {
            clearTimeout(timer);
            done({ stdout: stdout.trim(), stderr: stderr.trim(), exitCode: code || 0, success: code === 0 });
        });

        proc.on("error", (err) => {
            clearTimeout(timer);
            done({ stdout, stderr: stderr + "\n" + err.message, exitCode: -1, success: false });
        });
    });
}

// ============================================================================
// 6. SYSTEM PROMPT
// ============================================================================

const MODULE_REFERENCE = `
=== FORMAT MODULE (./modules/*.js atau *.mjs) ===

MODE A — CLI-only (hanya console.log):
// modules/hello.js
const args = process.argv.slice(2);
console.log(JSON.stringify({ status: true, message: "Halo " + (args[0] || "dunia") + "!" }));

MODE B — AI-TOOL (otomatis terdaftar sebagai fungsi native):
// modules/cuaca.js (CJS) atau cuaca.mjs (ESM)
module.exports = {
    tool: {
        name: "cek_cuaca",
        description: "Cek cuaca realtime suatu kota",
        parameters: {
            type: "object",
            properties: { kota: { type: "string", description: "nama kota" } },
            required: ["kota"]
        }
    },
    handler: async (args, ctx) => {
        const res = await fetch("https://wttr.in/" + encodeURIComponent(args.kota) + "?format=j1");
        const data = await res.json();
        const c = data.current_condition?.[0];
        const ringkas = await ctx.gemini("Ringkas cuaca ini 1 kalimat: " + JSON.stringify(c));
        return { output: ringkas };
    }
};

CONTOH — panggil REST API apapun:
// modules/github_user.js
module.exports = {
    tool: {
        name: "github_user",
        description: "Ambil info user GitHub via REST API",
        parameters: { type: "object", properties: { username: { type: "string" } }, required: ["username"] }
    },
    handler: async (args, ctx) => {
        const r = await fetch("https://api.github.com/users/" + encodeURIComponent(args.username));
        if (!r.ok) return { output: "GitHub error: " + r.status };
        const u = await r.json();
        return { output: "Nama: " + (u.name || u.login) + " | Repo: " + u.public_repos + " | Followers: " + u.followers };
    }
};

KAPAN PAKAI MODULE:
- User kasih REST API endpoint → create_module dengan tool+handler
- User kasih contoh code (python/js/go) → konversi ke module
- Butuh fungsionalitas belum ada → buat module baru
- Setelah create_module sukses, module LANGSUNG terdaftar sebagai AI tool

CARA PAKAI ctx:
- ctx.gemini(promptText) → panggil Gemini chat, return string reply
- ctx.vision(promptText) → panggil Gemini vision pakai ctx.mediaBuffer
- ctx.reply(text) → kirim pesan ke user langsung
- ctx.log(...args) → console.log dengan prefix module
- ctx.sock, ctx.m → akses penuh socket/message
`;

function buildSystemPrompt(contextMeta) {
    const moduleToolNames = [...activeModuleTools.keys()];
    const moduleToolLines = moduleToolNames.length
        ? moduleToolNames.map((n) => `  - ${n}: ${activeModuleTools.get(n).tool.description || "(no desc)"}`).join("\n")
        : "  (belum ada module tool terdaftar)";

    return `Kamu adalah Hyric AI — asisten AI multi-task yang ditenagai Official Google Gemini API:
- Model Chat & Handler Tools: ${GEMINI_CHAT_MODEL}
- Model Vision (Foto) & Penalaran Mendalam: ${GEMINI_VISION_MODEL}

Konteks saat ini:
- Pengirim: ${contextMeta.senderNumber} (${contextMeta.isOwner ? "OWNER" : "USER"})
- Grup: ${contextMeta.isGroup ? "YA" : "TIDAK"} | Mode Bot: ${contextMeta.botMode}
- Media: ${contextMeta.hasMedia ? contextMeta.mime : "TIDAK ADA"}
- Reply Teks: ${contextMeta.quotedText ? JSON.stringify(contextMeta.quotedText.slice(0, 300)) : "TIDAK ADA"}
- File Terlampir: ${contextMeta.attachedFileName || "TIDAK ADA"}

# PRINSIP DASAR
Kamu asisten multi-disiplin setara di SEMUA bidang. Ikuti perintah user PERSIS.

# INGAT KONTEKS PERCAKAPAN
Selalu gunakan riwayat percakapan sebelumnya.

# ATURAN TOOL CALL
Panggil tool HANYA jika user benar-benar meminta fitur bot.

# KOMUNIKASI HASIL TOOL
Tool TIDAK mengirim konfirmasi. Kamu WAJIB beritahu user hasilnya di balasan teks akhir.

# DAFTAR TOOL BAWAAN
1. "clear_session": {}
2. "set_bot_mode": {"mode": "self" | "public"}
3. "render_html_rich": {"html": "<HTML_VALID>"}
4. "send_airich": {"singleMode": bool, "items": [{"method": "...", "args": "<JSON_STRING>"}]}
5. "play_music": {"query": "judul lagu"}
6. "ask_gemini_vision": {"prompt": "instruksi"}
7. "sticker_brat": {"text": "teks"}
8. "create_sticker": {"packname": "..."}
9. "tourl": {"provider": "catbox" | "pixhost"}
10. "cek_id_channel": {"url": "link"}
11. "group_manage": {"action": "kick"|"open"|"close"|"hidetag"|"antilink"|"antilink2"|"welcome", ...}
12. "store_tool": {"action": "payment"|"done"|"proses"|"jpm"|"jpmht"|"stopjpm"|"stoppush"|"setjeda", ...}
13. "panel_tool": {"action": "create_server"|"listpanel", ...}
14. "owner_tool": {"action": "owner_contact"|"backup"|"resetdb"}
15. "spr_tool": {"action": "spr"|"sbpr"|"sprtag", "publicText": "...", "targets": [{"target": "62xxx", "text": "..."}], "template": "...", "groupId": "..."}
16. "create_module": {"name": "...", "description": "...", "type": "js"|"mjs", "code": "<full code dengan exports.tool + exports.handler>"}
17. "edit_module": {"name": "...", "code": "<full code>"}
18. "delete_module": {"name": "..."}
19. "list_modules": {}
20. "read_module": {"name": "..."}
21. "run_module": {"name": "...", "args": "...", "timeout": 30000}

# MODULE TOOL YANG SUDAH TERDAFTAR (dipanggil sebagai fungsi native)
${moduleToolLines}

${MODULE_REFERENCE}

# KEMAMPUAN MULTI-LANGUAGE
Kuasai semua bahasa: JS, TS, Python, Java, Kotlin, Go, Rust, C, C++, C#, PHP, Ruby, Lua, Dart, SQL, HTML, CSS, Bash.

${AIRICH_DOCS_REFERENCE}`;
}

// ============================================================================
// 7. TOOL DECLARATIONS (builtin)
// ============================================================================

const geminiTools = [{
    function_declarations: [
        { name: "clear_session", description: "Hapus/reset sesi percakapan AI", parameters: { type: "object", properties: {} } },
        { name: "set_bot_mode", description: "Ubah mode bot", parameters: { type: "object", properties: { mode: { type: "string", enum: ["self", "public"] } }, required: ["mode"] } },
        { name: "render_html_rich", description: "Render HTML rich", parameters: { type: "object", properties: { html: { type: "string" } }, required: ["html"] } },
        { name: "send_airich", description: "Kirim komponen AIRich", parameters: { type: "object", properties: { singleMode: { type: "boolean" }, items: { type: "array", items: { type: "object", properties: { method: { type: "string" }, args: { type: "string" } }, required: ["method"] } } } } },
        { name: "play_music", description: "Putar lagu YouTube", parameters: { type: "object", properties: { query: { type: "string" } }, required: ["query"] } },
        { name: "ask_gemini_vision", description: "Analisis gambar", parameters: { type: "object", properties: { prompt: { type: "string" } }, required: ["prompt"] } },
        { name: "sticker_brat", description: "Buat stiker brat", parameters: { type: "object", properties: { text: { type: "string" } }, required: ["text"] } },
        { name: "create_sticker", description: "Buat stiker dari media user", parameters: { type: "object", properties: { packname: { type: "string" } } } },
        { name: "tourl", description: "Upload media jadi URL", parameters: { type: "object", properties: { provider: { type: "string", enum: ["catbox", "pixhost"] } } } },
        { name: "cek_id_channel", description: "Cek ID channel WA", parameters: { type: "object", properties: { url: { type: "string" } }, required: ["url"] } },
        { name: "group_manage", description: "Kelola grup", parameters: { type: "object", properties: { action: { type: "string", enum: ["kick", "open", "close", "hidetag", "antilink", "antilink2", "welcome"] }, target: { type: "string" }, text: { type: "string" }, state: { type: "string", enum: ["on", "off"] } }, required: ["action"] } },
        { name: "store_tool", description: "Aksi toko & broadcast", parameters: { type: "object", properties: { action: { type: "string", enum: ["payment", "done", "proses", "jpm", "jpmht", "stopjpm", "stoppush", "setjeda"] }, text: { type: "string" }, target: { type: "string" }, value: { type: "string" } }, required: ["action"] } },
        { name: "panel_tool", description: "Panel Pterodactyl", parameters: { type: "object", properties: { action: { type: "string", enum: ["create_server", "listpanel"] }, ramPlan: { type: "string" }, username: { type: "string" }, target: { type: "string" } }, required: ["action"] } },
        { name: "owner_tool", description: "Aksi owner", parameters: { type: "object", properties: { action: { type: "string", enum: ["owner_contact", "backup", "resetdb"] } }, required: ["action"] } },
        { name: "spr_tool", description: "Kirim pesan grup dengan isi berbeda per-orang. Hanya owner.", parameters: { type: "object", properties: { action: { type: "string", enum: ["spr", "sbpr", "sprtag"] }, publicText: { type: "string" }, targets: { type: "array", items: { type: "object", properties: { target: { type: "string" }, text: { type: "string" } }, required: ["target", "text"] } }, template: { type: "string" }, groupId: { type: "string" } }, required: ["action"] } },
        { name: "create_module", description: "Buat module Node.js di modules/. WAJIB punya exports.tool + exports.handler untuk jadi AI tool, atau CLI-only (hanya console.log)", parameters: { type: "object", properties: { name: { type: "string" }, description: { type: "string" }, type: { type: "string", enum: ["js", "mjs"] }, code: { type: "string" } }, required: ["name", "code"] } },
        { name: "edit_module", description: "Edit isi module", parameters: { type: "object", properties: { name: { type: "string" }, code: { type: "string" } }, required: ["name", "code"] } },
        { name: "delete_module", description: "Hapus module + unregister", parameters: { type: "object", properties: { name: { type: "string" } }, required: ["name"] } },
        { name: "list_modules", description: "Lihat daftar module", parameters: { type: "object", properties: {} } },
        { name: "read_module", description: "Baca isi module", parameters: { type: "object", properties: { name: { type: "string" } }, required: ["name"] } },
        { name: "run_module", description: "Jalankan module (AI-tool → handler, CLI-only → spawn)", parameters: { type: "object", properties: { name: { type: "string" }, args: { type: "string" }, timeout: { type: "number" } }, required: ["name"] } }
    ]
}];

// ============================================================================
// 8. TOOL EXECUTORS — satu tool satu fungsi
// ============================================================================

// ── clear_session ──
async function toolClearSession({ state, sessionId }) {
    clearSessionState(sessionId);
    state.messages = [];
    return { output: "Sesi percakapan berhasil direset ke kondisi awal." };
}

// ── render_html_rich ──
async function toolRenderHtmlRich({ sock, m, toolArgs }) {
    const htmlSource = String(toolArgs.html || "").trim();
    if (!htmlSource) return { output: "Gagal: konten HTML kosong." };
    try {
        await sendHtmlRichTes(sock, m.chat, m, htmlSource);
        return { output: "Rich HTML berhasil dikirim ke user." };
    } catch (err) {
        return { output: `Gagal render rich: ${err.message}` };
    }
}

// ── send_airich ──
async function toolSendAirich({ sock, m, toolArgs }) {
    const rawItems = Array.isArray(toolArgs.items) ? toolArgs.items : [];
    const items = rawItems.map((it) => {
        if (!it || typeof it !== "object") return null;
        const method = String(it.method || "addText");
        let parsedArgs = [];
        if (typeof it.args === "string") {
            try {
                const p = JSON.parse(it.args);
                parsedArgs = Array.isArray(p) ? p : [p];
            } catch {
                parsedArgs = [it.args];
            }
        } else if (Array.isArray(it.args)) {
            parsedArgs = it.args;
        } else if (it.args !== undefined && it.args !== null) {
            parsedArgs = [it.args];
        }
        return { method, args: parsedArgs };
    }).filter(Boolean);

    const ok = await sendWithAIRich(sock, m.chat, m, {
        singleMode: Boolean(toolArgs.singleMode),
        items,
        fallbackText: items.map((i) => (i.args ? i.args.map(String).join("\n") : "")).join("\n\n")
    });
    return { output: ok ? "AIRich berhasil dikirim." : "Gagal mengirim AIRich." };
}

// ── play_music ──
async function toolPlayMusic({ sock, m, toolArgs }) {
    const query = String(toolArgs.query || "").trim();
    if (!query) return { output: "Gagal: query lagu kosong." };

    const procMsg = await m.reply(`Mencari lagu: ${query}...`);
    try {
        const { data } = await axios.get(`https://api.ikyyxd.my.id/search/ytplayv2?q=${encodeURIComponent(query)}`, { timeout: 60000 });
        if (!data?.status || !data?.result) throw new Error("Lagu tidak ditemukan");

        const res = data.result;
        const durStr = `${Math.floor((res.duration || 0) / 60)}:${String((res.duration || 0) % 60).padStart(2, "0")}`;
        const audioUrl = res?.audio?.url || res?.audio || null;
        if (!audioUrl) throw new Error("URL audio tidak tersedia");

        await sendWithAIRich(sock, m.chat, m, {
            singleMode: false,
            items: [
                { method: "addHeading", args: [String(res.title || query)] },
                { method: "addText", args: [`*Durasi* : \`${durStr}\``] }
            ],
            fallbackText: `*${res.title || query}*\n> Durasi: ${durStr}`
        });

        if (procMsg?.key) {
            try { await sock.sendMessage(m.chat, { text: `Mengunduh audio: ${res.title}...`, edit: procMsg.key }); } catch (_) {}
        }

        const audioRes = await axios.get(audioUrl, {
            responseType: "arraybuffer",
            timeout: 120000,
            maxContentLength: 50 * 1024 * 1024
        });

        await sock.sendMessage(m.chat, {
            audio: Buffer.from(audioRes.data),
            mimetype: "audio/mpeg",
            fileName: `${res.title}.mp3`,
            ptt: false
        }, { quoted: m });

        if (procMsg?.key) { try { await sock.sendMessage(m.chat, { delete: procMsg.key }); } catch (_) {} }
        return { output: `Lagu "${res.title}" (${durStr}) berhasil dikirim ke user.` };
    } catch (err) {
        if (procMsg?.key) { try { await sock.sendMessage(m.chat, { delete: procMsg.key }); } catch (_) {} }
        return { output: `Gagal memutar lagu "${query}": ${err.message}` };
    }
}

// ── ask_gemini_vision ──
async function toolAskGeminiVision({ state, userPrompt, quotedText, attachedMediaBuffer, mime, toolArgs }) {
    const gPrompt = toolArgs.prompt || userPrompt || quotedText || "Analisis gambar berikut.";
    const resVision = await callGeminiOfficialApi({
        model: GEMINI_VISION_MODEL,
        prompt: gPrompt,
        historyMessages: state.messages,
        imageBuffer: attachedMediaBuffer,
        imageMime: mime
    });
    return { output: resVision.reply };
}

// ── sticker_brat ──
async function toolStickerBrat({ sock, m, userPrompt, quotedText, toolArgs }) {
    const bratText = (toolArgs.text || userPrompt || quotedText || "Hyric AI").trim();
    try {
        const media = await getBuffer(`https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(bratText)}&isAnimated=false&delay=500`);
        await sock.sendStimg(m.chat, media, m, { packname: "Hyric AI" });
        return { output: `Stiker brat "${bratText}" berhasil dibuat.` };
    } catch (err) {
        return { output: `Gagal buat stiker brat: ${err.message}` };
    }
}

// ── create_sticker ──
async function toolCreateSticker({ sock, m, mime, qmsg, toolArgs }) {
    if (!/image|video/.test(mime)) return { output: "Gagal: user tidak melampirkan foto/video." };
    if (/video/.test(mime) && qmsg.seconds > 15) return { output: "Gagal: durasi video melebihi 15 detik." };
    try {
        const mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);
        await sock.sendStimg(m.chat, mediaPath, m, { packname: toolArgs.packname || "Hyric AI" });
        return { output: "Stiker berhasil dibuat." };
    } catch (err) {
        return { output: `Gagal buat stiker: ${err.message}` };
    }
}

// ── tourl ──
async function toolToUrl({ sock, m, mime, toolArgs }) {
    if (!/image|video|audio|application/.test(mime)) return { output: "Gagal: tidak ada media." };
    try {
        const FormData = require("form-data");
        const { fromBuffer } = require("file-type");
        const buffer = m.quoted ? await m.quoted.download() : await m.download();
        let uploadedUrl = "";

        if (toolArgs.provider === "pixhost" && /image/.test(mime)) {
            const { ImageUploadService } = require("node-upload-images");
            const service = new ImageUploadService("pixhost.to");
            const { directLink } = await service.uploadFromBinary(buffer, "hyric.png");
            uploadedUrl = directLink;
        } else {
            const { ext } = (await fromBuffer(buffer)) || { ext: "bin" };
            const bodyForm = new FormData();
            bodyForm.append("fileToUpload", buffer, "file." + ext);
            bodyForm.append("reqtype", "fileupload");
            const res = await fetch("https://catbox.moe/user/api.php", { method: "POST", body: bodyForm });
            uploadedUrl = (await res.text()).trim();
        }

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: `Upload sukses!\n\nURL: ${uploadedUrl}` },
                        nativeFlowMessage: {
                            buttons: [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy URL", copy_code: uploadedUrl }) }]
                        }
                    }
                }
            }
        }, { userJid: m.sender, quoted: m });

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        return { output: `Media berhasil diupload: ${uploadedUrl}` };
    } catch (err) {
        return { output: `Gagal upload: ${err.message}` };
    }
}

// ── cek_id_channel ──
async function toolCekIdChannel({ sock, m, userPrompt, quotedText, toolArgs }) {
    const chUrl = toolArgs.url || userPrompt || quotedText || "";
    if (!chUrl.includes("https://whatsapp.com/channel/")) return { output: "Gagal: link channel tidak valid." };
    try {
        const inviteCode = chUrl.split("https://whatsapp.com/channel/")[1].split(/[?\s]/)[0];
        const res = await sock.newsletterMetadata("invite", inviteCode);

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: `Channel ID:\n\n${res.id}` },
                        nativeFlowMessage: {
                            buttons: [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy ID", copy_code: res.id }) }]
                        }
                    }
                }
            }
        }, { userJid: m.sender, quoted: m });

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        return { output: `ID channel berhasil ditemukan: ${res.id}` };
    } catch (err) {
        return { output: `Gagal cek ID channel: ${err.message}` };
    }
}

// ── set_bot_mode ──
async function toolSetBotMode({ sock, m, isOwner, userPrompt, toolArgs }) {
    if (!isOwner && m.isGroup) return { output: global.mess?.owner || "Akses ditolak: khusus Owner." };

    let rawMode = String(toolArgs.mode || "").toLowerCase();
    if (/(matiin|matikan|off|disable)\s+mode\s+self/i.test(userPrompt)) rawMode = "public";
    else if (/(hidupin|hidupkan|on|enable|buat|jadi)\s+(jadi\s+)?mode\s+self/i.test(userPrompt)) rawMode = "self";

    const isSelf = rawMode === "self" || rawMode === "off" || rawMode === "false";
    global.mode_public = !isSelf;
    sock.public = !isSelf;

    try {
        const sp = require.resolve("./settings.js");
        const data = fs.readFileSync(sp, "utf-8");
        fs.writeFileSync(sp, data.replace(/global\.mode_public\s*=\s*(true|false)/, `global.mode_public = ${!isSelf}`), "utf-8");
    } catch (e) {}

    return { output: `Mode bot berhasil diubah ke ${isSelf ? "Self" : "Public"}.` };
}

// ── group_manage ──
async function toolGroupManage({ sock, m, isOwner, quotedText, toolArgs }) {
    const action = String(toolArgs.action || "").toLowerCase();

    if (action === "welcome") {
        if (!isOwner) return { output: global.mess?.owner || "Akses ditolak." };
        const st = String(toolArgs.state || "on").toLowerCase() === "on";
        global.db.settings.welcome = st;
        return { output: `Welcome berhasil di-${st ? "aktifkan" : "nonaktifkan"}.` };
    }

    if (!m.isGroup) return { output: "Gagal: fitur ini hanya di grup." };

    if (action === "kick") {
        if (!isOwner && !m.isAdmin) return { output: global.mess?.admin || "Akses ditolak." };
        if (!m.isBotAdmin) return { output: global.mess?.botadmin || "Bot harus admin grup dulu." };
        const target = m.mentionedJid?.[0] || m.quoted?.sender || (toolArgs.target ? toolArgs.target.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : null);
        if (!target) return { output: "Gagal: target kosong." };
        try {
            await sock.groupParticipantsUpdate(m.chat, [target], "remove");
            return { output: `User ${target.split("@")[0]} berhasil dikeluarkan.` };
        } catch (err) {
            return { output: `Gagal kick: ${err.message}` };
        }
    }

    if (action === "open" || action === "close") {
        if (!isOwner && !m.isAdmin) return { output: global.mess?.admin || "Akses ditolak." };
        if (!m.isBotAdmin) return { output: global.mess?.botadmin || "Bot harus admin grup dulu." };
        try {
            await sock.groupSettingUpdate(m.chat, action === "open" ? "not_announcement" : "announcement");
            return { output: `Grup berhasil di-${action}.` };
        } catch (err) {
            return { output: `Gagal ${action} grup: ${err.message}` };
        }
    }

    if (action === "hidetag") {
        if (!isOwner && !m.isAdmin) return { output: global.mess?.owner || "Akses ditolak." };
        const htText = toolArgs.text || quotedText || "Perhatian semua!";
        const members = (m.metadata?.participants || []).map((v) => v.id.includes("@s.whatsapp.net") ? v.id : v.jid);
        await sock.sendMessage(m.chat, { text: htText, mentions: members });
        return { output: "Hidetag berhasil terkirim." };
    }

    if (action === "antilink" || action === "antilink2") {
        if (!isOwner && !m.isAdmin) return { output: global.mess?.owner || "Akses ditolak." };
        const st = String(toolArgs.state || "on").toLowerCase() === "on";
        const grp = global.db.groups[m.chat] || (global.db.groups[m.chat] = {});
        if (action === "antilink") {
            grp.antilink = st;
            if (st) grp.antilink2 = false;
        } else {
            grp.antilink2 = st;
            if (st) grp.antilink = false;
        }
        return { output: `${action} berhasil di-${st ? "aktifkan" : "nonaktifkan"}.` };
    }

    return { output: `Aksi grup "${action}" tidak dikenali.` };
}

// ── store_tool ──
async function toolStore({ sock, m, isOwner, quotedText, mime, qmsg, FakeChannel, toolArgs }) {
    const action = String(toolArgs.action || "").toLowerCase();

    if (action === "payment") {
        try {
            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: { hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: global.qris } }, { upload: sock.waUploadToServer })) },
                            body: { text: `*Daftar Payment ${global.namaOwner} 🔖*` },
                            footer: { text: "Klik tombol salin" },
                            nativeFlowMessage: {
                                buttons: [
                                    { name: "cta_copy", buttonParamsJson: `{"display_text":"Copy Dana","copy_code":"${global.dana}"}` },
                                    { name: "cta_copy", buttonParamsJson: `{"display_text":"Copy OVO","copy_code":"${global.ovo}"}` },
                                    { name: "cta_copy", buttonParamsJson: `{"display_text":"Copy Gopay","copy_code":"${global.gopay}"}` }
                                ]
                            }
                        }
                    }
                }
            }, { userJid: m.sender, quoted: m });
            await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
            return { output: "Daftar payment berhasil ditampilkan." };
        } catch (err) {
            return { output: `Gagal payment: ${err.message}` };
        }
    }

    if (!isOwner) return { output: global.mess?.owner || "Akses ditolak." };

    if (action === "done" || action === "proses") {
        try {
            const item = toolArgs.text || "Layanan";
            const status = action === "done" ? "Transaksi Done ✅" : "Dana Diterima ✅";
            const teks = `${status}\n\n📦 Pembelian: ${item}\n🗓️ Tanggal: ${global.tanggal(Date.now())}\n\n📢 Testimoni:\n${global.linkChannel || "-"}\n\n📣 Marketplace:\n${global.linkGrup || "-"}`;
            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: teks },
                            nativeFlowMessage: {
                                buttons: [
                                    { name: "cta_url", buttonParamsJson: `{"display_text":"Testimoni","url":"${global.linkChannel}"}` },
                                    { name: "cta_url", buttonParamsJson: `{"display_text":"Marketplace","url":"${global.linkGrup}"}` }
                                ]
                            },
                            contextInfo: { isForwarded: true }
                        }
                    }
                }
            }, {});
            await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
            return { output: `Status ${action} berhasil dikirim.` };
        } catch (err) {
            return { output: `Gagal kirim ${action}: ${err.message}` };
        }
    }

    if (action === "stopjpm") { global.stopjpm = true; return { output: "JPM berhasil dihentikan." }; }
    if (action === "stoppush") { global.stoppush = true; return { output: "Push berhasil dihentikan." }; }

    if (action === "setjeda") {
        const target = String(toolArgs.target || "jpm").toLowerCase();
        const jeda = parseInt(toolArgs.value || toolArgs.text || "5000");
        if (isNaN(jeda)) return { output: "Gagal: jeda harus angka (ms)." };
        try {
            const sp = require.resolve("./settings.js");
            const data = fs.readFileSync(sp, "utf-8");
            if (target === "push") {
                fs.writeFileSync(sp, data.replace(/global\.JedaPushkontak\s*=\s*\d+/, `global.JedaPushkontak = ${jeda}`), "utf-8");
                global.JedaPushkontak = jeda;
            } else {
                fs.writeFileSync(sp, data.replace(/global\.JedaJpm\s*=\s*\d+/, `global.JedaJpm = ${jeda}`), "utf-8");
                global.JedaJpm = jeda;
            }
            return { output: `Jeda ${target} berhasil diubah ke ${jeda} ms.` };
        } catch (err) {
            return { output: `Gagal setjeda: ${err.message}` };
        }
    }

    if (action === "jpm" || action === "jpmht") {
        const jpmText = toolArgs.text || quotedText;
        if (!jpmText) return { output: "Gagal: teks JPM kosong." };
        try {
            let mediaPath = null;
            if (/image/.test(mime)) mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);

            const allGroups = await sock.groupFetchAllParticipating();
            const groupIds = Object.keys(allGroups);
            let successCount = 0;
            const procMsg = await m.reply(`Memproses JPM ke ${groupIds.length} grup...`);
            global.statusjpm = true;

            for (const groupId of groupIds) {
                if (db.settings.bljpm.includes(groupId)) continue;
                if (global.stopjpm) { delete global.stopjpm; delete global.statusjpm; break; }
                try {
                    const payload = mediaPath ? { image: fs.readFileSync(mediaPath), caption: jpmText } : { text: jpmText };
                    if (action === "jpmht") payload.mentions = allGroups[groupId].participants.map((e) => e.id);
                    await sock.sendMessage(groupId, payload, { quoted: FakeChannel });
                    successCount++;
                } catch (e) {}
                await localSleep(global.JedaJpm || 5000);
            }

            if (mediaPath) try { fs.unlinkSync(mediaPath); } catch (_) {}
            delete global.statusjpm;
            if (procMsg?.key) try { await sock.sendMessage(m.chat, { delete: procMsg.key }); } catch (_) {}
            return { output: `JPM berhasil dikirim ke ${successCount}/${groupIds.length} grup.` };
        } catch (err) {
            return { output: `Gagal JPM: ${err.message}` };
        }
    }

    return { output: `Aksi store "${action}" tidak dikenali.` };
}

// ── panel_tool ──
async function toolPanel({ sock, m, isOwner, isReseller, toolArgs }) {
    const action = String(toolArgs.action || "").toLowerCase();
    if (!isOwner && !isReseller) return { output: "Akses ditolak: khusus Owner/Reseller." };

    if (action === "create_server") {
        try {
            const plan = String(toolArgs.ramPlan || "1gb").toLowerCase();
            const resourceMap = {
                "1gb": { ram: "1000", disk: "1000", cpu: "40" },
                "2gb": { ram: "2000", disk: "1000", cpu: "60" },
                "3gb": { ram: "3000", disk: "2000", cpu: "80" },
                "4gb": { ram: "4000", disk: "2000", cpu: "100" },
                "5gb": { ram: "5000", disk: "3000", cpu: "120" },
                unlimited: { ram: "0", disk: "0", cpu: "0" }
            };
            const { ram, disk, cpu } = resourceMap[plan] || resourceMap.unlimited;

            const username = String(toolArgs.username || "user" + rid(4)).toLowerCase().replace(/[^a-z0-9]/g, "");
            const nomor = toolArgs.target ? toolArgs.target.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : m.isGroup ? m.sender : m.chat;
            const email = `${username}@gmail.com`;
            const name = `${global.capital ? global.capital(username) : username} Server`;
            const password = `${username}001`;

            const f = await fetch(global.domain + "/api/application/users", {
                method: "POST",
                headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: "Bearer " + global.apikey },
                body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
            });
            const data = await f.json();
            if (data.errors) return { output: `Gagal buat user: ${JSON.stringify(data.errors[0])}` };
            const user = data.attributes;

            const f1 = await fetch(`${global.domain}/api/application/nests/${global.nestid}/eggs/${global.egg}`, {
                method: "GET",
                headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: "Bearer " + global.apikey }
            });
            const data2 = await f1.json();
            const startup_cmd = data2.attributes.startup;

            const f2 = await fetch(global.domain + "/api/application/servers", {
                method: "POST",
                headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: "Bearer " + global.apikey },
                body: JSON.stringify({
                    name,
                    description: global.tanggal(Date.now()),
                    user: user.id,
                    egg: parseInt(global.egg),
                    docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                    startup: startup_cmd,
                    environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                    limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                    feature_limits: { databases: 5, backups: 5, allocations: 5 },
                    deploy: { locations: [parseInt(global.loc)], dedicated_ip: false, port_range: [] }
                })
            });
            const result = await f2.json();
            if (result.errors) return { output: `Gagal buat server: ${JSON.stringify(result.errors[0])}` };
            const server = result.attributes;

            const teks = `*Panel berhasil dibuat ✅*\n\n📡 Server ID: ${server.id}\n👤 Username: \`${user.username}\`\n🔐 Password: \`${password}\`\n🌐 Panel: ${global.domain}`;
            const msg = await generateWAMessageFromContent(nomor, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: teks },
                            nativeFlowMessage: {
                                buttons: [
                                    { name: "cta_copy", buttonParamsJson: `{"display_text":"Copy User","copy_code":"${user.username}"}` },
                                    { name: "cta_copy", buttonParamsJson: `{"display_text":"Copy Pass","copy_code":"${password}"}` },
                                    { name: "cta_url", buttonParamsJson: `{"display_text":"Open Panel","url":"${global.domain}"}` }
                                ]
                            }
                        }
                    }
                }
            }, {});
            await sock.relayMessage(nomor, msg.message, { messageId: msg.key.id });
            return { output: `Panel dengan username "${username}" berhasil dibuat.` };
        } catch (err) {
            return { output: `Gagal buat panel: ${err.message}` };
        }
    }

    if (action === "listpanel") {
        try {
            const response = await fetch(`${global.domain}/api/application/servers`, {
                method: "GET",
                headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikey}` }
            });
            const result = await response.json();
            const servers = result.data || [];
            if (!servers.length) return { output: "Belum ada server panel terdaftar." };

            const rows = [["ID", "Server Name", "RAM", "CPU"], ...servers.map((srv) => {
                const s = srv.attributes;
                const ram = s.limits.memory === 0 ? "Unlimited" : `${s.limits.memory} MB`;
                const cpu = s.limits.cpu === 0 ? "Unlimited" : `${s.limits.cpu}%`;
                return [String(s.id), String(s.name), ram, cpu];
            })];

            await sendWithAIRich(sock, m.chat, m, {
                singleMode: false,
                items: [
                    { method: "addHeading", args: [`Daftar Server (${servers.length})`] },
                    { method: "addTable", args: [rows] }
                ],
                fallbackText: rows.map((r) => r.join(" | ")).join("\n")
            });
            return { output: `Daftar ${servers.length} server panel berhasil ditampilkan.` };
        } catch (err) {
            return { output: `Gagal list panel: ${err.message}` };
        }
    }

    return { output: `Aksi panel "${action}" tidak dikenali.` };
}

// ── owner_tool ──
async function toolOwner({ sock, m, isOwner, toolArgs }) {
    const action = String(toolArgs.action || "").toLowerCase();

    if (action === "owner_contact") {
        try {
            await sock.sendContact(m.chat, [global.owner], global.namaOwner, "Developer Bot", m);
            return { output: "Kontak owner berhasil dikirim." };
        } catch (err) {
            return { output: `Gagal kirim kontak: ${err.message}` };
        }
    }

    if (!isOwner) return { output: global.mess?.owner || "Akses ditolak." };

    if (action === "resetdb") {
        global.db = {};
        return { output: "Database berhasil direset." };
    }

    if (action === "backup") {
        try {
            const name = "Backup-Script-Hyric";
            const exclude = ["node_modules", "skyzopedia", "session", "package-lock.json", "yarn.lock", ".npm", ".cache", "sampah", "modules"];
            const filesToZip = fs.readdirSync(".").filter((f) => !exclude.includes(f) && f !== "");
            execSync(`zip -r ${name}.zip ${filesToZip.join(" ")}`);
            await sock.sendMessage(m.sender, { document: fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip" }, { quoted: m });
            fs.unlinkSync(`./${name}.zip`);
            return { output: "Backup script berhasil dibuat dan dikirim." };
        } catch (err) {
            return { output: `Gagal backup: ${err.message}` };
        }
    }

    return { output: `Aksi owner "${action}" tidak dikenali.` };
}

// ── spr_tool ──
async function toolSpr({ sock, m, isOwner, toolArgs }) {
    if (!isOwner) return { output: global.mess?.owner || "Akses ditolak: spr_tool khusus Owner." };
    const action = String(toolArgs.action || "").toLowerCase();

    let groupJid = toolArgs.groupId ? String(toolArgs.groupId).trim() : null;
    if (!groupJid) {
        if (!m.isGroup) return { output: "Gagal: bukan di grup & groupId tidak diberikan." };
        groupJid = m.chat;
    }
    if (!groupJid.endsWith("@g.us")) {
        const parsed = sprParseJid(groupJid);
        if (!parsed || !parsed.endsWith("@g.us")) return { output: "Gagal: groupId tidak valid (harus @g.us)." };
        groupJid = parsed;
    }

    if (action === "spr") {
        const targets = Array.isArray(toolArgs.targets) ? toolArgs.targets : [];
        if (!targets.length) return { output: "Gagal: 'targets' kosong." };

        const overrides = [];
        for (const t of targets) {
            const jid = t.target || t.jid;
            const txt = t.text || t.message || "";
            if (!jid || !txt) continue;
            const parsed = sprParseJid(jid);
            if (parsed) overrides.push({ jid: parsed, text: txt });
        }
        if (!overrides.length) return { output: "Gagal: tidak ada target valid." };

        try {
            const result = await sprKirimSPR(sock, groupJid, { publicText: toolArgs.publicText || "🔒 Pesan ini punya isi khusus buat beberapa orang.", overrides });
            return { output: `sPR berhasil terkirim ke ${result.terkirim} target.` };
        } catch (err) {
            return { output: `Gagal sPR: ${err.message}` };
        }
    }

    if (action === "sbpr") {
        const template = String(toolArgs.template || "Halo {name} 👋");
        try {
            const result = await sprKirimSbpr(sock, groupJid, template);
            return { output: `sBPR berhasil terkirim ke ${result.terkirim} device.` };
        } catch (err) {
            return { output: `Gagal sBPR: ${err.message}` };
        }
    }

    if (action === "sprtag") {
        const template = String(toolArgs.template || "Halo {name} 👋");
        try {
            const result = await sprKirimSprtag(sock, groupJid, template);
            return { output: `sprtag berhasil terkirim ke ${result.terkirim} device.` };
        } catch (err) {
            return { output: `Gagal sprtag: ${err.message}` };
        }
    }

    return { output: `Aksi spr_tool "${action}" tidak dikenali.` };
}

// ── create_module ──
async function toolCreateModule({ isOwner, toolArgs }) {
    if (!isOwner) return { output: "Akses ditolak: hanya Owner yang bisa buat module." };
    const name = String(toolArgs.name || "").trim();
    const code = String(toolArgs.code || "").trim();
    const type = String(toolArgs.type || "js").toLowerCase();
    const description = String(toolArgs.description || "").trim();
    if (!name) return { output: "Gagal: nama kosong." };
    if (!code) return { output: "Gagal: kode kosong." };

    try {
        const header = `// Module: ${name}\n// Description: ${description || "(no description)"}\n// Created: ${new Date().toISOString()}\n// By: Hyric AI\n\n`;
        const result = saveModuleFile(name, header + code, { type });
        const toolInfo = await loadModuleAsTool(result.name);
        if (toolInfo) {
            activeModuleTools.set(toolInfo.name, toolInfo);
            return { output: `✅ Module "${result.name}" dibuat DAN TERDAFTAR sebagai AI tool "${toolInfo.name}". User bisa panggil langsung (contoh: "hyric cek cuaca Jakarta").` };
        }
        return { output: `✅ Module "${result.name}" dibuat di ${result.file} (${(header + code).length} bytes). Mode CLI-ONLY — tambahkan exports.tool + exports.handler untuk jadikan AI tool.` };
    } catch (err) {
        return { output: `Gagal buat module: ${err.message}` };
    }
}

// ── edit_module ──
async function toolEditModule({ isOwner, toolArgs }) {
    if (!isOwner) return { output: "Akses ditolak." };
    const name = String(toolArgs.name || "").trim();
    const code = String(toolArgs.code || "").trim();
    if (!name || !code) return { output: "Gagal: nama/kode kosong." };

    try {
        const filePath = getModulePath(name);
        if (!filePath) return { output: `Module "${name}" tidak ditemukan.` };

        const existing = fs.readFileSync(filePath, "utf-8");
        const lines = existing.split("\n");
        let headerEnd = 0;
        for (let i = 0; i < lines.length; i++) {
            if (lines[i].startsWith("//") || lines[i].trim() === "") headerEnd = i + 1;
            else break;
        }
        const header = headerEnd > 0 ? lines.slice(0, headerEnd).join("\n") : "";
        fs.writeFileSync(filePath, header + code, "utf-8");

        const toolInfo = await loadModuleAsTool(name);
        if (toolInfo) {
            activeModuleTools.set(toolInfo.name, toolInfo);
            return { output: `Module "${name}" diedit & AI tool "${toolInfo.name}" di-reload.` };
        }
        for (const [n, info] of activeModuleTools) {
            if (info.moduleName === name) activeModuleTools.delete(n);
        }
        return { output: `Module "${name}" diedit (mode CLI-only).` };
    } catch (err) {
        return { output: `Gagal edit: ${err.message}` };
    }
}

// ── delete_module ──
async function toolDeleteModule({ isOwner, toolArgs }) {
    if (!isOwner) return { output: "Akses ditolak." };
    const name = String(toolArgs.name || "").trim();
    if (!name) return { output: "Gagal: nama kosong." };

    try {
        const filePath = getModulePath(name);
        if (!filePath) return { output: `Module "${name}" tidak ditemukan.` };
        fs.unlinkSync(filePath);
        for (const [n, info] of activeModuleTools) {
            if (info.moduleName === name) activeModuleTools.delete(n);
        }
        return { output: `Module "${name}" dihapus & unregister dari AI tool.` };
    } catch (err) {
        return { output: `Gagal hapus: ${err.message}` };
    }
}

// ── list_modules ──
async function toolListModules() {
    const mods = listAllModules();
    if (!mods.length) return { output: "Belum ada module di ./modules/." };

    const list = mods.map((m, i) => {
        const toolInfo = [...activeModuleTools.values()].find((t) => t.moduleName === m.name);
        return `${i + 1}. ${m.name} (${m.file}, ${m.size}B) ${toolInfo ? `🤖 AI-TOOL: ${toolInfo.name}` : "📄 CLI-only"}`;
    }).join("\n");

    return { output: `Modules (${mods.length}):\n${list}` };
}

// ── read_module ──
async function toolReadModule({ isOwner, toolArgs }) {
    if (!isOwner) return { output: "Akses ditolak." };
    const name = String(toolArgs.name || "").trim();
    if (!name) return { output: "Gagal: nama kosong." };

    try {
        const fp = getModulePath(name);
        if (!fp) return { output: `Module "${name}" tidak ditemukan.` };
        const content = fs.readFileSync(fp, "utf-8");
        return { output: `Isi ${path.basename(fp)}:\n\n${content}` };
    } catch (err) {
        return { output: `Gagal baca: ${err.message}` };
    }
}

// ── run_module ──
async function toolRunModule({ isOwner, toolArgs, makeModuleCtx }) {
    if (!isOwner) return { output: "Akses ditolak." };
    const name = String(toolArgs.name || "").trim();
    if (!name) return { output: "Gagal: nama kosong." };

    const toolInfo = activeModuleTools.get(name) || [...activeModuleTools.values()].find((t) => t.moduleName === name);

    if (toolInfo) {
        try {
            const argsObj = {};
            if (toolArgs.args) {
                try { Object.assign(argsObj, JSON.parse(toolArgs.args)); }
                catch { argsObj.raw = toolArgs.args; }
            }
            const result = await toolInfo.handler(argsObj, makeModuleCtx());
            const output = typeof result === "string" ? result : (result?.output !== undefined ? String(result.output) : JSON.stringify(result));
            return { output: `Module "${toolInfo.name}" hasil:\n${output}` };
        } catch (err) {
            return { output: `Module "${toolInfo.name}" error: ${err.message}` };
        }
    }

    try {
        const result = await runModuleFile(name, toolArgs.args || "", { timeout: toolArgs.timeout || 30000 });
        const parts = [];
        if (result.stdout) parts.push(`STDOUT:\n${result.stdout}`);
        if (result.stderr) parts.push(`STDERR:\n${result.stderr}`);
        parts.push(`Exit: ${result.exitCode}`);
        return { output: parts.join("\n\n") };
    } catch (err) {
        return { output: `Gagal run: ${err.message}` };
    }
}

// ============================================================================
// 9. EXECUTE TOOL DISPATCHER
// ============================================================================

async function executeTool(toolName, toolArgs, ctx) {
    // Module tools FIRST (dynamic)
    if (activeModuleTools.has(toolName)) {
        const info = activeModuleTools.get(toolName);
        try {
            const result = await info.handler(toolArgs, ctx.makeModuleCtx());
            const output = typeof result === "string" ? result : (result?.output !== undefined ? String(result.output) : JSON.stringify(result));
            return { output };
        } catch (err) {
            return { output: `Module "${toolName}" error: ${err.message}` };
        }
    }

    switch (toolName) {
        case "clear_session": return toolClearSession(ctx);
        case "render_html_rich": return toolRenderHtmlRich(ctx);
        case "send_airich": return toolSendAirich(ctx);
        case "play_music": return toolPlayMusic(ctx);
        case "ask_gemini_vision": return toolAskGeminiVision(ctx);
        case "sticker_brat": return toolStickerBrat(ctx);
        case "create_sticker": return toolCreateSticker(ctx);
        case "tourl": return toolToUrl(ctx);
        case "cek_id_channel": return toolCekIdChannel(ctx);
        case "set_bot_mode": return toolSetBotMode(ctx);
        case "group_manage": return toolGroupManage(ctx);
        case "store_tool": return toolStore(ctx);
        case "panel_tool": return toolPanel(ctx);
        case "owner_tool": return toolOwner(ctx);
        case "spr_tool": return toolSpr(ctx);
        case "create_module": return toolCreateModule(ctx);
        case "edit_module": return toolEditModule(ctx);
        case "delete_module": return toolDeleteModule(ctx);
        case "list_modules": return toolListModules(ctx);
        case "read_module": return toolReadModule(ctx);
        case "run_module": return toolRunModule(ctx);
        default: return { output: `Tool "${toolName}" tidak dikenali.` };
    }
}

// ============================================================================
// 10. MAIN HANDLER
// ============================================================================

module.exports = async (m, sock) => {
    try {
        await LoadDataBase(sock, m);

        if (typeof sock.public !== "boolean") {
            sock.public = typeof global.mode_public === "boolean" ? global.mode_public : true;
        }

        const bodyText = m?.body || m?.text || "";
        const isCmd = bodyText.startsWith(m.prefix);
        const quoted = m.quoted ? m.quoted : m;
        const mime = quoted?.msg?.mimetype || quoted?.mimetype || null;
        const args = bodyText.trim().split(/ +/).slice(1);
        const qmsg = m.quoted || m;
        const text = args.join(" ");
        const command = isCmd ? bodyText.slice(m.prefix.length).trim().split(" ").shift().toLowerCase() : "";
        const cmd = m.prefix + command;

        const botNumber = (await sock.user.id.split(":")[0]) + "@s.whatsapp.net";
        const botLidBase = sock.user?.lid ? sock.user.lid.split(":")[0].split("@")[0] : "";
        const senderNum = (m.sender || "").split(":")[0].split("@")[0];
        const ownerNum = String(global.owner || "").replace(/[^0-9]/g, "");

        const isOwner = Boolean(m.key?.fromMe)
            || senderNum === ownerNum
            || m.sender === global.owner + "@s.whatsapp.net"
            || m.sender === botNumber
            || (botLidBase && senderNum === botLidBase)
            || (Array.isArray(db?.settings?.developer) && db.settings.developer.includes(m.sender))
            || (Array.isArray(db?.settings?.developer) && db.settings.developer.some((d) => d.split("@")[0] === senderNum));

        const isReseller = Array.isArray(db?.settings?.reseller)
            && (db.settings.reseller.includes(m.sender) || db.settings.reseller.some((r) => r.split("@")[0] === senderNum));

        m.isGroup = m.chat.endsWith("g.us");
        m.metadata = {};
        m.isAdmin = false;
        m.isBotAdmin = false;

        if (m.isGroup) {
            let meta = await global.groupMetadataCache.get(m.chat);
            if (!meta) meta = await sock.groupMetadata(m.chat).catch((_) => {});
            m.metadata = meta;
            const p = meta?.participants || [];
            m.isAdmin = p?.some((i) => (i.id === m.sender || i.jid === m.sender) && i.admin !== null);
            m.isBotAdmin = p?.some((i) => (i.id === botNumber || i.jid == botNumber) && i.admin !== null);
        }

        const trimmedBody = bodyText.trim();
        const isHyricCall = /^(\.?hyric)(\b|\s|$)/i.test(trimmedBody);
        const isModeToggleRequest = isHyricCall && /\b(mode\s*(self|public)|self\s*mode|public\s*mode|(matiin|matikan|hidupin|hidupkan|ubah|ganti|buat)\s*(jadi\s*)?mode\s*(self|public)|setapikey|apikey)\b/i.test(trimmedBody);

        if (!sock.public && !isOwner && !m.key?.fromMe && !(isModeToggleRequest && !m.isGroup)) return;

        if (isCmd) {
            console.log(chalk.white("• Sender :"), chalk.blue(m.chat) + "\n" + chalk.white("• Command :"), chalk.blue(cmd) + "\n");
        }

        if (!isCmd && bodyText && !isHyricCall) {
            const responder = db.settings.respon.find((v) => v.id.toLowerCase() == bodyText.toLowerCase());
            if (responder && responder.response) await m.reply(responder.response);
        }

        const FakeChannel = {
            key: { remoteJid: "status@broadcast", fromMe: false, participant: "0@s.whatsapp.net" },
            message: { newsletterAdminInviteMessage: { newsletterJid: "123@newsletter", caption: `Powered By Dilzx.`, inviteExpiration: 0 } }
        };

        // Antilink
        if (global.db.groups[m.chat]?.antilink === true || global.db.groups[m.chat]?.antilink2 === true) {
            const textMessage = m.text || "";
            const groupInviteLinkRegex = /(https?:\/\/)?(www\.)?chat\.whatsapp\.com\/[A-Za-z0-9]+(\?[^\s]*)?/gi;
            const links = textMessage.match(groupInviteLinkRegex);

            if (links && !isOwner && !m.isAdmin && m.isBotAdmin) {
                const senderJid = m.sender;
                const messageId = m.key.id;
                const participantToDelete = m.key.participant || m.sender;

                await sock.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: messageId, participant: participantToDelete } });

                if (global.db.groups[m.chat]?.antilink === true) {
                    await localSleep(800);
                    await sock.groupParticipantsUpdate(m.chat, [senderJid], "remove");
                }
            }
        }

        // ====================================================================
        // HYRIC HANDLER
        // ====================================================================
        if (isHyricCall) {
            await reactRocket(sock, m);
            const userPrompt = trimmedBody.replace(/^(\.?hyric)\s*/i, "").trim();
            const sessionId = `hyric_${senderNum || "user"}`;

            console.log(chalk.white("• Hyric :"), chalk.green(m.sender) + "\n" + chalk.white("• Prompt :"), chalk.yellow(userPrompt || "[Media/Reply Only]") + "\n");

            // Set API key
            const apiKeyMatch = userPrompt.match(/^(?:setapikey|apikey)\s+(\S+)/i);
            if (apiKeyMatch) {
                if (!isOwner && m.isGroup) return sendProfileMessage(sock, m, "Hanya Owner yang dapat mengatur API Key Gemini.");
                setGeminiApiKey(apiKeyMatch[1]);
                return sendProfileMessage(sock, m, `✅ API Key Gemini berhasil disimpan!\n- Chat: *${GEMINI_CHAT_MODEL}*\n- Vision: *${GEMINI_VISION_MODEL}*`);
            }

            // Banner
            if (!userPrompt && !m.quoted && !mime) {
                await sendWithAIRich(sock, m.chat, m, {
                    singleMode: false,
                    items: [
                        { method: "addHeading", args: [`Halo @${senderNum} 👋`] },
                        { method: "addText", args: ["Ketik `hyric <pertanyaan/instruksi>` untuk:\n• Chat & Coding AI\n• Analisis Foto / Vision\n• Reset sesi (`hyric hapus sesi`)\n• Rich / HTML (`hyric rich` sambil reply)\n• Kirim pesan privat grup (`hyric spr ...`)\n• Buat module baru (`hyric buat module <deskripsi>`)\n• Putar lagu (`hyric putar lagu ...`)\n• Tools lain"] },
                        { method: "addTable", args: [[["Komponen", "Model / Status"], ["Chat AI", GEMINI_CHAT_MODEL], ["Vision AI", GEMINI_VISION_MODEL], ["Bot Mode", sock.public ? "Public" : "Self"], ["AI Modules", String(activeModuleTools.size)]]] }
                    ],
                    fallbackText: "Halo! Ketik *hyric <pesan/instruksi>* untuk memulai."
                });
                return;
            }

            // Media download
            const quotedText = m.quoted?.text || m.quoted?.body || m.quoted?.caption || "";
            let attachedFileText = "", attachedFileName = "", attachedMediaBuffer = null;
            let savedHtmlPath = null, htmlExcerpt = null, htmlLineCount = 0;

            if (mime) {
                try {
                    const fname = qmsg?.msg?.fileName || qmsg?.fileName || "";
                    const isTextLike = /text|json|javascript|html|xml|csv|application\/(javascript|json|x-sh|x-httpd-php|octet-stream)/i.test(mime)
                        || /\.(js|ts|py|html?|htm|css|json|md|txt|sh|php)$/i.test(fname);
                    const isHtmlFile = /html/i.test(mime) || /\.(html?|htm)$/i.test(fname);
                    const wantsRich = /\b(rich|render.?rich|html.?rich|rich.?html)\b/i.test(userPrompt);

                    if (isHtmlFile) {
                        const buf = await qmsg.download();
                        const htmlText = buf.toString("utf-8");
                        const lines = htmlText.split("\n");
                        htmlLineCount = lines.length;
                        savedHtmlPath = await saveHtmlToSampah(htmlText, fname);
                        attachedFileName = fname || (savedHtmlPath ? path.basename(savedHtmlPath) : "file.html");

                        if (wantsRich) htmlExcerpt = lines.slice(0, 2000).join("\n");
                        else attachedFileText = htmlText;
                    } else if (isTextLike) {
                        const buf = await qmsg.download();
                        attachedFileText = buf.toString("utf-8");
                        attachedFileName = fname || "file.txt";
                    } else if (/image\//i.test(mime)) {
                        attachedMediaBuffer = await qmsg.download();
                    }
                } catch (dlErr) {
                    console.error("[Hyric Media Download Error]:", dlErr?.message || dlErr);
                }
            }

            const state = loadState(sessionId) || newState();

            // Module ctx factory
            const makeModuleCtx = () => ({
                sock, m,
                chat: m.chat,
                sender: m.sender,
                senderNumber: senderNum,
                isOwner, isReseller,
                sessionId,
                userPrompt,
                mime,
                mediaBuffer: attachedMediaBuffer,
                quotedText,
                gemini: async (promptText, opts = {}) => {
                    const r = await callGeminiOfficialApi({
                        model: opts.model || GEMINI_CHAT_MODEL,
                        prompt: String(promptText || ""),
                        historyMessages: opts.history ? state.messages : [],
                        systemInstruction: opts.systemInstruction || ""
                    });
                    return r.reply;
                },
                vision: async (promptText) => {
                    const r = await callGeminiOfficialApi({
                        model: GEMINI_VISION_MODEL,
                        prompt: String(promptText || "Analisis gambar ini."),
                        imageBuffer: attachedMediaBuffer,
                        imageMime: mime
                    });
                    return r.reply;
                },
                reply: async (textOut) => sendProfileMessage(sock, m, String(textOut || "")),
                log: (...a) => console.log("[Module]", ...a)
            });

            // Context for tool dispatcher
            const toolCtx = {
                sock, m,
                state, sessionId, isOwner, isReseller,
                userPrompt, quotedText, mime, qmsg,
                attachedMediaBuffer, FakeChannel,
                toolArgs: {},
                makeModuleCtx
            };

            const systemInstruction = buildSystemPrompt({
                senderNumber: senderNum, isOwner, isReseller,
                isGroup: m.isGroup, groupName: m.metadata?.subject || "",
                chat: m.chat, botMode: sock.public ? "Public" : "Self",
                hasMedia: Boolean(mime), mime, quotedText,
                attachedFileText: Boolean(attachedFileText), attachedFileName
            });

            // Build contents
            const contents = [];
            for (const msg of state.messages) {
                if (!msg || !msg.content) continue;
                const role = msg.role === "assistant" || msg.role === "model" ? "model" : "user";
                if (contents.length > 0 && contents[contents.length - 1].role === role) {
                    const lastParts = contents[contents.length - 1].parts;
                    if (lastParts[0] && typeof lastParts[0].text === "string") lastParts[0].text += `\n\n${msg.content}`;
                    else lastParts.push({ text: String(msg.content) });
                } else {
                    contents.push({ role, parts: [{ text: String(msg.content) }] });
                }
            }

            const userParts = [];
            if (attachedMediaBuffer) {
                userParts.push({ inline_data: { mime_type: mime || sniffMime(attachedMediaBuffer), data: attachedMediaBuffer.toString("base64") } });
            }

            let fullUserQuery = userPrompt || "Tolong proses media/file/pesan yang saya lampirkan ini.";
            if (quotedText) fullUserQuery += `\n\n[Pesan yang di-reply]:\n${quotedText}`;
            if (attachedFileText) fullUserQuery += `\n\n[Isi File (${attachedFileName})]:\n${attachedFileText.slice(0, 5000)}`;
            if (htmlExcerpt) {
                fullUserQuery += `\n\n[File HTML tersimpan: ${savedHtmlPath || "(gagal disimpan)"}]`;
                fullUserQuery += `\n[Total baris: ${htmlLineCount} — 2000 baris awal di bawah]`;
                fullUserQuery += `\n\n[Isi HTML (2000 baris awal)]:\n${htmlExcerpt}`;
                fullUserQuery += `\n\nINSTRUKSI WAJIB: User reply file HTML & minta RICH. Panggil "render_html_rich" dengan parameter "html" berisi HTML bersih/rapi. JANGAN kirim HTML sebagai teks biasa.`;
            }
            userParts.push({ text: fullUserQuery });

            if (contents.length > 0 && contents[contents.length - 1].role === "user") {
                contents[contents.length - 1].parts.push(...userParts);
            } else {
                contents.push({ role: "user", parts: userParts });
            }

            let finalReply = "";
            const maxRounds = 6;

            try {
                for (let round = 0; round < maxRounds; round++) {
                    const aiRes = await callGeminiOfficialApi({
                        model: GEMINI_CHAT_MODEL,
                        contents,
                        systemInstruction,
                        tools: buildGeminiToolsWithModules(),
                        toolConfig: { functionCallingConfig: { mode: "AUTO" } }
                    });

                    if (aiRes.functionCalls && aiRes.functionCalls.length > 0) {
                        contents.push({ role: "model", parts: aiRes.rawParts });
                        const functionResponses = [];

                        for (const fc of aiRes.functionCalls) {
                            const callCtx = { ...toolCtx, toolArgs: fc.args || {} };
                            const toolOutcome = await executeTool(fc.name, fc.args || {}, callCtx);
                            functionResponses.push({
                                functionResponse: {
                                    name: fc.name,
                                    response: { output: toolOutcome.output || "Selesai" },
                                    ...(fc.id ? { id: fc.id } : {})
                                }
                            });
                        }

                        contents.push({ role: "user", parts: functionResponses });
                    } else {
                        finalReply = aiRes.reply;
                        break;
                    }
                }

                if (finalReply) {
                    await sendFormattedAIResponse(sock, m.chat, m, finalReply);
                    const userTurnText = fullUserQuery.length > 2000 ? fullUserQuery.slice(0, 2000) + "\n...[dipotong]" : fullUserQuery;
                    appendSessionTurn(sessionId, state, userTurnText, finalReply);
                }
            } catch (aiErr) {
                console.error("[Hyric AI Handler Error]:", aiErr);
                await sendProfileMessage(sock, m, `⚠️ Maaf, terjadi kendala saat memproses permintaan: ${aiErr.message}`);
            }
            return;
        }

        // ====================================================================
        // SWITCH COMMAND
        // ====================================================================
        switch (command) {
            case "menu": {
                await reactRocket(sock, m);

                const teksMenu =
                    `Haii @${senderNum}\n` +
                    `Selamat ${ucapan()}!\n\n` +
                    "Aku *Hyric AI* — asisten pintar yang siap bantu kamu kapan saja.\n\n" +
                    "*TENTANG*\n" +
                    "Hyric AI bisa diajak ngobrol, bantu coding, analisis gambar, cari & putar lagu, bikin stiker, render rich / HTML, buat & jalankan module AI, dan masih banyak lagi.\n\n" +
                    "Cukup panggil *hyric* diikuti permintaanmu.\n\n" +
                    `*Mode* : ${sock.public ? "Public" : "Self"}\n` +
                    `*Runtime* : ${runtime(process.uptime())}\n` +
                    `*AI Modules* : ${activeModuleTools.size}\n` +
                    "*Trigger* : hyric <perintah>";

                const menuButtons = [
                    { name: "cta_url", buttonParamsJson: `{"display_text":"Contact Owner","url":"https://wa.me/dilzxxyz","merchant_url":"https://wa.me/dilzxxyz"}` },
                    { name: "cta_url", buttonParamsJson: `{"display_text":"Contact Telegram","url":"https://t.me/dilzxxyv","merchant_url":"https://t.me/dilzxxyv"}` }
                ];

                try {
                    const ppUrl = await getSenderPP(sock, m);
                    const msg = await generateWAMessageFromContent(m.chat, {
                        viewOnceMessage: {
                            message: {
                                interactiveMessage: {
                                    header: {
                                        hasMediaAttachment: true,
                                        ...(await prepareWAMessageMedia({ image: { url: ppUrl } }, { upload: sock.waUploadToServer }))
                                    },
                                    body: { text: teksMenu },
                                    nativeFlowMessage: { buttons: menuButtons },
                                    contextInfo: { mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"] }
                                }
                            }
                        }
                    }, { userJid: m.sender, quoted: FakeChannel });
                    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                } catch (err) {
                    console.error("[HYRIC MENU ERROR]:", err?.message || err);
                    const ok = await sendProfileMessage(sock, m, teksMenu, { buttons: menuButtons });
                    if (!ok) await m.reply(teksMenu + "\n\nOwner : https://wa.me/dilzxxyz\nTelegram : https://t.me/dilzxxyv");
                }
                break;
            }

            default: {
                if (m.text && m.text.toLowerCase().startsWith("xx")) {
                    if (!isOwner) return;
                    try {
                        const result = await eval(`(async () => { ${text} })()`);
                        const output = typeof result !== "string" ? util.inspect(result) : result;
                        return sock.sendMessage(m.chat, { text: util.format(output) }, { quoted: m });
                    } catch (err) {
                        return sendProfileMessage(sock, m, util.format(err));
                    }
                }

                if (m.text && m.text.toLowerCase().startsWith("x")) {
                    if (!isOwner) return;
                    try {
                        let result = await eval(text);
                        if (typeof result !== "string") result = util.inspect(result);
                        return sock.sendMessage(m.chat, { text: util.format(result) }, { quoted: m });
                    } catch (err) {
                        return sendProfileMessage(sock, m, util.format(err));
                    }
                }

                if (m.text && m.text.startsWith("$")) {
                    if (!isOwner) return;
                    exec(m.text.slice(2), async (err, stdout) => {
                        if (err) return sendProfileMessage(sock, m, err.toString());
                        if (stdout) return sock.sendMessage(m.chat, { text: util.format(stdout) }, { quoted: m });
                    });
                    return;
                }
                break;
            }
        }
    } catch (err) {
        console.log(err);
        try {
            await sock.sendMessage(global.owner + "@s.whatsapp.net", { text: err.toString() }, { quoted: m ? m : null });
        } catch (_) {}
    }
};

// ============================================================================
// 11. PROCESS & WATCHERS
// ============================================================================

process.on("uncaughtException", (err) => {
    console.error("Caught exception:", err);
});

// Auto-load module tools saat startup
setTimeout(() => {
    refreshModuleTools().catch((e) => console.error("[RefreshModules]", e.message));
}, 2000);

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.blue(">> Update File:"), chalk.black.bgWhite(__filename));
    delete require.cache[file];
    require(file);
});