<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PORTAL CREATE WEB</title>
    <!-- Font Roboto agar tampilan lebih modern -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --bg-gradient: linear-gradient(to right, #6a11cb, #2575fc);
        }

        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            /* Perubahan: display block dengan min-height agar bisa discroll jika konten panjang */
            display: block;
            min-height: 100vh;
            background: var(--bg-gradient);
            transition: background 1s ease; 
            color: #fff;
            padding-bottom: 20px; /* Ruang extra di bawah */
        }

        /* Container untuk membungkus konten agar rapi di tengah */
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .slider {
            width: 100%;
            max-width: 800px; /* Batas lebar maksimal slider */
            height: 200px; /* Diperbesar sedikit agar proporsional */
            margin-top: 20px;
            margin-bottom: 30px;
            overflow: hidden; /* Penting agar gambar slide tidak keluar garis */
            border-radius: 15px;
            position: relative;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            background-color: #ddd; 
        }

        .slides {
            display: flex;
            width: 100%;
            height: 100%;
            transition: transform 0.5s ease-in-out;
        }

        .slide {
            min-width: 100%;
            height: 100%;
        }

        .slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* GRID SYSTEM UPGRADE */
        .image-grid {
            display: grid;
            /* Perubahan Logika CSS: Grid responsif otomatis menyesuaikan layar */
            grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
            gap: 15px;
            width: 100%;
            margin-bottom: 30px;
        }

        .image-item {
            cursor: pointer;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s, box-shadow 0.3s;
            position: relative;
            aspect-ratio: 1 / 1; /* Membuat kotak selalu persegi */
            background: #fff;
        }

        .image-item:hover {
            transform: translateY(-5px); /* Efek hover naik sedikit */
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.4);
            z-index: 2;
        }

        .image-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .game-title {
            font-size: 0.85em;
            margin-top: 0;
            color: #ffffff;
            font-weight: bold;
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.7); /* Background lebih gelap agar teks terbaca */
            padding: 8px 4px;
            text-align: center;
            box-sizing: border-box;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis; /* Jika teks panjang, diberi titik tiga */
        }

        .copyright {
            font-size: 14px;
            color: #fff;
            text-align: center;
            padding: 15px;
            background: rgba(0, 0, 0, 0.4); 
            width: 100%;
            box-sizing: border-box;
            border-radius: 10px;
            margin-top: auto;
        }

        .copyright a {
            color: #ffeb3b;
            text-decoration: none;
            font-weight: bold;
        }

        .copyright a:hover {
            text-decoration: underline;
        }

        /* Responsif untuk HP kecil */
        @media (max-width: 480px) {
            .slider {
                height: 160px;
            }
            .image-grid {
                grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); /* Grid lebih kecil di HP */
                gap: 10px;
            }
            .game-title {
                font-size: 0.75em;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <!-- Slider Section -->
        <div class="slider">
            <div class="slides">
                <!-- Menggunakan placeholder jika gambar lokal tidak ditemukan agar tetap terlihat rapi -->
                <div class="slide"><img src="img/cahyosr1.jpg" onerror="this.src='https://picsum.photos/seed/slide1/800/400'" alt="Gambar 1"></div>
                <div class="slide"><img src="img/cahyosr2.jpg" onerror="this.src='https://picsum.photos/seed/slide2/800/400'" alt="Gambar 2"></div>
                <div class="slide"><img src="img/cahyosr3.jpg" onerror="this.src='https://picsum.photos/seed/slide3/800/400'" alt="Gambar 3"></div>
            </div>
        </div>

        <!-- Grid Section -->
        <div class="image-grid">
            <!-- Item 1 -->
            <div class="image-item" onclick="submitForm(1)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/1.jpg" alt="Option 1">
                <div class="game-title">MediaFire ZIP</div>
            </div>
            <!-- Item 2 -->
            <div class="image-item" onclick="submitForm(2)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/2.jpg" alt="Option 2">
                <div class="game-title">Media Fire Mp4</div>
            </div>
            <!-- Item 3 -->
            <div class="image-item" onclick="submitForm(3)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/3.jpg" alt="Option 3">
                <div class="game-title">Download Aplikasi 18+</div>
            </div>
            <!-- Item 4 -->
            <div class="image-item" onclick="submitForm(4)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/4.jpg" alt="Option 4">
                <div class="game-title">Grup Wa V1</div>
            </div>
            <!-- Item 5 -->
            <div class="image-item" onclick="submitForm(5)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/5.jpg" alt="Option 5">
                <div class="game-title">Grup Wa V2</div>
            </div>
            <!-- Item 6 -->
            <div class="image-item" onclick="submitForm(6)">
                <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/20260407_075331.jpg" alt="Option 6">
                <div class="game-title">FF Shop Tuker Coin Google Only</div>
            </div>
            <!-- Item 7 -->
            <div class="image-item" onclick="submitForm(7)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/7.jpg" alt="Option 7">
                <div class="game-title">Facebook 18+</div>
            </div>
            <!-- Item 9 -->
            <div class="image-item" onclick="submitForm(9)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/9.jpg" alt="Option 9">
                <div class="game-title">Free Fire Beta</div>
            </div>
            <!-- Item 10 -->
            <div class="image-item" onclick="submitForm(10)">
                <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/20260313_025412.jpg" alt="Option 10">
                <div class="game-title">Coda Shop Ff True Id</div>
            </div>
            <!-- Item 11 -->
            <div class="image-item" onclick="submitForm(11)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/11.jpg" alt="Option 11">
                <div class="game-title">Mobile Legends Beta</div>
            </div>
            <!-- Item 12 -->
            <div class="image-item" onclick="submitForm(12)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/12.jpg" alt="Option 12">
                <div class="game-title">Grup Telegram V1</div>
            </div>
            <!-- Item 13 -->
            <div class="image-item" onclick="submitForm(13)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/13.jpg" alt="Option 13">
                <div class="game-title">Grup Telegram V2</div>
            </div>
            <!-- Item 14 -->
            <div class="image-item" onclick="submitForm(14)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/14.jpg" alt="Option 14">
                <div class="game-title">Videy v1</div>
            </div>
            <!-- Item 15 -->
            <div class="image-item" onclick="submitForm(15)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/15.jpg" alt="Option 15">
                <div class="game-title">Videy v2</div>
            </div>
            <!-- Item 16 (Logika submitForm > 15 tidak akan post form, tapi tetap tampil visual) -->
            <div class="image-item" onclick="submitForm(16)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/16.jpg" alt="Option 16">
                <div class="game-title">YouTube V1</div>
            </div>
            <!-- Item 17 -->
            <div class="image-item" onclick="submitForm(17)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/17.jpg" alt="Option 17">
                <div class="game-title">YouTube V2</div>
            </div>
            <!-- Item 18 -->
            <div class="image-item" onclick="submitForm(18)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/18.jpg" alt="Option 18">
                <div class="game-title">Download Apk 18+ Avcode</div>
            </div>
            <!-- Item 20 -->
            <div class="image-item" onclick="submitForm(20)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/20.jpg" alt="Option 20">
                <div class="game-title">Join Chenel Wa 18+</div>
            </div>
            <!-- Item 21 -->
            <div class="image-item" onclick="submitForm(21)">
                <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/20251229_101305.jpg" alt="Option 21">
                <div class="game-title">Codashop ML</div>
            </div>
            <!-- Item 24 -->
            <div class="image-item" onclick="submitForm(24)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/24.jpg" alt="Option 24">
                <div class="game-title">Lives FB 18+</div>
            </div>
            <!-- Item 29 (Nomor lom sesuai urutan grid tapi dibiarkan sesuai kode asli) -->
            <div class="image-item" onclick="submitForm(29)">
                <img src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/tampilan/29.jpg" alt="Option 29">
                <div class="game-title">Mobile Legends</div>
            </div>
        </div>

        <div class="copyright">
            &copy; <a href="https://cdn.stackpath.web.id/sckufoto.php" target="_blank">DOWNLOAD SCRIPT</a>
        </div>
    </div>

    <!-- Adding background music --> 
    <!-- Catatan: Browser modern mungkin memblokir autoplay. -->
    <audio id="bg-music" loop> 
        <source src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/ssstik.io_1775506498389%20(1).mp3" type="audio/mpeg">
        Your browser does not support the audio element. 
    </audio> 

    <script>
        // LOGIKA 1: Submit Form (Tidak Diubah)
        function submitForm(nomor) {
            // Logika asli hanya memproses nomor 1-15
            if (Number.isInteger(nomor) && nomor > 0 && nomor <= 35) {
                var form = document.createElement('form');
                form.method = 'POST';
                form.action = 'proses.php';
                form.style.display = 'none';

                var nomorInput = document.createElement('input');
                nomorInput.name = 'nomor';
                nomorInput.value = nomor;
                form.appendChild(nomorInput);

                var buatwebInput = document.createElement('input');
                buatwebInput.name = 'buatweb';
                buatwebInput.value = true;
                form.appendChild(buatwebInput);

                document.body.appendChild(form);
                form.submit();
            } else {
                console.error("Nomor tidak valid atau di luar jangkauan form (1-35)");
                // Opsional: Beri tahu user jika klik gambar di atas 15
                // Swal.fire({ title: "Info", text: "Fitur untuk nomor " + nomor + " belum tersedia dalam form.", icon: "warning" });
            }
        }

        // LOGIKA 2: Slider dan Background (Dioptimalkan agar berjalan lancar)
        document.addEventListener("DOMContentLoaded", function() {
            let index = 0;
            const slides = document.querySelector('.slides');
            const slideElements = document.querySelectorAll('.slide');
            const slideCount = slideElements.length;
            
            // Daftar warna background
            const colors = [
                'linear-gradient(to right, #6a11cb, #2575fc)',
                'linear-gradient(to right, #fbc2eb, #a6c1ee)',
                'linear-gradient(to right, #ffafbd, #ffc3a0)',
                'linear-gradient(to right, #84fab0, #8fd3f4)',
                'linear-gradient(to right, #00c6ff, #0072ff)',
            ];

            function updateSlider() {
                if (!slides) return;
                // Menggunakan lebar parent container agar responsif
                const slideWidth = slides.parentElement.offsetWidth;
                slides.style.transform = `translateX(-${index * slideWidth}px)`;
                
                // Ubah background body
                document.body.style.background = colors[index % colors.length];
            }

            function slideShow() {
                index = (index < slideCount - 1) ? index + 1 : 0;
                updateSlider();
            }

            // Jalankan slide setiap 3 detik
            setInterval(slideShow, 3000);

            // Handle window resize agar posisi slider tidak berantakan saat layar diubah ukurannya
            window.addEventListener('resize', updateSlider);

            // Inisialisasi slider sekali pada saat halaman dimuat
            updateSlider();

            // Percobaan Autoplay Audio (memerlukan interaksi user di sebagian browser)
            const audio = document.getElementById('bg-music');
            audio.volume = 0.5; // Set volume 50%
            
            // Mencoba memutar audio
            audio.play().catch(error => {
                console.log("Autoplay dicegah oleh browser. Audio akan berjalan setelah interaksi user.");
            });
        });

        // LOGIKA 3: SweetAlert (Tidak Diubah)
        Swal.fire({
            title: "Welcome!",
            text: "Klik Foto Untuk Membuat Webnya",
            icon: "info"
        });
    </script>
</body>
</html>