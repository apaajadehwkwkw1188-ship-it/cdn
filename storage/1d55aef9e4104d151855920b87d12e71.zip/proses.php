<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nomor = $_POST["nomor"];
    
        if (isset($_POST["buatweb"])) {
        $newfol = uniqid();
        $folderPath = "xx/$newfol";

        mkdir($folderPath);

        $zipFilePath = "scwebvip/$nomor.zip";
        $newZipFilePath = "$folderPath/$nomor.zip";
        copy($zipFilePath, $newZipFilePath);

        $zip = new ZipArchive;
        if ($zip->open($newZipFilePath) === TRUE) {
            $zip->extractTo($folderPath);
            $zip->close();
        }

        unlink($newZipFilePath);

        // Arahkan ke selesai.php setelah proses selesai
        header("Location: done.php?folder=$newfol");
        exit();
    }
}
?>
