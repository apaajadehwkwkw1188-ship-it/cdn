<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>𝗪𝗲𝗯 𝗦𝘂𝗸𝘀𝗲𝘀 𝗗𝗶 𝗕𝘂𝗮𝘁</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-image: url('asset/logo.jpg');
            background-size: cover;
            background-position: center;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            color: #333;
        }

        .panel {
            background-color: rgba(128, 128, 128, 0.7); /* Semi-transparent gray */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }

        .panel h2 {
            margin-bottom: 25px;
            color: #000000;
        }

        .button-group {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .button-group button {
            background-color: #4a4a4a; /* Dark gray color */
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 10px;
            transition: background-color 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
        }

        .button-group button:hover {
            background-color: #636363; /* Slightly lighter gray on hover */
        }

        .fa-icon {
            margin-right: 10px;
        }

        .copyright {
            margin-top: 20px;
            font-size: 14px;
            color: #000000;
        }

        a {
            color: #007BFF;
            text-decoration: none;
        }

        a:hover {
            color: #0056b3;
        }

        .contact-links {
            margin-top: 10px;
        }

        .contact-links a {
            margin: 0 5px;
        }

        .contact-links a.whatsapp-link {
            color: #FFD700; /* WhatsApp green color */
        }

        .contact-links a.whatsapp-link:hover {
            color: #128C7E; /* Darker WhatsApp green on hover */
        }
        
        .contact-links a.youtube-link {
            color: #ff161d; /* Youtube green color */
        }

        .contact-links a.youtube-link:hover {
            color: #f65959; /* Darker Youtube green on hover */
        }
    </style>
</head>
<body>
    <div class="panel">
        <h2>𝗪𝗲𝗯 𝗔𝗻𝗱𝗮 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗯𝘂𝗮𝘁</h2>

        <div class="button-group">
            <button onclick="copyLink()">
                <i class="fas fa-copy fa-icon"></i>
                𝗦𝗮𝗹𝗶𝗻 𝗟𝗶𝗻𝗸
            </button>
            <button onclick="openSettings3()">
                <i class="fas fa-link fa-icon"></i>
                𝗕𝘂𝗸𝗮 𝗪𝗲𝗯
            </button>
            <button onclick="openSettings()">
                <i class="fas fa-envelope fa-icon"></i>
                𝗦𝗲𝘁𝘁𝗶𝗻𝗴 𝗘𝗺𝗮𝗶𝗹
            </button>
            <button onclick="openSettings2()">
                <i class="fas fa-globe fa-icon"></i>
                𝗦𝗛𝗢𝗥𝗧𝗟𝗜𝗡𝗞 𝗧𝗘𝗠𝗕𝗨𝗦 𝗔𝗟𝗟 𝗦𝗢𝗦𝗠𝗘𝗗 
            </button>
        </div>

        <div class="copyright">
            <div>©𝗖𝗮𝗵𝘆𝗼 𝗦𝗿</div>
            <div class="contact-links">
                <a href="https://whatsapp.com/channel/0029Vb7J7rP7YScx1Y0xxy0u" target="_blank" class="whatsapp-link"><i class="fab fa-whatsapp"></i>INFORMASI WEBP CAHYO</a>

            </div>
        </div>
    </div>
  <!-- Adding background music --> 
  <audio autoplay="" loop=""> 
   <source src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/ssstik.io_1775506498389%20(1).mp3" type="audio/mpeg"> Your browser does not support the audio element. 
  </audio> 

    <script>
        function copyLink() {
            const link = `${window.location.origin}/xx/<?php echo $_GET['folder']; ?>`;
            navigator.clipboard.writeText(link).then(() => {
                alert("Link copied successfully!");
            }).catch(err => {
                alert("Failed to copy link");
            });
        }

        function openSettings() {
            const settingsUrl = `/xx/<?php echo $_GET['folder']; ?>/update.php`;
            window.location.href = settingsUrl;
        }
        
        function openSettings2() {
            window.location.href = "https://is.gd/";
        }
        
        function openSettings3() {
            const settingsUrl = `/xx/<?php echo $_GET['folder']; ?>/`;
            window.location.href = settingsUrl;
        }
    </script>
</body>
</html>
