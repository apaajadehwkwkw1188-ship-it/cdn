#!/system/bin/sh
MODDIR=${0%/*}
(
 umask 077
 mkdir -p /data/adb/voiceshift-guard
 chmod 700 /data/adb/voiceshift-guard
 while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
 # Runtime microphone permission applies only to our explicit audio companion.
 pm grant id.rizal.voiceshift.audio android.permission.RECORD_AUDIO 2>> /data/adb/voiceshift-guard/guardian.log
 pm grant id.rizal.voiceshift.audio android.permission.POST_NOTIFICATIONS 2>> /data/adb/voiceshift-guard/guardian.log
 while [ ! -f "$MODDIR/disable" ] && [ ! -f "$MODDIR/remove" ]; do
  APK=$(pm path id.rizal.voiceshift | sed -n 's/^package://p' | head -n 1)
  if [ -f "$APK" ]; then
   CLASSPATH="$APK" /system/bin/app_process /system/bin id.rizal.voiceshift.root.RootKeeper >> /data/adb/voiceshift-guard/guardian.log 2>&1
   # Bound log growth; model data and microphone audio are never logged here.
   tail -c 32768 /data/adb/voiceshift-guard/guardian.log > /data/adb/voiceshift-guard/log.tmp
   mv /data/adb/voiceshift-guard/log.tmp /data/adb/voiceshift-guard/guardian.log
  fi
  sleep 5
 done
) </dev/null >/dev/null 2>&1 &
