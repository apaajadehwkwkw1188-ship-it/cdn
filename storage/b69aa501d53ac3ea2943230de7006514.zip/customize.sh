ui_print "VoiceShift Audio Service"
APK=$(pm path id.rizal.voiceshift | sed -n 's/^package://p' | head -n 1)
[ -f "$APK" ] || abort "Pasang APK VoiceShift 0.9.6 lebih dulu."
VERSION=$(dumpsys package id.rizal.voiceshift | sed -n 's/.*versionCode=\([0-9]*\).*/\1/p' | head -n 1)
case "$VERSION" in ''|*[!0-9]*) abort "Versi APK belum terbaca." ;; esac
[ "$VERSION" -ge 196 ] || abort "Perbarui APK ke VoiceShift 0.9.6 lebih dulu."
for marker in /data/adb/modules/voiceshift_resume/enabled-u*; do
 [ -f "$marker" ] && rm -f "$marker"
done
# Only the small companion is systemless; never copy/systemize the main APK.
[ -f "$MODPATH/system/priv-app/VoiceShiftAudio/VoiceShiftAudio.apk" ] || abort "Pendamping audio tidak ada. Unduh ulang modul."
rm -f "$MODPATH/skip_mount"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
ui_print "Izin audio dipasang lewat overlay sistem. Reboot diperlukan."
ui_print "KernelSU harus memiliki dukungan mount modul/metamodule."
ui_print "Setelah reboot, buka VoiceShift dan aktifkan efek."
ui_print "Tombol Action modul menghentikan mesin audio."
