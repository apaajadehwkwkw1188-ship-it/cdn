#!/system/bin/sh
umask 077
touch /data/adb/voiceshift-guard/stop
# Supervisor notices STOP before its next restart attempt.
