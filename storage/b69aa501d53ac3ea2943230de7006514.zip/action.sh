#!/system/bin/sh
umask 077
mkdir -p /data/adb/voiceshift-guard
for marker in /data/adb/modules/voiceshift_resume/enabled-u*; do
 [ -f "$marker" ] && rm -f "$marker"
done
touch /data/adb/voiceshift-guard/stop
echo "Permintaan menghentikan VoiceShift dikirim."
