export default async (req) => {
  const url = new URL(req.url);
  const targetPath = url.searchParams.get("path");
  if (!targetPath || !targetPath.startsWith("/")) {
    return new Response(JSON.stringify({error:"Invalid path"}),{status:400,headers:{"content-type":"application/json","cache-control":"no-store"}});
  }
  const target = new URL(targetPath, "https://api.ikyyxd.my.id");
  try {
    const upstream = await fetch(target.toString(), {
      method: "GET",
      headers: {
        "Accept": req.headers.get("accept") || "*/*",
        "User-Agent": "Netlify-API-Tools/1.0"
      }
    });
    const headers = new Headers();
    const ct = upstream.headers.get("content-type");
    if (ct) headers.set("content-type", ct);
    headers.set("cache-control","no-store");
    headers.set("access-control-allow-origin","*");
    return new Response(upstream.body,{status:upstream.status,headers});
  } catch (e) {
    return new Response(JSON.stringify({error:"Upstream request failed",message:String(e?.message||e)}),{
      status:502,headers:{"content-type":"application/json","cache-control":"no-store"}
    });
  }
};
