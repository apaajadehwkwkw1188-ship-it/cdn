const configs={
skiplink:{title:"Skiplink SFL",icon:"🔗",desc:"Masukkan URL yang ingin diproses.",fields:[["url","URL","https://example.com"]],path:v=>`/tools/skiplink/sfl?url=${encodeURIComponent(v.url)}`},
fakecall:{title:"Fake Call",icon:"📞",desc:"Isi nama, URL gambar, dan durasi.",fields:[["name","Nama","Aji"],["image","URL Gambar","https://example.com/image.jpg"],["durasi","Durasi","1000"]],path:v=>`/canvas/fakecall?name=${encodeURIComponent(v.name)}&url=${encodeURIComponent(v.image)}&image=${encodeURIComponent(v.image)}&durasi=${encodeURIComponent(v.durasi)}`},
stalk:{title:"Stalk EPEPv2",icon:"👤",desc:"API key dan UID wajib diisi. Key hanya dipakai untuk request.",fields:[["apikey","API Key","Masukkan API Key",true],["uid","UID","Masukkan UID"]],path:v=>`/stalk/epepv2?apikey=${encodeURIComponent(v.apikey)}&uid=${encodeURIComponent(v.uid)}`},
status:{title:"API Status",icon:"📡",desc:"Cek response status dari API.",fields:[],path:()=>"/status/api"},
bluearchive:{title:"Random Blue Archive",icon:"🎴",desc:"Masukkan API key. Response bisa berupa gambar atau data teks/JSON.",fields:[["apikey","API Key","Masukkan API Key",true]],path:v=>`/random/blue-archive?apikey=${encodeURIComponent(v.apikey)}`},
react:{title:"WhatsApp React",icon:"♥",desc:"Kirim satu request reaction menggunakan endpoint yang diizinkan. Tidak melakukan bypass CAPTCHA, anti-bot, atau cooldown.",fields:[["url","URL WhatsApp","https://whatsapp.com/channel/..."],["emojis","Emoji","😂"],["turnstile","Turnstile Token (jika diwajibkan API)","Tempel token yang sah dari layanan",true]],path:v=>null},
gdrive:{title:"GDrive Downloader",icon:"↘",desc:"Masukkan URL file Google Drive untuk diproses oleh API.",fields:[["url","URL Google Drive","https://drive.google.com/file/d/.../view"]],path:v=>`/download/gdrive?url=${encodeURIComponent(v.url)}`},
ngl:{title:"NGL Message",icon:"✉",desc:"Kirim satu pesan ke target. Tool ini tidak melakukan pengiriman berulang/spam.",fields:[["target","Target","username atau target NGL"],["message","Message","Tulis pesan…"]],path:v=>`/tools/nglspam?target=${encodeURIComponent(v.target)}&message=${encodeURIComponent(v.message)}`}
};
const API="/.netlify/functions/api";
const menu=document.querySelector("#menu"),toolView=document.querySelector("#toolView"),form=document.querySelector("#toolForm"),result=document.querySelector("#result");
const title=document.querySelector("#toolTitle"),icon=document.querySelector("#toolIcon"),desc=document.querySelector("#toolDescription"),error=document.querySelector("#error"),loading=document.querySelector("#loading"),runBtn=document.querySelector("#runBtn");
let current=null,lastCopy="";
document.querySelectorAll(".tool-card").forEach(c=>c.onclick=()=>openTool(c.dataset.tool));
document.querySelector("#backBtn").onclick=()=>{toolView.classList.remove("active");menu.classList.add("active");current=null};
document.querySelector("#clearBtn").onclick=()=>{form.reset();renderEmpty();error.classList.add("hidden")};
document.querySelector("#copyBtn").onclick=async()=>{if(!lastCopy)return;try{await navigator.clipboard.writeText(lastCopy);const b=document.querySelector("#copyBtn");b.textContent="Copied!";setTimeout(()=>b.textContent="Copy",1000)}catch{}};
function openTool(key){current=configs[key];title.textContent=current.title;icon.textContent=current.icon;desc.textContent=current.desc;form.innerHTML=current.fields.map(([id,label,placeholder,secret])=>`<div class="field"><label for="${id}">${label}</label><input id="${id}" name="${id}" placeholder="${placeholder||""}" ${secret?"type=password":""} required></div>`).join("");renderEmpty();error.classList.add("hidden");menu.classList.remove("active");toolView.classList.add("active")}
function renderEmpty(){lastCopy="";result.innerHTML=`<div class="empty"><div class="empty-icon">✦</div><b>Belum ada response</b><span>Jalankan tool untuk melihat hasilnya di sini.</span></div>`}function renderText(text){lastCopy=text;result.innerHTML="";const pre=document.createElement("pre");pre.textContent=text;result.appendChild(pre)}
function findImage(obj,seen=new Set()){if(!obj||typeof obj!=="object")return null;if(seen.has(obj))return null;seen.add(obj);for(const [k,v] of Object.entries(obj)){if(typeof v==="string"&&/^https?:\/\/[^\s]+/i.test(v)&&/\.(png|jpe?g|gif|webp|bmp|svg)(\?|$)/i.test(v))return v;if(v&&typeof v==="object"){const x=findImage(v,seen);if(x)return x}}return null}
function renderData(data){const image=findImage(data);lastCopy=typeof data==="string"?data:JSON.stringify(data,null,2);result.innerHTML="";if(image){const meta=document.createElement("div");meta.className="meta";meta.textContent="Response gambar";result.appendChild(meta);const img=document.createElement("img");img.src=image;img.alt="API response";img.referrerPolicy="no-referrer";img.onerror=()=>{img.remove();renderText(lastCopy)};result.appendChild(img);const a=document.createElement("a");a.href=image;a.target="_blank";a.rel="noopener";a.textContent=image;result.appendChild(a);if(typeof data!=="string"){const pre=document.createElement("pre");pre.className="json-image";pre.textContent=lastCopy;result.appendChild(pre)}}else renderText(lastCopy)}
form.onsubmit=async e=>{e.preventDefault();if(!current)return;const values=Object.fromEntries(new FormData(form).entries());loading.classList.remove("hidden");error.classList.add("hidden");runBtn.disabled=true;renderText("Memproses...");
try{const path=current.path(values);
let requestUrl;
if(current===configs.react){
  requestUrl=`/.netlify/functions/react`;
  const reactRes=await fetch(requestUrl,{method:"POST",headers:{"Content-Type":"application/json","Accept":"application/json,text/plain"},body:JSON.stringify({url:values.url,emojis:values.emojis,turnstileToken:values.turnstile||""})});
  const type=reactRes.headers.get("content-type")||"";
  const text=await reactRes.text();
  if(!reactRes.ok) throw new Error(`HTTP ${reactRes.status}: ${text||"Request gagal"}`);
  let data; try{data=JSON.parse(text)}catch{data=text}
  renderData(data);
  return;
}
const res=await fetch(`${API}?path=${encodeURIComponent(path)}`,{headers:{"Accept":"application/json,text/plain,image/*,*/*"}});const type=res.headers.get("content-type")||"";if(!res.ok){const t=await res.text();throw new Error(`HTTP ${res.status}: ${t||"Request gagal"}`)}if(type.startsWith("image/")){const blob=await res.blob();const url=URL.createObjectURL(blob);lastCopy=url;result.innerHTML=`<div class="meta">Response gambar dari API</div>`;const img=document.createElement("img");img.src=url;img.alt="API image";result.appendChild(img);const a=document.createElement("a");a.href=url;a.download="api-response";a.textContent="Buka gambar";a.target="_blank";result.appendChild(a)}else{const text=await res.text();let data;try{data=JSON.parse(text)}catch{data=text}renderData(data)}}catch(err){error.textContent=err.message;error.classList.remove("hidden");renderText("Request gagal.")}finally{loading.classList.add("hidden");runBtn.disabled=false}};
