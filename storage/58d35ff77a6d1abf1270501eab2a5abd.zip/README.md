# API Tools — Netlify (Fixed)

Versi ini mempertahankan endpoint yang ada dan memperbaiki frontend agar:
- Fake Call memiliki input URL gambar.
- Stalk EPEPv2 memiliki input API key.
- Random Blue Archive memiliki input API key.
- Response API otomatis dikenali sebagai gambar, teks, atau JSON.
- Response `image/*` langsung ditampilkan sebagai gambar.
- URL gambar yang berada di dalam JSON juga dicari dan ditampilkan.
- Request frontend lewat Netlify Function agar tidak langsung bergantung pada CORS browser.
- API key tidak disimpan di localStorage/cookie.

## Deploy
Upload ZIP/folder ini ke Netlify. Netlify akan otomatis memakai `netlify/functions/api.mjs` sebagai proxy.

## Catatan
Parameter endpoint dipertahankan berdasarkan konfigurasi awal:
- `/tools/skiplink/sfl?url=...`
- `/canvas/fakecall?name=...&url=...&image=...&durasi=...`
- `/stalk/epepv2?apikey=...&uid=...`
- `/status/api`
- `/random/blue-archive?apikey=...`

Jika API upstream mengharuskan nama parameter gambar yang berbeda dari `url`/`image`, bagian `fakecall.path` di `script.js` adalah satu-satunya bagian yang perlu disesuaikan.
