const express = require("express");
const multer = require("multer");
const axios = require("axios");
const crypto = require("crypto");
const mime = require("mime-types");
const path = require("path");
const fs = require("fs");
const FormData = require("form-data");
const app = express();
const fileMap = {};

// =======================
// MULTER SETUP (memory storage)
// =======================
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 500 * 1024 * 1024 } // 50MB max
});
const TMP_DIR = path.join(__dirname, "tmp");

// bikin folder kalau belum ada
if (!fs.existsSync(TMP_DIR)) {
  fs.mkdirSync(TMP_DIR);
}
// =======================
// GITHUB CONFIG
// =======================
const GITHUB_TOKEN = "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";
const GITHUB_OWNER = "IkyyExecutive-v2";
const GITHUB_REPO = "IkyySukaNgewe";
const GITHUB_BRANCH = "main";

// =======================
// GENERATE RANDOM ID
// =======================
const UGUU_API = "https://uguu.se/upload.php";
const MAP_FILE_UGUU = path.join(__dirname, "uguu-map.json");

let uguuMap = fs.existsSync(MAP_FILE_UGUU)
  ? JSON.parse(fs.readFileSync(MAP_FILE_UGUU))
  : {};

function saveUguuMap() {
  fs.writeFileSync(MAP_FILE_UGUU, JSON.stringify(uguuMap, null, 2));
}
function generateId() {
  return crypto.randomBytes(32).toString("hex");
}
function randomName(ext) {
  return crypto.randomBytes(16).toString("hex") + "." + ext;
}

function randomToken() {
  return crypto.randomBytes(6).toString("hex");
}

// =======================
// ROOT HACKER-STYLE HTML
// =======================
app.get("/", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Access Denied</title>
      <style>
        body {
          background: #0f0f0f;
          color: #00ff00;
          font-family: monospace;
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh;
          flex-direction: column;
        }
        h1 { font-size: 3rem; margin-bottom: 20px; }
        p { font-size: 1.2rem; margin-bottom: 20px; }
        .terminal {
          background: #000;
          padding: 20px;
          border-radius: 10px;
          box-shadow: 0 0 20px #00ff00aa;
          font-size: 0.9rem;
          width: 90%;
          max-width: 600px;
          overflow: auto;
          white-space: pre-wrap;
        }
        .blinking { animation: blink 1s step-start infinite; }
        @keyframes blink { 50% { opacity: 0 } }
      </style>
    </head>
    <body>
      <h1>⚠️ ACCESS DENIED</h1>
      <p>Unauthorized access detected...</p>
      <div class="terminal" id="terminal"></div>

      <script>
        const terminal = document.getElementById("terminal");
        const lines = [
          "root@cdn:~$ ls",
          "access.log  error.log  storage/",
          "root@cdn:~$ echo 'Intruder detected!'",
          "ALERT! Security breach attempt",
          "root@cdn:~$ whoami",
          "intruder",
          "root@cdn:~$ exit",
          "Connection terminated"
        ];
        let i = 0;
        function typeLine() {
          if(i >= lines.length) return;
          let line = lines[i];
          let j = 0;
          function typeChar() {
            if(j < line.length){
              terminal.innerHTML += line[j];
              j++;
              setTimeout(typeChar, 40);
            } else {
              terminal.innerHTML += "<br>";
              i++;
              setTimeout(typeLine, 300);
            }
          }
          typeChar();
        }
        typeLine();
      </script>
    </body>
    </html>
  `);
});
// =======================
// UPLOAD ENDPOINT
// =======================
app.post("/upload/v1", upload.single("file"), async (req, res) => {
  try {
    let buffer
    let filename

    // =========================
    // 📥 HANDLE FILE / URL
    // =========================
    if (req.file) {
      buffer = req.file.buffer
      filename = req.file.originalname

    } else if (req.body.url) {
      const url = req.body.url

      const response = await axios.get(url, {
        responseType: "arraybuffer",
        timeout: 15000
      })

      buffer = response.data

      // 🔥 ambil nama dari URL
      const urlPath = new URL(url).pathname
      filename = urlPath.split("/").pop() || "file"

    } else {
      return res.status(400).json({
        error: "No file or url"
      })
    }

    // =========================
    // 📁 EXTENSION FIX
    // =========================
    let ext = filename.split(".").pop().toLowerCase()

    if (!ext || ext.length > 5) ext = "bin"

    const fakeName = randomName(ext)
    const token = randomToken()
    const filePath = path.join(TMP_DIR, fakeName)

    // =========================
    // 💾 SAVE FILE
    // =========================
    fs.writeFileSync(filePath, buffer)

    fileMap[fakeName] = {
      path: filePath,
      createdAt: Date.now()
    }

    res.json({
      success: true,
      url: `https://cdn.ikyyzyyrestapi.my.id/upload/v1/${fakeName}/${token}?preview=true`,
      expired_in: "2 hours"
    })

  } catch (err) {
    console.log("UPLOAD ERROR:", err.response?.data || err.message)

    res.status(500).json({
      success: false,
      error: "Upload gagal"
    })
  }
})

app.post("/uploads", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file" });

    // ambil ekstensi asli
    const originalName = req.file.originalname;
    const ext = originalName.split(".").pop();
    const id = generateId();
    const path = `storage/${id}.${ext}`;

    // ubah buffer ke base64
    const content = req.file.buffer.toString("base64");

    // upload ke github
    await axios.put(
      `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${path}`,
      {
        message: `Upload ${id}`,
        content,
        branch: GITHUB_BRANCH
      },
      {
        headers: {
          Authorization: `Bearer ${GITHUB_TOKEN}`
        }
      }
    );

    res.json({
      success: true,
      url: `https://cdn.ikyyzyyrestapi.my.id/storage/${id}.${ext}?preview=true`
    });

  } catch (err) {
    console.log(err.response?.data || err.message);
    res.status(500).json({ error: "Upload gagal" });
  }
});
app.post("/s/upload", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file" });

    const originalName = req.file.originalname;
    const ext = originalName.split(".").pop();
    const id = generateId();

    const path = `storage/${id}.${ext}`;
    const content = req.file.buffer.toString("base64");

    await axios.put(
      `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${path}`,
      {
        message: `Upload ${id}`,
        content,
        branch: GITHUB_BRANCH
      },
      {
        headers: {
          Authorization: `Bearer ${GITHUB_TOKEN}`
        }
      }
    );

    res.json({
      success: true,
      url: `https://cdn.ikyyzyyrestapi.my.id/s/wp-content/${id}.${ext}?preview=true`
    });

  } catch (err) {
    console.log(err.response?.data || err.message);
    res.status(500).json({ error: "Upload gagal" });
  }
});
app.post("/api/upload.php", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file" });

    const ext = req.file.originalname.split(".").pop();
    const fakeName = randomName(ext);
    const token = randomToken();

    // upload ke uguu
    const form = new FormData();
    form.append("files[]", req.file.buffer, req.file.originalname);

    const uguuRes = await axios.post(UGUU_API, form, {
      headers: form.getHeaders()
    });

    const realUrl = uguuRes.data.files[0].url;

    // simpan mapping
    uguuMap[fakeName] = {
      url: realUrl
    };
    saveUguuMap();

    res.json({
      success: true,
      url: `https://cdn.ikyyzyyrestapi.my.id/api/upload/${fakeName}/${token}?preview=true`
    });

  } catch (err) {
    console.log("UGUU ERROR:", err.response?.data || err.message);

    res.status(500).json({
      error: "Upload gagal"
    });
  }
});

app.post("/api/audio/up.php", upload.single("file"), async (req, res) => {
  try {
    let buffer;
    let filename;

    // =========================
    // HANDLE FILE / URL
    // =========================
    if (req.file) {
      buffer = req.file.buffer;
      filename = req.file.originalname;
    } else if (req.body.url) {
      const response = await axios.get(req.body.url, {
        responseType: "arraybuffer",
        timeout: 15000
      });

      buffer = response.data;
      filename = "audio_from_url.mp3"; // fallback
    } else {
      return res.status(400).json({ error: "No file or url" });
    }

    // =========================
    // VALIDASI AUDIO ONLY
    // =========================
    const ext = filename.split(".").pop().toLowerCase();
    const allowed = ["mp3", "wav", "ogg", "m4a", "aac", "flac"];

    if (!allowed.includes(ext)) {
      return res.status(400).json({
        error: "Only audio allowed"
      });
    }

    const fakeName = randomName(ext);
    const token = randomToken();

    // =========================
    // UPLOAD KE UGUU
    // =========================
    const form = new FormData();
    form.append("files[]", buffer, filename);

    const uguuRes = await axios.post(UGUU_API, form, {
      headers: form.getHeaders()
    });

    const realUrl = uguuRes.data.files[0].url;

    // simpan mapping
    uguuMap[fakeName] = {
      url: realUrl
    };
    saveUguuMap();

    res.json({
      success: true,
      type: "audio",
      url: `https://cdn.ikyyzyyrestapi.my.id/api/upload/${fakeName}/${token}?preview=true`
    });

  } catch (err) {
    console.log("AUDIO UGUU ERROR:", err.response?.data || err.message);

    res.status(500).json({
      error: "Upload audio gagal"
    });
  }
});

// =======================
// STORAGE PROXY (preview / download)
// =======================
app.get("/storage/:filename", async (req, res) => {
  try {
    const filename = req.params.filename;

    const rawUrl = `https://raw.githubusercontent.com/${GITHUB_OWNER}/${GITHUB_REPO}/${GITHUB_BRANCH}/storage/${filename}`;

    const response = await axios.get(rawUrl, {
      responseType: "stream"
    });

    res.setHeader(
      "Content-Type",
      mime.lookup(filename) || "application/octet-stream"
    );

    response.data.pipe(res);

  } catch (err) {
    console.log(err.message);
    res.status(404).send("File tidak ditemukan");
  }
});
app.get("/s/wp-content/:filename", async (req, res) => {
  try {
    const filename = req.params.filename;

    const rawUrl = `https://raw.githubusercontent.com/${GITHUB_OWNER}/${GITHUB_REPO}/${GITHUB_BRANCH}/storage/${filename}`;

    const response = await axios.get(rawUrl, {
      responseType: "stream"
    });

    res.setHeader(
      "Content-Type",
      mime.lookup(filename) || "application/octet-stream"
    );

    response.data.pipe(res);

  } catch (err) {
    console.log(err.message);
    res.status(404).send("File tidak ditemukan");
  }
});
app.get("/api/upload/:file/:token", async (req, res) => {
  try {
    const file = req.params.file;

    if (!uguuMap[file]) {
      return res.status(404).send("File tidak ditemukan");
    }

    const realUrl = uguuMap[file].url;

    const response = await axios.get(realUrl, {
      responseType: "stream"
    });

    // preview mode
    if (req.query.preview === "true") {
      res.setHeader(
        "Content-Type",
        response.headers["content-type"] || "application/octet-stream"
      );
    } else {
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${file}"`
      );
    }

    response.data.pipe(res);

  } catch (err) {
    console.log(err.message);
    res.status(500).send("Error");
  }
});
app.get("/upload/v1/:file/:token", async (req, res) => {
  try {
    const { file } = req.params;

    const data = fileMap[file];
    if (!data) {
      return res.status(404).send("File tidak ditemukan");
    }

    const filePath = data.path;

    if (!fs.existsSync(filePath)) {
      return res.status(404).send("File sudah dihapus");
    }

    const ext = file.split(".").pop();

    // 🔥 HANDLE MIME
    let contentType = "application/octet-stream";

    if (ext === "html") contentType = "text/html";
    else if (ext === "js") contentType = "application/javascript";
    else if (ext === "css") contentType = "text/css";
    else if (ext === "json") contentType = "application/json";
    else if (ext === "png") contentType = "image/png";
    else if (ext === "jpg" || ext === "jpeg") contentType = "image/jpeg";
    else if (ext === "mp4") contentType = "video/mp4";

    if (req.query.preview === "true") {
      res.setHeader("Content-Type", contentType);
    } else {
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${file}"`
      );
    }

    fs.createReadStream(filePath).pipe(res);

  } catch (err) {
    console.log(err.message);
    res.status(500).send("Error");
  }
});

setInterval(() => {
  const now = Date.now();

  for (const file in fileMap) {
    const data = fileMap[file];

    if (now - data.createdAt > 2 * 60 * 60 * 1000) { // 2 jam
      try {
        fs.unlinkSync(data.path);
        delete fileMap[file];
        console.log("🗑️ Deleted:", file);
      } catch (e) {
        console.log("DELETE ERROR:", e.message);
      }
    }
  }
}, 60 * 1000); // cek tiap 1 menit
// =======================
// START SERVER
// =======================
const PORT = process.env.PORT || 4588;
app.listen(PORT, () => {
  console.log(`CDN Proxy running on port ${PORT}`);
});